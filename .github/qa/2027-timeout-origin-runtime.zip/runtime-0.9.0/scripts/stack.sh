#!/bin/bash
# stack.sh <config.sh>
# Run /review-council:rev across a STACK of repos, unattended: per-repo legs (PASSES passes), a cross-repo seam
# review, a completeness critic, then one push per repo with the review commits kept one per fix. Legs are
# headless `claude -p "/review-council:rev …"` runs marked REV_STACK_LEG=1, so they never push themselves.
#
# The config defines legs() - run_leg calls in DEPENDENCY ORDER - and may set SEAM_REPO / CRITIC_REPO / premises.
# See stack.example.sh next to this script.
#
# ONE stall detector, here, and nowhere else. A leg is killed only when (a) its run.log AND session dir have been
# quiet for STALL_SECS and (b) its CPU time did not move across CPU_SAMPLE_SECS. stream-json makes run.log a real
# liveness signal (one event per assistant message and tool call); the CPU veto is what prevents false kills
# during a long silent build. A stall is never counted as an infrastructure failure.
#
# CPU and kill both see the whole leg TREE, never just the direct child: the seat CLIs (codex/claude) run as
# grandchildren under claude and are where the CPU actually goes, so measuring the child alone reads "frozen"
# while a seat is mid-run (a false kill) and killing the child alone orphans the seats (leaked usage quota).
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
STACK_HOST=${REVIEW_COUNCIL_HOST:-claude}
case "$STACK_HOST" in
  claude|codex|cursor) ;;
  *) echo "stack: unsupported host '$STACK_HOST'" >&2; exit 1;;
esac
readonly STACK_HOST
# shellcheck source=lib/compat.sh
# Guarded: without rc_mtime/rc_newest_mtime the stall detector loses the file-activity half of its
# two-condition kill rule and silently kills healthy legs, so a missing compat.sh is fatal, not a warning.
. "$HERE/lib/compat.sh" || { echo "stack: cannot load $HERE/lib/compat.sh" >&2; exit 1; }   # rc_mtime / rc_newest_mtime - BSD and GNU stat differ
# PATH is APPENDED, never prepended: an operator's (or a test's) own claude/codex must keep winning.
export PATH="$PATH:$HOME/.nvm/versions/node/v22.22.0/bin:$HOME/.local/bin"
[ -z "${REV_ACTIVE:-}${REV_STACK_LEG:-}" ] || { echo "stack: refusing to nest (REV_ACTIVE or REV_STACK_LEG is set)" >&2; exit 1; }
CONFIG=${1:?usage: stack.sh <config.sh>   (template: stack.example.sh next to this script)}
[ -f "$CONFIG" ] || { echo "stack: config not found: $CONFIG" >&2; exit 1; }
CONFIG=$(cd "$(dirname "$CONFIG")" && pwd)/$(basename "$CONFIG")
ROOT=${ROOT:-/tmp/review-council-stack-$(date +%s)}
LOG=${LOG:-/tmp/review-council-stack.log}
# DETACH BY DEFAULT. A run lasts hours; anything still inside the launching tool's process tree dies with it -
# a Claude Code background Bash command was killed by the harness after ~56 min and took the leg (its whole
# process group) down mid-round. So the orchestrator re-executes itself in a NEW SESSION with HUP ignored
# (nohup; setsid via python because macOS ships none), prints where it went, and returns. Tail $LOG to follow.
# REV_STACK_FOREGROUND=1 keeps it attached (tests, or a terminal you intend to keep open).
if [ -z "${REV_STACK_FOREGROUND:-}" ] && [ -z "${REV_STACK_DETACHED:-}" ]; then
  mkdir -p "$ROOT"; OUTF="$ROOT/orchestrator.out"
  export REV_STACK_DETACHED=1 ROOT LOG
  nohup python3 -c 'import os,sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])' "$0" "$@" > "$OUTF" 2>&1 < /dev/null &
  echo "stack: detached (pid $!), session root $ROOT, log $LOG, orchestrator output $OUTF"
  exit 0
fi
PASSES=${PASSES:-2}
STALL_SECS=${STALL_SECS:-1800}
CPU_SAMPLE_SECS=${CPU_SAMPLE_SECS:-45}
POLL=${POLL:-60}
STATUS_EVERY=${STATUS_EVERY:-600}
MAX_ATTEMPTS=${MAX_ATTEMPTS:-4}
MAX_INFRA_RETRIES=${MAX_INFRA_RETRIES:-12}
FAST_FAIL_SECS=${FAST_FAIL_SECS:-90}
INFRA_SLEEP_SECS=${INFRA_SLEEP_SECS:-300}
AUTH_WAIT_TRIES=${AUTH_WAIT_TRIES:-60}
AUTH_WAIT_SECS=${AUTH_WAIT_SECS:-60}
if [ "$STACK_HOST" = codex ] || [ "$STACK_HOST" = cursor ]; then
  NO_PUSH=${NO_PUSH:-1}
else
  NO_PUSH=${NO_PUSH:-0}
fi
# Review commits stay one per fix on all hosts; NO_SQUASH=0 is a legacy opt-in that collapses them.
NO_SQUASH=${NO_SQUASH:-1}
export NO_PUSH NO_SQUASH
REV_SCRIPTS=${REV_SCRIPTS:-$HERE}   # roster.sh, rev-status.sh and rev-squash.sh live beside this script
if [ "$STACK_HOST" = cursor ] && [ "$(cd "$REV_SCRIPTS" 2>/dev/null && pwd -P)" != "$(cd "$HERE" && pwd -P)" ]; then
  echo "stack: Cursor host requires its packaged runtime at $HERE" >&2
  exit 1
fi
[ "$STACK_HOST" != cursor ] || readonly REV_SCRIPTS
SEAM_REPO=${SEAM_REPO:-}
SEAM_PREMISE=${SEAM_PREMISE:-"Review the SEAMS between the PRs in this stack, not the code again: what each PR promises the others, what each assumes of the others, and every claim that a sibling PR invalidates."}
CRITIC_REPO=${CRITIC_REPO:-}
CRITIC_PREMISE=${CRITIC_PREMISE:-"What did every previous pass MISS? Name modalities never run and claims never verified. Read every leg's findings.md under the stack session root first."}
VACUITY=${VACUITY:-"Check every assertion the diff adds or touches for VACUITY: would it still pass if the behaviour it names were deleted? Name the production change that would make each new test fail, and report any that has none."}
REPOS_SEEN=""
FAILED_LABELS=""      # every leg that ended without a completed review
FAILED_REPOS=""       # …and the repos they belong to: those are NOT squashed at the end
mkdir -p "$ROOT"
SESSION_MAP="$ROOT/repo-sessions.tsv"
[ -f "$SESSION_MAP" ] || : > "$SESSION_MAP"

say() { echo "$(date '+%m-%d %H:%M') $*" | tee -a "$LOG"; }
note_failure() {  # <label> <repo-dir> - a failed leg must not be reported as a complete run
  FAILED_LABELS="$FAILED_LABELS $1"
  case " $FAILED_REPOS " in *" $2 "*) ;; *) FAILED_REPOS="$FAILED_REPOS $2";; esac
}
stack_retry_command() {
  printf 'REVIEW_COUNCIL_HOST=%q NO_PUSH=%q NO_SQUASH=%q ROOT=%q LOG=%q REV_SCRIPTS=%q REV_STACK_FOREGROUND=1 %q %q' \
    "$STACK_HOST" "$NO_PUSH" "$NO_SQUASH" "$ROOT" "$LOG" \
    "$REV_SCRIPTS" "$HERE/stack.sh" "$CONFIG"
}
replace_tab_row() {  # <file> <key> <value> - replace one tab-separated row atomically
  local file=$1 key=$2 value=$3 temporary="$1.tmp.$$"
  if ! awk -F '\t' -v wanted="$key" '$1 != wanted' "$file" > "$temporary" \
      || ! printf '%s\t%s\n' "$key" "$value" >> "$temporary" \
      || ! mv "$temporary" "$file"; then
    rm -f "$temporary"
    return 1
  fi
}
session_for_repo() {  # <canonical-repo> - print its one authoritative completed session
  local repo=$1 rows count
  rows=$(awk -F '\t' -v wanted="$repo" '$1 == wanted { print $2 }' "$SESSION_MAP") || return 1
  count=$(printf '%s\n' "$rows" | grep -c .)
  [ "$count" -eq 1 ] || return 1
  printf '%s\n' "$rows"
}
leg_group() {  # the leg's own process-group id, and only when it leads that group (see leg_tree)
  local g; g=$(ps -o pgid= -p "$1" 2>/dev/null | tr -d ' ')
  [ -n "$g" ] && [ "$g" = "$1" ] && echo "$g"
}
leg_tree() {  # every pid in the leg's tree: its process group when it owns one, else a recursive walk of children
  local g c; g=$(leg_group "$1")
  if [ -n "$g" ]; then pgrep -g "$g" 2>/dev/null; return 0; fi
  kill -0 "$1" 2>/dev/null && echo "$1"
  for c in $(pgrep -P "$1" 2>/dev/null); do leg_tree "$c"; done
}
cpu_of() {  # summed CPU seconds over the whole leg tree - the seat CLIs burn it, not the leg's own shell
  local pids; pids=$(leg_tree "$1" | sort -un | tr '\n' ','); pids=${pids%,}
  [ -n "$pids" ] || return 0
  ps -o time= -p "$pids" 2>/dev/null |
    awk '{n=split($1,a,":"); s=0; for(i=1;i<=n;i++) s=s*60+a[i]; t+=s} END{if (NR>0) printf "%.2f", t}'
}
kill_leg() {  # TERM then KILL the whole tree; the group is resolved BEFORE the leader dies or the seats orphan
  local g pids; g=$(leg_group "$1"); pids=$(leg_tree "$1" | sort -un | tr '\n' ' ')
  if [ -n "$g" ]; then kill -TERM "-$g" 2>/dev/null; else kill -TERM $pids 2>/dev/null; fi
  sleep 3
  if [ -n "$g" ]; then kill -9 "-$g" 2>/dev/null; else kill -9 $pids 2>/dev/null; fi
}
last_activity() {  # <session-dir> → newest mtime of run.log or anything under it, 0 when nothing exists yet
  local m1 m2
  m1=$(rc_mtime "$1/run.log"); m1=${m1:-0}
  m2=$(rc_newest_mtime "$1"); m2=${m2:-0}
  [ "$m2" -gt "$m1" ] && m1=$m2
  echo "$m1"
}

status_of() {  # one status line, never empty: a blank or failing rev-status.sh is itself reported, its stderr kept in the orchestrator output
  local line; line=$("$REV_SCRIPTS/rev-status.sh" "$1" 2>>"${ROOT}/status.err") || line=""
  [ -n "$line" ] && printf '%s' "$line" || printf '(status unavailable - see %s/status.err)' "$ROOT"
}

state_signature() {  # stable identity for proving the current attempt refreshed state.json
  python3 - "$1" <<'PY'
import hashlib
import os
import stat
import sys

path = sys.argv[1]
try:
    details = os.lstat(path)
except FileNotFoundError:
    print('absent')
    raise SystemExit(0)
if not stat.S_ISREG(details.st_mode) or stat.S_ISLNK(details.st_mode):
    print('unsafe')
    raise SystemExit(0)
with open(path, 'rb') as source:
    digest = hashlib.sha256(source.read()).hexdigest()
print(f'{details.st_dev}:{details.st_ino}:{details.st_size}:{details.st_mtime_ns}:{details.st_ctime_ns}:{digest}')
PY
}

completion_receipt_error() {  # <session-dir> <pre-attempt-state-signature>
  python3 - "$1" "$2" <<'PY'
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

session = Path(sys.argv[1])
before = sys.argv[2]

def regular(path, nonempty=False):
    try:
        details = os.lstat(path)
    except FileNotFoundError:
        return None, f'{path.name} is missing'
    if stat.S_ISLNK(details.st_mode):
        return None, f'{path.name} is a symlink'
    if not stat.S_ISREG(details.st_mode):
        return None, f'{path.name} is not a regular file'
    if nonempty and details.st_size == 0:
        return None, f'{path.name} is empty'
    return details, None

report_details, error = regular(session / 'stack-report.md', nonempty=True)
if error:
    print(error)
    raise SystemExit(1)
state_path = session / 'state.json'
state_details, error = regular(state_path, nonempty=True)
if error:
    print(error)
    raise SystemExit(1)
try:
    data = state_path.read_bytes()
    state = json.loads(data)
except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
    print(f'state.json is invalid: {exc}')
    raise SystemExit(1)
if not isinstance(state, dict) or state.get('phase') != 'stack-ready':
    print('state.json does not record phase=stack-ready')
    raise SystemExit(1)
digest = hashlib.sha256(data).hexdigest()
current = (f'{state_details.st_dev}:{state_details.st_ino}:{state_details.st_size}:'
           f'{state_details.st_mtime_ns}:{state_details.st_ctime_ns}:{digest}')
if current == before:
    print('state.json was not refreshed by this attempt')
    raise SystemExit(1)
PY
}

ROSTER_BRIEF=""
wait_for_auth() {
  # The roster owns sign-in detection for every lab; the stack only asks whether it will seat a panel at all.
  # `roster.sh --brief` exits 0 whenever a panel exists - it pads a thin one with Claude seats and marks it
  # degraded rather than refusing. Exit 5 can recover when providers return. Exit 6 is a permanent config
  # error and must fail immediately. A degraded panel is a panel, and the leg's report says so.
  local i rc
  for i in $(seq 1 "$AUTH_WAIT_TRIES"); do
    ROSTER_BRIEF=$(REVIEW_COUNCIL_HOST="$STACK_HOST" "$REV_SCRIPTS/roster.sh" --brief 2>>"${ROOT}/roster.err")
    rc=$?
    case "$rc" in
      0) return 0;;
      5)
        say "    reviewer availability not ready ($i/$AUTH_WAIT_TRIES): ${ROSTER_BRIEF:-no cause reported}"
        [ "$i" -eq "$AUTH_WAIT_TRIES" ] || sleep "$AUTH_WAIT_SECS"
        ;;
      6) return 6;;
      *) return "$rc";;
    esac
  done
  return 5
}

run_leg() {  # <repo-path> <rounds> <label> "<premise>"
  local dir="$1" rounds="$2" label="$3" extra="$4" repo
  local S="$ROOT/$label" attempt=1 infra=0 roster_rc
  repo=$(git -C "$dir" rev-parse --show-toplevel 2>/dev/null) || {
    if [ "$NO_PUSH" = 1 ]; then
      repo=$(cd "$dir" 2>/dev/null && pwd -P) || repo=""
    fi
    if [ -z "$repo" ]; then
      say "!!! $label: cannot resolve repository root for $dir"
      note_failure "$label" "$dir"
      return 1
    fi
  }
  case " $REPOS_SEEN " in *" $repo "*) ;; *) REPOS_SEEN="$REPOS_SEEN $repo";; esac
  # Resume keys on THIS run's session root as well as the label: a different stack sharing the default LOG must
  # never skip a leg it has not actually run (that would fall straight through to the squash + push phase).
  grep -qF "=== DONE $label pass${PASS} exit=0 root=$ROOT" "$LOG" 2>/dev/null && { say "=== SKIP $label pass${PASS} (already done in $LOG)"; return 0; }
  while [ "$attempt" -le "$MAX_ATTEMPTS" ]; do
    mkdir -p "$S"
    wait_for_auth; roster_rc=$?
    case "$roster_rc" in
      0) ;;
      5) say "!!! $label: reviewer availability never recovered; skipping: ${ROSTER_BRIEF:-no cause reported}"; note_failure "$label" "$repo"; return 1;;
      6) say "!!! $label: roster configuration is invalid; skipping: ${ROSTER_BRIEF:-no cause reported}"; note_failure "$label" "$repo"; return 1;;
      *) say "!!! $label: roster check failed (exit $roster_rc); skipping: ${ROSTER_BRIEF:-no cause reported}"; note_failure "$label" "$repo"; return 1;;
    esac
    local resume=""
    [ -f "$S/findings.md" ] && resume="

NOTE: an earlier pass of this review exists. Read $S/findings.md FIRST and do not re-raise what it fixed, rejected with sound reasoning, or deferred with a stated reason. Start from the current branch state."
    say "=== START $label pass${PASS} (attempt $attempt/$MAX_ATTEMPTS) rounds=$rounds"
    local t0; t0=$(date +%s)
    local prompt="/review-council:rev branch $rounds - use $S as the session dir.
The host model orchestrates. The resolved workhorse writes the fix plan. The host implements a local cluster (one file, at most 3 sites). The workhorse implements every other cluster.

${extra}

${VACUITY}${resume}"
    if [ "$STACK_HOST" = codex ]; then
      local skill="$HERE/../codex-skills/rev/SKILL.md"
      [ -f "$skill" ] || { say "!!! missing Codex rev skill: $skill"; note_failure "$label" "$repo"; return 1; }
      prompt="Read and follow the Codex review-council skill at $skill.
Review branch $rounds rounds; use $S as the session dir. This is a stack leg: do not squash or push.
The host model orchestrates. The resolved workhorse writes the fix plan. The host implements a local cluster (one file, at most 3 sites). The workhorse implements every other cluster.

${extra}

${VACUITY}${resume}"
    elif [ "$STACK_HOST" = cursor ]; then
      local skill="$(dirname "$HERE")/cursor-skills/rev/SKILL.md"
      [ -f "$skill" ] || { say "!!! missing Cursor rev skill: $skill"; note_failure "$label" "$repo"; return 1; }
      local cursor_cli
      cursor_cli=$(command -v cursor-agent || command -v agent) || {
        say "!!! Cursor host executable unavailable"; note_failure "$label" "$repo"; return 1;
      }
      prompt="Read and follow the Cursor review-council skill at $skill using REVIEW_COUNCIL_HOST=cursor and the runtime at $HERE.
Review branch $rounds rounds; use $S as the session dir. This is a stack leg: do not squash or push.
The host model orchestrates. The resolved workhorse writes the fix plan. The host implements a local cluster (one file, at most 3 sites). The workhorse implements every other cluster.

${extra}

${VACUITY}${resume}"
    fi
    # A ready receipt certifies only the launch that created it. Archive any prior
    # pass or failed attempt before both host paths start, then require a new one.
    local previous_report="$S/stack-report.pass${PASS}.attempt${attempt}.previous.md"
    if { [ -e "$S/stack-report.md" ] || [ -L "$S/stack-report.md" ]; } \
        && ! mv "$S/stack-report.md" "$previous_report"; then
      say "!!! $label: could not archive the prior stack-ready report; refusing to launch"
      note_failure "$label" "$repo"
      return 1
    fi
    if [ -e "$S/report.md" ] || [ -L "$S/report.md" ]; then
      local previous_done="$S/report.pass${PASS}.attempt${attempt}.previous.md"
      if ! mv "$S/report.md" "$previous_done"; then
        say "!!! $label: could not archive the prior completed report; refusing to launch"
        note_failure "$label" "$repo"
        return 1
      fi
    fi
    local state_before; state_before=$(state_signature "$S/state.json")
    if [ "$state_before" = unsafe ]; then
      say "!!! $label: unsafe state.json; refusing to launch"
      note_failure "$label" "$repo"
      return 1
    fi
    set -m   # give the leg its own process group, so the CPU veto and the kill can address the whole tree
    (
      cd "$dir" || exit 1
      export REV_STACK_LEG=1 REVIEW_COUNCIL_HOST="$STACK_HOST"
      if [ "$STACK_HOST" = codex ]; then
        printf '%s\n' "$prompt" | codex exec --ephemeral -s workspace-write \
          -c sandbox_workspace_write.network_access=true --add-dir "$ROOT" --json -
      elif [ "$STACK_HOST" = cursor ]; then
        "$cursor_cli" -p "$prompt" --force --output-format stream-json </dev/null
      else
        # The leg is its own headless session, not a turn of the Claude Code session that started the stack.
        SESSION_ENV=$(cd "$HERE/lib" && python3 -c \
          'from roster import CLAUDE_SESSION_ENV; print(" ".join(CLAUDE_SESSION_ENV))') || exit 1
        unset $SESSION_ENV
        claude -p "$prompt" --permission-mode bypassPermissions --effort max --output-format stream-json --verbose </dev/null
      fi
    ) > "$S/run.log" 2>&1 &
    set +m
    local pid=$! last_seen last_cpu="" last_status stalled=0
    last_seen=$(date +%s); last_status=$last_seen
    while kill -0 "$pid" 2>/dev/null; do
      sleep "$POLL"
      local now m idle; now=$(date +%s)
      m=$(last_activity "$S")
      [ "$m" -gt "$last_seen" ] && last_seen=$m
      idle=$(( now - last_seen )); [ "$idle" -lt 0 ] && idle=0   # an mtime a second ahead of the clock is not negative idleness
      if [ $(( now - last_status )) -ge "$STATUS_EVERY" ]; then
        local c mv n; c=$(cpu_of "$pid"); mv=frozen; [ "$c" != "$last_cpu" ] && mv=moving; last_cpu=$c
        n=$(cd "$dir" && git rev-list --count '@{u}..HEAD' 2>/dev/null || echo -)
        say "[status] $label pass${PASS} attempt$attempt | $(status_of "$S") | idle=${idle}s cpu=${c:-none}($mv) commits=$n"
        last_status=$now
      fi
      if [ "$idle" -ge "$STALL_SECS" ]; then
        local c1 c2 idle2; c1=$(cpu_of "$pid"); sleep "$CPU_SAMPLE_SECS"; c2=$(cpu_of "$pid")
        # The sample is a blind window: the leg can finish or come back to life inside it. Re-check
        # BOTH before killing, or a leg that completed normally is recorded as stalled and retried.
        if ! kill -0 "$pid" 2>/dev/null; then
          say "    $label finished during the ${CPU_SAMPLE_SECS}s cpu sample - not killing"; break
        fi
        m=$(last_activity "$S")
        [ "$m" -gt "$last_seen" ] && last_seen=$m
        idle2=$(( $(date +%s) - last_seen ))
        if [ "$idle2" -lt "$STALL_SECS" ]; then
          say "    $label spoke during the cpu sample (idle ${idle2}s) - not killing"; continue
        fi
        if [ -n "$c2" ] && [ "$c1" != "$c2" ]; then
          say "    $label quiet ${idle}s but cpu $c1 -> $c2 - working, not killing"; last_seen=$(date +%s); continue
        fi
        say "!!! $label STALLED (${idle2}s idle, cpu frozen at ${c1:-n/a}) - killing"; stalled=1
        kill_leg "$pid"; break
      fi
    done
    wait "$pid" 2>/dev/null; local rc=$? dur=$(( $(date +%s) - t0 ))
    local receipt_error=""
    if [ "$rc" -eq 0 ] && [ "$stalled" = 0 ]; then
      receipt_error=$(completion_receipt_error "$S" "$state_before")
      if [ "$?" -ne 0 ]; then
        # A headless leg can exit 0 while its loop is unfinished. The stack-ready
        # report and state together are the attempt-local completion receipt.
        say "!!! $label exited 0 after ${dur}s with invalid completion receipt (${receipt_error}); retrying with resume"; rc=75
      fi
    fi
    if [ "$rc" -eq 0 ] && [ "$stalled" = 0 ]; then
      if ! replace_tab_row "$SESSION_MAP" "$repo" "$S"; then
        say "!!! $label: cannot record the authoritative review session"
        note_failure "$label" "$repo"
        return 1
      fi
      say "=== DONE $label pass${PASS} exit=0 root=$ROOT (${dur}s)"
      return 0
    fi
    if [ "$stalled" = 0 ] && [ "$dur" -lt "$FAST_FAIL_SECS" ] && [ "$infra" -lt "$MAX_INFRA_RETRIES" ]; then
      infra=$(( infra + 1 )); say "    $label failed in ${dur}s - infrastructure; sleeping ${INFRA_SLEEP_SECS}s"; sleep "$INFRA_SLEEP_SECS"; continue
    fi
    say "=== $label ended rc=$rc after ${dur}s (attempt $attempt)"; attempt=$(( attempt + 1 ))
  done
  say "=== GAVE UP on $label"; note_failure "$label" "$repo"; return 1
}

finish_repos() {
  local d srq push_rc session head branch_ref tracking_ref tracking_before
  local push_remote push_ref push_urls push_url remote_head upstream
  local -a validate_args
  for d in $REPOS_SEEN; do
    case " $FAILED_REPOS " in *" $d "*)
      say "--- skipping $(basename "$d") - a leg on it failed; its review is not complete"; continue;; esac
    say "--- finishing $(basename "$d")"
    if ! git -C "$d" rev-parse --show-toplevel >/dev/null 2>&1; then
      if [ "$NO_PUSH" = 1 ]; then
        say "--- $(basename "$d") is not a git repository; NO_PUSH=1 skips squash and push (NO_SQUASH=$NO_SQUASH)"
        continue
      fi
      say "!!! cannot finish $(basename "$d"): not a git repository"
      note_failure "finish:$(basename "$d")" "$d"
      continue
    fi
    session=$(session_for_repo "$d") || {
      say "!!! no authoritative completed review session for $(basename "$d")"
      note_failure "PR review validation" "$d"
      continue
    }
    if [ "$NO_PUSH" != 1 ]; then
      branch_ref=$(git -C "$d" symbolic-ref -q HEAD 2>/dev/null) || {
        say "!!! cannot capture the reviewed push branch for $(basename "$d")"
        note_failure "PR review validation" "$d"
        continue
      }
      upstream=$(git -C "$d" for-each-ref \
        --format='%(upstream)%09%(upstream:remotename)%09%(upstream:remoteref)' \
        "$branch_ref")
      IFS=$'\t' read -r tracking_ref push_remote push_ref <<< "$upstream"
      case "$tracking_ref:$push_remote:$push_ref" in
        :*|*::*|*:)
          say "!!! cannot resolve one upstream push destination for $(basename "$d")"
          note_failure "PR review validation" "$d"
          continue
          ;;
      esac
      if [ "$push_ref" != "$branch_ref" ]; then
        say "!!! upstream push ref does not match the reviewed branch for $(basename "$d")"
        note_failure "PR review validation" "$d"
        continue
      fi
      case "$tracking_ref" in
        "refs/remotes/$push_remote/"*) ;;
        *)
          say "!!! upstream tracking ref is outside the selected remote for $(basename "$d")"
          note_failure "PR review validation" "$d"
          continue
          ;;
      esac
      push_urls=$(git -C "$d" remote get-url --push --all "$push_remote" 2>/dev/null) || {
        say "!!! cannot resolve the push URL for $(basename "$d")"
        note_failure "PR review validation" "$d"
        continue
      }
      if [ "$(printf '%s\n' "$push_urls" | grep -c .)" -ne 1 ]; then
        say "!!! cannot resolve exactly one push URL for $(basename "$d")"
        note_failure "PR review validation" "$d"
        continue
      fi
      push_url=$push_urls
      set -o pipefail
      python3 "$REV_SCRIPTS/rev-pr-review.py" validate-stack-destination "$session" \
        --root "$d" --push-url "$push_url" --push-ref "$push_ref" 2>&1 \
        | sed 's/^/    /' | tee -a "$LOG"
      push_rc=$?
      set +o pipefail
      if [ "$push_rc" -ne 0 ]; then
        note_failure "PR review validation" "$d"
        continue
      fi
      tracking_before=$(git -C "$d" rev-parse "$tracking_ref" 2>/dev/null) || {
        say "!!! cannot read the upstream tracking ref for $(basename "$d")"
        note_failure "PR review validation" "$d"
        continue
      }
      if ! git -C "$d" fetch -q --no-tags "$push_url" "$push_ref"; then
        say "!!! cannot reconcile the upstream push destination for $(basename "$d")"
        note_failure "PR review validation" "$d"
        continue
      fi
      remote_head=$(git -C "$d" rev-parse FETCH_HEAD 2>/dev/null) || {
        say "!!! cannot read the upstream push destination for $(basename "$d")"
        note_failure "PR review validation" "$d"
        continue
      }
      if ! git -C "$d" update-ref "$tracking_ref" "$remote_head" "$tracking_before"; then
        say "!!! cannot reconcile the upstream tracking ref for $(basename "$d")"
        note_failure "PR review validation" "$d"
        continue
      fi
    fi
    set -o pipefail
    ( cd "$d" && if [ "$NO_SQUASH" = 1 ]; then echo "(NO_SQUASH=1: keeping review commits)"; else "$REV_SCRIPTS/rev-squash.sh" --apply; fi ) 2>&1 | sed 's/^/    /' | tee -a "$LOG"
    srq=$?
    set +o pipefail
    # A refused squash (NO_SQUASH=0 only) is not a reason to withhold the push: the review commits are real work and CI
    # must see them. Squash and push are therefore independent steps, not one && chain.
    [ "$srq" -eq 0 ] || say "!!! squash refused for $(basename "$d") - pushing the un-collapsed review commits"
    head=$(git -C "$d" rev-parse HEAD 2>/dev/null) || {
      say "!!! cannot capture the reviewed head for $(basename "$d")"
      note_failure "PR review validation" "$d"
      continue
    }
    validate_args=(validate-stack "$session" --head "$head" --root "$d")
    if [ "$NO_PUSH" != 1 ]; then
      validate_args+=(--push-url "$push_url" --push-ref "$push_ref")
    fi
    set -o pipefail
    python3 "$REV_SCRIPTS/rev-pr-review.py" "${validate_args[@]}" 2>&1 \
      | sed 's/^/    /' | tee -a "$LOG"
    push_rc=$?
    set +o pipefail
    if [ "$push_rc" -ne 0 ]; then
      note_failure "PR review validation" "$d"
      continue
    fi
    if [ "$NO_PUSH" = 1 ]; then
      say "    (NO_PUSH=1: not pushing)"
      continue
    fi
    set -o pipefail
    git -C "$d" push "$push_url" "$head:$push_ref" 2>&1 \
      | sed 's/^/    /' | tee -a "$LOG"
    push_rc=$?
    set +o pipefail
    if [ "$push_rc" -ne 0 ]; then
      say "!!! push failed for $(basename "$d")"
      note_failure "push:$(basename "$d")" "$d"
      continue
    fi
    # Git 2.56 and later record a push to a configured remote's URL in its tracking ref themselves.
    if [ "$(git -C "$d" rev-parse -q --verify "$tracking_ref" 2>/dev/null)" != "$head" ] \
      && ! git -C "$d" update-ref "$tracking_ref" "$head" "$remote_head"; then
      say "!!! cannot record the successful pinned push for $(basename "$d")"
      note_failure "push tracking:$(basename "$d")" "$d"
      continue
    fi
    if [ "$(git -C "$d" rev-parse HEAD 2>/dev/null)" != "$head" ]; then
      say "!!! branch moved while pushing $(basename "$d")"
      note_failure "push:$(basename "$d")" "$d"
      continue
    fi
  done
}

finalize_reviews() {
  local repo head session rc=0
  if [ "$NO_PUSH" = 1 ]; then
    say "--- NO_PUSH=1: deferring PR review finalization"
    return 0
  fi
  for repo in $REPOS_SEEN; do
    case " $FAILED_REPOS " in *" $repo "*) continue;; esac
    session=$(session_for_repo "$repo") || {
      say "!!! no authoritative completed review session for $(basename "$repo")"
      rc=1
      note_failure "PR review finalization" "$repo"
      continue
    }
    head=$(git -C "$repo" rev-parse HEAD 2>/dev/null) || {
      say "!!! cannot read final review head for $(basename "$repo")"
      rc=1
      note_failure "PR review finalization" "$repo"
      continue
    }
    if [ ! -f "$session/stack-report.md" ] && [ ! -f "$session/report.md" ]; then
      say "!!! authoritative review session has no stack-ready report: $session"
      rc=1
      note_failure "PR review finalization" "$repo"
      continue
    fi
    set -o pipefail
    python3 "$REV_SCRIPTS/rev-pr-review.py" finalize-stack "$session" \
      --head "$head" --root "$repo" 2>&1 | sed 's/^/    /' | tee -a "$LOG"
    if [ "$?" -ne 0 ]; then
      rc=1
      note_failure "PR review finalization" "$repo"
    fi
    set +o pipefail
  done
  return "$rc"
}

publish_reviews() {
  local repo session retry rc=0
  if [ "$NO_PUSH" = 1 ]; then
    say "--- NO_PUSH=1: not publishing PR reviews"
    return 0
  fi
  [ -f "$REV_SCRIPTS/rev-pr-review.py" ] || {
    say "!!! PR review publisher is missing: $REV_SCRIPTS/rev-pr-review.py"
    for repo in $REPOS_SEEN; do
      case " $FAILED_REPOS " in *" $repo "*) continue;; esac
      note_failure "PR review publication" "$repo"
    done
    return 1
  }
  for repo in $REPOS_SEEN; do
    case " $FAILED_REPOS " in *" $repo "*) continue;; esac
    session=$(session_for_repo "$repo") || {
      say "!!! no authoritative review session for $(basename "$repo")"
      rc=1
      note_failure "PR review publication" "$repo"
      continue
    }
    if [ ! -f "$session/stack-report.md" ] && [ ! -f "$session/report.md" ]; then
      say "!!! authoritative review session has no stack-ready report: $session"
      rc=1
      note_failure "PR review publication" "$repo"
      continue
    fi
    retry=$(stack_retry_command)
    set -o pipefail
    REV_STACK_PUBLICATION=1 REVIEW_COUNCIL_RETRY_COMMAND="$retry" \
      python3 "$REV_SCRIPTS/rev-pr-review.py" publish "$session" 2>&1 \
      | sed 's/^/    /' | tee -a "$LOG"
    if [ "$?" -ne 0 ]; then
      rc=1
      note_failure "PR review publication" "$repo"
    fi
    set +o pipefail
  done
  return "$rc"
}

complete_reviews() {
  local repo session rc=0
  for repo in $REPOS_SEEN; do
    case " $FAILED_REPOS " in *" $repo "*) continue;; esac
    session=$(session_for_repo "$repo") || {
      say "!!! no authoritative session to complete for $(basename "$repo")"
      rc=1
      note_failure "PR review completion" "$repo"
      continue
    }
    if [ ! -f "$session/stack-report.md" ] && [ ! -f "$session/report.md" ]; then
      say "!!! authoritative session has no report to complete: $session"
      rc=1
      note_failure "PR review completion" "$repo"
      continue
    fi
    if ! "$REV_SCRIPTS/rev-state.sh" "$session" phase=done; then
      say "!!! cannot mark the published review complete: $session"
      rc=1
      note_failure "PR review completion" "$repo"
      continue
    fi
    if [ -f "$session/stack-report.md" ] \
        && ! mv "$session/stack-report.md" "$session/report.md"; then
      say "!!! cannot promote the stack-ready report: $session"
      rc=1
      note_failure "PR review completion" "$repo"
      continue
    fi
    if [ -e "$session/incomplete.md" ] && ! rm -f -- "$session/incomplete.md"; then
      say "!!! cannot clear the completed review failure receipt: $session"
      rc=1
      note_failure "PR review completion" "$repo"
    fi
  done
  return "$rc"
}

# shellcheck disable=SC1090
set +u; . "$CONFIG"; set -u   # a user's stack config stays forgiving; this script does not
type legs >/dev/null 2>&1 || { echo "stack: $CONFIG must define legs() containing run_leg calls in dependency order" >&2; exit 1; }
say "########## review-council stack: session root $ROOT, log $LOG ##########"
for PASS in $(seq 1 "$PASSES"); do export PASS; say "########## PHASE 1 - PER-PR, PASS ${PASS}/${PASSES} ##########"; legs; done
say "ALL PHASE 1 COMPLETE"
if [ -n "$SEAM_REPO" ]; then PASS=seam; say "########## PHASE 2 - CROSS-REPO SEAMS ##########"; run_leg "$SEAM_REPO" 2 seams "$SEAM_PREMISE"; else say "PHASE 2 skipped (SEAM_REPO unset)"; fi
if [ -n "$CRITIC_REPO" ]; then PASS=critic; say "########## PHASE 3 - COMPLETENESS CRITIC ##########"; run_leg "$CRITIC_REPO" 1 critic "$CRITIC_PREMISE"; else say "PHASE 3 skipped (CRITIC_REPO unset)"; fi
say "########## FINISH - push per repo ##########"; finish_repos
say "########## FINALIZE - reconcile review links with the pushed head ##########"
finalize_reviews || true
say "########## PUBLISH - one PR review per completed repository ##########"
publish_reviews || true
say "########## COMPLETE - promote stack-ready review receipts ##########"
complete_reviews || true
if [ -n "$FAILED_LABELS" ]; then say "COMPLETE WITH FAILURES:$FAILED_LABELS"; exit 1; fi
say "ALL PHASES COMPLETE"
