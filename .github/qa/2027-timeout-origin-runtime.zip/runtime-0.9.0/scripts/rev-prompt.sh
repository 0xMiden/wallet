#!/bin/bash
# rev-prompt.sh <session-dir> <round> <seat> "<lens>" "<round emphasis>" [flags]
# rev-prompt.sh <session-dir> <round> --panel <assignments.tsv> [flags]
# flags: [--phase <phase>] [--vacuity] [--read-only <list-file>] [--plan <fix-plan-file>] [--pr <title-and-body-file>] [--evidence <manifest>]
# Render compact reviewer prompts. Provider adapters supply the output schema. Prints each path.
# A panel TSV holds one `<seat><TAB><lens><TAB><emphasis>` line per seat. The panel publishes every prompt or
# none, reads its evidence manifest once, and records per-seat render milliseconds in r<round>-render.json.
set -u
HERE=$(cd "$(dirname "$0")" && pwd); SCHEMA="$HERE/../schema/findings.schema.json"
now_ms() { python3 -c 'import time; print(time.time_ns() // 1000000)'; }
if [ $# -ge 4 ] && [ "$3" = --panel ]; then
  S=$1; N=$2; PANEL=$4; shift 4
elif [ $# -ge 5 ] && [ "$3" != --panel ]; then
  S=$1; N=$2; PANEL=""; SEATS=("$3"); LENSES=("$4"); EMPHASES=("$5"); shift 5
else
  echo "usage: rev-prompt.sh <session> <round> <seat> <lens> <emphasis> [flags] | rev-prompt.sh <session> <round> --panel <assignments.tsv> [flags]; flags: [--phase <phase>] [--vacuity] [--read-only <list-file>] [--plan <fix-plan-file>] [--pr <file>] [--evidence <manifest>]" >&2
  exit 1
fi
OUTS=(); TMPS=(); EVIDENCE_TMP=""; EVIDENCE_CHECK_TMP=""; FRAGMENTS=""; RULES_TMP=""; PATCH_TMP=""
RENDER_OUT=""; TIMING_TMP=""; PUBLISHED=0
BASELINE_TMP=""; BASELINE_FORMAT=""; BASELINE_FILE=""
cleanup_prompt() {
  rm -f -- "${EVIDENCE_TMP:-}" 2>/dev/null || true
  rm -f -- "${EVIDENCE_CHECK_TMP:-}" 2>/dev/null || true
  rm -f -- "${RULES_TMP:-}" 2>/dev/null || true
  rm -f -- "${PATCH_TMP:-}" 2>/dev/null || true
  rm -f -- "${TIMING_TMP:-}" 2>/dev/null || true
  rm -f -- "${BASELINE_TMP:-}" 2>/dev/null || true
  [ -z "${FRAGMENTS:-}" ] || rm -rf -- "$FRAGMENTS" 2>/dev/null || true
  [ "$PUBLISHED" = 1 ] \
    || rm -f -- ${TMPS[@]+"${TMPS[@]}"} ${OUTS[@]+"${OUTS[@]}"} "${RENDER_OUT:-}" 2>/dev/null || true
}
die() {
  cleanup_prompt
  echo "rev-prompt: $1" >&2
  exit 1
}
trap cleanup_prompt EXIT
if [ -n "$PANEL" ]; then
  PANEL_STARTED=$(now_ms) || die "cannot read the clock"
  [ -f "$PANEL" ] && [ -r "$PANEL" ] || die "panel assignments is not a readable regular file: $PANEL"
  SEATS=(); LENSES=(); EMPHASES=(); TAB=$(printf '\t'); line=""
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      *"$TAB"*"$TAB"*) ;;
      *) die "panel assignment is not <seat><TAB><lens><TAB><emphasis>: $line";;
    esac
    seat=${line%%"$TAB"*}; line=${line#*"$TAB"}; lens=${line%%"$TAB"*}
    [ -n "$seat" ] && [ -n "$lens" ] || die "panel assignment needs a seat and a lens: $seat"
    for seen in ${SEATS[@]+"${SEATS[@]}"}; do
      [ "$seen" != "$seat" ] || die "duplicate panel seat: $seat"
    done
    SEATS+=("$seat"); LENSES+=("$lens"); EMPHASES+=("${line#*"$TAB"}")
  done < "$PANEL"
  [ "${#SEATS[@]}" -gt 0 ] || die "panel assignments are empty: $PANEL"
  RENDER_OUT="$S/r${N}-render.json"
fi
for NAME in "$N" "${SEATS[@]}"; do
  case "$NAME" in ''|[!A-Za-z0-9]*|*[!A-Za-z0-9_.-]*) die "invalid prompt label or seat: $NAME";; esac
done
for SEAT in "${SEATS[@]}"; do OUTS+=("$S/r${N}-${SEAT}.prompt.md"); done
# A failed same-label rerender must not leave the prior prompt looking current.
for OUT in "${OUTS[@]}" ${RENDER_OUT:+"$RENDER_OUT"}; do
  rm -f -- "$OUT" 2>/dev/null || die "cannot remove stale prompt: $OUT"
done
PHASE=""; VAC=0; RO=""; PLAN=""; PRF=""; EVIDENCE=""
SIBLING_SITE_CHECK="Sibling-site completeness: for each fix commit since the base, name the rule it applies and search the repository for sites, arms, realms, callers and copies (tests, JSDoc, docs) the rule reaches but the commit missed."
while [ $# -gt 0 ]; do
  case "$1" in
    --phase) PHASE=${2:?}; shift 2;;
    --vacuity) VAC=1; shift;;
    --read-only) RO=${2:?}; shift 2;;
    --plan) PLAN=${2:?}; shift 2;;
    --pr) PRF=${2:?}; shift 2;;
    --evidence) EVIDENCE=${2:?}; shift 2;;
    *) die "unknown argument $1";;
  esac
done
case "$PHASE" in
  ''|discovery|risk|verification|repair|plan|numeric) ;;
  *) die "--phase must be discovery, risk, verification, repair, plan, or numeric: $PHASE";;
esac
if [ "$PHASE" = numeric ]; then
  [[ "$N" =~ ^[1-9][0-9]*(x|x0*([2-9]|[1-9][0-9]+))?$ ]] || die "invalid numeric prompt label: $N"
  for PRIOR in "$S/r${N}-"*.prompt.md; do
    rm -f -- "$PRIOR" || die "cannot invalidate prior numeric prompt: $PRIOR"
  done
  [ -n "$EVIDENCE" ] || die "numeric prompts require their bound evidence manifest"
fi
if [ -n "$RO" ] && [ -n "$EVIDENCE" ]; then
  die "--evidence applies to code and plan prompts, not --read-only document prompts"
fi
# scope.env values are single-quoted by rev-preflight.sh (so `source` is safe); strip that quoting here.
unq() {
  local s=$1
  case "$s" in "'"*"'") s=${s#\'}; s=${s%\'}; s=${s//\'\\\'\'/\'};; esac
  printf '%s' "$s"
}
is_present() { [ -e "$1" ] || [ -L "$1" ]; }
require_regular() {
  [ -f "$1" ] && [ -r "$1" ] || die "$2 is not a readable regular file: $1"
}

if [ -n "$PLAN" ]; then
  require_regular "$PLAN" "fix plan"
  [ ! -L "$PLAN" ] || die "fix plan must not be a symlink: $PLAN"
  [ -s "$PLAN" ] || die "fix plan missing or empty: $PLAN"
fi
if [ -n "$PLAN" ]; then
  PLAN_DIR=$(cd "$(dirname "$PLAN")" && pwd -P) || die "cannot resolve fix plan: $PLAN"
  PLAN="$PLAN_DIR/$(basename "$PLAN")"
fi
if [ -n "$RO" ]; then
  require_regular "$RO" "document list"
  [ -s "$RO" ] || die "document list missing or empty: $RO"
else
  require_regular "$S/scope.env" "scope metadata"
  require_regular "$S/files.txt" "changed-file list"
  HAS_UNTRACKED=0
  if is_present "$S/untracked.txt"; then
    require_regular "$S/untracked.txt" "untracked-file list"
    HAS_UNTRACKED=1
  fi
  # Parsed, never sourced: a repo path with a space or a branch name with shell metacharacters must not execute.
  REV_BASE=""; REV_BRANCH=""; REV_DEFAULT=""; REV_BASE_BRANCH=""; REV_ROOT=""; REV_SCOPE=""
  REV_PR_NUMBER=""; REV_PR_HEAD=""; REV_PR_BASE_HEAD=""; k=""; v=""
  while IFS='=' read -r k v || [ -n "$k" ]; do
    case "$k" in
      REV_BASE) REV_BASE=$(unq "$v");;
      REV_BRANCH) REV_BRANCH=$(unq "$v");;
      REV_DEFAULT) REV_DEFAULT=$(unq "$v");;
      REV_BASE_BRANCH) REV_BASE_BRANCH=$(unq "$v");;
      REV_ROOT) REV_ROOT=$(unq "$v");;
      REV_SCOPE) REV_SCOPE=$(unq "$v");;
      REV_PR_NUMBER) REV_PR_NUMBER=$(unq "$v");;
      REV_PR_HEAD) REV_PR_HEAD=$(unq "$v");;
      REV_PR_BASE_HEAD) REV_PR_BASE_HEAD=$(unq "$v");;
    esac
  done < "$S/scope.env"
  [ -n "$REV_BASE" ] && [ -n "$REV_ROOT" ] && [ -n "$REV_SCOPE" ] || {
    die "$S/scope.env is missing REV_BASE/REV_ROOT/REV_SCOPE; re-run rev-preflight.sh --write $S"; }
fi
if [ -n "$PRF" ]; then require_regular "$PRF" "PR description"; fi
if [ -n "$EVIDENCE" ]; then
  require_regular "$EVIDENCE" "evidence manifest"
  [ ! -L "$EVIDENCE" ] || die "evidence manifest must not be a symlink: $EVIDENCE"
  SESSION_DIR=$(cd "$S" && pwd -P) || die "cannot resolve session directory: $S"
  EVIDENCE_DIR=$(cd "$(dirname "$EVIDENCE")" && pwd -P) || die "cannot resolve evidence manifest: $EVIDENCE"
  EVIDENCE="$EVIDENCE_DIR/$(basename "$EVIDENCE")"
  [ "$EVIDENCE" = "$SESSION_DIR/r${N}-evidence.manifest.json" ] \
    || die "evidence manifest does not match session and prompt label: $EVIDENCE"
fi
HAS_BASELINE=0; HAS_REJECTED=0; HAS_CONTEXT=0
if is_present "$S/baseline.json"; then
  require_regular "$S/baseline.json" "structured baseline"
  [ ! -L "$S/baseline.json" ] || die "structured baseline must not be a symlink: $S/baseline.json"
  BASELINE_FORMAT=json; BASELINE_FILE="$S/baseline.json"; HAS_BASELINE=1
elif is_present "$S/baseline.md"; then
  require_regular "$S/baseline.md" "baseline"
  BASELINE_FORMAT=markdown; BASELINE_FILE="$S/baseline.md"; HAS_BASELINE=1
fi
if is_present "$S/rejected.md"; then require_regular "$S/rejected.md" "rejected-findings digest"; HAS_REJECTED=1; fi
if is_present "$S/context.md"; then require_regular "$S/context.md" "decision digest"; HAS_CONTEXT=1; fi
SHOW_PR=0; SHOW_UNTRACKED=0; SHOW_REJECTED=0; SHOW_CONTEXT=0
if [ -n "$PRF" ] && [ -s "$PRF" ]; then SHOW_PR=1; fi
if [ -z "$RO" ] && [ "$HAS_UNTRACKED" = 1 ] && [ -s "$S/untracked.txt" ]; then SHOW_UNTRACKED=1; fi
if [ "$HAS_REJECTED" = 1 ] && [ -s "$S/rejected.md" ]; then SHOW_REJECTED=1; fi
if [ "$HAS_CONTEXT" = 1 ] && [ -s "$S/context.md" ]; then SHOW_CONTEXT=1; fi
ADAPTERS=()
if is_present "$S/roster.json"; then
  require_regular "$S/roster.json" "roster"
  if [ -n "$RO" ]; then
    python3 - "$S/roster.json" <<'PY'
import json, sys
with open(sys.argv[1], encoding='utf-8') as stream:
    roster = json.load(stream)
if any(row.get('adapter') == 'cursor-sdk' for row in roster['seats']):
    sys.stderr.write('cursor-sdk document mode is unsupported\n')
    raise SystemExit(1)
PY
    [ "$?" = 0 ] || die "document roster is unsupported"
  fi
  LOOKUP_ERR=$(mktemp "${TMPDIR:-/tmp}/review-council-roster.XXXXXX")
  ROSTER_ADAPTERS=$(PYTHONPATH="$HERE/lib${PYTHONPATH:+:$PYTHONPATH}" python3 - "$S/roster.json" "${SEATS[@]}" <<'PY' 2>"$LOOKUP_ERR"
import sys
from workhorse import lookup_adapter
for seat in sys.argv[2:]:
    try:
        print(lookup_adapter(sys.argv[1], seat))
    except ValueError as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
PY
) || { detail=$(tr '\n' ' ' < "$LOOKUP_ERR"); rm -f "$LOOKUP_ERR"; die "roster is invalid or does not contain every selected seat (${SEATS[*]}): $S/roster.json${detail:+: $detail}"; }
  rm -f "$LOOKUP_ERR"
  while IFS= read -r ADAPTER; do ADAPTERS+=("$ADAPTER"); done <<< "$ROSTER_ADAPTERS"
else
  for SEAT in "${SEATS[@]}"; do ADAPTERS+=(agent); done
fi
NEEDS_SCHEMA=0
for ADAPTER in "${ADAPTERS[@]}"; do case "$ADAPTER" in agent|cursor-agent|gemini|cursor-sdk) NEEDS_SCHEMA=1;; esac; done
if [ "$NEEDS_SCHEMA" = 1 ]; then require_regular "$SCHEMA" "findings schema"; fi
check_read() { cat -- "$1" >/dev/null || die "cannot read $2: $1"; }
render_evidence() {
  if [ -n "$PLAN" ]; then
    python3 "$HERE/rev-evidence.py" render "$EVIDENCE" "$SEAT" --plan-source "$PLAN"
  else
    python3 "$HERE/rev-evidence.py" render "$EVIDENCE" "$SEAT"
  fi
}
render_evidence_panel() {
  if [ -n "$PLAN" ]; then
    python3 "$HERE/rev-evidence.py" render-panel --output-dir "$FRAGMENTS" ${PHASE:+--phase "$PHASE"} \
      --plan-source "$PLAN" -- "$EVIDENCE" "${SEATS[@]}"
  else
    python3 "$HERE/rev-evidence.py" render-panel --output-dir "$FRAGMENTS" ${PHASE:+--phase "$PHASE"} \
      -- "$EVIDENCE" "${SEATS[@]}"
  fi
}
if [ -n "$RO" ]; then
  check_read "$RO" "document list"
else
  check_read "$S/scope.env" "scope metadata"
  check_read "$S/files.txt" "changed-file list"
  [ "$HAS_UNTRACKED" = 0 ] || check_read "$S/untracked.txt" "untracked-file list"
fi
[ -z "$PLAN" ] || check_read "$PLAN" "fix plan"
[ -z "$PRF" ] || check_read "$PRF" "PR description"
[ -z "$EVIDENCE" ] || check_read "$EVIDENCE" "evidence manifest"
# The pinned-dependency root: an explicit REV_DEPS_DIR, else the evidence manifest's per-crate view.
DEPS_ROOT=${REV_DEPS_DIR:-}; DEPS_VIEW=""
if [ -z "$DEPS_ROOT" ] && [ -n "$EVIDENCE" ]; then
  DEPS_VIEW=$(python3 -c 'import json, sys; print((json.load(open(sys.argv[1], encoding="utf-8")).get("dependency_view") or {}).get("path", ""))' \
    "$EVIDENCE") || die "cannot read the dependency view of $EVIDENCE"
  DEPS_ROOT=$DEPS_VIEW
fi
[ "$HAS_BASELINE" = 0 ] || check_read "$BASELINE_FILE" "baseline"
[ "$HAS_REJECTED" = 0 ] || check_read "$S/rejected.md" "rejected-findings digest"
[ "$HAS_CONTEXT" = 0 ] || check_read "$S/context.md" "decision digest"
[ "$NEEDS_SCHEMA" = 0 ] || check_read "$SCHEMA" "findings schema"
if [ "$BASELINE_FORMAT" = json ]; then
  BASELINE_TMP=$(mktemp "$S/.rev-baseline.XXXXXX") || die "cannot create baseline fragment in $S"
  python3 - "$BASELINE_FILE" > "$BASELINE_TMP" <<'PY'
import json
import sys

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate baseline field: ' + key)
        result[key] = value
    return result

def nonempty(value):
    return isinstance(value, str) and bool(value.strip()) and '\x00' not in value

try:
    with open(sys.argv[1], encoding='utf-8') as stream:
        document = json.load(stream, object_pairs_hook=unique_object)
    if (not isinstance(document, dict) or set(document) != {'schema_version', 'checks'}
            or type(document['schema_version']) is not int or document['schema_version'] != 1
            or not isinstance(document['checks'], list) or not document['checks']):
        raise ValueError('baseline needs schema_version 1 and a nonempty checks list')
    for index, check in enumerate(document['checks'], 1):
        required = {'command', 'outcome', 'applicability'}
        if (not isinstance(check, dict) or not required <= set(check)
                or set(check) - required - {'failure', 'log'}
                or any(not nonempty(value) for value in check.values())
                or check['outcome'] not in ('passed', 'failed', 'skipped')
                or (check['outcome'] == 'failed') != ('failure' in check)):
            raise ValueError('invalid baseline check ' + str(index))
    print(json.dumps(document, ensure_ascii=True, separators=(',', ':')))
except (OSError, ValueError) as error:
    raise SystemExit('baseline: ' + str(error))
PY
  [ "$?" = 0 ] || die "invalid structured baseline: $BASELINE_FILE"
  BASELINE_FILE=$BASELINE_TMP
fi
if [ -n "$EVIDENCE" ] && [ -n "$PANEL" ]; then
  if [ "$PHASE" = numeric ]; then
    python3 - "$EVIDENCE" "$PANEL" <<'PY'
import json
from pathlib import Path
import sys
manifest = Path(sys.argv[1])
data = json.loads(manifest.read_bytes())
panel = Path(sys.argv[2])
if (data.get('phase') != 'numeric' or panel.is_symlink()
        or panel.resolve() != manifest.parent / data.get('numeric', {}).get('panel', '')):
    raise SystemExit('numeric renderer needs its exact prepared panel')
PY
    [ "$?" = 0 ] || die "numeric panel does not match its evidence manifest"
  fi
  FRAGMENTS=$(mktemp -d "$S/.rev-evidence-fragment.XXXXXX") || die "cannot create evidence fragments in $S"
  # The manifest phase is authoritative; render-panel rejects a conflicting --phase.
  PHASE=$(render_evidence_panel) || die "cannot render panel evidence from $EVIDENCE"
elif [ -n "$EVIDENCE" ]; then
  SEAT=${SEATS[0]}
  EVIDENCE_PHASE=$(python3 - "$EVIDENCE" "$PHASE" <<'PY'
import json
from pathlib import Path
import sys
path = Path(sys.argv[1])
manifest = json.loads(path.read_bytes())
if manifest['phase'] == 'repair' and manifest.get('parent_assignment'):
    name = manifest['parent_assignment']['manifest']
    if Path(name).name != name:
        raise SystemExit('invalid repair parent')
    parent = json.loads((path.parent / name).read_bytes())
    if (parent['phase'] == 'numeric') != (sys.argv[2] == 'numeric'):
        raise SystemExit('numeric repair must retain its parent covered phase')
print(manifest['phase'])
PY
  ) || die "cannot bind evidence manifest phase: $EVIDENCE"
  # A repair seat may name the phase of the panel it covers.
  case "$EVIDENCE_PHASE:$PHASE" in
    *:|repair:discovery|repair:risk|repair:verification|repair:numeric) ;;
    *) [ "$PHASE" = "$EVIDENCE_PHASE" ] || die "evidence manifest phase is $EVIDENCE_PHASE, not $PHASE: $EVIDENCE";;
  esac
  PHASE=${PHASE:-$EVIDENCE_PHASE}
  EVIDENCE_TMP=$(mktemp "$S/.rev-evidence-fragment.XXXXXX") || die "cannot create evidence fragment in $S"
  render_evidence > "$EVIDENCE_TMP"
  EVIDENCE_RC=$?
  [ "$EVIDENCE_RC" = 0 ] || die "cannot render evidence for $SEAT from $EVIDENCE"
  [ -s "$EVIDENCE_TMP" ] || die "empty evidence fragment for $SEAT from $EVIDENCE"
fi
if [ -n "$EVIDENCE" ]; then
  INSTRUCTIONS="$S/r${N}-instructions.md"
  require_regular "$INSTRUCTIONS" "repository instruction snapshot"
  check_read "$INSTRUCTIONS" "repository instruction snapshot"
fi
ROSTER_PATH=""
[ ! -f "$S/roster.json" ] || ROSTER_PATH="$S/roster.json"
COMPILED_MODES=$(PYTHONPATH="$HERE/lib${PYTHONPATH:+:$PYTHONPATH}" \
  python3 - "$HERE/lib/review_limits.py" "$EVIDENCE" "$ROSTER_PATH" "${SEATS[@]}" <<'PY'
import json
import runpy
import sys

limits = runpy.run_path(sys.argv[1])
print('limits', limits['READ_LINES'], limits['CODEX_READ_LINES'],
      limits['CODEX_SOURCE_READ_LINES'], limits['REPOSITORY_EXPANSION_CALL_LIMIT'],
      limits['MANDATORY_REPOSITORY_READ_LIMIT'])
manifest = None
if sys.argv[2]:
    with open(sys.argv[2], encoding='utf-8') as stream:
        manifest = json.load(stream)
roster_path = sys.argv[3]
if roster_path:
    from workhorse import lookup_launch
for seat in sys.argv[4:]:
    mode, packets, segments = 'windows', False, False
    assignment = manifest['assignments'][seat] if manifest else {}
    model = assignment.get('model')
    if not manifest and roster_path:
        model = lookup_launch(roster_path, seat).get('model')
    call_limit = limits['repository_expansion_call_limit_for_seat'](False, None, model)
    reserve = limits['repository_refutation_call_reserve_for_model'](model)
    mandatory_limit = call_limit - reserve
    if manifest:
        mode = assignment['patch_read_mode']
        context = manifest['source_context']['seats'][seat]
        packets = bool(context['shards'])
        segments = any(row['segments'] for row in context['required_source_ranges'])
        capacity = manifest.get('task_capacity', {}).get('seats', {}).get(seat, {})
        call_limit = limits['repository_expansion_call_limit_for_seat'](
            context['source_read_required'], capacity.get('repository_source_target'),
            assignment.get('model'))
        reserve = limits['repository_refutation_call_reserve_for_model'](
            assignment.get('model'))
        call_limit = capacity.get('repository_expansion_call_limit', call_limit)
        reserve = capacity.get('repository_refutation_call_reserve', reserve)
        mandatory_limit = call_limit - reserve
    print('mode', mode, int(packets), int(segments), call_limit, mandatory_limit)
PY
) || die "cannot compile prompt limits and evidence modes"
PATCH_MODES=(); PACKET_MODES=(); SEGMENT_MODES=(); CALL_LIMITS=(); MANDATORY_LIMITS=()
while read -r kind first second third fourth fifth; do
  if [ "$kind" = limits ]; then
    READ_LINES=$first; CODEX_READ_LINES=$second; CODEX_SOURCE_READ_LINES=$third
    CALL_LIMIT=$fourth; REFUTATION_START=$fifth
  else
    PATCH_MODES+=("$first"); PACKET_MODES+=("$second"); SEGMENT_MODES+=("$third")
    CALL_LIMITS+=("$fourth"); MANDATORY_LIMITS+=("$fifth")
  fi
done <<< "$COMPILED_MODES"
PATCH_ARTIFACT=""; PATCH_AVAILABLE=0
if [ -z "$RO" ]; then
  SESSION_DIR=$(cd "$S" && pwd -P) || die "cannot resolve session directory: $S"
  if [ -n "$EVIDENCE" ]; then
    PATCH_AVAILABLE=1
  else
    PATCH_ARTIFACT="$SESSION_DIR/r${N}-full.patch"
    if is_present "$PATCH_ARTIFACT"; then
      require_regular "$PATCH_ARTIFACT" "frozen patch"
      [ ! -L "$PATCH_ARTIFACT" ] || die "frozen patch must not be a symlink: $PATCH_ARTIFACT"
      PATCH_AVAILABLE=1
    elif git -C "$REV_ROOT" cat-file -e "$REV_BASE^{commit}" 2>/dev/null; then
      PATCH_TMP=$(mktemp "$S/.rev-patch.XXXXXX") || die "cannot create frozen patch temporary in $S"
      python3 - "$HERE/rev-evidence.py" "$S" "$PATCH_TMP" <<'PY'
from pathlib import Path
import runpy
import sys

module = runpy.run_path(sys.argv[1])
repository = module['Repository'](Path(sys.argv[2]).resolve())
base = repository.tree(repository.scope['REV_BASE'])
snapshot, _ = repository.snapshot()
patches, _, _, _ = repository.changes(base, snapshot)
Path(sys.argv[3]).write_bytes(b''.join(patch for _, patch in patches))
PY
      [ "$?" = 0 ] || die "cannot freeze assigned patch from $REV_ROOT"
      [ -s "$PATCH_TMP" ] || die "frozen assigned patch is empty"
      if ! ln -- "$PATCH_TMP" "$PATCH_ARTIFACT" 2>/dev/null; then
        is_present "$PATCH_ARTIFACT" || die "cannot publish frozen assigned patch: $PATCH_ARTIFACT"
        require_regular "$PATCH_ARTIFACT" "concurrently published frozen patch"
        [ ! -L "$PATCH_ARTIFACT" ] \
          || die "concurrently published frozen patch must not be a symlink: $PATCH_ARTIFACT"
      fi
      rm -f -- "$PATCH_TMP"; PATCH_TMP=""
      PATCH_AVAILABLE=1
    fi
    if [ "$PATCH_AVAILABLE" = 1 ]; then
      check_read "$PATCH_ARTIFACT" "frozen patch"
    else
      PATCH_ARTIFACT=""
    fi
  fi
fi
if [ -z "$RO" ] && [ -z "$EVIDENCE" ]; then
  RULES_TMP=$(mktemp "$S/.rev-repo-rules.XXXXXX") || die "cannot create repository instruction fragment in $S"
  python3 - "$REV_ROOT" "$S/files.txt" > "$RULES_TMP" <<'PY'
from pathlib import Path, PurePosixPath
import stat
import sys

root = Path(sys.argv[1]).resolve()
paths = [line for line in Path(sys.argv[2]).read_text().splitlines() if line]
directories = {root}
for name in paths:
    relative = PurePosixPath(name)
    if relative.is_absolute() or '..' in relative.parts:
        raise SystemExit('changed path escapes repository: ' + name)
    current = root
    for part in relative.parent.parts:
        if part in ('', '.'):
            continue
        candidate = current / part
        try:
            mode = candidate.lstat().st_mode
        except FileNotFoundError:
            break
        if stat.S_ISLNK(mode) or not stat.S_ISDIR(mode):
            break
        current = candidate
        directories.add(current)
rules = []
for directory in sorted(directories, key=lambda path: (len(path.relative_to(root).parts), path.as_posix())):
    override = directory / 'AGENTS.override.md'
    ordinary = directory / 'AGENTS.md'
    chosen = None
    for candidate in (override, ordinary):
        try:
            mode = candidate.lstat().st_mode
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
            raise SystemExit('repository instruction is not a regular file: ' + str(candidate))
        chosen = candidate
        break
    if chosen is None:
        continue
    rules.append(chosen)
if rules:
    print('## Applicable repository instructions')
    print('These files are embedded so provider rule discovery stays disabled. Apply each file only to paths below its directory; a deeper file wins on conflict.')
    print()
    for path in rules:
        print('### `' + path.relative_to(root).as_posix() + '`')
        print(path.read_text(), end='' if path.read_bytes().endswith(b'\n') else '\n')
        print()
PY
  [ "$?" = 0 ] || die "cannot collect applicable repository instructions from $REV_ROOT"
fi
lens_one() {
  case "$1" in
    correctness)     echo "Logic errors, off-by-one, wrong operators, inverted conditions, unreachable code.";;
    security)        echo "Injection, authz/authn gaps, secrets, unsafe deserialization, path traversal, SSRF, trust-boundary violations.";;
    edge-cases)      echo "Empty/null/zero, boundaries, Unicode, huge inputs, partial failure.";;
    error-handling)  echo "Swallowed errors, wrong error types, missing cleanup, misleading messages.";;
    concurrency)     echo "Races, deadlocks, unsafe shared state, cancellation, ordering assumptions.";;
    resources)       echo "Leaks, unclosed handles, unbounded growth, missing backpressure.";;
    api-contract)    echo "Breaking changes, inconsistent signatures, bad defaults, leaky abstractions, compatibility.";;
    data-state)      echo "Migrations, serialization compatibility, invariants, idempotency.";;
    performance)     echo "N+1s, needless allocation, hot-path cost, pathological complexity.";;
    tests)           echo "Missing cases, tests that cannot fail, over-mocking, fixture coupling.";;
    observability)   echo "Missing or noisy logs, unactionable errors, absent metrics.";;
    readability)     echo "Naming, dead code, misleading comments, structure.";;
    red-team)        echo "Assume the change is wrong and try to prove it. Adversarial reading: find the input, timing, or state that breaks it.";;
    regression)      echo "Re-review the fixes made in prior rounds and the cumulative diff as a whole; look for fixes that introduced new defects.";;
    maintainability) echo "Abstraction quality, file growth, spaghetti conditionals, logic in the wrong layer.";;
    simplicity)      echo "Could this change be smaller? The burden of proof is on every new mechanism, not on you: do not defend the design; make each piece justify itself against the simplest thing that serves its named consumer. Before judging correctness, ask, and search the tree for the answer: (1) Reuse: every comment of the form \"done by hand because X\" or \"until upstream does Y\" - open the pinned dependency source (cargo registry, node_modules .d.ts) and check whether X or Y still holds on the version this change pins; a dependency bumped in this same change or stack is the first place to look, so diff its public API for the feature area. (2) Native features: for every hand-rolled mechanism - a sequence computed as MAX plus one, a cursor codec, a retry loop, a serialization, a middleware stack - ask whether the engine, framework or standard library already provides it (an autoincrement column, an iterator instead of a collected copy, the framework router); name the feature. (3) Proportionality: for every new endpoint, transport, abstraction or option, name its consumer from the change description and ask whether the machinery fits that consumer - a browser or a script does not need a typed RPC framework with reflection, tracing layers and a timeout; a client that reads a whole collection in one sitting does not need pagination; a demo does not need a policy hook. (4) One value, one implementation: every new optional parameter, flag or config field - list every production caller; if they all pass the same value it is not a parameter. Every new trait, strategy parameter, associated type or generic - count the implementations in the change; if there is one, or none uses the freedom, replace it with the concrete type and delete the generic it forces onto every signature and error. Every wrapper or helper - does it do more than forward to an existing one plus one injected argument? (5) Unreleased history: for every migration, compatibility shim, backfill or deprecation path, check whether the thing it migrates from was created on this same unreleased branch or version; if so, fold it into the original and delete the shim and its legacy-data tests. (6) Surface: for every new public item, who outside this repository calls it, and does the file convention re-export types from private modules rather than expose module paths? (7) Tests: every test-matrix axis and cross-implementation vector test - after the sibling changes, does the axis have more than one value, is there more than one implementation? Every test helper and case - is it implied by a sibling in the same module? Every divergence test - can the two sources still differ in the new data flow? Consistency with sibling code is not a justification: a mechanism the siblings use is still unjustified here when this consumer does not need it. When a generic or associated type is forced by one bound, ask which of the two should collapse - the container or the error - and prefer collapsing the one no implementation varies. Name the existing symbol, its location and version for every reuse you propose, and the consumer for every proportionality finding. A scope cut is a finding too, marked as such - the author decides it.";;
    clean-room)      echo "Do NOT read the diff first. Read the change description above (and, failing that, the changed-file list and the names of the tests it adds) and write down for yourself the smallest design that serves the named consumer: which existing types, methods, endpoints and framework or engine features it would use, and what it would not add. Only then read the diff. Report as findings every place the change is larger than your design, each naming the smaller design concretely (existing symbol, location, version) and what the extra machinery costs; where the change is as small as your design or smaller, say so. Put your five-line design in the summary.";;
    plan-completeness) echo "The plan states rules. For each rule, verify its list of sites, arms, realms, callers and copies by searching the code yourself; list every one the plan misses, with file:line. An incomplete list is the defect this gate exists to catch.";;
    plan-soundness)  echo "For each rule, find the case where applying it breaks behaviour or an invariant, and any two rules that interact or contradict. Read the code the rule touches, not just the plan.";;
    plan-simplicity) echo "For each rule, look for a simpler fix: an existing helper, type, hook, or path in this repository that already does the job (name it with its location), a smaller change with the same effect, or two rules that should be one. Prefer reuse over new mechanism.";;
    plan-tests)      echo "For each rule, decide whether the named test would fail without the fix and pass with it. If it would not, name the test that would. A rule with no failing test is unverified.";;
    correctness-boundaries) echo "Check logic, boundary inputs, partial failure, cleanup, and error contracts. Trace only the consumers needed to prove or refute a concrete failure.";;
    security-state-api) echo "Check trust boundaries, authorization, durable-state invariants, serialization, idempotency, compatibility, and public API behavior.";;
    concurrency-resources-performance) echo "Check ordering, cancellation, shared state, cleanup, backpressure, leaks, and pathological hot-path cost.";;
    tests-observability-maintenance-regression) echo "Check whether tests can fail for the named behavior, whether failures are diagnosable, whether the structure remains maintainable, and whether prior fixes introduced regressions.";;
    *)               echo "$1";;
  esac
}
lens_text() {
  local remaining=$1 bundle
  while :; do
    case "$remaining" in
      *+*) bundle=${remaining%%+*}; remaining=${remaining#*+};;
      *) bundle=$remaining; remaining="";;
    esac
    [ -n "$bundle" ] || { echo "$1"; return; }
    lens_one "$bundle"
    [ -n "$remaining" ] || return 0
  done
}
render_prompt() (
  set -e
  set -o pipefail
  PATCH_LINE_COUNT=0
  if [ -z "$EVIDENCE" ] && [ "$PATCH_AVAILABLE" = 1 ]; then
    PATCH_LINE_COUNT=$(awk 'END {print NR}' "$PATCH_ARTIFACT")
  fi
  if [ -z "$RO" ]; then
    echo '# Reviewer contract'
    if [ -n "${EVIDENCE_TMP:-}" ] && [ -s "$EVIDENCE_TMP" ]; then
      echo '## Required reads, in this order'
      echo 'Finish each step before the next. Do not search or open another file early.'
      python3 - "$EVIDENCE_TMP" <<'PY'
import sys
lines = open(sys.argv[1], encoding='utf-8').read().splitlines()
has_source_context_packets = any(line.startswith('Source context packet: ') for line in lines)
has_required_source_segments = any(line.startswith('Required source segment ') for line in lines)
prefixes = (
    'First assigned-patch action: ',
    'First source-context action: ',
    'Required source range: ',
    'Required post-index original-source target: ',
    'Required post-index original-source boundary: ',
    'Optional post-index original-source target: ',
)
index_prefix = 'Evidence navigation index: '
step = 1
for line in lines:
    if line.startswith(index_prefix):
        path = line[len(index_prefix):]
        if has_source_context_packets and has_required_source_segments:
            action = ('Read the complete evidence navigation index after all listed source-context '
                      'packets and required source segments, before opening or searching original '
                      'repository source: ' + path)
        elif has_source_context_packets:
            action = ('Read the complete evidence navigation index after all listed source-context '
                      'packets, before opening or searching original repository source: ' + path)
        elif has_required_source_segments:
            action = ('Read the complete evidence navigation index after all required source '
                      'segments, before opening or searching original repository source: ' + path)
        else:
            action = ('Read the complete evidence navigation index before opening or searching '
                      'original repository source: ' + path)
        print('%d. %s' % (step, action))
        step += 1
    elif line.startswith(prefixes):
        print('%d. %s' % (step, line))
        step += 1
print('%d. Searches return at most 80 lines. If more matches exist, narrow the pattern or the path and read the next page. Do not read an unbounded search result.' % step)
PY
      echo
    fi
    cat <<'EOC'
You are one independent reviewer on a read-only multi-model code review panel. Substantiate every claim yourself, finish every assigned check, combine sibling sites under one root cause, and return no more than five distinct findings.

- Read only inside the repository, exact review-session artifacts named in this prompt, document inputs listed in this prompt, and explicitly named pinned dependency roots. Do not read any other review-session artifact, user or global rules, memories, skills, caches, other checkouts, or unrelated files.
- Never edit files or run a command that changes the repository or its dependencies. Never run an interpreter or inline script (`node`, `python3`, `bash -c`, `eval`): the read-only policy refuses it. Test runners on existing files (`npx tsc --noEmit`, `cargo test`) are optional and read-only. If an optional test cannot start because its runner or dependency is missing, the package-manager cache is unavailable or unwritable, or runtime permissions block it, skip the test without installing or changing dependencies. Continue static review, report runtime validation as unverified, and finish the assigned review; this alone is not incomplete proof. This exception is only for optional test execution; unread assigned evidence or an exhausted review-call budget still requires an INCOMPLETE PROOF result. If tests execute and fail, report their results. If a claim can only be settled by running new code, keep the finding and say in the finding that it is unverified at runtime.
EOC
    if [ "$CLEAN_ROOM" = 1 ]; then
      echo '- Clean-room ordering: Do NOT read the diff first. For this lens, write the smallest design before any patch or source read.'
    fi
    echo
    echo '## Bounded evidence protocol'
    if [ "$CLEAN_ROOM" = 1 ]; then
      printf '1. After the required clean-room design, '
    else
      printf '1. First, begin with assigned-hunk discovery: '
    fi
    printf 'read every byte of the assigned patch using its rendered mode. '
    if [ "$PATCH_MODE" = chunks ]; then
      printf 'In chunk mode, obey the rendered patch chunk batch limit, reading only consecutive chunks in exact order and in full. A skipped, partial, or out-of-order chunk read fails your whole review. Do not repeat completed chunk reads.'
    else
      printf 'In window mode, use consecutive windows of at most %s lines until coverage is complete.' "$PROMPT_PATCH_READ_LINES"
      if [ "$ADAPTER" = codex ]; then
        printf ' For Codex, keep each assigned-patch window to at most %s lines, then continue at the next line. This is a ceiling, not a target: split further when needed to keep each response below the byte ceiling.' "$PROMPT_PATCH_READ_LINES"
      fi
    fi
    if [ "$HAS_PACKETS" = 1 ]; then
      printf ' Then read every listed source-context packet in full before source expansion. Treat each packet entry as exact original source at its recorded path and one-based lines.'
    fi
    echo
    printf '2. Locate the enclosing symbol or named section, then search definitions, direct references, related tests, and config gates.'
    [ -z "$EVIDENCE" ] || printf ' When `Source read required` is true, resolve every relevant omission with a bounded original-source read.'
    echo
    printf '3. Read the smallest useful line window around each match. '
    case "$ADAPTER" in
      agent|claude|cursor-agent)
        printf 'Every source Read call must set an explicit one-based `offset` and a `limit` of at most %s lines. Every Grep or search call must set a result limit of at most 80. ' "$PROMPT_SOURCE_READ_LINES";;
      cursor-sdk)
        printf 'Every source council_read call must set an explicit one-based `offset` and a `limit` of at most %s lines. ' "$PROMPT_SOURCE_READ_LINES";;
      codex) printf 'Every repository source window must be at most %s lines. ' "$PROMPT_SOURCE_READ_LINES";;
      *) printf 'Every source read_file call must select an explicit one-based start and at most %s lines. Every search call must set a result limit of at most 80. ' "$PROMPT_SOURCE_READ_LINES";;
    esac
    echo 'Only exact full-read artifacts and document inputs named in this prompt are exceptions.'
    if [ "$ADAPTER" = cursor-sdk ]; then
      echo '4. Use council_read for exact authorized paths. Omit offset and limit only for complete named artifacts and document inputs; read those in full. Use prepared sibling-search results and bounded source reads to locate related sites.'
    else
    printf '4. Shell commands that print source, diffs, or logs must select at most %s inclusive lines, so `END - START + 1 <= %s`. ' "$PROMPT_SOURCE_READ_LINES" "$PROMPT_SOURCE_READ_LINES"
    printf 'Shell searches across one or more files need a global `| head -80` limiter; at most 80 result lines are accepted. If it fills, narrow the path or pattern and continue with another bounded search. '
    printf 'Never compose a `head -81` search yourself. If a `Required cluster sibling search` below contains it, run that exact command unchanged; it is the sole plan-audit exception, and an 81st result invalidates that proof. Use `head -80` for every other search, then narrow and continue if more results are needed. '
    if [ -n "$EVIDENCE" ]; then
      printf 'An accidental 81st line gets no proof credit for that call and remains advisory only after every hard proof obligation is satisfied. '
    else
      printf 'An 81st line invalidates the audit. '
    fi
    cat <<'EOC'
`rg --max-count` alone is per file. Use portable byte-preserving `sed -n 'START,ENDp' 'FILE'` for source windows. Never put backticks or command substitutions in shell search patterns.
EOC
    if [ -n "$EVIDENCE" ]; then
      echo 'Do not use `nl -ba ... | sed`; its added prefixes change the bytes and give that call no proof credit. Repeat needed source with byte-preserving bounded reads. An overflowing search or transformed exploratory read alone does not invalidate the whole assignment once every hard proof obligation is satisfied. Hard audit failures remain invalid. Missing required patch, chunk, segment, packet or original-source proof remains invalid. Unsubstantiated finding citations remain invalid.'
    else
      echo 'Do not use `nl -ba ... | sed`; its added prefixes change the bytes, and a rejected call invalidates the audit.'
    fi
    cat <<'EOC'
`head` limits lines, not bytes: keep searches off generated or minified files such as `dist/`, where one line can pass the output ceiling. Read original source from the working tree; `git show` of the base or any other revision is context only and never satisfies a required read or a citation.
EOC
    fi
    if [ "$ADAPTER" = codex ]; then
      if [ "$PATCH_MODE" = chunks ]; then
        printf '5. Codex source batching is disabled; do not use a source-batch payload. Each source read is a separate tool call. Read each assigned-patch chunk artifact once, completely, and in exact order; do not split or reread chunk contents in line windows. Use at most %s lines for every repository source window. Aim for under 24 KiB per response and per ordinary turn; if a planned response or turn may exceed 24 KiB, narrow it before reading. Hard ceilings are 32 KiB per response and for an ordinary turn. Ordered proof phases may use their rendered 60 KiB turn budget, with each response below 32 KiB; source packets stay within their ordinary 32 KiB turn cap. Line limits do not limit bytes. ' "$PROMPT_SOURCE_READ_LINES"
      else
        printf '5. Codex source batching is disabled; do not use a source-batch payload. Each source read is a separate tool call. Use at most %s lines for every repository source window and at most %s lines for each assigned-patch window, splitting further into consecutive windows as needed. Aim for under 24 KiB per response and per ordinary turn; if a planned response or turn may exceed 24 KiB, narrow it before reading. Hard ceilings are 32 KiB per response and for an ordinary turn. Ordered proof phases may use their rendered 60 KiB turn budget, with each response below 32 KiB; source packets stay within their ordinary 32 KiB turn cap. Line limits do not limit bytes. ' "$PROMPT_SOURCE_READ_LINES" "$PROMPT_PATCH_READ_LINES"
      fi
    else
      printf '5. Keep ordinary tool turns within 32 KiB combined output; follow the rendered ordered-proof read count and 60 KiB limit when that evidence phase is active. '
    fi
    if [ -n "$EVIDENCE" ]; then
      printf 'Ordered '
      [ "$PATCH_MODE" != chunks ] || printf 'patch-chunk, '
      [ "$HAS_SEGMENTS" != 1 ] || printf 'required-source-segment, '
      printf 'evidence-index phases may advance in one turn using at most the rendered proof read limit and a 60 KiB combined output ceiling. '
      if [ "$HAS_PACKETS" = 1 ]; then printf 'Source-context packets and repository reads keep the ordinary 32 KiB turn ceiling, and '; fi
      printf 'repository expansion begins in a later turn. '
    fi
    if [ "$ADAPTER" = cursor-sdk ]; then
      echo 'Keep each council_read call to one path and obey the rendered read batch limits.'
    else
      echo 'Keep each shell tool call to one producer pipeline. Never mix source reads and searches in one shell call. For Codex, two bounded reads are still two calls: `sed -n 1102,1102p repo.test.ts && sed -n 193,193p repo.migration.test.ts` is invalid. Issue separate shell calls; batching means separate calls in one turn, never `&&` or `;` in one shell command.'
      if [ "$ADAPTER" = codex ]; then
        cat <<'EOC'
For Codex source reads, use one path and one contiguous range per call; use a separate call for every other path or range. Safe examples: `sed -n '40,75p' 'src/file.ts'` and `rg -n -F 'symbolName' 'src/path' | head -80`. Do not combine source files or ranges with `&&` or `;`.
For shell searches, prefer simple fixed-string patterns such as `rg -n -F 'aria-checked' src | head -80`; avoid mixing single- and double-quoted fragments. If a pattern needs both quote types, search a stable literal such as the attribute name with `-F`. An unmatched quote invalidates the read audit, even if a later query succeeds.
EOC
      fi
    fi
    printf '%s' "6. Expand to another bounded block, file, or pinned dependency only to answer a concrete question that could prove or refute a finding. Name the concrete symbol or invariant question in your reasoning, never as a comment inside the command, then make the tool call that bounded window."
    if [ -n "$DEPS_ROOT" ]; then printf ' Read pinned dependency source only under %s.' "$DEPS_ROOT"; fi
    echo
    printf '7. Stop that evidence path when the question is answered. Finish every assigned check and expand again when evidence is insufficient; never treat '
    [ -z "$EVIDENCE" ] || printf 'the navigation index or '
    echo 'a summary as proof.'
    if [ -n "$EVIDENCE" ]; then printf '8. After the evidence index, '; else printf '8. After assigned-patch discovery, '; fi
    printf 'use at most %s repository tool calls. Finish required reads by call %s; start no new evidence path after call %s and reserve calls %s-%s for refutation and citations, then return the required JSON.\n\n' \
      "$CALL_LIMIT" "$REFUTATION_START" "$REFUTATION_START" "$((REFUTATION_START + 1))" "$CALL_LIMIT"
    echo '## Evidence and output'
    printf '%s' '- Every finding names a file and lines you opened yourself. Its cited range must intersect '
    if [ "$HAS_PACKETS" = 1 ]; then printf 'a source-context packet range you opened or '; fi
    cat <<'EOC'
an audited original source range from a bounded source read. Search results, navigation summaries, and patches do not establish citation coverage. `evidence` states what the source shows.
- Try to refute each candidate. `confidence` is your honest probability that it remains real.
- P0: incorrect behavior, security hole, data loss, or crash. P1: reachable bug, edge case, or broken contract. P2: maintainability, performance, missing test, or unclear API. P3: trivial style, naming, or comment issue.
- One strong finding beats several weak ones. No style findings unless P3 and trivial.
- `suggested_fix` states the general rule, every sibling site or branch it covers, and the test that would fail without it.
- Before starting another tool call, reserve capacity to return the required JSON. If only the final response fits, stop using tools and return an empty `findings` array with a `summary` beginning `INCOMPLETE PROOF:` and naming the unfinished obligations. Such a result is never review-complete.
- Return only the JSON object required by the runner. If the change is sound, return an empty `findings` array and say so in `summary`.
EOC
    echo
    echo "## Review assignment"
  else
    echo "You are one of several independent reviewers on a multi-model review panel. Others review the same documents on different models; your value is what you can substantiate yourself. Follow the scope and lens below, combine sibling issues under one root cause, and return no more than five distinct findings."
    echo
  fi
  if [ "$ADAPTER" = cursor-sdk ]; then
    echo 'Available evidence tool: council_read on custom-user-tools, with path and optional offset and limit. MCP metadata discovery is permitted only for that reader. Shell, search, execution, native file tools, web and delegation are unavailable. Resolve questions with prepared evidence and bounded reads; state unverified runtime claims explicitly.'
    echo 'Read each listed patch chunk, source-context packet, required source segment and evidence index as a complete artifact using only the path argument, without offset or limit. The chunk byte spans and segment raw-byte counts below describe their complete prepared contents. A prepared artifact can end inside a source line, declaration or diff hunk; that boundary is its actual EOF, not a truncated delivery.'
    echo 'A successful path-only council_read returns the whole artifact. Continue to the next assigned artifact instead of probing its tail or EOF, repeating a completed chunk, or trying to complete the declaration at its boundary. Explicit offset and limit apply to bounded original-source reads, not to these complete artifacts. If delivery reports an error or truncation, return INCOMPLETE PROOF rather than treating partial reads as completion.'
    echo
  fi
  if [ "$ADAPTER" = codex ] && [ -z "$RO" ]; then
    CODEX_SOURCE_BATCH=${REV_CODEX_SOURCE_BATCH:-0}
    case "$CODEX_SOURCE_BATCH" in
      0) ;;
      1) die "REV_CODEX_SOURCE_BATCH=1 is retired; use standalone bounded source reads";;
      *) die "REV_CODEX_SOURCE_BATCH must be 0 or 1";;
    esac
    echo "Codex source batching enabled: false"
    echo
  fi
  echo "## Scope"
  if [ -n "$RO" ]; then
    echo "Documents to review (read them in full):"; sed 's/^/- /' "$RO"; echo
    echo "In findings, \`file\` is the document path and \`line_start\`/\`line_end\` are lines in that document."; echo
  else
    echo "Repository: $REV_ROOT"
    echo "Base commit: $REV_BASE (branch \`$REV_BRANCH\`, default branch \`$REV_DEFAULT\`)"
    if [ -n "$REV_PR_NUMBER" ]; then
      echo "Bound pull request: #$REV_PR_NUMBER (head $REV_PR_HEAD, base branch \`$REV_BASE_BRANCH\` at $REV_PR_BASE_HEAD)"
    fi
    if [ -n "$EVIDENCE" ]; then
      echo "Prepared review scope:"
      cat "$EVIDENCE_TMP"
      echo "Do not generate a live diff from the current worktree."
    else
      if [ "$PATCH_AVAILABLE" = 1 ]; then
        echo "Exact frozen assigned patch: $PATCH_ARTIFACT"
        echo "Assigned patch line count: $PATCH_LINE_COUNT"
        case "$ADAPTER" in
          codex)
            echo "$FIRST_EVIDENCE: run portable bounded sed windows over $PATCH_ARTIFACT from line 1 through line $PATCH_LINE_COUNT, then stop."
            ;;
          agent|claude|cursor-agent)
            echo "$FIRST_EVIDENCE: use Read to read the exact frozen assigned patch $PATCH_ARTIFACT in consecutive windows of at most $PROMPT_PATCH_READ_LINES lines, from line 1 through line $PATCH_LINE_COUNT, then stop."
            ;;
          cursor-sdk)
            echo "$FIRST_EVIDENCE: use council_read to read the exact frozen assigned patch $PATCH_ARTIFACT in consecutive windows of at most $PROMPT_PATCH_READ_LINES lines, from line 1 through line $PATCH_LINE_COUNT, then stop."
            ;;
          *)
            echo "$FIRST_EVIDENCE: use read_file to read the exact frozen assigned patch $PATCH_ARTIFACT in consecutive windows of at most $PROMPT_PATCH_READ_LINES lines, from line 1 through line $PATCH_LINE_COUNT, then stop."
            ;;
        esac
        echo "Do not generate a live diff from the current worktree."
        echo "The frozen patch contains committed, staged, unstaged, and listed untracked changes against the pinned base."
      else
        case "$REV_SCOPE" in
          uncommitted) echo "Produce the diff yourself: \`git diff\` and \`git diff --cached\` in $REV_ROOT, plus \`git status --porcelain\` for untracked files.";;
          branch)      echo "Produce the diff yourself: \`git diff $REV_BASE\` in $REV_ROOT (committed, staged and unstaged work, all against the pinned base).";;
          *)           echo "Produce the diff yourself: \`git diff $REV_BASE -- $REV_SCOPE\` in $REV_ROOT.";;
        esac
      fi
      echo "Changed files:"
      if [ "$SHOW_UNTRACKED" = 1 ]; then
        awk 'NR==FNR{u[$0]=1;next} {printf "- %s%s\n", $0, ($0 in u ? " (untracked)" : "")}' "$S/untracked.txt" "$S/files.txt" 2>/dev/null
        if [ "$PATCH_AVAILABLE" = 0 ]; then
          echo
          echo "Files marked (untracked) do not appear in \`git diff\`; read them in full."
        fi
      else
        sed 's/^/- /' "$S/files.txt" 2>/dev/null
      fi
    fi
    echo
  fi
  if [ -z "$RO" ]; then
    if [ -n "$EVIDENCE" ] && [ -s "$INSTRUCTIONS" ]; then
      echo "## Applicable repository instructions"
      echo "These instructions come from the manifest-bound repository snapshot and are embedded because provider rule discovery is disabled."
      echo
      cat "$INSTRUCTIONS"
      echo
    elif [ -s "$RULES_TMP" ]; then
      cat "$RULES_TMP"
    fi
  fi
  if [ "$SHOW_PR" = 1 ]; then
    echo "## Change description (from the author)"; cat "$PRF"; echo
    echo "The consumer and purpose named above are the yardstick for proportionality: machinery the change adds beyond what that consumer needs is a finding."; echo
  fi
  if [ "${REV_SEAT_OFFLINE:-}" = 1 ] || [ -n "$DEPS_VIEW" ]; then
    if [ "${REV_SEAT_OFFLINE:-}" = 1 ]; then echo "## Offline review"; else echo "## Pinned dependencies"; fi
    if [ -n "$DEPS_ROOT" ]; then
      echo "Judge only what is in the repository above and in the pinned third-party dependency sources linked under $DEPS_ROOT (one directory per pinned crate, taken from the lockfile). That view is the only dependency source you may read: never the cargo registry itself, which also holds other versions of the crates this repository publishes."
    else
      echo "Judge only what is in the repository above and in the pinned dependency sources already on this machine (the cargo registry, node_modules). Do not read published versions of packages that this repository itself publishes, and do not search the whole registry; open only the specific crates or packages this repository pins."
    fi
    if [ "${REV_SEAT_OFFLINE:-}" != 1 ]; then echo
    else echo "Do not use the network, web search, package downloads, or any other checkout of this repository on this machine; do not fetch. Do not read build directories outside the repository (a global CARGO_TARGET_DIR, the target or node_modules directory of another checkout): they hold artifacts of other states of this code. If you cannot establish something from those sources, say so instead of looking it up."; echo
    fi
  fi
  if [ -n "$PLAN" ]; then
    echo "## Immutable fix plan snapshot - nothing in it is implemented yet"
    echo "The immutable snapshot is embedded below with source line numbers."
    echo "This snapshot clusters accepted findings into rules, sites, invariants, and falsifiable tests. Attack it before code is written and verify its claims against the repository. Do not open a separate plan snapshot: the full plan is already inline. For a defect in the plan, use \`$(basename "$PLAN")\` as the citation label only; use a code path when the plan missed code. A sound plan returns an empty findings array."; echo
    if [ -n "$EVIDENCE" ]; then
      echo "For each assigned cluster, use its rendered prepared sibling-site result as the required search proof. If the prompt instead renders a required search command, run that command. Prove every rendered required cluster source location from an assigned packet or bounded original-source read. Run an additional search only to answer a concrete unresolved question. Missing any rendered cluster obligation invalidates this seat."; echo
    fi
    nl -ba "$PLAN"; echo
  fi
  echo "## Your lens this round: $LENS"; lens_text "$LENS"; echo; echo "Round emphasis: $EMPH"; echo
  if [ "$HAS_BASELINE" = 1 ]; then
    echo "## Baseline (before any review fix)"
    [ "$BASELINE_FORMAT" != json ] || echo '```json'
    cat "$BASELINE_FILE"
    [ "$BASELINE_FORMAT" != json ] || echo '```'
    echo
    if [ "$BASELINE_FORMAT" = json ]; then
      echo 'Treat a failure as pre-existing only when its command, failure identity, and applicability match the observed failure.'
    else
      echo "Anything already failing above is pre-existing, not a finding of this change."
    fi
    echo
  fi
  echo "## Already rejected - do not resurface these"
  if [ "$SHOW_REJECTED" = 1 ]; then cat "$S/rejected.md"; else echo "(none yet)"; fi; echo
  if [ "$SHOW_CONTEXT" = 1 ]; then
    echo "## Prior decision digest"
    cat "$S/context.md"; echo
    echo "Use this digest only to avoid duplicate work. Never infer that an uncited area was already reviewed."; echo
  fi
  if [ "$VAC" = 1 ]; then
    cat <<'EOV'
## Vacuity check (tests are touched)
Check every assertion the diff adds or edits for VACUITY: would it still pass if the behaviour it names were deleted? For each new or changed test, name the production change that would make it fail; report any test that has none as a P1 with lens `tests`. Watch for: `.all()`/`.every()` over a possibly-empty query; a before/after measurement read from an accessor that returns a copy; a test recomputing its expected value via the path under test; `expect.anything()` in the slot holding the new argument; a success path that never executes; arguments in the wrong order so the test never ran.

EOV
  fi
  echo "## Runner schema"
  if [ "$INLINE_SCHEMA" = 1 ]; then
    echo '```json'; cat "$SCHEMA"; echo '```'
  fi
)
SEAT_MS=(); VALIDATE_ARGS=()
for i in "${!SEATS[@]}"; do
  [ -z "$PANEL" ] || SEAT_STARTED=$(now_ms) || die "cannot read the clock"
  SEAT=${SEATS[$i]}; LENS=${LENSES[$i]}; EMPH=${EMPHASES[$i]}; ADAPTER=${ADAPTERS[$i]}; OUT=${OUTS[$i]}
  PROMPT_PATCH_READ_LINES=$READ_LINES
  PROMPT_SOURCE_READ_LINES=$READ_LINES
  if [ "$ADAPTER" = codex ]; then
    PROMPT_PATCH_READ_LINES=$CODEX_READ_LINES
    PROMPT_SOURCE_READ_LINES=$CODEX_SOURCE_READ_LINES
  fi
  PATCH_MODE=${PATCH_MODES[$i]}; HAS_PACKETS=${PACKET_MODES[$i]}; HAS_SEGMENTS=${SEGMENT_MODES[$i]}
  CALL_LIMIT=${CALL_LIMITS[$i]}; REFUTATION_START=${MANDATORY_LIMITS[$i]}
  CLEAN_ROOM=0; FIRST_EVIDENCE='First evidence action'
  case "+$LENS+" in *+clean-room+*) CLEAN_ROOM=1; FIRST_EVIDENCE+=' after required clean-room design';; esac
  case "$ADAPTER" in agent|cursor-agent|gemini|cursor-sdk) INLINE_SCHEMA=1;; *) INLINE_SCHEMA=0;; esac
  [ "$PHASE" != verification ] || EMPH="${EMPH:+$EMPH }$SIBLING_SITE_CHECK"
  if [ -n "$FRAGMENTS" ]; then
    EVIDENCE_TMP="$FRAGMENTS/$SEAT"
    [ -s "$EVIDENCE_TMP" ] || die "empty evidence fragment for $SEAT from $EVIDENCE"
  fi
  TMP=$(mktemp "$S/.rev-prompt.XXXXXX") || die "cannot create temporary prompt in $S"
  TMPS+=("$TMP")
  render_prompt > "$TMP"
  RENDER_RC=$?
  [ "$RENDER_RC" = 0 ] || die "cannot render prompt: $OUT"
  WORDS=$(wc -w < "$TMP" | tr -d ' ') || die "cannot measure prompt: $OUT"
  if [ -n "$PLAN" ]; then KIND=plan; LIMIT=3000; else KIND=code; LIMIT=1800; fi
  if [ "$WORDS" -gt "$LIMIT" ]; then
    echo "rev-prompt: WARNING: $KIND prompt has $WORDS words and exceeds $LIMIT words" >&2
  fi
  if [ -n "$EVIDENCE" ] && [ -n "$PANEL" ]; then
    VALIDATE_ARGS+=(--seat "$SEAT" --prompt "$TMP")
  elif [ -n "$EVIDENCE" ]; then
    EVIDENCE_CHECK_TMP=$(mktemp "$S/.rev-evidence-fragment.XXXXXX") \
      || die "cannot create evidence recheck fragment in $S"
    render_evidence > "$EVIDENCE_CHECK_TMP"
    EVIDENCE_RC=$?
    [ "$EVIDENCE_RC" = 0 ] || die "evidence changed while rendering prompt: $EVIDENCE"
    cmp -s -- "$EVIDENCE_TMP" "$EVIDENCE_CHECK_TMP" \
      || die "evidence changed while rendering prompt: $EVIDENCE"
    python3 "$HERE/lib/review-read-audit.py" validate-prompt \
      --root "$REV_ROOT" --session "$S" --manifest "$EVIDENCE" --seat "$SEAT" \
      --prompt "$TMP" >/dev/null \
      || die "rendered prompt does not match its evidence assignment: $SEAT"
  fi
  if [ -n "$PANEL" ]; then
    SEAT_DONE=$(now_ms) || die "cannot read the clock"
    SEAT_MS+=("$SEAT" "$((SEAT_DONE - SEAT_STARTED))")
  fi
done
if [ -n "$PANEL" ]; then
  if [ -n "$EVIDENCE" ]; then
    # Validates the manifest once, freshly, and binds every prompt to the hash its fragment was rendered from.
    python3 "$HERE/lib/review-read-audit.py" validate-prompt \
      --root "$REV_ROOT" --session "$S" --manifest "$EVIDENCE" "${VALIDATE_ARGS[@]}" >/dev/null \
      || die "rendered prompts do not match their evidence assignments: ${SEATS[*]}"
  fi
  TIMING_TMP=$(mktemp "$S/.rev-render.XXXXXX") || die "cannot create render timing in $S"
  python3 - "$TIMING_TMP" "$PANEL_STARTED" "${SEAT_MS[@]}" <<'PY' || die "cannot record render timing: $RENDER_OUT"
import json, sys, time
path, started, pairs = sys.argv[1], int(sys.argv[2]), sys.argv[3:]
seats = {seat: int(ms) for seat, ms in zip(pairs[0::2], pairs[1::2])}
with open(path, 'w', encoding='utf-8') as stream:
    json.dump({'schema_version': 1, 'seats': seats,
               'total_ms': time.time_ns() // 1000000 - started}, stream)
    stream.write('\n')
PY
  mv -f -- "$TIMING_TMP" "$RENDER_OUT" || die "cannot publish render timing: $RENDER_OUT"
  TIMING_TMP=""
fi
for i in "${!SEATS[@]}"; do
  mv -f -- "${TMPS[$i]}" "${OUTS[$i]}" || die "cannot publish prompt: ${OUTS[$i]}"
done
PUBLISHED=1
printf '%s\n' "${OUTS[@]}"
