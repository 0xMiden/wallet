#!/usr/bin/env python3
"""Summarize prompt size, result yield, and terminal provider usage."""

import argparse
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
from pathlib import Path

LIB_DIR = Path(__file__).resolve().parent / "lib"
if str(LIB_DIR) not in sys.path:
    sys.path.insert(0, str(LIB_DIR))
from usage import USAGE_FIELDS, add_usage, empty_usage, host_usage, reviewer_streams
from roster import cursor_sdk_identity


REVIEW_ARTIFACT = re.compile(r"^r[A-Za-z0-9][A-Za-z0-9_.-]*-")
RENDER_TIMING = re.compile(r"^r([A-Za-z0-9][A-Za-z0-9_.-]*)-render\.json$")
VALIDATOR = Path(__file__).resolve().parent / "lib" / "validate-findings.py"
EVIDENCE_SCRIPT = Path(__file__).resolve().parent / "rev-evidence.py"


def session_directory(value):
    path = Path(value).expanduser()
    try:
        resolved = path.resolve(strict=True)
    except OSError as error:
        raise argparse.ArgumentTypeError(
            f"{value}: session directory does not exist or cannot be resolved"
        ) from error
    if not resolved.is_dir():
        raise argparse.ArgumentTypeError(f"{value}: session path is not a directory")
    if not os.access(resolved, os.R_OK | os.X_OK):
        raise argparse.ArgumentTypeError(f"{value}: session directory is not readable and traversable")
    return resolved


def host_log_path(value):
    path = Path(value).expanduser()
    try:
        resolved = path.resolve(strict=True)
    except OSError as error:
        raise argparse.ArgumentTypeError(f"{value}: host log does not exist or cannot be resolved") from error
    if not resolved.is_file() or not os.access(resolved, os.R_OK):
        raise argparse.ArgumentTypeError(f"{value}: host log is not a readable file")
    return resolved


def session_streams(directory):
    adapters, _, _ = roster_metadata(directory)
    return [(path, adapter_for_key(artifact_key(path), adapters))
            for path in sorted(directory.glob("*.stream.*")) if artifact_key(path) is not None]


def is_plan(path):
    name = path.name.lower()
    if re.match(r"^r\d+x-", name):
        return False
    if re.match(r"^r\d+pf?-", name):
        return True
    return re.match(r"^r\d+-plan-", name) is not None


def artifact_key(path):
    name = path.name
    if ".stream." in name:
        name = name.split(".stream.", 1)[0]
    elif name.endswith(".prompt.md"):
        name = name[:-len(".prompt.md")]
    else:
        name = path.stem
    return name if REVIEW_ARTIFACT.match(name) else None


def roster_metadata(directory):
    path = directory / "roster.json"
    try:
        path.lstat()
    except FileNotFoundError:
        return {}, 0, {}
    except OSError:
        return {}, 1, {}
    try:
        document = json.loads(path.read_text(errors="replace"))
    except (OSError, ValueError):
        return {}, 1, {}
    if not isinstance(document, dict):
        return {}, 1, {}
    adapters = {}
    for item in document.get("seats", []):
        if isinstance(item, dict) and item.get("seat") and item.get("adapter"):
            adapters[str(item["seat"])] = str(item["adapter"])
    if "result_receipts" not in document:
        return adapters, 0, {}
    receipts = document["result_receipts"]
    if not isinstance(receipts, dict):
        return adapters, 1, {}
    version = receipts.get("version")
    legacy = receipts.get("legacy_no_exit_sha256")
    if (not isinstance(version, int) or isinstance(version, bool) or version < 1
            or not isinstance(legacy, dict)
            or not all(isinstance(name, str) and isinstance(digest, str)
                       and re.fullmatch(r"[0-9a-fA-F]{64}", digest) is not None
                       for name, digest in legacy.items())):
        return adapters, 1, {}
    return adapters, version, {name: digest.lower() for name, digest in legacy.items()}


def roster_identity(directory):
    path = directory / "roster.json"
    try:
        document = json.loads(path.read_text(errors="replace"))
    except (OSError, ValueError):
        return {"signature": "unavailable", "complete": False, "core_seats": []}
    if not isinstance(document, dict) or not isinstance(document.get("seats"), list):
        return {"signature": "unavailable", "complete": False, "core_seats": []}
    core_seats = []
    complete = True
    for item in document["seats"]:
        if not isinstance(item, dict) or item.get("extra") is True:
            continue
        fields = {}
        for key in ("seat", "adapter", "model", "effort"):
            value = item.get(key)
            if key == "effort" and item.get("adapter") == "gemini" \
                    and key in item and value is None:
                fields[key] = "none"
            else:
                fields[key] = value if isinstance(value, str) and value else "?"
        complete = complete and all(fields[key] != "?" for key in fields)
        substitute = item.get("substitutes_for")
        if isinstance(substitute, str) and substitute:
            fields["substitutes_for"] = substitute
        if item.get("adapter") == "cursor-sdk":
            try:
                fields.update(cursor_sdk_identity(item))
            except (ValueError, TypeError, KeyError):
                complete = False
        core_seats.append(fields)
    if not core_seats:
        return {"signature": "unavailable", "complete": False, "core_seats": []}
    signature = ",".join(
        "%s=%s:%s@%s%s%s" % (
            item["seat"], item["adapter"], item["model"], item["effort"],
            "[for=%s]" % item["substitutes_for"] if "substitutes_for" in item else "",
            "[sdk=%s]" % hashlib.sha256(json.dumps(
                {key: item[key] for key in ("model_selection", "cursor_sdk")},
                sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            if "cursor_sdk" in item else "",
        )
        for item in core_seats
    )
    return {"signature": signature, "complete": complete, "core_seats": core_seats}


def adapter_for_key(key, adapters):
    matches = (seat for seat in adapters if key.endswith("-" + seat))
    seat = max(matches, key=len, default=None)
    return adapters.get(seat) if seat else None


def empty_provider():
    item = empty_usage()
    item.update({"completed_calls": 0, "metered_calls": 0, "unmetered_calls": 0})
    return item


def empty_scope_projection(with_names=True):
    return {
        "valid_manifests": 0,
        "invalid_manifests": [] if with_names else 0,
        "full_words": 0,
        "assigned_patch_words": 0,
        "delta_words": 0,
        "evidence_words": 0,
        "source_context_words": 0,
        "avoided_words": 0,
        "plan_words": 0,
        "closure_words": 0,
        "prepared_search_words": 0,
        "plan_specialist_patch_words": 0,
        "receipt_relative_plan_manifests": 0,
        "cumulative_plan_manifests": 0,
    }


def seat_models(directory):
    path = directory / "roster.json"
    models = {}
    try:
        document = json.loads(path.read_text(errors="replace"))
    except (OSError, ValueError):
        return models
    seats = document.get("seats") if isinstance(document, dict) else None
    if not isinstance(seats, list):
        return models
    for item in seats:
        if not isinstance(item, dict) or not isinstance(item.get("seat"), str):
            continue
        model = item.get("model")
        models[item["seat"]] = model if isinstance(model, str) and model else "unknown"
    return models


def result_summary(path):
    try:
        document = json.loads(path.read_text(errors="replace"))
    except (OSError, ValueError):
        return None
    summary = document.get("summary") if isinstance(document, dict) else None
    return summary if isinstance(summary, str) else None


def seat_yield(directory):
    """Usable, invalid, and incomplete seat runs, with failure codes by model."""
    models = seat_models(directory)
    rows = {}
    for path in sorted(directory.glob("r*-*.exit")):
        stem = path.name[:-len(".exit")]
        body = stem[1:] if stem.startswith("r") else ""
        seat = next((name for name in sorted(models, key=len, reverse=True)
                     if body.endswith("-" + name)), None)
        if seat is None:
            continue
        model = models[seat]
        try:
            exit_code = int(path.read_text().strip().split()[0])
        except (OSError, ValueError, IndexError):
            exit_code = None
        result_path = directory / (stem + ".json")
        invalid_path = directory / (stem + ".audit-invalid.json")
        audit_path = directory / (stem + ".read-audit.json")
        summary = result_summary(result_path) or result_summary(invalid_path)
        incomplete = isinstance(summary, str) and summary.startswith("INCOMPLETE PROOF")
        audit = None
        if audit_path.is_file():
            try:
                loaded = json.loads(audit_path.read_text(errors="replace"))
            except (OSError, ValueError):
                loaded = None
            if isinstance(loaded, dict):
                audit = loaded
        salvaged = bool(audit and audit.get("citation_reaudit") is True and exit_code == 0
                        and result_path.is_file() and not incomplete)
        if incomplete:
            kind = "incomplete_proof"
        elif salvaged:
            kind = "salvaged"
        elif invalid_path.is_file() or (audit and audit.get("status") == "invalid"):
            kind = "audit_invalid"
        elif exit_code == 0 and result_path.is_file():
            kind = "usable"
        else:
            kind = "no_result"
        row = rows.setdefault(model, {
            "runs": 0, "usable": 0, "audit_invalid": 0, "incomplete_proof": 0,
            "salvaged": 0, "no_result": 0, "codes": {},
        })
        row["runs"] += 1
        row[kind] += 1
        if audit and kind in ("audit_invalid", "salvaged"):
            recorded = audit.get("violations") if kind == "audit_invalid" else audit.get("advisories")
            if isinstance(recorded, list):
                for item in recorded:
                    code = item.get("code") if isinstance(item, dict) else None
                    if isinstance(code, str) and code:
                        row["codes"][code] = row["codes"].get(code, 0) + 1
    return rows


def format_seat_yield(rows):
    lines = []
    for model in sorted(rows):
        row = rows[model]
        codes = ",".join("%s:%d" % item for item in sorted(row["codes"].items())) or "-"
        lines.append(
            "seat_yield model=%s runs=%d usable=%d audit_invalid=%d incomplete_proof=%d salvaged=%d no_result=%d codes=%s"
            % (model, row["runs"], row["usable"], row["audit_invalid"], row["incomplete_proof"],
               row["salvaged"], row["no_result"], codes)
        )
    return lines


def empty_read_activity(with_names=True):
    return {
        "audits": 0,
        "violating_audits": 0,
        "advisories": 0,
        "invalid_audits": [] if with_names else 0,
        "tool_calls": 0,
        "tool_turns": 0,
        "tool_output_bytes": 0,
        "max_tool_output_bytes": 0,
        "recognized_tool_calls": 0,
        "source_read_calls": 0,
        "source_read_batches": 0,
        "packet_shards": 0,
        "packet_bytes": 0,
        "packet_ranges": 0,
        "opened_source_ranges": 0,
        "finding_citations": 0,
        "patch_proof_calls": 0,
        "patch_proof_turns": 0,
        "patch_proof_visible_bytes": 0,
        "expected_patch_chunks": 0,
        "opened_patch_chunks": 0,
        "window_seats": 0,
        "chunk_seats": 0,
    }


def read_activity(directory, adapters):
    activity = empty_read_activity()
    metric_fields = ("tool_calls", "tool_turns", "tool_output_bytes", "max_tool_output_bytes")
    source_fields = (
        "recognized_tool_calls", "source_read_calls", "source_read_batches", "packet_shards", "packet_bytes",
        "packet_ranges", "opened_source_ranges", "finding_citations",
    )
    for path in sorted(directory.glob("r*-*.read-audit.json")):
        try:
            audit = json.loads(path.read_text())
            if not isinstance(audit, dict):
                raise ValueError("read audit must be an object")
            stem = path.name[:-len(".read-audit.json")]
            prompt = directory / (stem + ".prompt.md")
            stream_candidates = [
                candidate for candidate in (
                    directory / (stem + ".stream.ndjson"),
                    directory / (stem + ".stream.jsonl"),
                ) if candidate.is_file()
            ]
            version = audit.get("schema_version")
            values = [audit.get(field) for field in metric_fields]
            advisories = audit.get("advisories", [])
            if (version not in (1, 2)
                    or audit.get("status") not in ("valid", "invalid")
                    or not isinstance(audit.get("narrow"), bool)
                    or not isinstance(audit.get("adapter"), str) or not audit["adapter"]
                    or not isinstance(audit.get("violations"), list)
                    or not isinstance(advisories, list)
                    or any(not isinstance(item, dict) or set(item) != {"code", "tool"}
                           or not isinstance(item.get("code"), str) or not item["code"]
                           or not isinstance(item.get("tool"), str) or not item["tool"]
                           for item in advisories)
                    or any(not isinstance(value, int) or isinstance(value, bool) or value < 0
                           for value in values)):
                raise ValueError("invalid read audit structure")
            if ((audit["status"] == "valid") != (audit["violations"] == [])
                    or audit["tool_turns"] > audit["tool_calls"]
                    or audit["max_tool_output_bytes"] > audit["tool_output_bytes"]):
                raise ValueError("inconsistent read audit metrics")
            if version == 2:
                source_values = [audit.get(field, 0) for field in source_fields]
                ranges = audit.get("source_ranges")
                if (any(not isinstance(value, int) or isinstance(value, bool) or value < 0
                        for value in source_values)
                        or audit["recognized_tool_calls"] > audit["tool_calls"]
                        or audit["source_read_calls"] > audit["recognized_tool_calls"]
                        or audit.get("source_read_batches", 0) > audit["source_read_calls"]
                        or not isinstance(ranges, list)
                        or any(not isinstance(row, dict) or set(row) != {
                            "path", "line_start", "line_end", "origin"
                        } or not isinstance(row["path"], str) or not row["path"]
                            or type(row["line_start"]) is not int or type(row["line_end"]) is not int
                            or row["line_start"] < 1 or row["line_end"] < row["line_start"]
                            or row["origin"] not in ("packet", "tool") for row in ranges)
                        or audit["packet_ranges"] < sum(row["origin"] == "packet" for row in ranges)
                        or audit["opened_source_ranges"] != sum(row["origin"] == "tool" for row in ranges)):
                    raise ValueError("invalid source evidence audit structure")
                result = directory / (stem + ".json")
                result_hash = audit.get("result_sha256")
                if not isinstance(result_hash, str) or re.fullmatch(r"[0-9a-f]{64}", result_hash) is None:
                    raise ValueError("read audit result hash mismatch")
                findings = None
                if result.is_file():
                    if result_hash != hashlib.sha256(result.read_bytes()).hexdigest():
                        raise ValueError("read audit result hash mismatch")
                    try:
                        findings = json.loads(result.read_text()).get("findings")
                    except (OSError, ValueError, AttributeError) as error:
                        raise ValueError("invalid audited result") from error
                elif audit["status"] == "valid":
                    raise ValueError("read audit result hash mismatch")
                plan_citations = audit.get("plan_citation_ranges", [])
                plan_finding_citations = audit.get("plan_finding_citations", 0)
                plan_artifact_sha256 = audit.get("plan_artifact_sha256")
                finding_coverage = audit["finding_citations"] + plan_finding_citations
                if (type(plan_finding_citations) is not int or plan_finding_citations < 0
                        or not isinstance(plan_citations, list)
                        or len(plan_citations) != plan_finding_citations
                        or any(not isinstance(row, dict) or set(row) != {"line_start", "line_end"}
                               or type(row["line_start"]) is not int or type(row["line_end"]) is not int
                               or row["line_start"] < 1 or row["line_end"] < row["line_start"]
                               for row in plan_citations)
                        or (findings is not None and not isinstance(findings, list))
                        or (audit["status"] == "valid" and finding_coverage != len(findings))
                        or (audit["status"] == "invalid" and findings is not None
                            and finding_coverage > len(findings))):
                    raise ValueError("read audit finding coverage mismatch")
                packet_rows = sum(row["origin"] == "packet" for row in ranges)
                assigned_ranges = None
                manifest_hash = audit.get("evidence_manifest_sha256")
                if manifest_hash is not None:
                    if not isinstance(manifest_hash, str) or re.fullmatch(r"[0-9a-f]{64}", manifest_hash) is None:
                        raise ValueError("invalid read audit manifest hash")
                    manifests = [candidate for candidate in directory.glob("r*-evidence.manifest.json")
                                 if hashlib.sha256(candidate.read_bytes()).hexdigest() == manifest_hash]
                    if len(manifests) != 1:
                        raise ValueError("read audit manifest hash mismatch")
                    manifest = json.loads(manifests[0].read_text())
                    seat = max((name for name in adapters if stem.endswith("-" + name)), key=len, default=None)
                    context = manifest.get("source_context", {})
                    if not isinstance(context, dict) or not isinstance(context.get("seats", {}), dict):
                        raise ValueError("invalid source evidence audit structure")
                    seat_context = context.get("seats", {}).get(seat, {})
                    if not isinstance(seat_context, dict):
                        raise ValueError("invalid source evidence audit structure")
                    shards = seat_context.get("shards")
                    if "shards" in seat_context:
                        if (not isinstance(shards, list) or any(
                                not isinstance(shard, dict) or not isinstance(shard.get("ranges"), list)
                                for shard in shards)):
                            raise ValueError("invalid source evidence audit structure")
                        try:
                            validated, _validated_hash = evidence_validator()(
                                manifests[0], fresh=False, offline=True)
                            validated_shards = validated["source_context"]["seats"][seat]["shards"]
                            assigned_ranges = sum(len(shard["ranges"]) for shard in validated_shards)
                        except Exception as error:
                            raise ValueError("invalid source evidence audit structure") from error
                    if manifest.get("phase") == "plan":
                        plan = manifest.get("plan") or {}
                        artifact = directory / str(plan.get("artifact", ""))
                        line_count = len(artifact.read_bytes().splitlines())
                        if (plan_artifact_sha256 != plan.get("sha256")
                                or any(row["line_end"] > line_count for row in plan_citations)):
                            raise ValueError("read audit plan citation binding mismatch")
                    elif (plan_artifact_sha256 is not None or plan_citations
                          or plan_finding_citations):
                        raise ValueError("non-plan audit contains plan citation coverage")
                elif (plan_artifact_sha256 is not None or plan_citations or plan_finding_citations):
                    raise ValueError("plan citations require an evidence manifest")
                if (assigned_ranges is None and audit["packet_ranges"] != packet_rows
                        or assigned_ranges is not None and (
                            audit["packet_ranges"] > assigned_ranges
                            or audit["status"] == "valid" and audit["packet_ranges"] != assigned_ranges)):
                    raise ValueError("invalid source evidence audit structure")
                patch_mode = audit.get("patch_proof_mode")
                patch_fields = (
                    "patch_proof_calls", "patch_proof_turns", "patch_proof_visible_bytes",
                    "expected_patch_chunks", "opened_patch_chunks",
                )
                if manifest_hash is not None and patch_mode is None:
                    raise ValueError("evidence audit lacks patch proof counters")
                if patch_mode is not None:
                    patch_values = [audit.get(field) for field in patch_fields]
                    if (patch_mode not in ("chunks", "windows")
                            or any(not isinstance(value, int) or isinstance(value, bool) or value < 0
                                   for value in patch_values)
                            or audit["patch_proof_calls"] > audit["tool_calls"]
                            or audit["patch_proof_turns"] > audit["patch_proof_calls"]
                            or audit["patch_proof_visible_bytes"] > audit["tool_output_bytes"]
                            or audit["opened_patch_chunks"] > audit["expected_patch_chunks"]
                            or (patch_mode == "windows" and (
                                audit["expected_patch_chunks"] or audit["opened_patch_chunks"]))
                            or (audit["status"] == "valid" and patch_mode == "chunks"
                                and not (audit["opened_patch_chunks"]
                                         == audit["expected_patch_chunks"]
                                         == audit["patch_proof_calls"]))):
                        raise ValueError("invalid patch proof audit structure")
            expected_adapter = adapter_for_key(stem, adapters)
            if expected_adapter and audit["adapter"] != expected_adapter:
                raise ValueError("read audit adapter mismatch")
            if (not prompt.is_file()
                    or audit.get("prompt_sha256") != hashlib.sha256(prompt.read_bytes()).hexdigest()):
                raise ValueError("read audit prompt hash mismatch")
            matching_streams = [candidate for candidate in stream_candidates
                                if audit.get("stream_sha256") == hashlib.sha256(candidate.read_bytes()).hexdigest()]
            if len(matching_streams) != 1:
                raise ValueError("read audit stream hash mismatch")
        except json.JSONDecodeError:
            reason = "malformed read audit JSON"
        except (OSError, TypeError, ValueError) as error:
            reason = str(error).strip() or error.__class__.__name__
        else:
            activity["audits"] += 1
            activity["violating_audits"] += audit["status"] == "invalid"
            activity["advisories"] += len(advisories)
            for field in metric_fields[:-1]:
                activity[field] += audit[field]
            activity["max_tool_output_bytes"] = max(
                activity["max_tool_output_bytes"], audit["max_tool_output_bytes"]
            )
            if version == 2:
                for field in source_fields:
                    activity[field] += audit.get(field, 0)
                if audit.get("patch_proof_mode") is not None:
                    for field in patch_fields:
                        activity[field] += audit[field]
                    activity["chunk_seats" if audit["patch_proof_mode"] == "chunks"
                             else "window_seats"] += 1
            continue
        activity["invalid_audits"].append({"audit": path.name, "reason": reason})
    return activity


def evidence_validator():
    spec = importlib.util.spec_from_file_location("review_council_evidence", EVIDENCE_SCRIPT)
    if spec is None or spec.loader is None:
        raise ValueError("evidence validator is unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.validated_manifest


def evidence_words(path, validate):
    manifest, manifest_hash = validate(path, fresh=False, offline=True)
    words = manifest.get("word_counts")
    required = ("full", "semantic", "delta", "evidence", "source_context", "assigned_patch", "avoided")
    if not isinstance(words, dict) or any(
        not isinstance(words.get(key), int) or isinstance(words.get(key), bool) or words[key] < 0
        for key in required
    ):
        raise ValueError("invalid evidence word counts")

    label = manifest["label"]
    session = path.parent
    direct = {
        "full": session / f"r{label}-full.patch",
        "semantic": session / f"r{label}-semantic.patch",
        "delta": session / f"r{label}-delta.patch",
    }
    for key, artifact in direct.items():
        actual = len(artifact.read_bytes().split())
        metadata = manifest["artifacts"][artifact.name]
        if words[key] != actual or metadata.get("words") != actual:
            raise ValueError("evidence word count mismatch")
    shared_evidence = sum(
        len((session / f"r{label}-{suffix}").read_bytes().split())
        for suffix in ("evidence.md", "instructions.md")
    )
    if words["evidence"] != shared_evidence:
        raise ValueError("evidence word count mismatch")
    source_context = manifest.get("source_context")
    if not isinstance(source_context, dict) or not isinstance(source_context.get("seats"), dict):
        raise ValueError("source context word count unavailable")
    source_context_words = 0
    for packet in source_context["seats"].values():
        artifacts = [shard["artifact"] for shard in packet["shards"]]
        artifacts.extend(
            segment["artifact"]
            for required in packet["required_source_ranges"]
            for segment in required["segments"]
        )
        for name in artifacts:
            artifact = session / name
            actual = len(artifact.read_bytes().split())
            if manifest["artifacts"][artifact.name].get("words") != actual:
                raise ValueError("source context artifact word count mismatch")
            source_context_words += actual
    if words["source_context"] != source_context_words:
        raise ValueError("source context word count mismatch")

    assignments = manifest["assignments"]
    manifest_line = "Evidence manifest SHA-256: " + manifest_hash
    assigned = 0
    plan_specialist_patch_words = 0
    for seat, assignment in assignments.items():
        prompt = session / f"r{label}-{seat}.prompt.md"
        try:
            prompt_lines = prompt.read_text(errors="replace").splitlines()
        except OSError as error:
            raise ValueError("evidence prompt unavailable: " + seat) from error
        if manifest_line not in prompt_lines:
            raise ValueError("evidence prompt manifest hash mismatch")
        try:
            assigned_patch = Path(assignment["patch"]).resolve(strict=True)
            assigned_patch.relative_to(session)
            patch_words = len(assigned_patch.read_bytes().split())
            assigned += patch_words
            if manifest.get("phase") == "plan" and seat != manifest.get("mechanical_owner"):
                plan_specialist_patch_words += patch_words
        except (KeyError, OSError, ValueError) as error:
            raise ValueError("assigned evidence patch unavailable: " + seat) from error
    plan_words = 0
    closure_words = 0
    prepared_search_words = 0
    if manifest.get("phase") == "plan":
        if any(not isinstance(words.get(key), int) or isinstance(words.get(key), bool)
               or words[key] < 0 for key in ("plan", "closure")):
            raise ValueError("invalid plan evidence word counts")
        plan_words = len((session / f"r{label}-plan.md").read_bytes().split())
        closure_words = len((session / f"r{label}-plan-closure.patch").read_bytes().split())
        clusters = {cluster["id"]: cluster for cluster in manifest["plan"]["clusters"]}
        if all("search_proof" in cluster for cluster in clusters.values()) \
                and all("plan_clusters" in assignment for assignment in assignments.values()):
            prepared_search_words = sum(
                len((session / clusters[cluster_id]["search_proof"]["artifact"]).read_bytes().split())
                for assignment in assignments.values()
                for cluster_id in assignment["plan_clusters"])
        if (words["plan"] != plan_words or words["closure"] != closure_words
                or words.get("prepared_search", 0) != prepared_search_words):
            raise ValueError("plan evidence word count mismatch")
    avoided = max(0, len(assignments) * words["full"] - assigned
                  - len(assignments) * words["evidence"] - source_context_words
                  - prepared_search_words)
    if words["assigned_patch"] != assigned or words["avoided"] != avoided:
        raise ValueError("invalid evidence scope projection")
    return {
        "full_words": words["full"],
        "assigned_patch_words": words["assigned_patch"],
        "delta_words": words["delta"],
        "evidence_words": words["evidence"],
        "source_context_words": source_context_words,
        "avoided_words": words["avoided"],
        "plan_words": plan_words,
        "closure_words": closure_words,
        "prepared_search_words": prepared_search_words,
        "plan_specialist_patch_words": plan_specialist_patch_words,
        "receipt_relative_plan_manifests": int(
            manifest.get("schema_version") == 4
            and manifest.get("plan", {}).get("delta_mode") == "receipt-delta"),
        "cumulative_plan_manifests": int(
            manifest.get("phase") == "plan"
            and not (manifest.get("schema_version") == 4
                     and manifest.get("plan", {}).get("delta_mode") == "receipt-delta")),
    }


def is_milliseconds(value):
    return type(value) is int and value >= 0


def render_timing(directory):
    """Read the per-panel render timing that rev-prompt.sh --panel records."""
    timing = {"panels": [], "invalid": []}
    for path in sorted(directory.glob("r*-render.json")):
        match = RENDER_TIMING.match(path.name)
        if match is None:
            continue
        try:
            document = json.loads(path.read_text(errors="replace"))
        except (OSError, ValueError):
            document = None
        seats = document.get("seats") if isinstance(document, dict) else None
        if (not isinstance(seats, dict) or not seats or type(document.get("schema_version")) is not int
                or document["schema_version"] != 1
                or not all(is_milliseconds(value) for value in seats.values())
                or not is_milliseconds(document.get("total_ms"))):
            timing["invalid"].append({"timing": path.name, "reason": "invalid render timing"})
            continue
        timing["panels"].append({
            "label": match.group(1), "seats": seats, "total_ms": document["total_ms"]})
    return timing


def profile_evidence(directory):
    projection = empty_scope_projection()
    try:
        validate = evidence_validator()
    except (ImportError, OSError, ValueError):
        validate = None
    for path in sorted(directory.glob("r*-evidence.manifest.json")):
        try:
            if validate is None:
                raise ValueError("evidence validator is unavailable")
            item = evidence_words(path, validate)
        except (AttributeError, KeyError, OSError, TypeError, ValueError, json.JSONDecodeError) as error:
            if isinstance(error, json.JSONDecodeError):
                reason = "malformed manifest JSON"
            else:
                reason = str(error).strip() or error.__class__.__name__
            projection["invalid_manifests"].append({"manifest": path.name, "reason": reason})
            continue
        projection["valid_manifests"] += 1
        for key, value in item.items():
            projection[key] += value
    return projection


def is_completed_result(path, receipt_version=0, legacy_no_exit_sha256=None):
    exit_path = path.with_suffix(".exit")
    if exit_path.exists():
        try:
            if exit_path.read_text(errors="replace").strip() != "0":
                return False
        except OSError:
            return False
    elif receipt_version >= 1:
        expected = (legacy_no_exit_sha256 or {}).get(path.name)
        try:
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
        except OSError:
            return False
        if expected != actual:
            return False
    return subprocess.run(
        [sys.executable, str(VALIDATOR), str(path)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    ).returncode == 0


def is_completed_sdk_result(path, seat):
    try:
        label = path.stem[1:-(len(seat) + 1)]
        if path.name != 'r%s-%s.json' % (label, seat):
            return False
        spec = importlib.util.spec_from_file_location('sdk_result_evidence', EVIDENCE_SCRIPT)
        evidence = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(evidence)
        manifest, manifest_hash = evidence.validated_manifest(
            path.parent / ('r%s-evidence.manifest.json' % label), fresh=False, offline=True)
        if manifest['assignments'][seat]['adapter'] != 'cursor-sdk':
            return False
        evidence.validate_results(path.parent, manifest, manifest_hash, [seat])
        return True
    except (ImportError, OSError, ValueError, TypeError, KeyError, StopIteration):
        return False


def profile_session(directory, stream_usage=None):
    adapters, receipt_version, legacy_no_exit_sha256 = roster_metadata(directory)
    if stream_usage is None:
        stream_usage, _ = reviewer_streams(session_streams(directory))
    prompts = {"code": {"count": 0, "words": 0}, "plan": {"count": 0, "words": 0}}
    for path in directory.glob("*.prompt.md"):
        if artifact_key(path) is None:
            continue
        phase = "plan" if is_plan(path) else "code"
        prompts[phase]["count"] += 1
        prompts[phase]["words"] += len(path.read_text(errors="replace").split())

    results = {"code": {"calls": 0, "findings": 0}, "plan": {"calls": 0, "findings": 0}}
    completed = []
    for path in directory.glob("*.json"):
        if path.name.endswith('.json.summary-candidate.json'):
            continue
        key = artifact_key(path)
        if key is None:
            continue
        adapter = adapter_for_key(key, adapters)
        if adapter == 'cursor-sdk':
            seat = max((name for name in adapters if key.endswith('-' + name)), key=len)
            if not is_completed_sdk_result(path, seat):
                continue
        elif not is_completed_result(path, receipt_version, legacy_no_exit_sha256):
            continue
        try:
            document = json.loads(path.read_text(errors="replace"))
        except (OSError, ValueError):
            continue
        if document["summary"].startswith("INCOMPLETE PROOF"):
            continue
        phase = "plan" if is_plan(path) else "code"
        results[phase]["calls"] += 1
        results[phase]["findings"] += len(document["findings"])
        completed.append((key, adapter))

    usage = empty_usage()
    providers = {}
    metered_keys = set()
    stream_providers = {}
    invalid_usage = []
    for path, _ in session_streams(directory):
        key = artifact_key(path)
        item, invalid = stream_usage[path]
        invalid_usage.extend(invalid)
        if item is None or (item["processed_tokens"] == 0 and item["cost_usd_known_calls"] == 0
                            and item["provider"] != 'cursor-sdk'):
            continue
        add_usage(usage, item)
        metered_keys.add(key)
        stream_providers[key] = item["provider"]
        provider_usage = providers.setdefault(item["provider"], empty_provider())
        add_usage(provider_usage, item)
        provider_usage["metered_calls"] = provider_usage["calls"]

    unmetered = 0
    for key, adapter in completed:
        provider = adapter or stream_providers.get(key) or "unknown"
        provider_usage = providers.setdefault(provider, empty_provider())
        provider_usage["completed_calls"] += 1
        if key not in metered_keys:
            unmetered += 1
            provider_usage["unmetered_calls"] += 1

    calls = {"completed": len(completed), "metered": usage["calls"], "unmetered": unmetered}

    return {
        "session": directory.name,
        "path": str(directory),
        "roster": roster_identity(directory),
        "prompts": prompts,
        "results": results,
        "calls": calls,
        "usage": usage,
        "providers": providers,
        "invalid_usage": invalid_usage,
        "read_activity": read_activity(directory, adapters),
        "seat_yield": seat_yield(directory),
        "scope_projection": profile_evidence(directory),
        "render_timing": render_timing(directory),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true", dest="as_json")
    parser.add_argument("--host-log", action="append", default=[], type=host_log_path,
                        metavar="PATH", help="Explicit native host log; mixed usage stays separate from reviewer totals")
    parser.add_argument("sessions", nargs="+", type=session_directory)
    args = parser.parse_args()

    stream_usage, leaf_ids = reviewer_streams(
        [stream for directory in args.sessions for stream in session_streams(directory)])
    sessions = [profile_session(directory, stream_usage) for directory in args.sessions]
    totals = empty_usage()
    totals.update({"completed_calls": 0, "metered_calls": 0, "unmetered_calls": 0})
    totals["invalid_usage"] = 0
    scope_totals = empty_scope_projection(with_names=False)
    read_totals = empty_read_activity(with_names=False)
    render_totals = {"panels": 0, "total_ms": 0, "seat_ms": 0, "invalid": 0}
    for session in sessions:
        timing = session["render_timing"]
        render_totals["panels"] += len(timing["panels"])
        render_totals["invalid"] += len(timing["invalid"])
        for panel in timing["panels"]:
            render_totals["total_ms"] += panel["total_ms"]
            render_totals["seat_ms"] += sum(panel["seats"].values())
        usage = session["usage"]
        totals["calls"] += usage["calls"]
        for key in USAGE_FIELDS:
            totals[key] += usage[key]
        totals["completed_calls"] += session["calls"]["completed"]
        totals["metered_calls"] += session["calls"]["metered"]
        totals["unmetered_calls"] += session["calls"]["unmetered"]
        totals["invalid_usage"] += len(session["invalid_usage"])
        activity = session["read_activity"]
        read_totals["audits"] += activity["audits"]
        read_totals["violating_audits"] += activity["violating_audits"]
        read_totals["advisories"] += activity["advisories"]
        read_totals["invalid_audits"] += len(activity["invalid_audits"])
        for key in (
            "tool_calls", "tool_turns", "tool_output_bytes", "recognized_tool_calls",
            "source_read_calls", "source_read_batches", "packet_shards", "packet_bytes", "packet_ranges",
            "opened_source_ranges", "finding_citations", "patch_proof_calls",
            "patch_proof_turns", "patch_proof_visible_bytes", "expected_patch_chunks",
            "opened_patch_chunks", "window_seats", "chunk_seats",
        ):
            read_totals[key] += activity[key]
        read_totals["max_tool_output_bytes"] = max(
            read_totals["max_tool_output_bytes"], activity["max_tool_output_bytes"]
        )
        projection = session["scope_projection"]
        scope_totals["valid_manifests"] += projection["valid_manifests"]
        scope_totals["invalid_manifests"] += len(projection["invalid_manifests"])
        for key in ("full_words", "assigned_patch_words", "delta_words", "evidence_words",
                    "source_context_words", "avoided_words", "plan_words", "closure_words",
                    "prepared_search_words", "plan_specialist_patch_words",
                    "receipt_relative_plan_manifests", "cumulative_plan_manifests"):
            scope_totals[key] += projection[key]
    totals["scope_projection"] = scope_totals
    totals["read_activity"] = read_totals
    yield_totals = {}
    for session in sessions:
        for model, row in session["seat_yield"].items():
            total = yield_totals.setdefault(model, {
                "runs": 0, "usable": 0, "audit_invalid": 0, "incomplete_proof": 0,
                "salvaged": 0, "no_result": 0, "codes": {},
            })
            for key in ("runs", "usable", "audit_invalid", "incomplete_proof", "salvaged", "no_result"):
                total[key] += row[key]
            for code, count in row["codes"].items():
                total["codes"][code] = total["codes"].get(code, 0) + count
    totals["seat_yield"] = yield_totals
    totals["render_timing"] = render_totals
    roster_groups = []
    roster_group_indexes = {}
    for session in sessions:
        roster = session["roster"]
        key = (roster["signature"], roster["complete"])
        if key not in roster_group_indexes:
            roster_group_indexes[key] = len(roster_groups)
            roster_groups.append({
                "signature": roster["signature"],
                "complete": roster["complete"],
                "sessions": [],
            })
        roster_groups[roster_group_indexes[key]]["sessions"].append(session["session"])
    comparison = {
        "mixed_core_rosters": len(roster_groups) > 1,
        "roster_signatures": roster_groups,
    }
    document = {"sessions": sessions, "totals": totals, "comparison": comparison}
    if totals["unidentified_terminal_calls"]:
        document["usage_identity_limit"] = (
            "Terminal streams without message IDs are counted as artifact attempts; "
            "mirrored requests cannot be deduplicated without stable identity.")
    if args.host_log:
        operations = {path.name for pattern in ("rev-*.sh", "rev-*.py")
                      for path in Path(__file__).resolve().parent.glob(pattern)}
        document["host_usage"] = host_usage(args.host_log, args.sessions, leaf_ids, operations)

    if args.as_json:
        print(json.dumps(document, indent=2, sort_keys=True, allow_nan=False))
        return
    for session in sessions:
        usage = session["usage"]
        code = session["prompts"]["code"]
        plan = session["prompts"]["plan"]
        scope = session["scope_projection"]
        print(
            "%s roster=%s roster_complete=%s calls=%d processed=%d input=%d output=%d cached_input=%d cache_write_input=%d cache_read_input=%d cost_usd=%.2f completed=%d metered=%d unmetered=%d usage_invalid=%d prompt_words=%d/%d projected_scope_words=full:%d assigned:%d delta:%d evidence:%d avoided:%d packet:%d plan_search:%d plan_specialist:%d plan_routes:receipt:%d,cumulative:%d evidence_invalid=%d"
            % (
                session["session"], session["roster"]["signature"],
                str(session["roster"]["complete"]).lower(),
                usage["calls"], usage["processed_tokens"], usage["input_tokens"],
                usage["output_tokens"], usage["cached_input_tokens"], usage["cache_write_input_tokens"],
                usage["cache_read_input_tokens"], usage["cost_usd"],
                session["calls"]["completed"], session["calls"]["metered"], session["calls"]["unmetered"],
                len(session["invalid_usage"]), code["words"], plan["words"], scope["full_words"], scope["assigned_patch_words"],
                scope["delta_words"], scope["evidence_words"], scope["avoided_words"],
                scope["source_context_words"],
                scope["prepared_search_words"],
                scope["plan_specialist_patch_words"],
                scope["receipt_relative_plan_manifests"],
                scope["cumulative_plan_manifests"],
                len(scope["invalid_manifests"])
            )
        )
        print("  usage_detail=" + usage_detail(usage))
        for invalid in scope["invalid_manifests"]:
            print("  evidence_invalid_detail=%s: %s" % (invalid["manifest"], invalid["reason"]))
        for invalid in session["invalid_usage"]:
            print("  usage_invalid_detail=%s: %s" % (invalid["stream"], invalid["reason"]))
        activity = session["read_activity"]
        print(
            "  read_activity=audits:%d violating:%d advisories:%d calls:%d turns:%d output_bytes:%d max_output_bytes:%d invalid:%d packet_shards:%d packet_bytes:%d packet_ranges:%d source_reads:%d source_batches:%d opened_ranges:%d finding_citations:%d patch_proof_calls:%d patch_proof_turns:%d patch_proof_bytes:%d expected_chunks:%d opened_chunks:%d patch_modes:window:%d,chunk:%d"
            % (
                activity["audits"], activity["violating_audits"], activity["advisories"], activity["tool_calls"],
                activity["tool_turns"], activity["tool_output_bytes"],
                activity["max_tool_output_bytes"], len(activity["invalid_audits"]),
                activity["packet_shards"], activity["packet_bytes"], activity["packet_ranges"],
                activity["source_read_calls"], activity["source_read_batches"],
                activity["opened_source_ranges"],
                activity["finding_citations"],
                activity["patch_proof_calls"], activity["patch_proof_turns"],
                activity["patch_proof_visible_bytes"], activity["expected_patch_chunks"],
                activity["opened_patch_chunks"], activity["window_seats"],
                activity["chunk_seats"],
            )
        )
        for invalid in activity["invalid_audits"]:
            print("  read_audit_invalid_detail=%s: %s" % (invalid["audit"], invalid["reason"]))
        for line in format_seat_yield(session["seat_yield"]):
            print("  " + line)
        timing = session["render_timing"]
        print("  render_timing=%s" % (";".join(
            "%s:total_ms:%d,%s" % (panel["label"], panel["total_ms"], ",".join(
                "%s:%d" % item for item in panel["seats"].items()))
            for panel in timing["panels"]) or "none"))
        for invalid in timing["invalid"]:
            print("  render_timing_invalid_detail=%s: %s" % (invalid["timing"], invalid["reason"]))
    print(
        "COMPARABILITY mixed_core_rosters=%s roster_signatures=%d"
        % (str(comparison["mixed_core_rosters"]).lower(), len(roster_groups))
    )
    print(
        "TOTAL calls=%d processed=%d input=%d output=%d cached_input=%d cache_write_input=%d cache_read_input=%d cost_usd=%.2f completed=%d metered=%d unmetered=%d usage_invalid=%d projected_scope_words=full:%d assigned:%d delta:%d evidence:%d avoided:%d packet:%d plan_search:%d plan_specialist:%d plan_routes:receipt:%d,cumulative:%d evidence_invalid=%d"
        % (
            totals["calls"], totals["processed_tokens"], totals["input_tokens"], totals["output_tokens"],
            totals["cached_input_tokens"], totals["cache_write_input_tokens"],
            totals["cache_read_input_tokens"], totals["cost_usd"], totals["completed_calls"],
            totals["metered_calls"], totals["unmetered_calls"], totals["invalid_usage"], scope_totals["full_words"],
            scope_totals["assigned_patch_words"], scope_totals["delta_words"],
            scope_totals["evidence_words"], scope_totals["avoided_words"],
            scope_totals["source_context_words"],
            scope_totals["prepared_search_words"],
            scope_totals["plan_specialist_patch_words"],
            scope_totals["receipt_relative_plan_manifests"],
            scope_totals["cumulative_plan_manifests"],
            scope_totals["invalid_manifests"]
        )
    )
    print("TOTAL_USAGE_DETAIL " + usage_detail(totals))
    for line in format_seat_yield(totals["seat_yield"]):
        print("TOTAL_" + line)
    if "usage_identity_limit" in document:
        print("USAGE_IDENTITY_LIMIT " + document["usage_identity_limit"])
    print(
        "TOTAL_READ_ACTIVITY audits=%d violating=%d calls=%d turns=%d output_bytes=%d max_output_bytes=%d invalid=%d packet_shards=%d packet_bytes=%d packet_ranges=%d source_reads:%d source_batches:%d opened_ranges:%d finding_citations:%d patch_proof_calls:%d patch_proof_turns:%d patch_proof_bytes:%d expected_chunks:%d opened_chunks:%d patch_modes:window:%d,chunk:%d"
        % (
            read_totals["audits"], read_totals["violating_audits"], read_totals["tool_calls"],
            read_totals["tool_turns"], read_totals["tool_output_bytes"],
            read_totals["max_tool_output_bytes"], read_totals["invalid_audits"],
            read_totals["packet_shards"], read_totals["packet_bytes"], read_totals["packet_ranges"],
            read_totals["source_read_calls"], read_totals["source_read_batches"],
            read_totals["opened_source_ranges"],
            read_totals["finding_citations"],
            read_totals["patch_proof_calls"], read_totals["patch_proof_turns"],
            read_totals["patch_proof_visible_bytes"], read_totals["expected_patch_chunks"],
            read_totals["opened_patch_chunks"], read_totals["window_seats"],
            read_totals["chunk_seats"],
        )
    )
    print(
        "TOTAL_RENDER_TIMING panels=%d total_ms=%d seat_ms=%d invalid=%d"
        % (render_totals["panels"], render_totals["total_ms"], render_totals["seat_ms"],
           render_totals["invalid"])
    )
    if args.host_log:
        host = document["host_usage"]
        for label, key in (("HOST_ENVELOPE", "envelope"), ("HOST_COUNCIL_OPERATIONS", "council_operations")):
            item = host[key]
            print("%s calls=%d processed=%d input=%d output=%d %s" % (
                label, item["calls"], item["processed_tokens"], item["input_tokens"],
                item["output_tokens"], usage_detail(item)))
        print("HOST_ATTRIBUTION " + host["attribution"] + " " + host["cost_basis"])
        for invalid in host["invalid_usage"]:
            print("  host_usage_invalid_detail=%s: %s" % (invalid["stream"], invalid["reason"]))


def usage_detail(usage):
    return "uncached_input=%d uncached_input_unknown_calls=%d reasoning_output=%d cache_write_5m_input=%d cache_write_1h_input=%d reported_cost_usd=%.2f cost_known=%d cost_unknown=%d terminal_identity_unknown=%d" % (
        usage["uncached_input_tokens"], usage["uncached_input_unknown_calls"],
        usage["reasoning_output_tokens"],
        usage["cache_write_5m_input_tokens"], usage["cache_write_1h_input_tokens"],
        usage["cost_usd"], usage["cost_usd_known_calls"], usage["cost_usd_unknown_calls"],
        usage["unidentified_terminal_calls"])



if __name__ == "__main__":
    main()
