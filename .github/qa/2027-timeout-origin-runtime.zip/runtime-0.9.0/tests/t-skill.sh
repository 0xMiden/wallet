# shellcheck shell=bash
# The skill text IS the contract for the orchestrator: nothing but SKILL.md tells it to preserve a
# resumed ledger, to read the roster, to render the extra seats' prompts, to scope the baseline patch,
# or what `--read-only` means over code. Static assertions, so a regression in the prose is caught like
# any other. Also the port guard: every plugin path is ${CLAUDE_PLUGIN_ROOT}-relative and resolves.
#
# The forbidden-string patterns below are written with bracket escapes ('~/[.]claude') on purpose:
# the recursive grep scans this file too, and a literal would match itself.
rev_bundle() {
  local src=$1 dest=$2 file
  mkdir -p "$(dirname "$dest")"
  cat "$src/SKILL.md" > "$dest"
  if [ -d "$src/phases" ]; then
    for file in "$src"/phases/*.md; do
      [ -f "$file" ] || continue
      printf '\n' >> "$dest"
      cat "$file" >> "$dest"
    done
  fi
}

test_skill_contract() {
  if [ ! -f "$SK/skills/rev/SKILL.md" ]; then fail "rev SKILL.md exists" "$SK/skills/rev/SKILL.md missing"; return; fi
  ok "rev SKILL.md exists"
  local bytes
  bytes=$(wc -c < "$SK/skills/rev/SKILL.md")
  [ "$bytes" -lt 16000 ] && ok "injected rev skill stays under 16KB" || fail "injected rev skill stays under 16KB" "$bytes bytes"
  bytes=$(wc -c < "$SK/codex-skills/rev/SKILL.md")
  [ "$bytes" -lt 12000 ] && ok "injected codex rev skill stays under 12KB" || fail "injected codex rev skill stays under 12KB" "$bytes bytes"
  rev_bundle "$SK/skills/rev" "$T/skills/rev/SKILL.md"
  rev_bundle "$SK/codex-skills/rev" "$T/codex-skills/rev/SKILL.md"
  local K="$T/skills/rev/SKILL.md" ST="$SK/skills/stack/SKILL.md" POL="$SK/skills/rev/POLICY.md" AG="$SK/agents/rev-reviewer.md" SG="$SK/agents/rev-reviewer-sonnet.md"
  local CK="$T/codex-skills/rev/SKILL.md" CST="$SK/codex-skills/stack/SKILL.md"
  if [ ! -f "$ST" ]; then fail "stack SKILL.md exists" "$ST missing"; return; fi
  ok "stack SKILL.md exists"
  if [ ! -f "$CK" ]; then fail "Codex rev SKILL.md exists" "$CK missing"; return; fi
  ok "Codex rev SKILL.md exists"
  if [ ! -f "$CST" ]; then fail "Codex stack SKILL.md exists" "$CST missing"; return; fi
  ok "Codex stack SKILL.md exists"

  # --- names and namespaces -------------------------------------------------
  assert_grep "rev skill is named rev" "$K" '^name: rev$'
  assert_grep "stack skill is named stack" "$ST" '^name: stack$'
  assert_grep "rev skill points at the namespaced agent" "$K" 'subagent_type: "review-council:rev-reviewer"'
  assert_grep "rev skill points at the namespaced Sonnet agent" "$K" 'subagent_type: "review-council:rev-reviewer-sonnet"'
  assert_grep "rev skill routes agent seats by roster model" "$K" 'model.*sonnet.*rev-reviewer-sonnet'
  assert_grep "rev skill points at the namespaced stack" "$K" '/review-council:stack'
  assert_grep "rev skill is invoked namespaced" "$K" '/review-council:rev '
  assert_grep "stack legs run the namespaced rev" "$ST" '/review-council:rev'
  assert_grep "stack launch line is the plugin script" "$ST" '\$\{CLAUDE_PLUGIN_ROOT\}/scripts/stack\.sh'

  # --- the port: nothing outside the plugin, everything referenced resolves ---
  local pat hits
  # This is a regular expression for a literal tilde, not a shell path.
  # shellcheck disable=SC2088
  for pat in '~/[.]claude/skills' 'review[-]via[-]cursor' 'rev[-]stack[.]sh'; do
    hits=$(grep -rlE -- "$pat" "$SK" 2>/dev/null | tr '\n' ' ')
    if [ -z "$hits" ]; then ok "no /$pat/ anywhere under the plugin"; else fail "no /$pat/ anywhere under the plugin" "in: $hits"; fi
  done
  assert_nogrep "rev skill has no \$R script shorthand left" "$K" '\$R/'
  assert_nogrep "stack skill has no \$R script shorthand left" "$ST" '\$R/'
  grep -hoE '\$\{CLAUDE_PLUGIN_ROOT\}/[A-Za-z0-9_./-]+' "$K" "$ST" "$AG" | sed 's/[.,:;]*$//' | sort -u > "$T/skill-paths"
  assert_eq "the skills reference plugin paths at all" "$([ -s "$T/skill-paths" ] && echo yes)" "yes"
  local p rel
  while IFS= read -r p; do
    rel=${p#\$\{CLAUDE_PLUGIN_ROOT\}/}
    if [ -e "$SK/$rel" ]; then ok "referenced plugin file exists: $rel"; else fail "referenced plugin file exists: $rel" "$SK/$rel missing"; fi
  done < "$T/skill-paths"

  # --- the fix-plan gate (0.2.0) ---------------------------------------------
  assert_grep "loop header has the plan step" "$K" 'triage → plan → fix'
  assert_grep "Plan section exists" "$K" '^### Plan'
  assert_grep "plan is written to fix-plan.md" "$K" '\$S/fix-plan\.md'
  assert_grep "plan prompts render with immutable plan evidence" "$K" \
    '--plan "\$PLAN_SNAPSHOT" --evidence "\$MANIFEST"'
  assert_grep "plan prompts use a distinct artifact label" "$K" 'PANEL_LABEL=<N>p'
  assert_grep "the four plan lenses are named" "$K" 'plan-completeness, plan-soundness,'
  assert_grep "triage clusters by root cause" "$K" '\*\*Cluster\.\*\*'
  assert_grep "fix lands one cluster per commit" "$K" 'one\s*cluster per commit'
  assert_grep "evidence doc is referenced" "$K" 'churn-analysis-2026-09-06\.md'
  assert_grep "rev skill documents --base" "$K" '--base <ref>'
  assert_grep "simplicity discovery uses every seat" "$K" '\| Simplicity discovery \|.*\| simplicity for every seat \|'
  assert_grep "PR description is not passed to seats by default" "$K" 'do \*\*not\*\* pass `--pr \$S/pr\.md`'
  assert_grep "no-SDK legacy evidence path is scoped to numeric panels" "$K" \
    'Only explicit numeric panels without a `cursor-sdk` row keep the legacy path'
  assert_nogrep "no-SDK legacy evidence path is not stated as a global fallback" "$K" \
    '^Without a `cursor-sdk` row, keep the legacy path'
  assert_grep "Codex no-SDK legacy evidence path is scoped to numeric panels" "$CK" \
    'Only explicit numeric panels without a `cursor-sdk` row keep the legacy path'
  assert_grep "Codex adaptive panels prepare evidence without an SDK row" "$CK" \
    'whether or not their roster contains a `cursor-sdk` row'
  assert_nogrep "Codex no-SDK legacy evidence path is not stated as a global fallback" "$CK" \
    '^Without a `cursor-sdk` row, keep the legacy path'

  # --- the agent and its read-only fence ------------------------------------
  if [ ! -f "$AG" ]; then fail "agent file exists" "$AG missing"; return; fi
  ok "agent file exists"
  if [ ! -f "$SG" ]; then fail "Sonnet agent file exists" "$SG missing"; return; fi
  ok "Sonnet agent file exists"
  assert_nogrep "agent does not advertise ignored hook frontmatter" "$AG" '^hooks:'
  assert_eq "the CLI guard remains executable" "$([ -x "$SK/scripts/lib/readonly-bash-guard.py" ] && echo yes)" "yes"
  assert_grep "agent schema reference is plugin-relative" "$AG" '\$\{CLAUDE_PLUGIN_ROOT\}/schema/findings\.schema\.json'

  # --- POLICY.md: what the session-start hook injects ------------------------
  if [ ! -f "$POL" ]; then fail "POLICY.md exists" "$POL missing"; return; fi
  ok "POLICY.md exists"
  local lines; lines=$(awk 'END{print NR}' "$POL")
  if [ "$lines" -le 12 ] && [ "$lines" -gt 0 ]; then ok "POLICY.md is ≤ 12 lines ($lines)"; else fail "POLICY.md is ≤ 12 lines" "got $lines"; fi
  assert_grep "POLICY names the rev command" "$POL" '/review-council:rev'
  assert_grep "POLICY names the stack command" "$POL" '/review-council:stack'
  assert_grep "POLICY says reviewers never write" "$POL" 'never edit|never write'
  assert_grep "POLICY says apply actionable findings" "$POL" 'actionable'
  assert_grep "POLICY says relay the status line" "$POL" 'status line'
  assert_grep "POLICY forbids self-review as a substitute" "$POL" 'substitute'
  assert_grep "POLICY says a degraded panel still runs, loudly" "$POL" 'degraded'
  assert_grep "POLICY makes the skill an executable workflow contract" "$POL" \
    'executable workflow contract.*every applicable step in order.*required receipt'

  # --- fan-out reads the roster ---------------------------------------------
  assert_grep "fan-out reads the session roster" "$K" '\$S/roster\.json'
  assert_grep "non-extra seats launch together" "$K" 'every non-extra seat'
  assert_grep "the agent-adapter seat is launched with the Agent tool" "$K" 'adapter is `agent`'
  assert_grep "the agent adapter is not an adapter script" "$K" 'The `agent` adapter is not a script'
  assert_grep "extras join in their own round" "$K" '`round`'
  assert_grep "lens rule is stated as a formula" "$K" 'lenses\[\(i \+ N\) mod L\]'
  assert_grep "worked example for a 3-seat roster" "$K" '\*\*3 seats\*\*'
  assert_grep "worked example for a 4-seat roster" "$K" '\*\*4 seats\*\*'
  assert_grep "worked example for a 6-seat roster" "$K" '\*\*6 seats\*\*'
  assert_grep "three-seat minimum survives the port" "$K" 'three or more'
  # Task 11 - a degraded panel is run, not refused, and every launched agent seat gets its own call
  assert_grep "padded Claude seats are named" "$K" '`claude-1`'
  assert_grep "every agent-adapter seat is its own Agent call" "$K" 'one `Agent` call per seat whose adapter is `agent`'
  assert_grep "every Agent transcript is recorded by seat" "$K" 'agent_transcripts\.<seat>='
  assert_grep "CLI seats keep log-based status" "$K" 'CLI seats use their own logs'
  assert_grep "padding is explained where the roster is introduced" "$K" 'padded'
  assert_grep "the report opens with the degradation" "$K" 'Degraded panel:'
  assert_grep "coverage quotes the roster sentence verbatim" "$K" '`degradation`'

  # C-13 and C-14: both hosts keep panel state exact and numeric mode compatible.
  local H
  for H in "$K" "$CK"; do
    assert_grep "host recognizes a fresh input session" "$H" \
      '`fresh`: none of the four inputs exists, so preflight may run once'
    assert_grep "host recognizes an initialized input session" "$H" \
      '`initialized`: all four safe inputs exist, so validate and reuse them without probing'
    assert_grep "host rejects an invalid input session" "$H" \
      '`invalid`: a partial or unsafe set exists, so stop incomplete and use a fresh session'
    assert_nogrep "host never rebuilds an initialized session roster" "$H" \
      '[Rr]oster is rebuilt every run'
    assert_grep "fresh session rebuilds the roster once" "$H" \
      '[Aa] fresh session rebuilds its roster once during preflight'
    assert_grep "roster configuration changes require a fresh session" "$H" \
      '[Rr]oster configuration changes require a fresh session'
    assert_grep "host forbids cherry-picking the workflow" "$H" \
      'executable workflow contract.*Do not cherry-pick'
    assert_grep "host refuses certification without required artifacts" "$H" \
      'missing any audit, receipt, or final report required by its selected mode is incomplete'
    assert_grep "host writes exact code-panel state" "$H" 'phase=fan-out round=<N> "seats=\$LAUNCHED_SEATS"'
    assert_grep "host writes child replacement state for its selected executor" "$H" \
      'phase=repair .*round=\$CHILD_LABEL.*seats=\[.*\$EXECUTOR.*\]'
    assert_grep "host writes exact plan state" "$H" 'phase=plan round=<N>p "seats=\$PLAN_SEATS"'
    assert_grep "host counts only numbered code panels" "$H" 'Plan panels do not count as numbered code panels'
    assert_grep "host preserves numeric continuation" "$H" 'Only numeric mode continues past its requested minimum'
    assert_grep "host distinguishes retryable roster status" "$H" 'Exit 5 is retryable'
    assert_grep "host distinguishes permanent roster status" "$H" 'Exit 6 is permanent'
    assert_grep "host clears same-label exits before every launch" "$H" \
      '[Bb]efore every initial or same-label retry launch.*synchronously remove.*\.exit.*confirm.*absent'
    assert_grep "direct document roster requests its brief cause" "$H" \
      'roster\.sh --probe --brief --write .*roster\.json'
    assert_grep "host prepares evidence before adaptive fan-out" "$H" \
      'rev-evidence\.py"? prepare .* --phase "\$PANEL_PHASE"'
    assert_eq "host canonicalizes the session once for macOS tmp aliases" \
      "$(grep -Ec '^[[:space:]]*S=\$\(cd "\$S" && pwd -P\)$' "$H" || true)" 1
    assert_grep "host names the macOS tmp alias pair" "$H" \
      'macOS `/tmp` and `/private/tmp`'
    assert_grep "host prepares against the canonical session" "$H" \
      'rev-evidence\.py"? prepare "\$S"'
    assert_grep "host compares the canonical manifest identity" "$H" \
      '"\$S/r\$PANEL_LABEL-evidence\.manifest\.json"'
    assert_grep "host invokes the non-executable evidence script with Python" "$H" \
      'python3 .*rev-evidence\.py"? prepare'
    assert_grep "host builds one conditional evidence flag" "$H" \
      'EVIDENCE_PROMPT_ARGS=\(--evidence "\$MANIFEST"\)'
    assert_grep "host passes the conditional evidence flag to every prompt" "$H" \
      'rev-prompt\.sh.*"\$\{EVIDENCE_PROMPT_ARGS\[@\]\}"'
    assert_grep "host renders every adaptive prompt before launching" "$H" \
      '[Rr]ender every seat before any reviewer process starts'
    assert_grep "host runs one ordinary evidence verify after all renders" "$H" \
      '[Aa]fter every prompt.*one ordinary.*rev-evidence\.py.*verify'
    assert_grep "host matches every prompt to the verified manifest hash" "$H" \
      '[Ee]very evidence prompt must'
    assert_grep "host names the embedded manifest hash line" "$H" \
      'Evidence manifest SHA-256: <hash>'
    assert_grep "fan-out launches the already-rendered prompts" "$H" \
      '[Ff]an-out launches only those already-rendered prompt files'
    assert_grep "host certifies evidence after collection" "$H" \
      'rev-evidence\.py"? receipt .* "\$PANEL_LABEL"'
    assert_grep "host certifies a completed discovery panel" "$H" \
      '[Cc]ertify discovery after its complete simplicity panel'
    assert_grep "host uses the first core seat as discovery owner" "$H" \
      '[Ff]irst core seat.*discovery.*full-state'
    assert_grep "host uses the regression bundle owner as integration seat" "$H" \
      'tests-observability-maintenance-regression.*full-state'
    assert_grep "valid narrowed panels keep one integration seat" "$H" \
      '[Vv]alid narrowed panel.*exactly one full-state seat'
    assert_grep "host gives repairs full cumulative scope" "$H" \
      '[Rr]epair.*full cumulative patch'
    assert_grep "host rerenders every prompt on evidence failure" "$H" \
      '[Rr]ender every seat again without `--evidence`'
    assert_grep "code proof budget refusal is not a legacy rerender" "$H" \
      'proof reads exceed repository capacity, is not a legacy rerender'
    assert_grep "code proof budget refusal stops before the legacy rerender" "$H" \
      'proof reads exceed repository capacity refusal, which stops before that rerender'
    assert_grep "receipt failure stops before another reviewer" "$H" \
      '[Rr]eceipt fails.*stop before another reviewer launch'
    assert_grep "host preserves the exact configured roster" "$H" \
      '[Ss]cope optimization never changes.*roster'
    assert_grep "host keeps a caller panel roster frozen" "$H" \
      'panel-request\.json` exists, set `PLAN_COMPLETENESS_SEAT` to the first surviving non-extra seat in that frozen roster, preferring one whose adapter is not `agent`, and do not read the workhorse for this seat'
    assert_grep "host preserves all four bundles" "$H" \
      '[Aa]ll four risk bundles at least once'
    assert_grep "host assigns bundles in stable roster order" "$H" \
      'core seat `i` receives bundle `BUNDLES\[i mod 4\]`'
    assert_grep "three-seat panels combine the missing bundle deterministically" "$H" \
      '[Tt]hree core seats.*fourth bundle.*first seat'
    assert_grep "surplus seats repeat bundles deterministically" "$H" \
      '[Ff]ive or more core seats.*cycle through `BUNDLES` again'
    assert_grep "the exact four-seat assignment is unchanged" "$H" \
      '[Ww]ith four core seats.*one canonical bundle per seat'
    assert_grep "composite bundles use one canonical assignment" "$H" \
      'join.*bundle names with `\+`'
    assert_grep "every code panel receives one composite red-team seat" "$H" \
      'Every code panel, including explicit numeric and read-only code panels, gives one existing core seat a composite red-team emphasis'
    assert_grep "composite red-team emphasis preserves canonical coverage" "$H" \
      'supplements and never replaces the canonical lens, bundle, fixed numeric lens, or evidence assignment'
    assert_grep "composite red-team ownership rotates deterministically" "$H" \
      'Select it deterministically from stable roster order and rotate it across code panels'
    assert_grep "numeric mode adds no composite panel" "$H" \
      'Numeric mode adds no panel for this composite assignment'
    assert_grep "qualifying adaptive reviews run one full red-team panel before planning" "$H" \
      'Large, high-risk, user-marked-important, or explicitly adversarial adaptive reviews run exactly one full red-team panel before planning'
    assert_grep "full red-team composes verification evidence and canonical bundles" "$H" \
      'PANEL_PHASE=verification.*existing four canonical bundle assignments'
    assert_grep "unchanged verification is checked by the coverage helper" "$H" \
      'current-coverage.*\$S'
    assert_grep "risk receipts are never promoted to verification" "$H" \
      '[Nn]ever relabel a risk receipt'
    assert_grep "ordinary and numeric schedules keep their verification obligation" "$H" \
      '[Ss]implicity-only.*numeric.*unchanged'
    assert_grep "full red-team assignments are explicitly distinct" "$H" \
      'four distinct composed adversarial assignments'
    assert_grep "full red-team covers attacker behavior and trust boundaries" "$H" \
      'correctness and boundaries plus attacker behavior and trust boundaries'
    assert_grep "full red-team covers rollback and recovery" "$H" \
      'security, state, and API plus rollback and recovery'
    assert_grep "full red-team covers duplication and exhaustion" "$H" \
      'concurrency, resources, and performance plus duplication and exhaustion'
    assert_grep "full red-team covers compatibility and integration" "$H" \
      'tests, observability, and regression plus consumer compatibility and integration'
    assert_grep "full red-team concatenates multi-bundle emphases" "$H" \
      '[Ww]hen a core seat carries multiple canonical bundles.*concatenate.*matching adversarial emphases.*single prompt'
    assert_grep "full red-team cycles surplus-seat emphases" "$H" \
      '[Ff]or surplus seats.*cycle.*mapped adversarial emphasis.*canonical bundle'
    assert_grep "verification owner traces integration boundaries" "$H" \
      '[Vv]erification owner always traces the cumulative change through consumers and integration boundaries'
    assert_grep "compatibility routing is explicit" "$H" \
      'compatibility and consumer contracts for public APIs, protocols, schemas'
    assert_grep "recovery routing is explicit" "$H" \
      'recovery and idempotency for persistence, external writes, migrations, retries'
    assert_grep "security routing is explicit" "$H" \
      'security and trust boundaries for authentication, authorization, signatures'
    assert_grep "red-team findings join initial clusters without another cycle" "$H" \
      'joins the same initial finding clusters and does not grant another correction cycle'
    assert_grep "ordinary stopping rules remain unchanged" "$H" \
      'The ordinary adaptive and numeric stopping rules remain unchanged'
    assert_grep "document reviews exclude automatic red-team coverage" "$H" \
      'Document panels receive no automatic red-team assignment unless the user explicitly requests an adversarial document review'
    assert_grep "evidence owns component assignment" "$H" \
      '`rev-evidence\.py` owns semantic component assignment'
    assert_grep "components retain specialist and integration coverage" "$H" \
      '[Ee]very semantic component.*specialist.*full-state'
    assert_grep "later fixes return to prior finding owners" "$H" \
      '[Pp]rior finding.*returns to that finding owner'
    assert_grep "integration-owned findings still get a specialist" "$H" \
      '[Ii]ntegration.*least-loaded specialist'
    assert_grep "invalid owner data restores normal routing" "$H" \
      '[Mm]issing or invalid ownership data.*normal component routing'
    assert_grep "unprovable component coverage widens fully" "$H" \
      '[Cc]omponent coverage cannot be proved.*full cumulative patch'
    assert_grep "benign non-delta verification keeps component routing" "$H" \
      '[Nn]o usable delta.*cumulative semantic scope'
    assert_grep "only delta verification binds prior coverage" "$H" \
      '[Oo]nly.*delta scope.*predecessor'
    assert_grep "invalid predecessor widens verification fully" "$H" \
      '[Ii]nvalid predecessor.*every seat.*full cumulative patch'
    assert_grep "host treats source-context bytes as original source" "$H" \
      'literal source bytes with original'
    assert_grep "host bounds specialist packet shards" "$H" \
      '[Ss]pecialist receives.*one 32 KiB shard'
    assert_grep "host bounds integration packet shards" "$H" \
      'integration seat receives at most three'
    assert_grep "host carries the paired source-context switch through prepare" "$H" \
      'REV_SOURCE_CONTEXT=\$\{REV_SOURCE_CONTEXT:-1\} python3'
    assert_grep "host carries the patch chunk switch through prepare" "$H" \
      'REV_PATCH_CHUNKS=\$\{REV_PATCH_CHUNKS:-auto\} REV_SOURCE_CONTEXT='
    assert_grep "host keeps the monolithic patch as chunk identity" "$H" \
      'SHA-256 remain the identity'
    assert_grep "host shares identical patch sets" "$H" \
      '[Ii]dentical assigned patch bodies share one patch set'
    assert_grep "host records conservative chunk limits" "$H" \
      '24 KiB raw, 30 KiB.*eight prefix bytes'
    assert_grep "host preserves the ordinary output authority" "$H" \
      '32 KiB per-tool and ordinary per-turn output limits still apply'
    assert_grep "host keeps mixed ordered proof batches to two reads" "$H" \
      'Mixed ordered proof turns may use at most two reads under a 60 KiB combined cap'
    assert_grep "host limits Claude four-read batches to source-only segments" "$H" \
      'Claude may use up to four consecutive required-source-segment reads in a source-only turn.*do not mix them with patch chunks or the evidence index'
    assert_grep "host keeps packet and repository turns ordinary" "$H" \
      'Source-context packets and repository reads retain the ordinary 32 KiB turn cap'
    assert_grep "host orders chunk reads before source packets" "$H" \
      'full, before source-context packets or source expansion'
    assert_grep "host denies chunk source citation credit" "$H" \
      'discovery only; they never establish source citation evidence'
    assert_grep "host documents the ten percent chunk gate" "$H" \
      '^10 percent against 240-line windows'
    assert_grep "host documents safe legacy chunk fallback" "$H" \
      'chunk set, or `REV_PATCH_CHUNKS=0` keeps window mode'
    assert_grep "host rejects incomplete chunk receipts" "$H" \
      '[Mm]issing, reordered, truncated, replaced,'
    assert_grep "host rejects redirected chunk receipts" "$H" \
      'unassigned, or redirected chunks invalidate the attempt'
    assert_nogrep "size is not a completeness failure in the host contract" "$H" \
      'oversized, unassigned, or unparseable|redirected, or oversized chunks'
    assert_grep "host preserves component narrowing in paired baseline" "$H" \
      'same component assignments and patch narrowing'
    assert_grep "host checks narrow read audits before triage" "$H" \
      '[Bb]efore triage or receipt.*read-audit'
    assert_grep "every evidence seat requires a schema 2 read audit" "$H" \
      '[Ee]very evidence-launched seat.*schema 2'
    assert_grep "an invalid read audit is a hard evidence-audit failure" "$H" \
      "read audit with status .invalid. is a hard evidence-audit failure"
    assert_grep "advisories stay visible and never earn credit" "$H" \
      'valid audit may carry advisories: these never discard the review, stay visible in the receipt, and never earn credit'
    assert_grep "a violating call or overflowing turn proves nothing" "$H" \
      'A call that raises a call-local violation, and every proof call in a turn that overflows the turn ceiling, proves no range, no patch chunk, packet or segment, and no citation\. Pacing counts and whole-transcript counts revoke nothing\.'
    assert_grep "a hard audit failure ends only that seat's assignment" "$H" \
      "[Hh]ard evidence-audit failure ends only that seat's assignment: never relaunch that seat under that label"
    assert_grep "seat-local recovery retains valid completed reviewers" "$H" \
      '[Rr]etain each completed valid result'
    assert_grep "host retains one launch handle for every pending seat" "$H" \
      '[Rr]etain.*launch handle.*every pending seat'
    assert_grep "host inspects terminal results as they arrive" "$H" \
      '[Ii]nspect.*terminal result.*as.*arrive'
    assert_grep "host cancels pending siblings on auth or quota exit" "$H" \
      '[Ee]xit 3 or 4.*cancel.*pending sibling'
    assert_grep "host keeps authentication failures permanent" "$H" \
      '[Ee]xit 3.*never enters quota fallback'
    assert_grep "host gates quota substitution on explicit config" "$H" \
      '`quota_fallback`.*`true`'
    assert_grep "host reruns preflight after a quota failure" "$H" \
      '[Rr]un preflight again.*fresh sibling session'
    assert_grep "quota fallback reloads sealed parent scope in a fresh shell" "$H" \
      '\. "\$PARENT_S/scope\.env"'
    assert_grep "quota fallback preserves a pinned PR number" "$H" \
      '--pr "\$REV_PR_NUMBER"'
    assert_grep "quota fallback preserves the pinned PR repository" "$H" \
      '--pr-repo "\$REV_PR_REPO"'
    assert_grep "host binds a mid-panel quota seat into preflight" "$H" \
      '--quota-failed-seat "\$SEAT"'
    assert_grep "quota fallback keeps the original session immutable" "$H" \
      '[Nn]ever run quota fallback preflight against the original session'
    assert_grep "quota fallback compares frozen session inputs" "$H" \
      'scope\.env.*files\.txt.*untracked\.txt'
    assert_grep "quota fallback compares content-addressed source identity" "$H" \
      'rev-evidence\.py.*same-source.*PARENT_MANIFEST.*MANIFEST'
    assert_grep "quota fallback covers same-path content mutations" "$H" \
      'same-path tracked, staged, and untracked content'
    assert_grep "quota fallback promotes the fresh panel label" "$H" \
      'PANEL_LABEL=\$FALLBACK_LABEL'
    assert_grep "quota fallback rebuilds active prompt arguments" "$H" \
      'EVIDENCE_PROMPT_ARGS=\(--evidence "\$MANIFEST"\)'
    assert_grep "quota fallback promotes its launched seat list" "$H" \
      'LAUNCHED_SEATS=\$FALLBACK_LAUNCHED_SEATS'
    assert_grep "host ignores reviewer prose when classifying Agent quota" "$H" \
      '[Pp]latform terminal metadata.*never reviewer prose'
    assert_grep "quota fallback restarts the complete frozen panel" "$H" \
      '[Rr]estart every assignment.*fresh full-panel label'
    assert_grep "quota fallback never creates a repair child" "$H" \
      '[Nn]ever use a repair child for quota fallback'
    assert_grep "quota fallback retries preferred providers next run" "$H" \
      '[Nn]ext review run probes the preferred providers again'
    assert_grep "host distinguishes local attempt exhaustion" "$H" \
      '[Ee]xit 7.*local attempt exhaustion'
    assert_grep "host preserves siblings when an audit stops the panel" "$H" \
      '[Hh]ard evidence-audit failure.*preserve.*valid sibling'
    assert_grep "host never cancels completed valid siblings" "$H" \
      'cancel a completed valid sibling'
    assert_grep "host retains partial streams on cancellation" "$H" \
      '[Pp]reserve.*partial stream'
    assert_nogrep "no host section can retry an audit failure" "$H" \
      '[Aa]n individual audit failure.*retr(y|ies)'
    assert_nogrep "Codex host has no unconditional exit 1/2 retry directive" "$H" \
      '[Ee]xit 1/2: retry'
    assert_nogrep "Claude host has no unconditional exit 1/2 retry table row" "$H" \
      '\| (`1` or `2`|seat exit 1 or 2) \| retry'
    assert_grep "collection retries only without an invalid audit" "$H" \
      '([Ee]xit 1/2|seat exit|`1` or `2`).*no invalid read audit.*retry'
    assert_grep "seat-local recovery preserves receipted effort" "$H" \
      '[Nn]ever lower effort|same receipted effort'
    assert_grep "triage may overlap stragglers without early edits" "$H" \
      '[Tt]riage valid results as they arrive'
    assert_grep "one quota fallback panel is the retry ceiling" "$H" \
      '[Qq]uota fallback panel.*only permitted full-panel restart'
    assert_grep "a hard audit inside the fallback panel follows the replacement rule" "$H" \
      'later hard audit inside the fallback panel follows the replacement rule'
    assert_grep "host requires citation range coverage" "$H" \
      '[Ee]very finding citation must intersect'
    assert_grep "host runs code evidence with Agent seats recorded unenforced" "$H" \
      'Code preparation RUNS with an Agent seat and records it as unenforced'
    assert_grep "numeric panels bypass evidence narrowing" "$H" \
      '[Ee]xplicit numeric.*full cumulative patch'
    assert_grep "document panels retain full reads" "$H" \
      '[Dd]ocument.*read every supplied document in full'
    assert_grep "plan preparation hash-binds the source plan" "$H" \
      '--phase plan --plan .*--plan-sha256'
    assert_grep "plan preparation keeps source context like code panels" "$H" \
      'REV_SOURCE_CONTEXT=\$\{REV_SOURCE_CONTEXT:-1\} python3 .*prepare "\$S" "\$PANEL_LABEL" \\$'
    assert_grep "plan locations are read only from Sites and the test path" "$H" \
      'Locations are read only from `Sites` and the first'
    assert_grep "plan completeness owns full-state coverage" "$H" \
      'plan-completeness seat receives'
    assert_grep "surplus plan seats never duplicate completeness" "$H" \
      'keep `plan-completeness` unique'
    assert_grep "plan clusters keep two independent readers" "$H" \
      'two independent'
    assert_grep "plan specialists use receipt-relative deltas" "$H" \
      'receive only the fix delta'
    assert_grep "plan specialist fallback stays cluster bounded" "$H" \
      'receive the cumulative cluster closure'
    assert_grep "plan specialists may receive three source shards" "$H" \
      'up to three'
    assert_grep "plan prompts are compiled before publication" "$H" \
      'validates each rendered plan prompt against the schema-4'
    assert_grep "plan specialists receive one exact first read" "$H" \
      'mandatory first native read'
    assert_grep "plan tasks forbid malformed first shell actions" "$H" \
      'compound shell command'
    assert_grep "plan clusters require repository-wide sibling searches" "$H" \
      'repository-wide sibling-site'
    assert_grep "plan cluster rg form covers hidden and ignored files" "$H" \
      "rg --hidden --no-ignore --glob '!.git/\\*\\*' --null -n"
    assert_grep "plan cluster grep form excludes only git metadata" "$H" \
      'grep --exclude-dir=\.git --null -r -n'
    assert_grep "plan cluster queries reject extra traversal filters" "$H" \
      'Do not add other globs'
    assert_grep "plan clusters support source ranges" "$H" \
      'path:start-end'
    assert_grep "plan panels use non-persisting verification" "$H" \
      'rev-evidence\.py"? verify-panel "\$S" "\$PANEL_LABEL"'
    assert_grep "plan validation never advances code coverage" "$H" \
      'never writes a receipt or advances `coverage-head\.json`'
    assert_grep "plan global evidence failure regenerates schema 4" "$H" \
      'prepare a fresh schema-4 label'
    assert_grep "capacity refusal is not an identical prepare retry" "$H" \
      'mandatory source reads exceed repository capacity` or `preparation timed out` is not that retry'
    assert_grep "prepare failure keeps a non-certifying diagnostic" "$H" \
      'prepare-diagnostic-<label>\.json'
    assert_grep "a prepare diagnostic never certifies" "$H" \
      'never certifies a panel'
    assert_grep "capacity refusal is not a provider-seat retry" "$H" \
      'do not use the provider-seat replacement'
    assert_grep "prepare names the stage it is in" "$H" \
      'evidence: stage <name>'
    assert_grep "plan seat failure retains valid siblings" "$H" \
      'retains valid sibling results'
    assert_grep "exhausted plan retry leaves the panel incomplete" "$H" \
      'plan panel incomplete'
    assert_grep "exhausted plan retry preserves completed siblings" "$H" \
      'preserve every completed sibling and partial stream'
    assert_grep "plan specialists never widen to full scope" "$H" \
      'Do not broaden a specialist to full scope'
    assert_grep "self-host verification is tiered" "$H" \
      '8-30 second'
    assert_grep "unchanged material trees reuse their gate" "$H" \
      'unchanged tree reuses that gate result'
    assert_grep "provider boundary changes require replay before payment" "$H" \
      'provider envelopes through the current auditor'
    assert_grep "provider replay follows the bound roster probe and precedes reviewer launches" "$H" \
      'after the roster probe.*before any reviewer launch'
    assert_nogrep "verification prose has no orphaned build fragment" "$H" \
      '^a broken build\.$'
    assert_grep "provider replay receipt binds every contract input" "$H" \
      'hash-keyed pass receipt'
    assert_grep "profile reports the active roster identity" "$H" \
      'core-roster signature'
    assert_grep "mixed rosters bound provider comparisons" "$H" \
      'mixed.*roster.*comparison boundary'
    assert_grep "Agent plan panels run rather than refusing" "$H" \
      'Plan preparation RUNS with an Agent seat and records it as unenforced rather than'
    assert_grep "an Agent plan panel is never reported as certified" "$H" \
      'never describe it\s*$|as certified'
  done
  skill_adapter_and_plan_gate_contract "$K" "$CK" "$T"
  assert_nogrep "Claude Agent output transcript is not treated as enforced evidence" "$K" \
    'audit every Agent `output_file` as adapter `agent`'
  assert_grep "Claude Agent transcript is retained for profiling" "$K" \
    'copy `<output_file>` to `\$S/r<N>-<seat>\.stream\.ndjson`'
  assert_grep "Claude skill records why Agent evidence is disabled" "$K" \
    'plugin subagents ignore'
  assert_grep "Claude host stores Bash and Agent task identifiers" "$K" \
    '[Ss]tore.*Bash task ID.*Agent task ID'
  assert_grep "Claude host stops only pending tasks" "$K" \
    'TaskStop.*only.*pending'
  assert_grep "Codex host stores attached execution session identifiers" "$CK" \
    '[Ss]tore.*attached execution session'
  assert_grep "Codex host interrupts only pending sessions" "$CK" \
    '[Ii]nterrupt.*only.*pending session'
  assert_grep "Claude host has one fan-out section" "$K" '^### Fan out$'
  assert_grep "Codex host has one fan-out section" "$CK" '^### Fan out$'
  awk '/^### Fan out$/{copy=1} /^### Collect$/{if(copy) exit} copy' "$K" > "$T/claude-fan-out"
  awk '/^### Fan out$/{copy=1} /^## Triage/{if(copy) exit} copy' "$CK" > "$T/codex-fan-out"
  assert_nogrep "Claude fan-out cannot overwrite adaptive prompts" "$T/claude-fan-out" \
    'rev-prompt\.sh.*\$S <N>'
  assert_nogrep "Codex fan-out cannot overwrite adaptive prompts" "$T/codex-fan-out" \
    'rev-prompt\.sh.*"\$S" "\$ROUND"'
  assert_grep "Claude schedule keeps state in round 5" "$K" '^\| 5 \| API & contract, compatibility \| api-contract, data-state, readability \| - \|$'
  assert_grep "Codex schedule keeps maintenance in round 5" "$CK" '^\| 5 \| Contracts and compatibility \| api-contract, readability, maintainability \| - \|$'
  for H in "$ST" "$CST"; do
    assert_grep "stack preserves numeric continuation" "$H" 'Numeric legs may continue past the requested minimum'
    assert_grep "stack excludes plan panels from numeric count" "$H" '[Pp]lan panels do not count'
    assert_grep "stack distinguishes retryable roster status" "$H" 'Exit 5 is retryable'
    assert_grep "stack distinguishes permanent roster status" "$H" 'Exit 6 is permanent'
    assert_grep "stack names the upstream destination" "$H" \
      'upstream destination|destination ref'
    assert_grep "stack binds that destination to the reviewed branch" "$H" \
      'reviewed branch'
    assert_grep "stack reconciles before pushing" "$H" '[Bb]efore pushing'
    assert_grep "stack reconciles the tracking ref" "$H" 'tracking ref'
    assert_grep "stack records successful pinned pushes" "$H" \
      '[Aa]fter a pinned push succeeds'
    assert_grep "stack checks branch movement after recording" "$H" \
      'before checking'
  done
  assert_grep "Claude stack documents post-push PR review publication" "$ST" \
    'latest completed review for'
  assert_grep "Codex stack documents post-push PR review publication" "$CST" \
    'latest actually completed session'

  local PRDOC="$SK/docs/pr-review.md"
  assert_exit "canonical PR review instructions are shipped" 0 test -f "$PRDOC"
  for H in "$K" "$CK"; do
    assert_grep "host requires the canonical PR review instructions" "$H" \
      'docs/pr-review\.md'
    assert_grep "host applies publication to read-only code reviews" "$H" \
      'normal and read-only'
    assert_grep "host skips branches without an open PR" "$H" \
      'no associated open PR skips cleanly'
    assert_grep "host blocks success when required publication fails" "$H" \
      'blocks `phase=done` and `report\.md`'
    assert_grep "host leaves stack publication until after push" "$H" \
      'final push'
    assert_grep "host gives stack legs a ready report" "$H" 'stack-report\.md'
    assert_grep "host gives stack legs a ready phase" "$H" 'phase=stack-ready'
    assert_grep "host keeps associated review sessions outside the checkout" "$H" \
      'associated with an open PR.*outside the reviewed'
  done
  assert_grep "PR review input preserves the decisions section" "$PRDOC" \
    '^  "decisions": \[$'
  assert_grep "PR review publisher uses a commit-pinned COMMENTED review" "$PRDOC" \
    'commit_id.*COMMENT'
  assert_grep "PR review publication keeps the inspected bytes" "$PRDOC" \
    'reads the saved Markdown without rerendering'
  local first_report_line
  first_report_line=$(awk '/^## Report/{inside=1; next} inside && NF{print; exit}' "$K")
  assert_eq "Claude report schema is not nested under publication" \
    "${first_report_line%%,*}" '1. **Outcome**'
  assert_grep "shared publication contract freezes the reviewed target" "$PRDOC" \
    'freezes the associated PR, reviewed merge base'
  assert_grep "shared publication contract binds a clean committed tree" "$PRDOC" \
    'staged, unstaged, or untracked bytes'
  assert_grep "shared publication contract rejects overlapping associated sessions" "$PRDOC" \
    'publication-capable sessions outside the reviewed checkout'
  assert_grep "shared publication contract revalidates the PR base" "$PRDOC" \
    'branch, base branch, reviewed merge base, and'
  assert_grep "shared publication contract binds discovery to reviewed remotes" "$PRDOC" \
    "restricted to repositories named by the reviewed checkout's"
  assert_grep "shared publication contract enforces NO_PUSH before GitHub" "$PRDOC" \
    'no-push gate'
  assert_grep "shared publication contract requires COMMENTED-state idempotence" "$PRDOC" \
    'exact `COMMENTED` review'
  assert_grep "shared publication contract makes confirmation the success boundary" "$PRDOC" \
    'later live-state check'
  assert_grep "shared publication contract uses the remote pending-review transaction" "$PRDOC" \
    'PENDING.*COMMENTED'
  assert_grep "shared publication contract limits pending recovery to safe owned drafts" "$PRDOC" \
    'owned.*no inline comments'
  assert_grep "shared publication contract requires the stack push barrier" "$PRDOC" \
    'every completed repository.*push'
  assert_grep "shared publication contract binds the stack destination branch" "$PRDOC" \
    'destination ref must equal the reviewed branch ref'
  assert_grep "shared publication contract reconciles prior pinned pushes before squash" "$PRDOC" \
    'tracking ref.*reconciled.*before squash'
  assert_grep "shared publication contract records a successful pinned push before branch checks" "$PRDOC" \
    'successful pinned push.*tracking ref.*before.*branch movement'
  assert_grep "shared publication contract requires post-squash final rendering" "$PRDOC" \
    'squash.*render'
  assert_grep "shared publication contract selects one stack session per repository" "$PRDOC" \
    'latest completed session for each repository'
  assert_grep "shared publication contract preserves separate-PR fix links" "$PRDOC" \
    '`fixed_in` remain pinned'
  assert_grep "shared publication contract derives finalization recovery durably" "$PRDOC" \
    'derives finalization from the frozen target'
  assert_nogrep "Codex host does not prohibit required PR publication" "$CK" \
    'not authorize pushing, publishing'
  assert_grep "Codex host limits publication authority to the canonical review" "$CK" \
    'authorizes only the canonical `COMMENTED` PR review'

  local read_only_section="$T/claude-read-only-section.md"
  awk '/^## Read-only panel$/{inside=1} inside && /^## / && $0 != "## Read-only panel"{exit} inside{print}' \
    "$K" > "$read_only_section"
  assert_grep "Claude read-only code path reaches PR review publication" \
    "$read_only_section" 'Follow \*\*PR review publication\*\*'

  # B1 - a resumed leg's ledger must be read, never truncated
  assert_grep "findings.md created only if absent" "$K" '\[ -f \$S/findings\.md \] \|\| printf'
  assert_grep "rejected.md created only if absent" "$K" '\[ -f \$S/rejected\.md \] \|\| : >'
  assert_nogrep "no unconditional ledger truncation" "$K" "^   printf '# Findings ledger"
  assert_grep "says create, never truncate" "$K" 'Create, never truncate'
  # B2 - every launched seat has a rendered prompt, and its lens is named
  assert_grep "numeric extra joins the single render pass" "$K" \
    'add it.*`LAUNCHED_SEATS` before the single render pass'
  assert_grep "numeric extra keeps its fixed lens" "$K" \
    'fixed.*`security` lens'
  # B3 - a path scope must not diff the whole branch, and untracked files are in no diff at all
  assert_grep "baseline patch is scoped" "$K" 'git diff \$REV_BASE -- "\$REV_SCOPE"'
  assert_grep "untracked appended to the baseline patch" "$K" 'git diff --no-index /dev/null "\$f" >> \$S/00-baseline\.patch'
  assert_grep "untracked.txt named in setup" "$K" 'untracked\.txt'
  assert_grep "session listing includes untracked.txt" "$K" 'scope\.env  files\.txt  untracked\.txt'
  # B9 - --read-only over code has a documented path of its own
  assert_grep "read-only over code documented" "$K" '\*\*Code with `--read-only`\*\*'
  assert_grep "read-only code still preflights" "$K" 'rev-preflight\.sh --scope <scope> --write \$S'
  assert_grep "read-only code skips fix/verify/commit" "$K" 'no \*\*Fix\*\*, no \*\*Verify\*\*'
  # inherited loop machinery that other tasks' scripts depend on
  assert_grep "failure table kept" "$K" '\| seat exit 3 \|'
  assert_grep "status tick kept" "$K" 'rev-status\.sh'
  assert_grep "Claude status watcher exits at terminal state" "$K" \
    'rev-context\.py \\"\$S\\" --watch --interval 600 --poll-interval 5'
  assert_nogrep "Claude status watcher does not loop past terminal state" "$K" \
    'while true; do sleep 600;.*rev-status\.sh'
  assert_grep "ledger format kept" "$K" '## F-012 · P1 · FIXED'
  assert_grep "report sections kept" "$K" 'Residual risk'
  assert_grep "stack-leg mode kept" "$K" 'REV_STACK_LEG=1'
  # A7 - the stack's verdict and finish semantics
  assert_grep "failed leg blocks its repo's finish" "$ST" 'COMPLETE WITH FAILURES'
  assert_grep "squash and push are independent" "$ST" 'squash refused for <repo>'
}

# C-7 and C-8: evidence mode follows each row's adapter, the plan gate defaults to one seat and runs
# before code, verification seats check sibling sites, and evidence panels render in one --panel call.
skill_adapter_and_plan_gate_contract() {
  local K=$1 CK=$2 W=$3 H host flat
  local host_evidence="Evidence mode depends on each launched row's adapter, never on the host."
  local cli_rows='Rows on adapters `codex`, `gemini`, and `claude` launch through `rev-seat.sh` and keep evidence mode.'
  local adapter_choice='`claude_adapter` decides whether a Claude Code host seats Claude rows on `agent`; a Codex host always seats them on `claude`.'
  local plan_refusal='Plan preparation RUNS with an Agent seat and records it as unenforced rather than'
  local refusal_skip='Report such a panel as an unenforced plan panel; never describe it'
  local code_unenforced='Code preparation RUNS with an Agent seat and records it as unenforced rather than'
  local code_report='Report such a panel as partially unenforced; never describe it as'
  local ungated_audit='recorded in `unenforced_audits` with its would-have-passed verdict; nothing gates on it, because whether an Agent transcript clears the gate is unmeasured and gating on an unmeasured pass rate would trade one blanket refusal for another.'
  # The advisory audit re-walks every earlier round, so it runs only on request; the receipt records
  # its verdict, so the setting has to hold for the whole session.
  local audit_opt_in='With `REV_UNENFORCED_AUDIT=1`, an unenforced seat'"'"'s read audit is produced anyway'
  local audit_off='Without that flag no audit runs and each row records `would_pass: false` with the reason `advisory read audit is off`; keep one setting for the whole session, because the receipt records the verdict.'
  # An unenforced seat's result, exit and transcript are HASHED into the receipt, never compared to
  # the panel: only the prompt carries the manifest hash. Two independent fixtures proved a seat's
  # result and transcript can be swapped in from another panel and accepted. The contract said
  # "binding their result, exit and prompt hashes" in BOTH the code and the plan paragraph, so the
  # count below is two, not one - the sentence was already wrong for plan panels in 0.4.8, and a
  # one-paragraph fix would satisfy a bare fixed-string pin.
  local not_bound='Be exact about what that leaves proven: the prompt is bound to this manifest, but the result, exit and transcript are only hashed into the receipt, never compared to this panel, so a result or transcript filed under the wrong seat or round is recorded rather than detected.'
  local misfiling='The orchestrator writes each Agent seat'"'"'s result by hand, so a misfiling is the realistic failure here, not an attacker.'
  # The prohibition this replaced: a whole code panel skipped evidence preparation because one row
  # was an Agent row. Claude rows resolve to `agent` wherever the Claude CLI is not seated, so that
  # sentence meant evidence mode never ran on a code panel at all.
  local blanket_skip='skip evidence preparation'
  local plan_default='When `$S/panel-request.json` is absent, the plan panel is one `plan-completeness` seat on the resolved workhorse: set `PLAN_COMPLETENESS_SEAT` to the `seat` in `$S/workhorse.json` when `family` is set, `PLAN_SEATS` to the JSON array `["<that seat>"]`, and set `PLAN_EVIDENCE_ARGS=(--assignment "$PLAN_COMPLETENESS_SEAT=plan-completeness")`.'
  local local_cluster='A cluster is local when its Sites list names one file and at most 3 sites, and the change does not add a mechanism, cross a realm, or change a public contract. Two anchors in one file are two sites. Excluded paths are not sites. The workhorse writes the fix plan whenever it is available. You implement each local cluster. You launch the workhorse for every other cluster. When a panel or assignment is incomplete, fix a local cause you can see.'
  local plan_all='When `roster.json` has `"plan_seats": "all"`, set `PLAN_SEATS` to the JSON array of every surviving non-extra seat'
  local minimum='Repair children use `<N>x`, then distinct suffixed labels such as `<N>x2`; the default one-seat plan panel remains a separate exception.'
  local verify_one='`verify-panel` certifies the one-seat plan panel once that seat returns'
  local before_code='The plan panel runs after triage and before any edit of the working tree.'
  local skip_line='When the plan panel is skipped, append a line beginning `Plan panel r<N>p - SKIPPED: <reason>` to `$S/findings.md` before `phase=fix`.'
  local gate='`rev-state.sh` refuses `phase=fix` for code round `<N>` while `open.P0 + open.P1 + open.P2` is above zero, unless the skip line exists, every original plan assignment has its own valid result or a successful bound one-seat replacement, or a current, hash-bound manual plan review accepts the full plan after the eligible chain is exhausted.'
  local incomplete='An incomplete plan panel is not a skip: after fixing a local cause, continue through `rev-workhorse.py escalate`, which honors a matching per-review override and otherwise uses the next higher enforced seat, until a valid plan result exists or the eligible chain is exhausted. Once each unresolved assignment has recorded terminal failure and no replacement is pending, review the plan yourself against the plan contract before any edit and record that review in `r<N>p-manual-plan-review.json`.'
  local fresh_counts='Write all three counts in one call after the round'"'"'s seats have exited: `rev-state.sh` refuses `phase=fix` while `open.P0`, `open.P1` and `open.P2` predate the newest `r<N>-<seat>.exit`, and only all three in one call refresh that stamp. A plan panel'"'"'s `r<N>p-<seat>.exit` is not a seat exit for this purpose, so triage stays valid across the plan gate.'
  local sibling='Sibling-site completeness: for each fix commit since the base, name the rule it applies and search the repository for sites, arms, realms, callers and copies (tests, JSDoc, docs) the rule reaches but the commit missed.'
  # Host-tied evidence wording that must never return: an evidence or plan decision keyed on the
  # host instead of a launched row's adapter.
  local host_tied='Claude Code host[^.]*(skip|legacy|refuse|unavailable)|(skip|refuse|unavailable)[^.]*on a Claude Code host'
  for H in "$K" "$CK"; do
    host=$(basename "$(dirname "$(dirname "$H")")")
    assert_flat_fixed "$host ties evidence mode to adapters, not the host" "$H" "$host_evidence"
    assert_flat_fixed "$host keeps evidence mode for CLI rows" "$H" "$cli_rows"
    assert_flat_fixed "$host names claude_adapter as the agent-row control" "$H" "$adapter_choice"
    assert_flat_fixed "$host refuses plan prep only for non-extra agent rows" "$H" "$plan_refusal"
    assert_flat_fixed "$host records a plan prep refusal as the skip reason" "$H" "$refusal_skip"
    assert_flat_fixed "$host prepares code evidence with an Agent row" "$H" "$code_unenforced"
    assert_flat_fixed "$host never calls a partly unenforced code panel certified" "$H" "$code_report"
    assert_flat_fixed "$host records the unenforced audit verdict without gating on it" "$H" "$ungated_audit"
    assert_flat_fixed "$host runs the advisory audit only when asked" "$H" "$audit_opt_in"
    assert_flat_fixed "$host says what an unasked advisory audit records" "$H" "$audit_off"
    assert_flat_fixed "$host says a misfiled unenforced result goes undetected" "$H" "$not_bound"
    assert_flat_fixed "$host names hand transcription as the realistic failure" "$H" "$misfiling"
    local bound_hits
    bound_hits=$(tr '\n' ' ' < "$H" | tr -s ' ' | grep -o -F -- "$not_bound" | grep -c .)
    assert_eq "$host carries the unenforced-binding caveat in both the code and plan paragraphs" \
      "$bound_hits" 2
    assert_nogrep "$host no longer claims an unenforced result is bound" "$H" \
      'binding their result'
    assert_nogrep "$host never skips a whole code panel over an Agent row" "$H" "$blanket_skip"
    assert_nogrep "$host has no host-tied evidence rule" "$H" "$host_tied"
    assert_flat_fixed "$host defaults to one plan-completeness seat" "$H" "$plan_default"
    assert_flat_fixed "$host keeps a local cluster with the orchestrator" "$H" "$local_cluster"
    assert_grep "$host restores every core seat with plan_seats all" "$H" "$(printf '%s' "$plan_all" | sed 's/[][\.*^$|+?(){}]/\\&/g')"
    assert_flat_fixed "$host exempts the one-seat plan from the three-seat minimum" "$H" "$minimum"
    assert_flat_fixed "$host certifies a one-seat plan panel" "$H" "$verify_one"
    assert_flat_fixed "$host runs the plan panel before code" "$H" "$before_code"
    assert_flat_fixed "$host records a skipped plan panel" "$H" "$skip_line"
    assert_flat_fixed "$host states the rev-state fix gate" "$H" "$gate"
    assert_flat_fixed "$host stops on an incomplete plan panel" "$H" "$incomplete"
    assert_flat_fixed "$host requires counts written after the round's seat exits" "$H" "$fresh_counts"
    assert_flat_fixed "$host verification seats check sibling sites" "$H" "$sibling"
    assert_grep "$host renders a panel in one --panel call" "$H" \
      'rev-prompt\.sh"? "\$S" "\$PANEL_LABEL" --panel "\$S/r\$PANEL_LABEL-panel\.tsv" "\$\{PHASE_PROMPT_ARGS\[@\]\}" "\$\{EVIDENCE_PROMPT_ARGS\[@\]\}"$'
    assert_grep "$host passes the panel phase to renders" "$H" 'PHASE_PROMPT_ARGS=\(--phase "\$PANEL_PHASE"\)'
    assert_grep "$host renders the plan panel with --panel" "$H" \
      'rev-prompt\.sh"? "\$S" "\$PANEL_LABEL" --panel "\$S/r\$PANEL_LABEL-panel\.tsv" \\$'
    assert_grep "$host keeps the per-seat form for a repair seat" "$H" \
      'rev-prompt\.sh"? "\$S" "\$PANEL_LABEL" "\$SEAT" "\$LENS" "\$EMPHASIS" --phase "\$COVERED_PHASE" "\$\{EVIDENCE_PROMPT_ARGS\[@\]\}"'
    assert_nogrep "$host has no per-seat panel render left" "$H" '"\$EMPHASIS" "\$\{EVIDENCE_PROMPT_ARGS'
    assert_nogrep "$host has no per-seat plan render left" "$H" '<seat> <plan-lens>'
    # The plan gate must be stated before the host is told to enter the fix phase.
    local gate_line fix_line
    gate_line=$(grep -n 'The plan panel runs after triage and before any edit of the working tree' "$H" | head -1 | cut -d: -f1)
    fix_line=$(grep -nE '^`\$\{CLAUDE_PLUGIN_ROOT\}/scripts/rev-state\.sh \$S phase=fix`|^Before the first edit, write `rev-state\.sh "\$S" phase=fix`' "$H" | head -1 | cut -d: -f1)
    if [ -n "$gate_line" ] && [ -n "$fix_line" ] && [ "$gate_line" -lt "$fix_line" ]; then
      ok "$host states the plan gate before entering phase=fix"
    else
      fail "$host states the plan gate before entering phase=fix" "gate line '$gate_line', fix line '$fix_line'"
    fi
  done
  # Plant each forbidden host-tied form so the negative assertion above cannot pass vacuously.
  printf 'On a Claude Code host, skip evidence preparation.\n' > "$W/planted-host-tied-1.md"
  printf 'Plan review is unavailable on a Claude Code host.\n' > "$W/planted-host-tied-2.md"
  for flat in "$W/planted-host-tied-1.md" "$W/planted-host-tied-2.md"; do
    assert_grep "planted host-tied rule is detected: $(basename "$flat")" "$flat" "$host_tied"
  done
  # Plant the blanket skip too, so its negative assertion above cannot pass vacuously.
  printf 'If any launched code-panel roster row has adapter `agent`, skip evidence preparation.\n' \
    > "$W/planted-blanket-skip.md"
  assert_grep "planted blanket code-evidence skip is detected" "$W/planted-blanket-skip.md" "$blanket_skip"
  # Same for the overclaim: plant it so its negative assertion cannot pass vacuously.
  printf 'validation skips only their read audit while still binding their result, exit and prompt hashes.\n' \
    > "$W/planted-bound-claim.md"
  assert_grep "planted unenforced-binding overclaim is detected" "$W/planted-bound-claim.md" \
    'binding their result'

  assert_grep "Claude host documents claude_adapter values and override" "$K" \
    '`claude_adapter` \(`cli`, `agent`, or `auto`, default'
  assert_grep "Claude host names the adapter environment override" "$K" 'REVIEW_COUNCIL_CLAUDE_ADAPTER` wins'
  assert_flat_fixed "Claude host pads on the resolved adapter" "$K" \
    'roster appends Claude seats - `claude-1`, `claude-2`, … , on the resolved Claude adapter (`claude` or `agent`), marked `"padded": true`'
  assert_nogrep "Claude padding no longer pins the agent adapter" "$K" 'adapter `agent`, marked'
  assert_nogrep "Claude host no longer calls every Claude seat a subagent" "$K" 'configured Claude subagents'
  assert_flat_fixed "Claude fan-out launches claude rows through rev-seat.sh" "$K" \
    'per seat whose adapter is `codex`, `gemini`, or `claude` - each launches through `rev-seat.sh` - and one `Agent` call per seat whose adapter is `agent`.'
  assert_nogrep "Claude fan-out has no adapter-script shorthand" "$K" 'an adapter script'
  assert_flat_fixed "Claude records transcripts only for agent rows" "$K" \
    'for each row whose adapter is `agent`, record its Agent result path under its seat name'
  assert_flat_fixed "Claude stack legs poll every rev-seat.sh row" "$K" \
    'Launch every `rev-seat.sh` row - `codex`, `gemini`, and `claude` alike - with `run_in_background` as usual, then **wait for them with a foreground poll**'
  assert_grep "Codex host writes phase=fix before its first edit" "$CK" \
    '^Before the first edit, write `rev-state\.sh "\$S" phase=fix`\.$'
  assert_grep "Codex host shares the plan_seats key" "$CK" '`plan_seats`, and `quota_fallback` are shared with Claude Code'
}

# assert_flat_fixed matches a SUBSTRING, so a pin that stops mid-sentence is satisfied by the
# weakened sentence containing it: appending ", or skip the red run entirely when it is
# inconvenient" after "watch it fail" inverted this branch's flagship obligation with every
# assertion green. Each of the four pins below therefore runs through its own sentence terminator
# and into the opening words of the sentence after it, which is what bounds it - the appended
# clause now falls inside the pinned span. The four spans interlock in pairs (each pin's tail is
# the next one's head), so nothing can be inserted between the full-gate sentence and the mutation
# invocation, or between the red-run sentence and the Implement/Apply directive. The helper is
# deliberately left alone: the pins elsewhere that share its weakness are a separate task.
test_skill_requires_the_full_gate_list_on_a_fix_commit() {
  rev_bundle "$SK/skills/rev" "$T/skills/rev/SKILL.md"
  rev_bundle "$SK/codex-skills/rev" "$T/codex-skills/rev/SKILL.md"
  ( local tick='`'
    local want="Run the repository's required gate list within the user's authorized scope, and record the result in the ledger. Then run rev-mutate.sh over the changed hunks"
    local mut="run rev-mutate.sh over the changed hunks before committing: revert each hunk alone and confirm a test notices, and compare what failed against the cluster's Prediction: $tick"
    assert_flat_fixed "rev skill requires the full gate list" \
      "$T/skills/rev/SKILL.md" "$want"
    assert_flat_fixed "codex skill requires the full gate list" \
      "$T/codex-skills/rev/SKILL.md" "$want"
    assert_flat_fixed "rev skill invokes the mutation check" \
      "$T/skills/rev/SKILL.md" "$mut"
    assert_flat_fixed "codex skill invokes the mutation check" \
      "$T/codex-skills/rev/SKILL.md" "$mut" )
}

test_skill_requires_a_proven_red_before_the_fix() {
  rev_bundle "$SK/skills/rev" "$T/skills/rev/SKILL.md"
  rev_bundle "$SK/codex-skills/rev" "$T/codex-skills/rev/SKILL.md"
  ( local tick='`'
    local red="Run the test named in Prediction before the fix exists and watch it fail, once per cluster's Prediction, not once for the round. Record the observed failure line in fix-plan.md beside the Prediction it belongs to: a failure whose message"
    local stop='a failure whose message does not match the Prediction is a STOP, not a note, because a test that fails for an unrelated reason proves nothing about the defect.'
    assert_flat_fixed "rev skill requires a proven red" "$T/skills/rev/SKILL.md" "$red"
    assert_flat_fixed "codex skill requires a proven red" "$T/codex-skills/rev/SKILL.md" "$red"
    # The sentence after the STOP is the one place the two hosts word this differently.
    assert_flat_fixed "rev skill treats a mismatched failure as a stop" \
      "$T/skills/rev/SKILL.md" "$stop Implement each local cluster in ${tick}fix-plan.md${tick} yourself."
    assert_flat_fixed "codex skill treats a mismatched failure as a stop" \
      "$T/codex-skills/rev/SKILL.md" "$stop Apply each local cluster yourself." )
}

# rev-mutate.sh reports a verdict and the failing line; it never reads fix-plan.md, so it cannot
# check anything against a Prediction. The contract said it did, which is the shape of claim that
# survives precisely because no test can fail on it. Both hosts carry one definition, word for word.
test_skill_states_what_a_prediction_is_read_against() {
  rev_bundle "$SK/skills/rev" "$T/skills/rev/SKILL.md"
  rev_bundle "$SK/codex-skills/rev" "$T/codex-skills/rev/SKILL.md"
  ( local K
    local want='`Prediction` states which test fails, on which arm, at which assertion or message, and why - a concrete symptom, not a restatement of `Rule`. It is read twice, not filed and forgotten: Fix compares it against the observed pre-fix red run, and Verify compares it against the failure line `rev-mutate.sh` prints beside each pinned hunk. Both comparisons are yours - the tool surfaces what failed and never reads a prediction.'
    for K in "$T/skills/rev/SKILL.md" "$T/codex-skills/rev/SKILL.md"; do
      assert_flat_fixed "$(basename "$(dirname "$(dirname "$K")")") names both readers of a Prediction" "$K" "$want"
      assert_flat_absent "$(basename "$(dirname "$(dirname "$K")")") claims no automatic check" "$K" \
        'checked twice|checked against what a mutation'
      assert_eq "$(basename "$(dirname "$(dirname "$K")")") defines Prediction exactly once" \
        "$(tr '\n' ' ' < "$K" | tr -s ' ' | grep -o 'states which test fails' | grep -c .)" 1
    done )
}

# Pins the two IMPORTANT fixes from the fix-contract review: the mutation-check
# invocation must be runnable (a path plus arguments, not bare prose), and it must
# run before the commit directive on both hosts - the exact defect a relative-position
# mirror recreated on Codex (rev-mutate ran with nothing staged, exit 4).
assert_flat_order() {
  local name=$1 file=$2 pattern=$3 flat
  flat="$T/flat-order-$(basename "$file")-$RANDOM"
  tr '\n' ' ' < "$file" | tr -s ' ' > "$flat"
  grep -Eq -- "$pattern" "$flat" && ok "$name" || fail "$name" "no /$pattern/ in $file (flattened)"
}

test_skill_rev_mutate_invocation_is_runnable() {
  rev_bundle "$SK/skills/rev" "$T/skills/rev/SKILL.md"
  rev_bundle "$SK/codex-skills/rev" "$T/codex-skills/rev/SKILL.md"
  ( assert_flat_fixed "rev skill's mutation check has a runnable invocation" \
      "$T/skills/rev/SKILL.md" 'scripts/rev-mutate.sh $S "<the test command>"'
    assert_flat_fixed "codex skill's mutation check has a runnable invocation" \
      "$T/codex-skills/rev/SKILL.md" 'scripts/rev-mutate.sh "$S" "<the test command>"' )
}

test_skill_rev_mutate_precedes_commit() {
  rev_bundle "$SK/skills/rev" "$T/skills/rev/SKILL.md"
  rev_bundle "$SK/codex-skills/rev" "$T/codex-skills/rev/SKILL.md"
  ( assert_flat_order "rev skill runs the mutation check before Commit" \
      "$T/skills/rev/SKILL.md" 'rev-mutate.*### Commit'
    # Anchored on "the test command", not "rev-mutate": that word also appears in
    # the prose sentence describing the check, so a directive inserted between the
    # prose and the concrete invocation would still read as "after rev-mutate" and
    # pass. "the test command" occurs exactly once, inside the invocation itself.
    assert_flat_order "codex skill runs the mutation check before Commit only when" \
      "$T/codex-skills/rev/SKILL.md" 'the test command.*Commit only when' )
}

# The replacement-chain rule replaces every hard-audit stop and every coverage-repair clause, found by
# search in both host skills, and the review-origin breaker is stated where phase=fix is.
test_skill_replacement_and_breaker_contract() {
  rev_bundle "$SK/skills/rev" "$T/skills/rev/SKILL.md"
  rev_bundle "$SK/codex-skills/rev" "$T/codex-skills/rev/SKILL.md"
  python3 - "$T/skills/rev/SKILL.md" "$T/codex-skills/rev/SKILL.md" <<'PY'
import re, sys
RULE = ('continue that assignment through the configured eligible replacement chain until '
        'valid proof exists or no eligible seat remains.')
REMOVED = [
    'Each failed assignment gets at most one replacement',
    'If no eligible family remains, finish that assignment yourself',
    'a second failure occurs on the same assignment',
    'second replacement for the same assignment',
    'stop the current panel without another paid retry',
    'widen an evidence-audit failure into a full-state repair',
    'If a hard audit failure occurs in the fallback panel, stop',
    'never enters coverage repair',
    'Do not create a replacement generation for execution or audit compliance failures',
    'coverage repair',
    'stop the panel; preserve its diagnostics; do not relaunch that label',
    'hard plan read-audit failure stops the panel',
    'hard audit marker stops the panel',
    'returns at least three valid reviewers',
    'fresh review session',
    'Numeric, stack and legacy rounds have no receipt and are not counted',
]
problems = []
for path in sys.argv[1:]:
    text = open(path).read()
    host = 'codex' if 'codex-skills' in path else 'claude'
    flat = ' '.join(text.split())
    for phrase in REMOVED:
        if phrase.lower() in flat.lower():
            problems.append(f'{host}: removed clause survives: {phrase}')
    paragraphs = [' '.join(block.split()) for block in re.split(r'\n\s*\n', text)]
    rows = [line for line in text.splitlines() if line.startswith('|')]
    replacement_commands = [i for i, p in enumerate(paragraphs)
                            if '--parent-assignment "$PARENT_LABEL:$FAILED_SEAT"' in p]
    locations = {
        'hard-audit': [p for p in paragraphs if "hard evidence-audit failure ends only that seat's assignment" in p],
        'coverage-repair': [p for p in paragraphs if 'Do not certify an adaptive panel until every assignment has a valid result' in p],
        'replacement procedure': [paragraphs[i] + ' ' + paragraphs[i + 1]
                                  for i in replacement_commands if i + 1 < len(paragraphs)],
        'plan replacement': [p for p in paragraphs if 'round=<N>px' in p and 'plan-completeness' in p],
    }
    if host == 'claude':
        locations['failure table'] = [row for row in rows if row.startswith('| hard evidence-audit failure |')]
        if len(locations['failure table']) != 2:
            problems.append(f'{host}: expected two failure-table rows, found {len(locations["failure table"])}')
    else:
        locations['collection'] = [p for p in paragraphs if 'Exit 1/2 with no invalid read audit' in p]
    for name, found in locations.items():
        if not found:
            problems.append(f'{host}: no {name} location')
        elif name == 'replacement procedure' and not all(
                'parent without a terminal failure' in item
                and 'permits multiple attempts for one original failed assignment' in item
                and 'immediately failed parent' in item
                and 'duplicate child label' in item for item in found):
            problems.append(f'{host}: replacement procedure omits its binding safeguards')
        elif name not in ('plan replacement', 'replacement procedure') and not all(RULE in item for item in found):
            problems.append(f'{host}: the rule is missing at the {name} location')
    for phrase in ('"$S" review_origin_ack=<N>', 'inherit-breaker "$PARENT_S"',
                   'Apply the standing decision yourself', 'revert the cited review changes',
                   'defer the originating findings', 'An exit-4 quota substitution never uses a replacement child',
                   '`--panel` with the exact label containing that attempt',
                   'When `quota_fallback` is false, an exit-4 child is accepted only if',
                   'Receiptless legacy numeric rounds are not counted.',
                   'SDK numeric receipts also support this review-origin accounting;',
                   'they still never grant adaptive coverage.'):
        if phrase not in flat:
            problems.append(f'{host}: missing: {phrase}')
print('\n'.join(problems))
raise SystemExit(1 if problems else 0)
PY
  assert_eq "both skills state the replacement chain and review-origin breaker" "$?" 0
}

test_skill_keeps_one_commit_per_fix() {
  rev_bundle "$SK/skills/rev" "$T/skills/rev/SKILL.md"
  rev_bundle "$SK/codex-skills/rev" "$T/codex-skills/rev/SKILL.md"
  ( local rule="Review commits are never squashed: each fix is its own commit, and its subject names the finding IDs it closes, never the round."
    assert_flat_fixed "rev skill keeps one commit per fix" "$T/skills/rev/SKILL.md" "$rule"
    assert_flat_fixed "codex skill keeps one commit per fix" "$T/codex-skills/rev/SKILL.md" "$rule"
    assert_nogrep "rev skill no longer squashes after the loop" "$T/skills/rev/SKILL.md" 'rev-squash\.sh --apply'
    assert_nogrep "codex skill no longer squashes when authorized" "$T/codex-skills/rev/SKILL.md" 'rev-squash\.sh` dry-run'
    assert_nogrep "rev commit example carries no round" "$T/skills/rev/SKILL.md" 'fix\(rev\): round'
    assert_grep "rev commit example names finding IDs" "$T/skills/rev/SKILL.md" '^fix\(rev\): F-012, F-019 '
    assert_nogrep "stack skill no longer squashes per repo" "$SK/skills/stack/SKILL.md" 'one squash \+ one push per repo'
    assert_nogrep "no rev skill invokes rev-squash" "$T/skills/rev/SKILL.md" 'rev-squash'
    assert_nogrep "no codex rev skill invokes rev-squash" "$T/codex-skills/rev/SKILL.md" 'rev-squash'
    assert_nogrep "stack skills and runner promise no squashed commit" "$SK/skills/stack/SKILL.md" 'squashed review commit|squash \+ push' -i
    assert_nogrep "stack runner banner promises no squash" "$SK/scripts/stack.sh" 'squash \+ push per repo|post-squash' -i
    assert_grep "stack runner defaults to keeping review commits on every host" "$SK/scripts/stack.sh" '^NO_SQUASH=\$\{NO_SQUASH:-1\}$'
    assert_flat_fixed "rev skill commits each cluster on its own" "$T/skills/rev/SKILL.md" "Commit each cluster on its own: stage exactly that cluster's changes"
    assert_flat_fixed "rev skill keeps finding IDs unique" "$T/skills/rev/SKILL.md" "Finding IDs are unique within the session and never reused"
    assert_flat_fixed "codex skill keeps finding IDs unique" "$T/codex-skills/rev/SKILL.md" "Finding IDs are unique within the session and never reused"
    assert_flat_fixed "codex stack skill states the unsquashed default" "$SK/codex-skills/stack/SKILL.md" "keeps changes local and review commits one per fix"
    assert_flat_fixed "README states the unsquashed default on both hosts" "$SK/../../README.md" "so review commits stay one per fix on both hosts"
    assert_grep "codex doc table states the unsquashed default" "$SK/../../docs/codex.md" 'Push, keep one commit per fix' )
}
