# tests for Task 2 - sourced by run-tests.sh
write_plan_manifest() {
  local S=$1 label=$2 assignments=$3
  [ -f "$S/fix-plan.md" ] || printf '# Test plan\n' > "$S/fix-plan.md"
  python3 - "$S" "$label" "$assignments" <<'PY'
import hashlib
import json
from pathlib import Path
import sys

session = Path(sys.argv[1])
label = sys.argv[2]
assignments = json.loads(sys.argv[3])
plan = hashlib.sha256((session / 'fix-plan.md').read_bytes()).hexdigest()
manifest = {'label': label, 'phase': 'plan', 'plan': {'sha256': plan},
            'assignments': assignments}
(session / f'r{label}-evidence.manifest.json').write_text(json.dumps(manifest))
PY
}

test_state() {
  local S="$T/state-sess" ST="$SCRIPTS/rev-state.sh"
  "$ST" "$S" round=1 phase=fan-out min_rounds=7 >/dev/null
  assert_grep "creates state.json" "$S/state.json" '"round": 1'
  assert_grep "string value" "$S/state.json" '"phase": "fan-out"'
  "$ST" "$S" phase=triage open.P1=2 'seats=["codex-sol","codex-terra"]' last_commit=a1b2c3d >/dev/null
  assert_grep "merge keeps round" "$S/state.json" '"round": 1'
  assert_grep "overwrites phase" "$S/state.json" '"phase": "triage"'
  assert_grep "nested key" "$S/state.json" '"P1": 2'
  assert_grep "json list value" "$S/state.json" '"codex-terra"'
  assert_grep "sha stays string" "$S/state.json" '"last_commit": "a1b2c3d"'
  assert_exit "dotted path through scalar fails" 1 "$ST" "$S" round.sub=1
  assert_exit "usage without args fails" 1 "$ST"
}

# phase=fix with open P0-P2 findings needs a completed plan panel <N>p or a recorded skip line.
state_gate_refuses() {
  local name=$1 S=$2 round=$3; shift 3
  local before after rc
  before=$(cksum < "$S/state.json")
  "$SCRIPTS/rev-state.sh" "$S" "$@" > "$T/gate.out" 2> "$T/gate.err"; rc=$?
  after=$(cksum < "$S/state.json")
  if [ "$rc" -ne 2 ]; then
    printf '%s: unexpected phase=fix result rc=%s\n' "$name" "$rc" >&2
    cat "$T/gate.err" "$T/gate.out" "$S/state.json" >&2
  fi
  assert_eq "$name: refused" "$rc" 2
  assert_eq "$name: state unchanged" "$after" "$before"
  assert_grep "$name: names the round" "$T/gate.err" "refusing phase=fix for round $round:"
  assert_grep "$name: names the plan panel way out" "$T/gate.err" "plan panel r${round}p"
  assert_grep "$name: names the skip-line way out" "$T/gate.err" "Plan panel r${round}p - SKIPPED: <reason>"
  assert_grep "$name: names the manual-review way out" "$T/gate.err" "r${round}p-manual-plan-review.json"
}

state_gate_allows() {
  local name=$1 S=$2; shift 2
  local rc
  "$@" > "$T/gate-allow.out" 2> "$T/gate-allow.err"; rc=$?
  if [ "$rc" -ne 0 ]; then
    printf '%s: expected phase=fix to pass, got rc=%s\n' "$name" "$rc" >&2
    cat "$T/gate-allow.err" "$T/gate-allow.out" >&2
  fi
  assert_eq "$name" "$rc" 0
}

state_write_plan_manifest() {
  local session=$1 label=$2 freshness=$3 sha
  shift 3
  [ -f "$session/fix-plan.md" ] || printf 'Plan panel %s\n' "$label" > "$session/fix-plan.md"
  sha=$(python3 - "$session/fix-plan.md" <<'PY'
import hashlib
import pathlib
import sys
print(hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest())
PY
)
  [ "$freshness" = current ] || sha=$(printf '%064d' 0)
  python3 - "$session" "$label" "$sha" "$@" <<'PY'
import json
import pathlib
import sys
session = pathlib.Path(sys.argv[1])
label, sha = sys.argv[2:4]
assignments = {seat: {"bundle": "plan-completeness", "scope": "full"}
               for seat in sys.argv[4:]}
manifest = {"label": label, "phase": "plan", "plan": {"sha256": sha},
            "assignments": assignments}
(session / f"r{label}-evidence.manifest.json").write_text(json.dumps(manifest) + "\n")
PY
}

state_write_manual_plan_review() {
  local session=$1 label=$2 failed=$3 mutation=${4:-}
  python3 - "$session" "$label" "$failed" "$mutation" <<'PY'
import hashlib
import json
from pathlib import Path
import sys

session = Path(sys.argv[1])
label, failed, mutation = sys.argv[2:]
manifest_path = session / f'r{label}-evidence.manifest.json'
manifest_bytes = manifest_path.read_bytes()
manifest = json.loads(manifest_bytes)
review = {
    'schema_version': 1,
    'plan_label': label,
    'plan_sha256': hashlib.sha256((session / 'fix-plan.md').read_bytes()).hexdigest(),
    'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
    'reviewed_assignments': sorted(manifest['assignments']),
    'failed_assignments': sorted(filter(None, failed.split(','))),
    'escalation_exhausted': True,
    'decision': 'accepted',
    'summary': 'Reviewed every cluster against the plan contract.',
    'contract_checks': {
        'required_cluster_fields': True,
        'bounded_site_search_and_path_accounting': True,
        'falsifiable_tests_and_predictions': True,
        'authorized_scope_preserved': True,
        'objections_resolved': True,
    },
}
if mutation == 'unchecked':
    review['contract_checks']['authorized_scope_preserved'] = False
if mutation == 'missing-assignment':
    review['reviewed_assignments'] = []
if mutation == 'stale-plan':
    review['plan_sha256'] = '0' * 64
if mutation == 'stale-manifest':
    review['manifest_sha256'] = '0' * 64
(session / f'r{label}-manual-plan-review.json').write_text(json.dumps(review) + '\n')
PY
}

state_record_terminal_failure() {
  local session=$1 label=$2 seat=$3 prompt attempt code
  prompt="$session/r${label}-${seat}.prompt.md"
  attempt="$SCRIPTS/lib/rev-attempt.py"
  printf 'review prompt\n' > "$prompt"
  for code in 2 2; do
    python3 "$attempt" reserve "$session" "$label" "$seat" "$prompt" || return
    python3 "$attempt" record "$session" "$label" "$seat" "$prompt" "$code" || return
  done
  printf '2\n' > "$session/r${label}-${seat}.exit"
}

state_record_quota_disabled_failure() {
  local session=$1 label=$2 seat=$3 replacement=$4 code final prompt attempt config token
  shift 4
  prompt="$session/r${label}-${seat}.prompt.md"
  attempt="$SCRIPTS/lib/rev-attempt.py"
  config="$session/review-council-config.json"
  printf '{}\n' > "$config"
  printf 'review prompt\n' > "$prompt"
  for code in "$@"; do
    token=$(python3 -c 'import secrets; print(secrets.token_hex(16))') || return
    python3 "$attempt" reserve "$session" "$label" "$seat" "$prompt" "$token" || return
    python3 "$attempt" record "$session" "$label" "$seat" "$prompt" "$code" "$token" || return
    final=$code
  done
  printf '%s\n' "$final" > "$session/r${label}-${seat}.exit"
  if [ "$replacement" != none ]; then
    REVIEW_COUNCIL_CONFIG="$config" python3 "$attempt" record-quota-disabled-escalation \
      "$session" "$label" "$seat" "$replacement" || return
  fi
}

state_write_prepare_diagnostic() {
  local session=$1 label=$2
  python3 - "$session" "$label" <<'PY'
import json
from pathlib import Path
import sys

session = Path(sys.argv[1])
label = sys.argv[2]
diagnostic = {
    'schema_version': 1,
    'kind': 'prepare-diagnostic',
    'certifying': False,
    'label': label,
    'phase': 'plan',
    'stage': 'capacity',
    'timed_out': False,
    'error': 'mandatory source reads exceed repository capacity',
    'refusals': [{'seat': 'codex-sol', 'limit': 16, 'count': 17}],
}
(session / f'prepare-diagnostic-{label}.json').write_text(json.dumps(diagnostic) + '\n')
PY
}

test_state_fix_gate() {
  local ST="$SCRIPTS/rev-state.sh" S

  S="$T/gate-refused"
  "$ST" "$S" round=3 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
  state_gate_refuses "no plan and no skip" "$S" 3 phase=fix
  assert_grep "refusal keeps the triage phase" "$S/state.json" '"phase": "triage"'
  printf '# Findings ledger\n\n  Plan panel r3p - SKIPPED: indented\n> Plan panel r3p - SKIPPED: quoted\nPlan panel r13p - SKIPPED: other round\nPlan panel r3p - SKIPPED:   \n' > "$S/findings.md"
  state_gate_refuses "skip line must start the line, match the round, and carry a reason" "$S" 3 phase=fix

  S="$T/gate-skip-no-manifest"
  "$ST" "$S" round=3 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
  printf 'Plan panel r3p - SKIPPED: no prepared plan manifest\n' > "$S/findings.md"
  state_gate_refuses "skip line without a current manifest" "$S" 3 phase=fix

  S="$T/gate-refused"
  "$ST" "$S" phase=plan round=3p 'seats=["codex-sol"]' >/dev/null
  state_write_plan_manifest "$S" 3p current codex-sol
  "$ST" "$S" phase=triage round=3 >/dev/null
  printf 'Plan panel r3p - SKIPPED: every accepted fix is a one-line P2\n' >> "$S/findings.md"
  assert_exit "recorded skip line allows fix" 0 "$ST" "$S" phase=fix
  assert_grep "allowed fix is written" "$S/state.json" '"phase": "fix"'

  S="$T/gate-effective-counts"
  "$ST" "$S" round=2 phase=triage open.P1=1 >/dev/null
  assert_exit "counts cleared in the same call allow fix" 0 "$ST" "$S" phase=fix open.P1=0
  "$ST" "$S" phase=triage >/dev/null
  state_gate_refuses "counts raised in the same call" "$S" 2 phase=fix open.P2=1
  "$ST" "$S" open.P2=0 'open.P1="one"' >/dev/null
  local before rc
  before=$(cksum < "$S/state.json")
  "$ST" "$S" phase=fix > /dev/null 2> "$T/gate.err"; rc=$?
  assert_eq "a non-integer count fails closed" "$rc" 2
  assert_eq "a non-integer count leaves state unchanged" "$(cksum < "$S/state.json")" "$before"
  assert_grep "a non-integer count names its key" "$T/gate.err" "open.P1='one' is not a non-negative integer"

  S="$T/gate-one-seat-plan"
  "$ST" "$S" round=4 phase=triage open.P0=1 open.P1=2 >/dev/null
  before=$(cksum < "$S/state.json")
  "$ST" "$S" phase=plan round=4p seats=codex-sol > /dev/null 2> "$T/plan-seats.err"; rc=$?
  assert_eq "a bare plan seat name is refused at launch" "$rc" 2
  assert_eq "a refused plan launch leaves state unchanged" "$(cksum < "$S/state.json")" "$before"
  assert_grep "the plan launch refusal names the JSON array form" "$T/plan-seats.err" 'seats must be a JSON array of seat names'
  "$ST" "$S" phase=plan round=4p 'seats=["codex-sol"]' >/dev/null
  state_write_plan_manifest "$S" 4p current codex-sol
  assert_eq "plan launch persists its seats" \
    "$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["plans"]["4p"])' "$S/state.json")" "['codex-sol']"
  state_gate_refuses "plan launched but not returned" "$S" 4 phase=fix
  printf '{"findings":[]}\n' > "$S/r4p-codex-sol.json"
  state_gate_refuses "plan result without an exit receipt" "$S" 4 phase=fix
  echo 0 > "$S/r4p-codex-sol.exit"
  assert_exit "completed one-seat plan allows fix" 0 "$ST" "$S" phase=fix
  assert_grep "fix after a plan panel is written" "$S/state.json" '"phase": "fix"'
  "$ST" "$S" round=5 phase=triage open.P1=1 >/dev/null
  state_gate_refuses "a completed plan for another round does not count" "$S" 5 phase=fix

  S="$T/gate-plan-seat-failed"
  "$ST" "$S" round=6 phase=triage open.P1=1 >/dev/null
  "$ST" "$S" phase=plan round=6p 'seats=["codex-sol","opus"]' >/dev/null
  state_write_plan_manifest "$S" 6p current codex-sol opus
  printf '{"findings":[]}\n' > "$S/r6p-codex-sol.json"; echo 0 > "$S/r6p-codex-sol.exit"
  printf '{"findings":[]}\n' > "$S/r6p-opus.json"; echo 2 > "$S/r6p-opus.exit"
  state_gate_refuses "a plan seat with a nonzero exit" "$S" 6 phase=fix
  rm -f "$S/r6p-opus.json"; echo 0 > "$S/r6p-opus.exit"
  state_gate_refuses "a plan seat with an exit but no result" "$S" 6 phase=fix
  printf '{"findings":[]}\n' > "$S/r6p-opus.json"
  assert_exit "every plan seat returned allows fix" 0 "$ST" "$S" phase=fix

  S="$T/gate-plan-manual-review"
  "$ST" "$S" round=8 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
  "$ST" "$S" phase=plan round=8p 'seats=["codex-opus"]' >/dev/null
  state_write_plan_manifest "$S" 8p current codex-opus
  state_record_terminal_failure "$S" 8p codex-opus
  printf '{"status":"invalid"}\n' > "$S/r8p-codex-opus.audit-invalid.json"
  state_write_manual_plan_review "$S" 8p codex-opus
  assert_exit "explicit full-plan manual review allows fix after hard seat failure" 0 "$ST" "$S" phase=fix
  assert_grep "manual fallback is recorded separately from a seat result" "$S/r8p-manual-plan-review.json" '"decision": "accepted"'
  test ! -e "$S/r8p-codex-opus.json"
  assert_eq "manual fallback does not fabricate a seat result" "$?" 0
  assert_eq "manual fallback preserves the failed exit receipt" \
    "$(cat "$S/r8p-codex-opus.exit")" 2

  for mutation in unchecked missing-assignment stale-plan stale-manifest; do
    S="$T/gate-plan-manual-review-$mutation"
    "$ST" "$S" round=9 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
    "$ST" "$S" phase=plan round=9p 'seats=["codex-opus"]' >/dev/null
    state_write_plan_manifest "$S" 9p current codex-opus
    state_record_terminal_failure "$S" 9p codex-opus
    printf '{"status":"invalid"}\n' > "$S/r9p-codex-opus.audit-invalid.json"
    state_write_manual_plan_review "$S" 9p codex-opus "$mutation"
    if [ "$mutation" = stale-plan ]; then printf '\nChanged plan\n' >> "$S/fix-plan.md"; fi
    if [ "$mutation" = stale-manifest ]; then printf ' \n' >> "$S/r9p-evidence.manifest.json"; fi
    state_gate_refuses "manual review rejects $mutation" "$S" 9 phase=fix
  done

  S="$T/gate-plan-manual-review-without-failure"
  "$ST" "$S" round=10 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
  "$ST" "$S" phase=plan round=10p 'seats=["codex-opus"]' >/dev/null
  state_write_plan_manifest "$S" 10p current codex-opus
  printf 'review prompt\n' > "$S/r10p-codex-opus.prompt.md"
  printf '2\n' > "$S/r10p-codex-opus.exit"
  state_write_manual_plan_review "$S" 10p codex-opus
  state_gate_refuses "an unrecorded failed exit cannot authorize manual fix" "$S" 10 phase=fix

  S="$T/gate-plan-manual-review-pending-child"
  "$ST" "$S" round=11 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
  "$ST" "$S" phase=plan round=11p 'seats=["codex-opus"]' >/dev/null
  state_write_plan_manifest "$S" 11p current codex-opus
  state_record_terminal_failure "$S" 11p codex-opus
  printf '{"status":"invalid"}\n' > "$S/r11p-codex-opus.audit-invalid.json"
  "$ST" "$S" phase=plan round=11px 'seats=["codex-sol"]' \
    plan_replacement_for=11p:codex-opus >/dev/null
  state_write_plan_manifest "$S" 11px current codex-sol
  state_write_manual_plan_review "$S" 11p codex-opus
  state_gate_refuses "manual review cannot bypass a pending replacement" "$S" 11 phase=fix
  state_record_terminal_failure "$S" 11px codex-sol
  printf '{"status":"invalid"}\n' > "$S/r11px-codex-sol.audit-invalid.json"
  state_write_manual_plan_review "$S" 11p codex-opus
  state_gate_allows "manual review allows fix after the replacement chain fails" \
    "$S" "$ST" "$S" phase=fix

  S="$T/gate-plan-child-duplicate-binding"
  "$ST" "$S" round=14 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
  "$ST" "$S" phase=plan round=14p 'seats=["codex-opus","codex-sol"]' >/dev/null
  state_write_plan_manifest "$S" 14p current codex-opus codex-sol
  for failed_seat in codex-opus codex-sol; do
    state_record_terminal_failure "$S" 14p "$failed_seat"
    printf '{"status":"invalid"}\n' > "$S/r14p-$failed_seat.audit-invalid.json"
  done
  "$ST" "$S" phase=plan round=14px 'seats=["codex-terra"]' \
    plan_replacement_for=14p:codex-opus >/dev/null
  local before_duplicate
  before_duplicate=$(cksum < "$S/state.json")
  local duplicate_rc=0
  "$ST" "$S" phase=plan round=14px 'seats=["codex-terra"]' \
    plan_replacement_for=14p:codex-sol >/dev/null 2>&1 || duplicate_rc=$?
  assert_eq "a replacement child cannot bind to a second root assignment" "$duplicate_rc" 2
  assert_eq "a rejected replacement binding leaves state unchanged" \
    "$(cksum < "$S/state.json")" "$before_duplicate"
  python3 - "$S/state.json" <<'PY'
import json, sys
from pathlib import Path

path = Path(sys.argv[1])
state = json.loads(path.read_text())
state['plan_replacements']['14p']['codex-sol'] = ['14px']
path.write_text(json.dumps(state) + '\n')
PY
  state_write_plan_manifest "$S" 14px current codex-terra
  printf '{"findings":[]}\n' > "$S/r14px-codex-terra.json"
  printf '0\n' > "$S/r14px-codex-terra.exit"
  state_gate_refuses "one successful replacement cannot satisfy two failed assignments" \
    "$S" 14 phase=fix

  S="$T/gate-plan-prepare-retry"
  "$ST" "$S" round=12 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
  "$ST" "$S" phase=plan round=12p 'seats=["codex-opus"]' >/dev/null
  state_write_plan_manifest "$S" 12p current codex-opus
  state_record_terminal_failure "$S" 12p codex-opus
  printf '{"status":"invalid"}\n' > "$S/r12p-codex-opus.audit-invalid.json"
  "$ST" "$S" phase=plan round=12px 'seats=["codex-sol"]' \
    plan_replacement_for=12p:codex-opus >/dev/null
  state_write_prepare_diagnostic "$S" 12px
  "$ST" "$S" phase=plan round=12px2 'seats=["codex-terra"]' \
    plan_replacement_for=12p:codex-opus >/dev/null
  state_write_plan_manifest "$S" 12px2 current codex-terra
  printf '{"findings":[]}\n' > "$S/r12px2-codex-terra.json"
  echo 0 > "$S/r12px2-codex-terra.exit"
  state_gate_allows "a fresh successful replacement covers a failed prepare attempt" \
    "$S" "$ST" "$S" phase=fix

  S="$T/gate-plan-root-prepare-only"
  "$ST" "$S" round=13 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
  "$ST" "$S" phase=plan round=13p 'seats=["codex-opus"]' >/dev/null
  state_write_prepare_diagnostic "$S" 13p
  state_gate_refuses "a root prepare diagnostic cannot authorize manual fix" "$S" 13 phase=fix

  S="$T/gate-round-labels"
  "$ST" "$S" round=7 phase=triage open.P2=1 >/dev/null
  "$ST" "$S" phase=plan round=7p 'seats=["codex-sol"]' >/dev/null
  state_write_plan_manifest "$S" 7p current codex-sol
  "$ST" "$S" round=7x phase=triage >/dev/null
  printf 'Plan panel r7p - SKIPPED: plan review unavailable with an Agent seat\n' > "$S/findings.md"
  assert_exit "a repair label resolves to its code round" 0 "$ST" "$S" phase=fix
  "$ST" "$S" phase=triage >/dev/null
  state_gate_refuses "a round argument wins over state" "$S" 8 phase=fix round=8
  "$ST" "$S" round=setup phase=triage >/dev/null
  before=$(cksum < "$S/state.json")
  "$ST" "$S" phase=fix > /dev/null 2> "$T/gate.err"; rc=$?
  assert_eq "an unparseable round fails closed" "$rc" 2
  assert_eq "an unparseable round leaves state unchanged" "$(cksum < "$S/state.json")" "$before"
  assert_grep "an unparseable round explains itself" "$T/gate.err" "cannot determine the code round from round='setup'"

  S="$T/gate-p3-and-other-phases"
  "$ST" "$S" round=9 phase=triage open.P0=0 open.P1=0 open.P2=0 open.P3=4 >/dev/null
  assert_exit "P3-only findings allow fix without a plan" 0 "$ST" "$S" phase=fix
  "$ST" "$S" round=10 phase=triage open.P1=3 >/dev/null
  local phase
  for phase in fan-out collect triage plan verify commit done; do
    assert_exit "phase=$phase ignores the fix gate" 0 "$ST" "$S" "phase=$phase"
  done
  assert_exit "plain keys ignore the fix gate" 0 "$ST" "$S" last_commit=abc1234 fixed=2
  "$ST" "$S" phase=fan-out round=10 'seats=["codex-sol","opus"]' >/dev/null
  "$ST" "$S" phase=repair round=10x 'seats=["opus"]' >/dev/null
  "$ST" "$S" phase=plan round=10 'seats=["opus"]' >/dev/null
  assert_nogrep "only a <N>p plan launch records plan seats" "$S/state.json" '"plans"'
}

test_state_fix_gate_refuses_a_stale_open_count() {
  ( local S="$T/st-stale"; mkdir -p "$S"
    "$SCRIPTS/rev-state.sh" "$S" round=1 phase=triage open.P0=0 open.P1=0 open.P2=0 >/dev/null
    # A seat answers AFTER the counts were written, so the counts are now stale.
    printf '0\n' > "$S/r2-codex-sol.exit"
    "$SCRIPTS/rev-state.sh" "$S" round=2 >/dev/null
    local out="$T/st-stale.err"
    "$SCRIPTS/rev-state.sh" "$S" phase=fix 2>"$out"
    assert_eq "a stale open count refuses phase=fix" "$?" 2
    assert_grep "names the way out" "$out" "open\.P0=.*open\.P1=.*open\.P2="

    # open merges per severity, so one severity alone is no re-count of the round.
    "$SCRIPTS/rev-state.sh" "$S" open.P2=0 >/dev/null
    assert_exit "one severity alone does not refresh the count" 2 \
      "$SCRIPTS/rev-state.sh" "$S" phase=fix

    # Rewriting all three counts after the exit clears it.
    "$SCRIPTS/rev-state.sh" "$S" open.P0=0 open.P1=0 open.P2=0 >/dev/null
    assert_exit "a fresh open count passes phase=fix" 0 \
      "$SCRIPTS/rev-state.sh" "$S" phase=fix )
}

test_state_fix_gate_ignores_staleness_with_no_seat_exits() {
  ( local S="$T/st-noexit"; mkdir -p "$S"
    "$SCRIPTS/rev-state.sh" "$S" round=1 phase=triage open.P0=0 open.P1=0 open.P2=0 >/dev/null
    assert_exit "no seat exits means nothing to be stale against" 0 \
      "$SCRIPTS/rev-state.sh" "$S" phase=fix )
}

test_state_fix_gate_allows_fix_after_the_plan_panel() {
  ( local S="$T/st-after-plan"; mkdir -p "$S"
    printf '0\n' > "$S/r2-codex-sol.exit"
    "$SCRIPTS/rev-state.sh" "$S" round=2 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
    "$SCRIPTS/rev-state.sh" "$S" phase=plan round=2p 'seats=["codex-sol"]' >/dev/null
    state_write_plan_manifest "$S" 2p current codex-sol
    # The plan panel answers after triage because the contract puts it there. Its exit is
    # newer than the counts and must not read as staleness.
    printf '{"findings":[]}\n' > "$S/r2p-codex-sol.json"; printf '0\n' > "$S/r2p-codex-sol.exit"
    assert_exit "a plan panel answering after triage is not staleness" 0 \
      "$SCRIPTS/rev-state.sh" "$S" phase=fix round=2 )
}

test_state_fix_gate_refuses_when_no_stamp_was_ever_written() {
  ( local S="$T/st-nostamp"; mkdir -p "$S"
    local out="$T/st-nostamp.err"
    # open merges per severity, so one severity never arms the stamp at all.
    "$SCRIPTS/rev-state.sh" "$S" round=2 phase=triage open.P1=1 >/dev/null
    printf '0\n' > "$S/r2-codex-sol.exit"
    "$SCRIPTS/rev-state.sh" "$S" phase=fix 2>"$out"
    assert_eq "an absent stamp refuses phase=fix" "$?" 2
    assert_grep "an absent stamp refuses for staleness, not for the plan gate" "$out" \
      "open\.P0=.*open\.P1=.*open\.P2="

    # A session written before this gate existed carries no open_stamp. Its counts are
    # zeroed, so nothing but the staleness check can refuse it.
    local R="$T/st-preupgrade"; mkdir -p "$R"
    printf '{"round": 2, "open": {"P0": 0, "P1": 0, "P2": 0}}\n' > "$R/state.json"
    printf '0\n' > "$R/r2-codex-sol.exit"
    local rout="$T/st-preupgrade.err"
    "$SCRIPTS/rev-state.sh" "$R" phase=fix 2>"$rout"
    assert_eq "a resumed session with no stamp refuses phase=fix" "$?" 2
    assert_grep "the resumed refusal names the way out" "$rout" "open\.P0=.*open\.P1=.*open\.P2=" )
}

test_state_open_stamp_is_the_newest_exit_mtime() {
  ( local S="$T/st-stamp-value"; mkdir -p "$S"
    # Backdated exits, with the EARLIEST-created one the greatest-valued: a wall-clock
    # stamp matches neither, and reading the older exit or the last file seen would both
    # read 1000000000.0.
    printf '0\n' > "$S/r3-codex-sol.exit"
    python3 -c 'import os,sys; os.utime(sys.argv[1], (1200000000, 1200000000))' "$S/r3-codex-sol.exit"
    printf '0\n' > "$S/r3-opus.exit"
    python3 -c 'import os,sys; os.utime(sys.argv[1], (1000000000, 1000000000))' "$S/r3-opus.exit"
    "$SCRIPTS/rev-state.sh" "$S" round=3 phase=triage open.P0=0 open.P1=0 open.P2=0 >/dev/null
    assert_eq "open_stamp is the greatest exit mtime, not the wall clock" \
      "$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["open_stamp"])' "$S/state.json")" \
      "1200000000.0" )
}

test_state_fix_gate_counts_a_repair_round_seat_exit() {
  ( local S="$T/st-repair"; mkdir -p "$S"
    "$SCRIPTS/rev-state.sh" "$S" round=2 phase=triage open.P0=0 open.P1=0 open.P2=0 >/dev/null
    # A coverage-repair panel answers after triage and its findings still need counting,
    # unlike the plan panel's, which review a triage that already happened.
    printf '0\n' > "$S/r2x-opus.exit"
    local out="$T/st-repair.err"
    "$SCRIPTS/rev-state.sh" "$S" round=2x phase=fix 2>"$out"
    assert_eq "a repair round's seat exit makes the counts stale" "$?" 2
    assert_grep "the repair refusal names the way out" "$out" "open\.P0=.*open\.P1=.*open\.P2=" )
}

# A failed plan seat is replaced by a one-seat <N>px plan panel, and the fix gate accepts it.
test_state_fix_gate_accepts_a_px_plan_replacement() {
  ( local ST="$SCRIPTS/rev-state.sh" S="$T/gate-px"
    "$ST" "$S" round=5 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
    "$ST" "$S" phase=plan round=5p 'seats=["codex-terra"]' >/dev/null
    state_write_plan_manifest "$S" 5p stale codex-terra
    state_record_terminal_failure "$S" 5p codex-terra
    printf '{"summary":"x","findings":[]}\n' > "$S/r5p-codex-terra.audit-invalid.json"
    state_gate_refuses "a hard-failed plan seat" "$S" 5 phase=fix
    local before
    before=$(cksum < "$S/state.json")
    assert_exit "an unbound plan replacement is refused" 2 \
      "$ST" "$S" phase=plan round=5px 'seats=["codex-sol"]'
    assert_eq "an unbound plan replacement leaves state unchanged" \
      "$(cksum < "$S/state.json")" "$before"
    "$ST" "$S" phase=plan round=5px 'seats=["codex-sol"]' \
      plan_replacement_for=5p:codex-terra >/dev/null
    state_write_plan_manifest "$S" 5px current codex-sol
    assert_eq "the <N>px plan launch records its seats" \
      "$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["plans"].get("5px"))' "$S/state.json")" "['codex-sol']"
    state_gate_refuses "a <N>px plan panel that has not returned" "$S" 5 phase=fix
    printf '{"summary":"sound","findings":[]}\n' > "$S/r5px-codex-sol.json"; echo 0 > "$S/r5px-codex-sol.exit"
    state_gate_allows "a completed <N>px plan panel allows fix" "$S" "$ST" "$S" phase=fix
  )
}

test_state_plan_quota_disabled_replacement_requires_the_bound_seat() {
  local ST="$SCRIPTS/rev-state.sh" S sequence replacement rc
  for sequence in single retry; do
    S="$T/gate-plan-quota-$sequence"
    rc=0
    "$ST" "$S" round=6 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
    "$ST" "$S" phase=plan round=6p 'seats=["codex-opus"]' >/dev/null
    state_write_plan_manifest "$S" 6p current codex-opus
    if [ "$sequence" = single ]; then
      state_record_quota_disabled_failure "$S" 6p codex-opus codex-sol 4 || rc=$?
    else
      state_record_quota_disabled_failure "$S" 6p codex-opus codex-sol 4 2 || rc=$?
    fi
    assert_eq "the $sequence quota-disabled marker fixture is valid" "${rc:-0}" 0
    rc=0
    REVIEW_COUNCIL_CONFIG="$S/review-council-config.json" "$ST" "$S" \
      phase=plan round=6px 'seats=["codex-sol"]' plan_replacement_for=6p:codex-opus >/dev/null || rc=$?
    assert_eq "the $sequence marker permits its bound plan replacement" "$rc" 0
    state_write_plan_manifest "$S" 6px current codex-sol
    printf '{"summary":"sound","findings":[]}\n' > "$S/r6px-codex-sol.json"
    printf '0\n' > "$S/r6px-codex-sol.exit"
    state_gate_allows "a $sequence exit-4 plan replacement satisfies the plan gate" \
      "$S" env REVIEW_COUNCIL_CONFIG="$S/review-council-config.json" "$ST" "$S" phase=fix
  done

  for replacement in none codex-terra; do
    S="$T/gate-plan-quota-invalid-$replacement"
    "$ST" "$S" round=7 phase=triage open.P0=0 open.P1=1 open.P2=0 >/dev/null
    "$ST" "$S" phase=plan round=7p 'seats=["codex-opus"]' >/dev/null
    state_write_plan_manifest "$S" 7p current codex-opus
    rc=0
    state_record_quota_disabled_failure "$S" 7p codex-opus "$replacement" 4 || rc=$?
    assert_eq "the $replacement quota-disabled marker fixture is valid" "$rc" 0
    assert_exit "a missing or mismatched escalation seat cannot authorize replacement" 2 \
      env REVIEW_COUNCIL_CONFIG="$S/review-council-config.json" "$ST" "$S" \
      phase=plan round=7px 'seats=["codex-sol"]' plan_replacement_for=7p:codex-opus
  done
}
