"""Config-path lexical compatibility and the public predicate's no-CWD contract."""
import importlib.util
from pathlib import Path
import posixpath
import sys
import unittest
from unittest.mock import patch


CWDS = ('/', '/work', '/work/repo/nested')


def config_fixture(directory='', **fields):
    config = {'path': posixpath.join(directory, 'tsconfig.json'),
              'directory': directory, **fields}
    for field in ('files', 'include', 'exclude'):
        config['has_' + field] = field in fields
    return config


def relpath_outcome(function, path, start):
    try:
        return ('value', function(path, start))
    except Exception as error:
        return ('error', type(error))


class SourceConfigPathsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = Path(__file__).resolve().parents[1] / 'scripts' / 'rev-evidence.py'
        spec = importlib.util.spec_from_file_location('source_config_paths_evidence', compiler)
        cls.evidence = importlib.util.module_from_spec(spec)
        with patch.object(sys, 'path', sys.path[:]):
            spec.loader.exec_module(cls.evidence)

    def test_repository_relative_config_comparisons_do_not_read_cwd(self):
        root = config_fixture()
        package = config_fixture('packages/a')
        cases = (
            ('src/a.ts', root, True),
            ('node_modules/pkg/a.ts', root, False),
            ('packages/b/src/a.ts', package, False),
        )
        with patch('os.getcwd', return_value='/work/repo') as getcwd:
            for path, config, expected in cases:
                self.assertIs(self.evidence.source_config_is_root(path, config, [config]), expected)
            self.assertEqual(getcwd.call_count, 0,
                             'repository-relative config comparisons must not read process cwd')

    def test_lexical_relpath_matches_stdlib_and_literal_results(self):
        relpath = getattr(self.evidence, 'source_config_relpath', posixpath.relpath)
        cases = (
            ('src/a.ts', '.', 'src/a.ts'),
            ('a.ts', 'src', '../a.ts'),
            ('packages/a/src/a.ts', 'packages/a', 'src/a.ts'),
            ('src/a.ts', 'packages/a', '../../src/a.ts'),
            ('packages/ab/a.ts', 'packages/a', '../ab/a.ts'),
            ('src/a.ts', 'src/a.ts', '.'),
            ('./src//a.ts', './src/', 'a.ts'),
            ('.', '.', '.'),
            ('space dir/a file.ts', 'space dir', 'a file.ts'),
            ('源/é.ts', '源', 'é.ts'),
            (r'src/a\b.ts', 'src', r'a\b.ts'),
            ('C:/src/a.ts', 'C:/src', 'a.ts'),
            ('src/.../a.ts', 'src/...', 'a.ts'),
            ('src/x..y/a.ts', 'src', 'x..y/a.ts'),
            ('nonexistent/link/a.ts', 'nonexistent', 'link/a.ts'),
        )
        for cwd in CWDS:
            with patch('os.getcwd', return_value=cwd):
                for path, start, expected in cases:
                    with self.subTest(cwd=cwd, path=path, start=start):
                        self.assertEqual(posixpath.relpath(path, start), expected)
                        self.assertEqual(relpath(path, start), expected)

    def test_compatibility_fallback_preserves_values_and_exception_types(self):
        relpath = getattr(self.evidence, 'source_config_relpath', posixpath.relpath)
        cases = (
            ('/abs/a.ts', 'src'), ('src/a.ts', '/abs/config'),
            ('/abs/a.ts', '/abs/config'), ('//server/a.ts', '.'),
            ('../a.ts', '.'), ('a/../../x.ts', '.'), ('a/../x.ts', '.'),
            ('src/a.ts', '..'), ('src/a.ts', '../configs'),
            ('', '.'), ('src/a.ts', ''), (b'', b'.'),
            (b'src/a.ts', '.'), ('src/a.ts', b'.'), (b'src/a.ts', b'.'),
            (Path('src/a.ts'), Path('src')), (Path('/abs/a.ts'), '.'),
            ('src/a.ts', Path('src')), (None, '.'), ('src/a.ts', None),
        )
        for cwd in CWDS:
            with patch('os.getcwd', return_value=cwd), \
                    patch('os.getcwdb', return_value=cwd.encode()):
                for path, start in cases:
                    with self.subTest(cwd=cwd, path=path, start=start):
                        expected = relpath_outcome(posixpath.relpath, path, start)
                        self.assertEqual(relpath_outcome(relpath, path, start), expected)
                self.assertEqual(relpath_outcome(relpath, '', '.'), ('error', ValueError))

    def test_public_predicate_matches_stdlib_oracle_and_literal_decisions(self):
        root = config_fixture()
        package = config_fixture('packages/a')
        included = config_fixture(include=['src/**/*.ts'], exclude=['src/**/*.test.ts'])
        empty_include = config_fixture(include=[])
        empty_exclude = config_fixture(exclude=[])
        files = config_fixture('packages/a', files=['../outside.ts'], exclude=['../outside.ts'])
        base = config_fixture('configs', include=['../src/**/*.ts'], exclude=['../src/private/**'])
        inherited = config_fixture('packages/a', extends='../../configs/tsconfig.json')
        windows_pattern = config_fixture(include=[r'src\**\*.ts'])
        parent_pattern = config_fixture('packages/a', include=['../src/**/*.ts'])
        absolute_pattern = config_fixture(include=['/src/**/*.ts'])
        absolute_config = config_fixture('/pkg')
        cases = (
            ('src/a.ts', root, [root], True),
            ('node_modules/pkg/a.ts', root, [root], False),
            ('README.md', root, [root], False),
            ('packages/a/src/a.ts', package, [package], True),
            ('src/a.ts', package, [package], False),
            ('packages/b/src/a.ts', package, [package], False),
            ('packages/ab/a.ts', package, [package], False),
            ('packages/a/./src//a.ts', package, [package], True),
            ('src/a.ts', included, [included], True),
            ('src/a.test.ts', included, [included], False),
            ('src/a.ts', empty_include, [empty_include], False),
            ('node_modules/pkg/a.ts', empty_exclude, [empty_exclude], True),
            ('packages/outside.ts', files, [files], True),
            ('packages/a/src/a.ts', files, [files], False),
            ('src/a.ts', inherited, [inherited, base], True),
            ('src/private/a.ts', inherited, [inherited, base], False),
            ('src/a.ts', windows_pattern, [windows_pattern], True),
            ('packages/src/a.ts', parent_pattern, [parent_pattern], True),
            ('src/a.ts', absolute_pattern, [absolute_pattern], False),
            ('/pkg/src/a.ts', absolute_config, [absolute_config], True),
            ('/else/a.ts', package, [package], False),
            ('src/a.ts', absolute_config, [absolute_config], False),
        )
        for cwd in CWDS:
            with patch('os.getcwd', return_value=cwd):
                for path, config, configs, expected in cases:
                    with self.subTest(cwd=cwd, path=path, config=config):
                        with patch.object(self.evidence, 'source_config_relpath',
                                          posixpath.relpath, create=True):
                            oracle = self.evidence.source_config_is_root(path, config, configs)
                        actual = self.evidence.source_config_is_root(path, config, configs)
                        self.assertIs(oracle, expected)
                        self.assertIs(actual, expected)
                        self.assertEqual(actual, oracle)


if __name__ == '__main__':
    unittest.main()
