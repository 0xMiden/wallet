# preflight + prompt - sourced by run-tests.sh
# Seats no longer come from hardcoded provider checks: preflight asks
# scripts/roster.sh. These tests drive that seam through a STUB roster.sh placed next to a symlink to the
# real rev-preflight.sh, so `$HERE/roster.sh` resolves to the stub. The stub models the contract preflight
# depends on (argv, strict exits + JSON, --brief); roster.sh's own detection is covered by t-roster.sh.
pf_bin() {  # pf_bin → prints a dir holding {roster.sh stub, rev-preflight.sh symlink}
  local D="$T/pf-bin"
  if [ ! -x "$D/roster.sh" ]; then
    mkdir -p "$D"
    cat > "$D/roster.sh" <<'STUB'
#!/bin/bash
# stub roster.sh: RSTUB_ARGS=<file> APPENDS every call's argv, RSTUB_EXIT sets the exit code,
# RSTUB_JSON overrides the JSON, RSTUB_BRIEF the --brief line. Like the real roster.sh, --write always
# stores the JSON and --brief only changes what goes to stdout; the exit code is the same either way.
[ -n "${RSTUB_ARGS:-}" ] && printf '%s\n' "$@" >> "$RSTUB_ARGS"
WRITE=""; BRIEF=0
while [ $# -gt 0 ]; do
  case "$1" in --write) WRITE=${2:-}; shift 2;; --brief) BRIEF=1; shift;; *) shift;; esac
done
JSON=${RSTUB_JSON:-}
if [ -z "$JSON" ]; then
  JSON=$(cat <<'J'
{"generated_at": "2026-09-02T00:00:00Z", "seats": [
 {"seat": "codex-sol", "lab": "openai", "adapter": "codex", "model": "gpt-5.6-sol", "effort": "max", "extra": false},
 {"seat": "codex-terra", "lab": "openai", "adapter": "codex", "model": "gpt-5.6-terra", "effort": "max", "extra": false},
 {"seat": "opus", "lab": "anthropic", "adapter": "claude", "model": "opus", "effort": "max", "extra": false},
 {"seat": "sonnet", "lab": "anthropic", "adapter": "claude", "model": "sonnet", "effort": "max", "extra": false},
 {"seat": "codex-review", "lab": "openai", "adapter": "codex", "mode": "review", "extra": true, "round": 2}],
 "result_receipts": {"version": 1, "legacy_no_exit_sha256": {}},
 "excluded": [{"cli": "gemini", "reason": "not installed"}]}
J
)
fi
[ -n "$WRITE" ] && printf '%s\n' "$JSON" > "$WRITE"
if [ "$BRIEF" = 1 ]; then
  printf '%s\n' "${RSTUB_BRIEF:-review-council seats: codex ✓ (gpt-5.6-sol@max, gpt-5.6-terra@max) · gemini ✗ not installed · claude ✓ (opus@max, sonnet@max)}"
else
  printf '%s\n' "$JSON"      # --json: preflight must keep this off its own stdout
fi
exit "${RSTUB_EXIT:-0}"
STUB
    chmod +x "$D/roster.sh"
    ln -sf "$SCRIPTS/rev-preflight.sh" "$D/rev-preflight.sh"
    ln -sf "$SCRIPTS/rev-contract-check.py" "$D/rev-contract-check.py"
    mkdir -p "$D/lib"
    ln -sf "$SCRIPTS/lib/session_inputs.py" "$D/lib/session_inputs.py"
  fi
  printf '%s' "$D"
}

test_preflight_refuses_sealed_session_inputs() {
  ( local B="$T/pf-sealed"; seat_env; local PF; PF="$(pf_bin)/rev-preflight.sh"
    export RSTUB_ARGS="$B/roster.args"
    local R="$B/repo" S="$B/session" name
    mkrepo "$R"; git -C "$R" checkout -qb feat
    printf 'changed\n' > "$R/change.txt"; git -C "$R" add change.txt; git -C "$R" commit -qm change
    mkdir -p "$S" "$B/original"
    for name in scope.env roster.json files.txt untracked.txt; do
      printf 'old-%s' "$name" > "$S/$name"
      cp "$S/$name" "$B/original/$name"
    done
    printf '{' > "$S/r1-evidence.manifest.json"
    (cd "$R" && "$PF" --write "$S") > "$B/out" 2> "$B/err"
    assert_eq "sealed session preflight is refused" "$?" 1
    assert_exit "sealed refusal happens before the roster probe" 0 test ! -e "$RSTUB_ARGS"
    for name in scope.env roster.json files.txt untracked.txt; do
      assert_exit "sealed refusal preserves $name byte-for-byte" 0 cmp -s "$S/$name" "$B/original/$name"
    done
  )
}

test_preflight_installs_complete_staged_generation() {
  ( local B="$T/pf-generation"; seat_env; local PF; PF="$(pf_bin)/rev-preflight.sh"
    export RSTUB_ARGS="$B/roster.args"
    local R="$B/repo" S="$B/session" roster_target
    mkrepo "$R"; git -C "$R" checkout -qb feat
    printf 'tracked\n' > "$R/tracked.txt"; git -C "$R" add tracked.txt; git -C "$R" commit -qm tracked
    printf 'untracked\n' > "$R/untracked.txt"
    (cd "$R" && "$PF" --write "$S") > "$B/out" 2> "$B/err"
    assert_eq "complete staged generation preflight exits 0" "$?" 0
    roster_target=$(awk 'previous == "--write" { print; exit } { previous=$0 }' "$RSTUB_ARGS")
    case "$roster_target" in
      "$S"/*) fail "the roster is staged outside the live session" "$roster_target";;
      *) ok "the roster is staged outside the live session";;
    esac
    assert_exit "the private staging directory is removed" 1 test -e "$(dirname "$roster_target")"
    assert_grep "the complete generation installs scope.env" "$S/scope.env" '^REV_BASE='
    assert_grep "the complete generation installs roster.json" "$S/roster.json" '"seat": "codex-sol"'
    assert_grep "the complete generation installs files.txt" "$S/files.txt" '^tracked.txt$'
    assert_grep "the complete generation installs untracked.txt" "$S/untracked.txt" '^untracked.txt$'
    python3 - "$S" <<'PY'
import pathlib, stat, sys
session = pathlib.Path(sys.argv[1])
assert all(stat.S_IMODE((session / name).stat().st_mode) == 0o600
           for name in ('scope.env', 'roster.json', 'files.txt', 'untracked.txt'))
PY
    assert_eq "installed generation files are private" "$?" 0
  )
}
pf_strict_roster() {  # a padded single-lab panel that a config min_labs floor refuses (roster exit 5)
  cat <<'J'
{"generated_at": "2026-09-02T00:00:00Z", "seats": [
 {"seat": "opus", "lab": "anthropic", "adapter": "agent", "model": "opus", "effort": "max", "extra": false},
 {"seat": "claude-1", "lab": "anthropic", "adapter": "agent", "model": "opus", "effort": "max", "extra": false, "padded": true},
 {"seat": "claude-2", "lab": "anthropic", "adapter": "agent", "model": "opus", "effort": "max", "extra": false, "padded": true}],
 "labs": ["anthropic"], "padded": 2, "degraded": true,
 "degradation": "only Claude is available - 3 Claude seats, no cross-lab decorrelation", "strict_class": "availability",
 "strict_reason": "1 lab(s) available, min_labs=2",
 "result_receipts": {"version": 1, "legacy_no_exit_sha256": {}},
 "excluded": [{"cli": "codex", "reason": "not signed in"}, {"cli": "gemini", "reason": "not installed"},
              {"cli": "min_labs", "reason": "strict: 1 lab(s) available, min_labs=2"}]}
J
}
pf_config_roster() {
  cat <<'J'
{"generated_at": "2026-09-02T00:00:00Z", "seats": [], "strict_class": "config",
 "strict_reason": "invalid codex_models: expected a list",
 "result_receipts": {"version": 1, "legacy_no_exit_sha256": {}},
 "excluded": [{"cli": "codex", "reason": "invalid codex_models: expected a list"},
              {"cli": "codex_models", "reason": "strict: invalid codex_models: expected a list"}]}
J
}
pf_degraded_roster() {  # a padded panel that is accepted - preflight warns, it does not refuse
  cat <<'J'
{"generated_at": "2026-09-02T00:00:00Z", "seats": [
 {"seat": "codex-terra", "lab": "openai", "adapter": "codex", "model": "gpt-5.6-terra", "effort": "max", "extra": false},
 {"seat": "opus", "lab": "anthropic", "adapter": "claude", "model": "opus", "effort": "max", "extra": false},
 {"seat": "opus-1", "lab": "anthropic", "adapter": "claude", "model": "opus", "effort": "max", "extra": false, "padded": true}],
 "labs": ["openai", "anthropic"], "padded": 1, "degraded": true,
 "degradation": "available labs: openai, anthropic - 1 repeat CLI seats; reduced panel diversity",
 "result_receipts": {"version": 1, "legacy_no_exit_sha256": {}},
 "excluded": [{"cli": "codex", "reason": "not signed in"}, {"cli": "gemini", "reason": "not installed"}]}
J
}

# No subshell: ok/fail must increment the runner's PASS/FAIL in the parent shell, so state is saved and restored by hand.
test_preflight() {
  local old_pwd=$PWD old_path=$PATH
  seat_env; local PF; PF="$(pf_bin)/rev-preflight.sh"
  export RSTUB_ARGS="$T/rstub.args"
  local R="$T/pf"; mkrepo "$R"
  cd "$R" || { fail "preflight setup" "cannot cd to $R"; PATH=$old_path; return 1; }
  R=$(git rev-parse --show-toplevel)   # /tmp is a symlink on macOS; git reports the physical path
  rm -f "$RSTUB_ARGS"
  "$PF" > "$T/pf.out" 2> "$T/pf.err"; assert_eq "main refused" "$?" 1
  assert_grep "reason names branch" "$T/pf.err" "shared branch 'main'"
  assert_exit "roster is not consulted before the git checks" 1 test -e "$RSTUB_ARGS"
  git checkout -qb feat; "$PF" 2> "$T/pf.err"; assert_eq "empty scope refused" "$?" 1
  assert_grep "reason says empty" "$T/pf.err" 'scope is empty'
  echo b > b.txt; git add b.txt; git commit -qm "feat: b"; echo c > c.txt
  rm -f "$T/args"                      # the shims record every call here; preflight must make none
  "$PF" --write "$T/pf-sess" > "$T/pf.out" 2> "$T/pf.err"; assert_eq "feature branch ok" "$?" 0
  assert_grep "summary line" "$T/pf.out" "^base=$(git rev-parse main) base_branch=main \(nearest fork point\) branch=feat default=main root=$R scope=branch changed_files=2$"
  assert_grep "roster brief line follows it" "$T/pf.out" '^review-council seats: codex ✓'
  assert_nogrep "roster JSON never reaches stdout" "$T/pf.out" '"seats"'
  assert_grep "roster is probed" "$T/rstub.args" '^--probe$'
  assert_grep "roster is written" "$T/rstub.args" '^--write$'
  local first_roster
  first_roster=$(awk 'previous == "--write" { print; exit } { previous=$0 }' "$T/rstub.args")
  case "$first_roster" in
    "$T/pf-sess"/*) fail "the roster is staged before publication" "$first_roster";;
    *) ok "the roster is staged before publication";;
  esac
  # one call, not two: the printed line comes from the same probed roster the JSON was built from
  assert_grep "the line is asked for in the same call" "$T/rstub.args" '^--brief$'
  assert_eq "the roster is consulted exactly once" "$(wc -l < "$T/rstub.args" | tr -d ' ')" "4"
  assert_grep "roster.json stored" "$T/pf-sess/roster.json" '"seat": "codex-sol"'
  assert_grep "new session records the receipt policy" "$T/pf-sess/roster.json" '"result_receipts"'
  assert_exit "preflight calls no lab CLI itself" 1 test -e "$T/args"
  local contract_runner="$T/contract-runner"
  cat > "$contract_runner" <<'SH'
#!/bin/bash
printf '%s\n' "$1" >> "$CONTRACT_CALLS"
exit "${CONTRACT_EXIT:-0}"
SH
  chmod +x "$contract_runner"
  mkdir -p "$R/plugins/review-council/scripts" "$R/plugins/review-council/.codex-plugin"
  printf '{}\n' > "$R/plugins/review-council/.codex-plugin/plugin.json"
  printf 'changed boundary\n' > "$R/plugins/review-council/scripts/rev-prompt.sh"
  REVIEW_COUNCIL_CONTRACT_RUNNER="$contract_runner" \
    REVIEW_COUNCIL_CONTRACT_PROVIDER_VERSIONS='{"codex":"1","claude":"1"}' \
  REVIEW_COUNCIL_CACHE_DIR="$T/contract-cache" CONTRACT_CALLS="$T/contract.calls" CONTRACT_EXIT=2 \
    "$PF" --write "$T/pf-contract-fail" > "$T/pf.out" 2> "$T/pf.err"
  assert_eq "failed provider replay blocks preflight" "$?" 1
  assert_grep "failed provider replay is explained" "$T/pf.err" \
    'provider contract replay failed before the roster probe'
  assert_eq "failed static replay spends no additional roster probe" \
    "$(wc -l < "$RSTUB_ARGS" | tr -d ' ')" "4"
  : > "$T/contract.calls"
  REVIEW_COUNCIL_CONTRACT_RUNNER="$contract_runner" \
    REVIEW_COUNCIL_CONTRACT_PROVIDER_VERSIONS='{"codex":"1","claude":"1"}' \
    REVIEW_COUNCIL_CACHE_DIR="$T/contract-cache" CONTRACT_CALLS="$T/contract.calls" \
    "$PF" --write "$T/pf-contract-pass" > "$T/pf.out" 2> "$T/pf.err"
  assert_eq "passing provider replay allows preflight" "$?" 0
  assert_eq "provider replay runs every contract group" \
    "$(wc -l < "$T/contract.calls" | tr -d ' ')" "4"
  assert_grep "provider replay includes preserved provider envelopes" \
    "$T/contract.calls" '^provider_envelope_replay$'
  assert_eq "provider replay writes one immutable keyed receipt" \
    "$(find "$T/pf-contract-pass" -name 'contract-pass-*.json' | wc -l | tr -d ' ')" "1"
  python3 - "$T/pf-contract-pass" <<'PY'
import json, pathlib, sys
session = pathlib.Path(sys.argv[1])
receipt = json.loads(next(session.glob('contract-pass-*.json')).read_text())
assert receipt['identity']['core_roster'][0] == {
    'seat':'codex-sol','adapter':'codex','model':'gpt-5.6-sol','effort':'max'}
assert receipt['identity']['executor']['plugin'] != str(pathlib.Path.cwd() / 'plugins/review-council')
assert receipt['identity']['executor']['policy'] == 'external-override'
assert receipt['identity']['executor']['runner_sha256']
PY
  assert_eq "preflight contract identity uses the probed roster" "$?" 0
  REVIEW_COUNCIL_CONTRACT_RUNNER="$contract_runner" \
    REVIEW_COUNCIL_CONTRACT_PROVIDER_VERSIONS='{"codex":"1","claude":"1"}' \
    REVIEW_COUNCIL_CACHE_DIR="$T/contract-cache" CONTRACT_CALLS="$T/contract.calls" \
    "$PF" --write "$T/pf-contract-cached" > "$T/pf.out" 2> "$T/pf.err"
  assert_eq "matching provider contract receipt is reusable" "$?" 0
  assert_eq "cached provider replay launches no contract group" \
    "$(wc -l < "$T/contract.calls" | tr -d ' ')" "4"
  rm "$R/plugins/review-council/scripts/rev-prompt.sh" \
    "$R/plugins/review-council/.codex-plugin/plugin.json"
  rmdir "$R/plugins/review-council/scripts" "$R/plugins/review-council/.codex-plugin" \
    "$R/plugins/review-council" "$R/plugins"
  : > "$RSTUB_ARGS"
  mkdir -p "$T/pf-quota-original"
  printf 'original roster\n' > "$T/pf-quota-original/roster.json"
  printf 'original scope\n' > "$T/pf-quota-original/scope.env"
  "$PF" --quota-failed-seat opus --write "$T/pf-quota-original" \
    > "$T/pf.out" 2> "$T/pf.err"
  assert_eq "quota handoff refuses an initialized session" "$?" 1
  assert_grep "quota overwrite refusal explains the fresh-session requirement" "$T/pf.err" \
    'quota fallback requires a fresh empty session directory'
  assert_exit "quota overwrite refusal happens before a paid roster probe" 0 test ! -s "$RSTUB_ARGS"
  assert_grep "quota overwrite refusal preserves the original roster" \
    "$T/pf-quota-original/roster.json" '^original roster$'
  assert_grep "quota overwrite refusal preserves the original scope" \
    "$T/pf-quota-original/scope.env" '^original scope$'
  "$PF" --quota-failed-seat opus --quota-failed-seat sonnet \
    --write "$T/pf-quota-handoff" > "$T/pf.out" 2> "$T/pf.err"
  assert_eq "preflight accepts classified quota handoffs" "$?" 0
  local quota_roster
  quota_roster=$(awk 'previous == "--write" { print; exit } { previous=$0 }' "$RSTUB_ARGS")
  cat > "$T/pf-quota-expected.args" <<EOF
--probe
--brief
--write
$quota_roster
--quota-failed-seat
opus
--quota-failed-seat
sonnet
EOF
  assert_exit "preflight passes quota handoffs exactly once and in order" 0 \
    cmp -s "$T/pf-quota-expected.args" "$RSTUB_ARGS"
  : > "$RSTUB_ARGS"
  "$PF" --quota-failed-seat > "$T/pf.out" 2> "$T/pf.err"
  assert_eq "preflight refuses a missing quota handoff seat" "$?" 1
  assert_exit "invalid handoff does not reach the roster" 0 test ! -s "$RSTUB_ARGS"
  # values are single-quoted so `. scope.env` can never expand or execute one (see t-scopeenv.sh)
  assert_grep "scope.env base" "$T/pf-sess/scope.env" "^REV_BASE='$(git rev-parse main)'$"
  assert_grep "scope.env root" "$T/pf-sess/scope.env" "^REV_ROOT='$R'$"
  assert_grep "files.txt committed" "$T/pf-sess/files.txt" '^b.txt$'
  assert_grep "files.txt untracked" "$T/pf-sess/files.txt" '^c.txt$'
  # untracked files are invisible to `git diff`: listed separately so the prompt can say "read them in full"
  assert_grep "untracked.txt lists the untracked file" "$T/pf-sess/untracked.txt" '^c.txt$'
  assert_nogrep "untracked.txt excludes tracked files" "$T/pf-sess/untracked.txt" '^b.txt$'
  "$PF" --scope uncommitted > "$T/pf.out"; assert_eq "uncommitted scope ok" "$?" 0
  assert_grep "uncommitted base is HEAD" "$T/pf.out" "^base=$(git rev-parse HEAD) .* scope=uncommitted changed_files=1$"
  "$PF" --scope b.txt > "$T/pf.out"; assert_eq "path scope ok" "$?" 0
  assert_grep "path scope counts" "$T/pf.out" ' scope=b.txt changed_files=1$'
  assert_exit "missing path refused" 1 "$PF" --scope nope.txt
  assert_exit "REV_ACTIVE refused" 1 env REV_ACTIVE=1 "$PF"
  # without --write the roster JSON goes in a private temp directory that is cleaned up
  rm -f "$RSTUB_ARGS"
  local real_mktemp mktemp_bin scratch
  real_mktemp=$(command -v mktemp); mktemp_bin="$T/mktemp-bin"; mkdir -p "$mktemp_bin"
  cat > "$mktemp_bin/mktemp" <<'SH'
#!/bin/bash
printf '%s\n' "$*" >> "$MKTEMP_CALLS"
out=$("$REAL_MKTEMP" "$@") || exit $?
printf '%s\n' "$out" >> "$MKTEMP_OUTPUTS"
printf '%s\n' "$out"
SH
  chmod +x "$mktemp_bin/mktemp"
  MKTEMP_CALLS="$T/mktemp.calls" MKTEMP_OUTPUTS="$T/mktemp.outputs" REAL_MKTEMP="$real_mktemp" \
    PATH="$mktemp_bin:$PATH" "$PF" > "$T/pf.out" 2>&1
  assert_grep "the roster is still probed" "$T/rstub.args" '^--probe$'
  local tmpj; tmpj=$(grep -A1 -- '^--write$' "$T/rstub.args" | sed -n '2p')
  [ -n "$tmpj" ] && ok "the JSON still lands on a file" || fail "the JSON still lands on a file" "no --write target recorded"
  assert_grep "bare preflight requests a private temp directory" "$T/mktemp.calls" '^-d '
  scratch=$(tail -n 1 "$T/mktemp.outputs")
  assert_eq "roster file is inside the private temp directory" "$tmpj" "$scratch/roster.json"
  case "$tmpj" in "$R"/*) fail "…outside the repository" "$tmpj";; *) ok "…outside the repository";; esac
  assert_exit "…and that temp file is removed" 1 test -e "$tmpj"
  assert_exit "the private temp directory is removed" 1 test -e "$scratch"
  assert_exit "no roster.json left in the repo" 1 test -e "$R/roster.json"
  # a thin panel is no longer a refusal - it is a padded panel and a loud warning (Task 11)
  rm -f "$RSTUB_ARGS"
  RSTUB_JSON="$(pf_degraded_roster)" \
    RSTUB_BRIEF='review-council seats: codex ✓ (gpt-5.6-terra@max) · gemini ✗ not installed · claude ✓ (opus@max) · DEGRADED: available labs: openai, anthropic - 1 repeat CLI seats; reduced panel diversity' \
    "$PF" --write "$T/pf-deg" > "$T/pf.out" 2> "$T/pf.err"; assert_eq "a degraded roster is accepted" "$?" 0
  assert_grep "the summary line is still printed" "$T/pf.out" '^base='
  assert_grep "the roster line carries DEGRADED" "$T/pf.out" 'DEGRADED: available labs: openai, anthropic - 1 repeat CLI seats; reduced panel diversity$'
  assert_grep "…and a warning line of its own follows it" "$T/pf.out" \
    '^preflight: WARNING - available labs: openai, anthropic - 1 repeat CLI seats; reduced panel diversity$'
  assert_exit "scope.env is written for a degraded run" 0 test -f "$T/pf-deg/scope.env"
  assert_nogrep "nothing on stderr" "$T/pf.err" '.'
  # a not-degraded roster gets no warning line at all
  "$PF" > "$T/pf.out" 2>&1; assert_grep "still fine" "$T/pf.out" '^base='
  assert_nogrep "no warning when the panel is whole" "$T/pf.out" 'WARNING'
  # Retryable availability and permanent configuration refusals stay distinct.
  rm -f "$RSTUB_ARGS"
  RSTUB_EXIT=5 RSTUB_JSON="$(pf_strict_roster)" RSTUB_BRIEF='provider availability: only anthropic survived' \
    "$PF" > "$T/pf.out" 2> "$T/pf.err"; assert_eq "strict roster preserves retryable status" "$?" 5
  assert_grep "retryable refusal includes provider evidence" "$T/pf.err" \
    '^provider availability: only anthropic survived$'
  assert_grep "retryable strict reason is relayed" "$T/pf.err" \
    '^preflight: strict availability \(retryable\): 1 lab\(s\) available, min_labs=2$'
  assert_eq "retryable canonical diagnostic is the final line" "$(awk 'NF { line=$0 } END { print line }' "$T/pf.err")" \
    'preflight: strict availability (retryable): 1 lab(s) available, min_labs=2'
  assert_eq "provider evidence precedes retryable diagnostic" \
    "$(awk '/^provider availability:/{p=NR} /^preflight: strict availability/{s=NR} END {print ((p < s) ? "yes" : "no")}' "$T/pf.err")" yes
  assert_grep "the roster still ran with --probe" "$T/rstub.args" '^--probe$'
  assert_nogrep "no summary line on a refusal" "$T/pf.out" '^base='
  RSTUB_EXIT=6 RSTUB_JSON="$(pf_config_roster)" RSTUB_BRIEF='provider availability: configuration rejected before probes' \
    "$PF" > "$T/pf.out" 2> "$T/pf.err"
  assert_eq "permanent config roster preserves status" "$?" 6
  assert_grep "permanent refusal includes provider evidence" "$T/pf.err" \
    '^provider availability: configuration rejected before probes$'
  assert_grep "permanent strict reason is relayed" "$T/pf.err" \
    '^preflight: strict config \(permanent\): invalid codex_models: expected a list$'
  assert_eq "permanent canonical diagnostic is the final line" "$(awk 'NF { line=$0 } END { print line }' "$T/pf.err")" \
    'preflight: strict config (permanent): invalid codex_models: expected a list'
  assert_eq "provider evidence precedes permanent diagnostic" \
    "$(awk '/^provider availability:/{p=NR} /^preflight: strict config/{s=NR} END {print ((p < s) ? "yes" : "no")}' "$T/pf.err")" yes
  assert_nogrep "no summary line on a permanent refusal" "$T/pf.out" '^base='
  RSTUB_EXIT=5 RSTUB_JSON='{"strict_class":"config","strict_reason":"wrong class"}' \
    "$PF" > /dev/null 2> "$T/pf.err"
  assert_eq "mismatched strict metadata is a wrapper error" "$?" 1
  assert_grep "mismatched strict metadata is explained" "$T/pf.err" 'valid matching strict metadata'
  RSTUB_EXIT=6 RSTUB_JSON='{"strict_class":"config"}' "$PF" > /dev/null 2> "$T/pf.err"
  assert_eq "missing strict reason is a wrapper error" "$?" 1
  assert_grep "missing strict reason is explained" "$T/pf.err" 'valid matching strict metadata'
  RSTUB_EXIT=5 RSTUB_JSON='{"strict_class":"availability","strict_reason":"provider unavailable"}' \
    "$PF" > /dev/null 2> "$T/pf.err"
  assert_eq "strict metadata without a roster shape is a wrapper error" "$?" 1
  assert_grep "invalid roster shape is explained" "$T/pf.err" 'valid matching strict metadata'
  # A roster crash outside the strict 5/6 contract fails loudly instead of running seatless.
  RSTUB_EXIT=5 RSTUB_JSON='not json at all' "$PF" > /dev/null 2> "$T/pf.err"; assert_eq "unreadable roster refused" "$?" 1
  assert_grep "says strict metadata could not be validated" "$T/pf.err" 'valid matching strict metadata'
  assert_nogrep "no traceback" "$T/pf.err" 'Traceback'
  RSTUB_EXIT=7 "$PF" > /dev/null 2> "$T/pf.err"; assert_eq "roster crash refused" "$?" 1
  assert_grep "names the roster exit code" "$T/pf.err" 'roster.sh failed \(exit 7\)'
  local D2="$T/pf-bin-noroster"; mkdir -p "$D2"
  ln -sf "$SCRIPTS/rev-preflight.sh" "$D2/rev-preflight.sh"
  ln -sf "$SCRIPTS/rev-contract-check.py" "$D2/rev-contract-check.py"
  "$D2/rev-preflight.sh" > /dev/null 2> "$T/pf.err"; assert_eq "missing roster.sh refused" "$?" 1
  assert_grep "blames the roster" "$T/pf.err" 'roster.sh failed'
  # paths with spaces: the pathspec and the changed-file list must not be word-split (git quotes such paths in porcelain v1)
  mkdir -p "my dir"; echo s > "my dir/a note.txt"; git add "my dir/a note.txt"; git commit -qm "feat: spaces"
  echo u > "untracked note.txt"
  "$PF" --write "$T/pf-sp" > "$T/pf.out" 2>&1; assert_eq "space paths ok" "$?" 0
  assert_grep "space path intact" "$T/pf-sp/files.txt" '^my dir/a note\.txt$'
  assert_grep "untracked space path intact" "$T/pf-sp/files.txt" '^untracked note\.txt$'
  assert_nogrep "no quote fragments" "$T/pf-sp/files.txt" '"'
  "$PF" --scope "my dir" > "$T/pf.out" 2>&1; assert_eq "scope with a space ok" "$?" 0
  assert_grep "space scope counts one file" "$T/pf.out" ' scope=my dir changed_files=1$'
  cd "$T" && assert_exit "outside a repo refused" 1 "$PF"
  cd "$old_pwd" 2>/dev/null || cd "$T" || return 1
  PATH=$old_path; export PATH; unset RSTUB_ARGS
}
test_preflight_pr_identity() {
  ( local B="$T/pf-pr"; seat_env; local PF; PF="$(pf_bin)/rev-preflight.sh"
    local R="$B/repo" S="$B/session" STALE="$B/stale-session" base head
    mkdir -p "$B/bin"
    cat > "$B/bin/gh" <<'SH'
#!/bin/bash
printf '%s\n' "$@" >> "$GH_ARGS"
printf '%s\n' "${GH_REPO-unset}" >> "$GH_REPO_OBS"
[ "$1" = pr ] && [ "$2" = view ] || exit 2
payload="{\"number\":71,\"url\":\"https://github.com/acme/repo/pull/71\",\"state\":\"$PR_STATE\",\"headRefName\":\"$PR_BRANCH\",\"headRefOid\":\"$STUB_PR_HEAD\",\"baseRefName\":\"main\",\"baseRefOid\":\"$PR_BASE\"}"
printf '%s\n' "$payload" > "$GH_JSON"
cat "$GH_JSON"
SH
    chmod +x "$B/bin/gh"
    export PATH="$B/bin:$PATH" GH_ARGS="$B/gh.args" GH_JSON="$B/gh.json" \
      GH_REPO_OBS="$B/gh-repo-observed" GH_REPO=wrong/repo RSTUB_ARGS="$B/roster.args"
    unset REV_BASE_REF
    mkrepo "$R"; git -C "$R" checkout -qb feat
    printf 'change\n' > "$R/change.txt"; git -C "$R" add change.txt; git -C "$R" commit -qm change
    base=$(git -C "$R" rev-parse main); head=$(git -C "$R" rev-parse HEAD)
    export PR_STATE=OPEN PR_BRANCH=feat STUB_PR_HEAD="$head" PR_BASE="$base"
    (cd "$R" && "$PF" --pr 71 --write "$S") > "$B/out" 2> "$B/err"
    local preflight_rc=$?
    if [ "$preflight_rc" -ne 0 ]; then cat "$B/err" "$B/gh.json" >&2; fi
    assert_eq "exact PR checkout passes preflight" "$preflight_rc" 0
    assert_grep "preflight pins PR number" "$S/scope.env" "^REV_PR_NUMBER='71'$"
    assert_grep "preflight pins PR repository" "$S/scope.env" "^REV_PR_REPO='acme/repo'$"
    assert_grep "preflight pins exact PR head" "$S/scope.env" "^REV_PR_HEAD='$head'$"
    assert_grep "preflight pins exact PR base head" "$S/scope.env" "^REV_PR_BASE_HEAD='$base'$"
    assert_grep "preflight pins PR base branch" "$S/scope.env" "^REV_BASE_BRANCH='main'$"
    assert_grep "preflight pins the exact local base ref" "$S/scope.env" "^REV_PR_BASE_REF='refs/heads/main'$"
    assert_grep "preflight measures the PR against its exact base" "$B/out" "^base=$base base_branch=main \\(open PR #71\\) branch=feat"
    assert_eq "preflight ignores the ambient repository override" \
      "$(grep -c '^unset$' "$GH_REPO_OBS")" 2
    : > "$GH_ARGS"; : > "$GH_REPO_OBS"
    (cd "$R" && "$PF" --pr 71 --pr-repo acme/repo --write "$B/explicit-repo") \
      > "$B/explicit-repo.out" 2> "$B/explicit-repo.err"
    assert_eq "an explicit pinned PR repository passes preflight" "$?" 0
    assert_eq "an explicit PR repository skips ambient context resolution" \
      "$(grep -c '^pr$' "$GH_ARGS")" 1
    assert_eq "an explicit PR repository query ignores GH_REPO" \
      "$(grep -c '^unset$' "$GH_REPO_OBS")" 1
    (cd "$R" && "$PF" --pr-repo acme/repo --write "$B/repo-without-pr") \
      > "$B/repo-without-pr.out" 2> "$B/repo-without-pr.err"
    assert_eq "an explicit PR repository requires a PR number" "$?" 1
    assert_grep "missing PR number is explained" "$B/repo-without-pr.err" '--pr-repo requires --pr'
    (cd "$R" && "$PF" --pr 71 --pr-repo ../repo --write "$B/invalid-repo") \
      > "$B/invalid-repo.out" 2> "$B/invalid-repo.err"
    assert_eq "an invalid PR repository is refused" "$?" 1
    assert_grep "invalid PR repository format is explained" "$B/invalid-repo.err" \
      '--pr-repo must be an owner/repository pair'
    export PR_BASE="$head"
    rm -f "$RSTUB_ARGS"
    (cd "$R" && "$PF" --pr 71 --write "$B/base-drift") > "$B/base-drift.out" 2> "$B/base-drift.err"
    assert_eq "PR preflight refuses a stale local base" "$?" 1
    assert_grep "stale base refusal identifies the PR binding" "$B/base-drift.err" \
      'no local ref for PR #71 base branch matches its base head'
    assert_exit "stale base refusal happens before a provider probe" 0 test ! -e "$RSTUB_ARGS"
    export PR_BASE="$base"
    printf 'new local commit\n' >> "$R/change.txt"
    git -C "$R" add change.txt; git -C "$R" commit -qm stale
    rm -f "$RSTUB_ARGS"
    (cd "$R" && "$PF" --pr 71 --write "$STALE") > "$B/stale.out" 2> "$B/stale.err"
    assert_eq "stale PR checkout is refused" "$?" 1
    assert_grep "stale PR refusal identifies the head mismatch" "$B/stale.err" 'checked out HEAD does not match PR #71 head'
    assert_exit "stale PR refusal happens before a provider probe" 1 test -e "$RSTUB_ARGS"
    assert_grep "preflight asks GitHub for repository, head and base identities" "$GH_ARGS" '^number,url,state,headRefName,headRefOid,baseRefName,baseRefOid$'
    assert_grep "preflight explicitly re-queries the resolved PR repository" "$GH_ARGS" '^--repo$'
    assert_grep "preflight uses the repository resolved from the local PR context" "$GH_ARGS" '^acme/repo$'
  )
}

test_prompt() {
  local S="$T/pr-sess"; mkdir -p "$S"
  printf 'REV_BASE=abc123\nREV_BRANCH=feat\nREV_DEFAULT=main\nREV_ROOT=/repo\nREV_SCOPE=branch\n' > "$S/scope.env"
  printf 'src/x.ts\nsrc/x.test.ts\n' > "$S/files.txt"; echo "build: pass; test: 2 pre-existing failures (a, b); lint: pass" > "$S/baseline.md"
  printf '%s' '{"seats":[{"seat":"codex-sol","adapter":"codex"},{"seat":"codex-terra","adapter":"codex"},{"seat":"opus","adapter":"claude"},{"seat":"sonnet","adapter":"claude"}]}' > "$S/roster.json"
  local p; p=$("$SCRIPTS/rev-prompt.sh" "$S" 1 codex-terra correctness "Correctness, edge cases, error handling")
  assert_eq "prints path" "$p" "$S/r1-codex-terra.prompt.md"
  assert_grep "Terra begins with assigned-hunk discovery" "$p" 'begin with assigned-hunk discovery'
  assert_grep "base sha" "$p" 'Base commit: abc123'
  assert_grep "diff command" "$p" 'git diff abc123'
  assert_grep "files listed" "$p" '^- src/x.test.ts$'
  assert_grep "lens text" "$p" 'off-by-one'
  printf "REV_BASE='abc123'\nREV_BRANCH='feat'\nREV_DEFAULT='main'\nREV_BASE_BRANCH='main'\nREV_ROOT='/repo'\nREV_SCOPE='branch'\nREV_PR_NUMBER='71'\nREV_PR_HEAD='0123456789012345678901234567890123456789'\nREV_PR_BASE_HEAD='abcdefabcdefabcdefabcdefabcdefabcdefabcd'\n" > "$S/scope.env"
  p=$("$SCRIPTS/rev-prompt.sh" "$S" 2 codex-terra correctness "Correctness, edge cases, error handling")
  assert_grep "PR-bound prompt names the exact head and base" "$p" \
    'Bound pull request: #71 \(head 0123456789012345678901234567890123456789, base branch `main` at abcdefabcdefabcdefabcdefabcdefabcdefabcd\)'
  assert_grep "emphasis" "$p" '^Round emphasis: Correctness, edge cases, error handling$'
  assert_grep "baseline included" "$p" 'pre-existing failures'
  assert_grep "rejected none" "$p" '\(none yet\)'
  assert_nogrep "native-provider schema is not embedded" "$p" '"severity"'
  assert_nogrep "no vacuity by default" "$p" 'VACUITY'
  p=$("$SCRIPTS/rev-prompt.sh" "$S" 2 codex-sol tests "Tests, observability" --vacuity)
  assert_nogrep "codex has no tools-first" "$p" '^FIRST run your tools'
  assert_grep "vacuity section" "$p" '^## Vacuity check'
  echo "- F-003 REJECTED: retry is bounded by maxAttempts (handler.ts:40)" > "$S/rejected.md"
  p=$("$SCRIPTS/rev-prompt.sh" "$S" 3 codex-terra red-team "Red team")
  assert_grep "rejected listed" "$p" 'F-003 REJECTED'
  assert_grep "red-team lens" "$p" 'Assume the change is wrong'
  # untracked files are invisible to `git diff`: rev-preflight.sh lists them in untracked.txt and the
  # prompt marks them so a seat reads them in full instead of reporting an empty diff.
  p=$("$SCRIPTS/rev-prompt.sh" "$S" 5 codex-terra correctness "Untracked")
  assert_nogrep "no untracked note without untracked.txt" "$p" 'Files marked .untracked.'
  : > "$S/untracked.txt"
  p=$("$SCRIPTS/rev-prompt.sh" "$S" 5 codex-terra correctness "Untracked")
  assert_nogrep "empty untracked.txt renders no file note" "$p" 'Files marked .untracked.'
  printf 'src/x.test.ts\n' > "$S/untracked.txt"
  p=$("$SCRIPTS/rev-prompt.sh" "$S" 5 codex-terra correctness "Untracked")
  assert_grep "untracked file marked" "$p" '^- src/x.test.ts \(untracked\)$'
  assert_grep "tracked file unmarked" "$p" '^- src/x.ts$'
  assert_grep "untracked note rendered" "$p" 'do not appear in .git diff.; read them in full'
  rm -f "$S/untracked.txt"
  printf '%s\n' "$S/plan.md" > "$S/docs.txt"; echo "# plan" > "$S/plan.md"
  p=$("$SCRIPTS/rev-prompt.sh" "$S" 1 codex-terra correctness "Prose review" --read-only "$S/docs.txt")
  assert_grep "read-only lists docs" "$p" "^- $S/plan\.md$"
  assert_nogrep "read-only has no repo scope" "$p" '^Repository:'
  # scope.env is parsed, not sourced: a space in the root and metacharacters in the branch are inert data
  printf 'REV_BASE=abc123\nREV_BRANCH=x;touch %s/pwned\nREV_DEFAULT=main\nREV_ROOT=/my repo/w s\nREV_SCOPE=branch\n' "$S" > "$S/scope.env"
  p=$("$SCRIPTS/rev-prompt.sh" "$S" 4 codex-terra correctness "Injection") ; assert_eq "space/metachar scope.env ok" "$?" 0
  assert_grep "root with a space intact" "$p" '^Repository: /my repo/w s$'
  assert_grep "branch metachars are literal" "$p" 'branch .x;touch '
  assert_exit "no command ran from scope.env" 1 test -e "$S/pwned"
  printf 'REV_BASE=abc123\nREV_BRANCH=feat\nREV_DEFAULT=main\nREV_ROOT=/repo\nREV_SCOPE=branch\n' > "$S/scope.env"
  : > "$S/empty-docs.txt"
  assert_exit "empty --read-only list → 1" 1 "$SCRIPTS/rev-prompt.sh" "$S" 1 codex-terra correctness x --read-only "$S/empty-docs.txt"
  assert_exit "missing --read-only list → 1" 1 "$SCRIPTS/rev-prompt.sh" "$S" 1 codex-terra correctness x --read-only "$S/no-such-list.txt"
  "$SCRIPTS/rev-prompt.sh" "$S" 1 codex-terra correctness x --read-only "$S/empty-docs.txt" 2> "$T/ro.err"
  assert_grep "names the missing list" "$T/ro.err" 'document list missing or empty'
  assert_exit "unknown flag → 1" 1 "$SCRIPTS/rev-prompt.sh" "$S" 1 codex-terra correctness x --bogus
  # unwritable output must fail loudly, not print a path for a file that was never written
  assert_exit "unwritable OUT → 1" 1 "$SCRIPTS/rev-prompt.sh" "$T/no-such-session" 1 codex-terra correctness x --read-only "$S/docs.txt"
  printf 'REV_ROOT=/repo\n' > "$S/scope.env"
  assert_exit "incomplete scope.env → 1" 1 "$SCRIPTS/rev-prompt.sh" "$S" 1 codex-terra correctness x
  rm "$S/scope.env"; assert_exit "missing scope.env → 1" 1 "$SCRIPTS/rev-prompt.sh" "$S" 1 codex-terra correctness x
}
