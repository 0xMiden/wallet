# shellcheck shell=bash
# Usage profiling separates completed results from metered attempts and preserves provider detail.
test_profile_labels_roster_comparability() {
  # Frozen historical Grok rosters preserve the 0.4.0 measurement baseline.
  ( local OLD="$T/profile-roster-old" NEW="$T/profile-roster-new" LEGACY="$T/profile-roster-legacy"
    mkdir -p "$OLD" "$NEW" "$LEGACY"
    cat > "$OLD/roster.json" <<'JSON'
{"seats":[
  {"seat":"codex-sol","adapter":"codex","model":"gpt-5.6-sol","effort":"max","extra":false},
  {"seat":"grok","adapter":"grok","model":"grok-4.6","effort":"xhigh","extra":false},
  {"seat":"opus","adapter":"claude","model":"opus","effort":"max","extra":false},
  {"seat":"opus-2","adapter":"claude","model":"opus","effort":"max","extra":false},
  {"seat":"codex-review","adapter":"codex","model":"gpt-5.6-sol","effort":"max","extra":true}
]}
JSON
    cat > "$NEW/roster.json" <<'JSON'
{"seats":[
  {"seat":"codex-sol","adapter":"codex","model":"gpt-5.6-sol","effort":"max","extra":false},
  {"seat":"grok","adapter":"grok","model":"grok-4.6","effort":"xhigh","extra":false},
  {"seat":"opus","adapter":"claude","model":"opus","effort":"max","extra":false},
  {"seat":"sonnet","adapter":"claude","model":"sonnet","effort":"max","extra":false}
]}
JSON
    printf '%s\n' '{"seats":[{"seat":"opus","adapter":"claude"}]}' > "$LEGACY/roster.json"
    printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":10,"output_tokens":1}}' \
      > "$OLD/r1-codex-sol.stream.ndjson"
    printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":20,"output_tokens":2}}' \
      > "$NEW/r1-codex-sol.stream.ndjson"
    printf '%s\n' '{"type":"result","usage":{"input_tokens":3,"output_tokens":1}}' \
      > "$LEGACY/r1-opus.stream.ndjson"

    "$SCRIPTS/rev-profile.py" --json "$OLD" "$NEW" "$LEGACY" > "$T/profile-rosters.json"
    python3 - "$T/profile-rosters.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
old, new, legacy = d['sessions']
old_signature = ('codex-sol=codex:gpt-5.6-sol@max,'
                 'grok=grok:grok-4.6@xhigh,'
                 'opus=claude:opus@max,opus-2=claude:opus@max')
new_signature = ('codex-sol=codex:gpt-5.6-sol@max,'
                 'grok=grok:grok-4.6@xhigh,'
                 'opus=claude:opus@max,sonnet=claude:sonnet@max')
assert old['roster']['signature'] == old_signature, old
assert old['roster']['complete'] is True, old
assert new['roster']['signature'] == new_signature, new
assert new['roster']['complete'] is True, new
assert legacy['roster']['signature'] == 'opus=claude:?@?', legacy
assert legacy['roster']['complete'] is False, legacy
comparison = d['comparison']
assert comparison['mixed_core_rosters'] is True, comparison
assert comparison['roster_signatures'] == [
    {'signature': old_signature, 'complete': True,
     'sessions': ['profile-roster-old']},
    {'signature': new_signature, 'complete': True,
     'sessions': ['profile-roster-new']},
    {'signature': 'opus=claude:?@?', 'complete': False,
     'sessions': ['profile-roster-legacy']},
], comparison
assert d['totals']['calls'] == 3, d
assert d['totals']['input_tokens'] == 33, d
assert d['totals']['output_tokens'] == 4, d
assert d['totals']['processed_tokens'] == 37, d
PY
    assert_eq "profile labels old, new, and historical rosters without changing totals" "$?" 0

    "$SCRIPTS/rev-profile.py" "$OLD" "$NEW" "$LEGACY" > "$T/profile-rosters.txt"
    assert_grep "text profile identifies the old two-Opus roster" "$T/profile-rosters.txt" \
      'roster=codex-sol=codex:gpt-5\.6-sol@max,grok=grok:grok-4\.6@xhigh,opus=claude:opus@max,opus-2=claude:opus@max roster_complete=true'
    assert_grep "text profile identifies the Opus and Sonnet roster" "$T/profile-rosters.txt" \
      'roster=codex-sol=codex:gpt-5\.6-sol@max,grok=grok:grok-4\.6@xhigh,opus=claude:opus@max,sonnet=claude:sonnet@max roster_complete=true'
    assert_grep "text profile marks historical roster identity incomplete" "$T/profile-rosters.txt" \
      'roster=opus=claude:\?@\? roster_complete=false'
    assert_grep "text profile warns that mixed roster totals need grouping" "$T/profile-rosters.txt" \
      '^COMPARABILITY mixed_core_rosters=true roster_signatures=3$'
  )
}

test_profile_discloses_quota_substitutions() {
  ( local S="$T/profile-quota-fallback"; mkdir -p "$S"
    cat > "$S/roster.json" <<'JSON'
{"seats":[
  {"seat":"opus","adapter":"claude","model":"opus","effort":"max","extra":false},
  {"seat":"sonnet","adapter":"claude","model":"sonnet","effort":"max","extra":false},
  {"seat":"claude-sonnet-fallback-1","adapter":"claude","model":"sonnet","effort":"max","extra":false,"padded":true,"substitutes_for":"codex-sol"}
]}
JSON
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile.json"
    python3 - "$S/profile.json" <<'PY'
import json, sys
roster = json.load(open(sys.argv[1]))['sessions'][0]['roster']
fallback = roster['core_seats'][2]
assert fallback['substitutes_for'] == 'codex-sol', roster
assert roster['signature'].endswith(
    'claude-sonnet-fallback-1=claude:sonnet@max[for=codex-sol]'
), roster
PY
    assert_eq "profile records the preferred seat behind a quota substitution" "$?" 0
    "$SCRIPTS/rev-profile.py" "$S" > "$S/profile.txt"
    assert_grep "text profile discloses the effective mixed roster" "$S/profile.txt" \
      'claude-sonnet-fallback-1=claude:sonnet@max\[for=codex-sol\]'
  )
}

test_profile_keeps_null_effort_complete_only_for_gemini() {
  ( local GEMINI="$T/profile-gemini-effort" CODEX="$T/profile-codex-null-effort"
    mkdir -p "$GEMINI" "$CODEX"
    printf '%s\n' '{"seats":[{"seat":"gemini","adapter":"gemini","model":"gemini-2.5-pro","effort":null,"extra":false}]}' > "$GEMINI/roster.json"
    printf '%s\n' '{"seats":[{"seat":"codex-sol","adapter":"codex","model":"gpt-5.6-sol","effort":null,"extra":false}]}' > "$CODEX/roster.json"
    "$SCRIPTS/rev-profile.py" --json "$GEMINI" "$CODEX" > "$T/profile-null-effort.json"
    python3 - "$T/profile-null-effort.json" <<'PY'
import json, sys
gemini, codex = json.load(open(sys.argv[1]))['sessions']
assert gemini['roster']['signature'] == 'gemini=gemini:gemini-2.5-pro@none', gemini
assert gemini['roster']['complete'] is True, gemini
assert gemini['roster']['core_seats'][0]['effort'] == 'none', gemini
assert codex['roster']['signature'] == 'codex-sol=codex:gpt-5.6-sol@?', codex
assert codex['roster']['complete'] is False, codex
PY
    assert_eq "profile treats only Gemini null effort as a complete stable identity" "$?" 0
  )
}

test_session_profile() {
  # Historical mixed-provider streams keep Grok decoder compatibility measurable.
  ( local S="$T/profile-session" S2="$T/profile-session-2" S3="$T/profile-session-mixed" S4="$T/profile-session-malformed"; mkdir -p "$S" "$S2" "$S3" "$S4"
    cat > "$S/roster.json" <<'JSON'
{"result_receipts":{"version":1,"legacy_no_exit_sha256":{}},"seats":[
  {"seat":"opus-cli","adapter":"claude"},
  {"seat":"codex-sol","adapter":"codex"},
  {"seat":"grok","adapter":"grok"},
  {"seat":"gemini","adapter":"gemini"},
  {"seat":"opus-agent","adapter":"agent"}
]}
JSON
    cat > "$S/r1-opus-cli.stream.jsonl" <<'EOF'
{"type":"assistant","usage":{"input_tokens":999}}
{"type":"result","usage":{"input_tokens":10,"cache_creation_input_tokens":20,"cache_read_input_tokens":30,"output_tokens":4},"total_cost_usd":1.5}
EOF
    cat > "$S/r2-opus-cli.stream.ndjson" <<'EOF'
{"type":"result","is_error":true,"usage":{"input_tokens":8,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"output_tokens":2},"total_cost_usd":0.1}
EOF
    cat > "$S/r3-opus-cli.stream.ndjson" <<'EOF'
{"type":"result","is_error":true,"usage":{"input_tokens":6,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"output_tokens":3},"total_cost_usd":0.2}
EOF
    cat > "$S/r1x-codex-sol.stream.ndjson" <<'EOF'
{"type":"turn.completed","usage":{"input_tokens":100,"cached_input_tokens":20,"cache_write_input_tokens":11,"output_tokens":10,"reasoning_output_tokens":5}}
EOF
    cat > "$S/r1p-grok.stream.ndjson" <<'EOF'
{"type":"end","usage":{"input_tokens":5,"cache_read_input_tokens":7,"output_tokens":3,"total_tokens":15,"cost_usd":0.5}}
EOF
    cp "$FX/gemini-stream.ndjson" "$S/r2-gemini.stream.ndjson"
    cat > "$S/preflight-gemini.stream.ndjson" <<'EOF'
{"type":"result","status":"success","stats":{"input_tokens":9000,"output_tokens":1000}}
EOF
    printf 'two words\n' > "$S/r1x-codex-sol.prompt.md"
    printf 'three prompt words\n' > "$S/r1p-grok.prompt.md"
    printf 'historical plan prompt\n' > "$S/r8-plan-opus-cli.prompt.md"
    python3 - "$S" <<'PY'
import hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1])
fixtures = {
    'r1x-codex-sol': ('codex', 'valid', [], 4, 3, 100, 80),
    'r1p-grok': ('grok', 'invalid', [{'code': 'fixture-violation'}], 6, 2, 250, 200),
}
for stem, (adapter, status, violations, calls, turns, output, maximum) in fixtures.items():
    prompt = root / (stem + '.prompt.md')
    stream = root / (stem + '.stream.ndjson')
    audit = {
        'schema_version': 1,
        'status': status,
        'narrow': True,
        'adapter': adapter,
        'prompt_sha256': hashlib.sha256(prompt.read_bytes()).hexdigest(),
        'stream_sha256': hashlib.sha256(stream.read_bytes()).hexdigest(),
        'violations': violations,
        'advisories': ([{'code':'bounded-proof-advisory','tool':'Bash'}]
                       if stem == 'r1x-codex-sol' else []),
        'tool_calls': calls,
        'tool_turns': turns,
        'tool_output_bytes': output,
        'max_tool_output_bytes': maximum,
    }
    (root / (stem + '.read-audit.json')).write_text(json.dumps(audit))
(root / 'r2-gemini.read-audit.json').write_text('{')
PY
    cat > "$S/r1x-codex-sol.json" <<'JSON'
{"summary":"code","findings":[{"severity":"P1","file":"src/a.py","line_start":3,"line_end":3,"claim":"a","evidence":"b","suggested_fix":"c","confidence":0.9}]}
JSON
    printf '{"summary":"plan","findings":[]}' > "$S/r1p-grok.json"
    printf '{"summary":"gemini","findings":[]}' > "$S/r2-gemini.json"
    printf '{"summary":"agent","findings":[]}' > "$S/r2-opus-agent.json"
    printf '{"summary":"failed invalid","findings":[{"claim":"missing schema fields"}]}' > "$S/r2-opus-cli.json"
    printf '{"summary":"failed valid","findings":[]}' > "$S/r3-opus-cli.json"
    printf '{"summary":"current missing receipt","findings":[]}' > "$S/r4-opus-agent.json"
    printf '{"summary":"current invalid","findings":[{"claim":"missing schema fields"}]}' > "$S/r5-opus-agent.json"
    printf '{"summary":"probe","findings":[]}' > "$S/preflight-opus-agent.json"
    printf '0\n' > "$S/r1x-codex-sol.exit"
    printf '0\n' > "$S/r1p-grok.exit"
    printf '0\n' > "$S/r2-gemini.exit"
    printf '0\n' > "$S/r2-opus-agent.exit"
    printf '0\n' > "$S/r5-opus-agent.exit"
    printf '2\n' > "$S/r2-opus-cli.exit"
    printf '2\n' > "$S/r3-opus-cli.exit"

    cat > "$S2/r9-plan-opus.stream.jsonl" <<'EOF'
{"type":"result","usage":{"input_tokens":2,"output_tokens":1},"total_cost_usd":0.25}
EOF
    printf '{"summary":"old plan","findings":[]}' > "$S2/r9-plan-opus.json"

    printf '{"summary":"legacy before receipt rollout","findings":[]}' > "$S3/r7-opus.json"
    printf '{"summary":"new incomplete result","findings":[]}' > "$S3/r8-opus.json"
    printf '{"summary":"overwritten legacy result","findings":[]}' > "$S3/r9-opus.json"
    python3 - "$S3" <<'PY'
import hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1])
old = root / 'r7-opus.json'
roster = {
    'result_receipts': {
        'version': 1,
        'legacy_no_exit_sha256': {
            old.name: hashlib.sha256(old.read_bytes()).hexdigest(),
            'r9-opus.json': hashlib.sha256(b'different prior content').hexdigest(),
        },
    },
    'seats': [{'seat': 'opus', 'adapter': 'claude'}],
}
(root / 'roster.json').write_text(json.dumps(roster))
PY
    printf '{"summary":"malformed marker","findings":[]}' > "$S4/r10-opus.json"
    printf '{"result_receipts":{"version":"invalid"},"seats":[{"seat":"opus","adapter":"claude"}]}' > "$S4/roster.json"

    "$SCRIPTS/rev-profile.py" --json "$S" "$S2" "$S3" "$S4" > "$S/profile.json"
    python3 - "$S/profile.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
s, old, mixed, malformed = d['sessions']
assert d['totals']['calls'] == 7, d
assert d['totals']['processed_tokens'] == 1411, d
assert d['totals']['cached_input_tokens'] == 20, d
assert d['totals']['cache_write_input_tokens'] == 31, d
assert d['totals']['cache_read_input_tokens'] == 37, d
assert abs(d['totals']['cost_usd'] - 2.55) < 1e-9, d
assert d['totals']['completed_calls'] == 6, d
assert d['totals']['metered_calls'] == 7, d
assert d['totals']['unmetered_calls'] == 2, d
assert d['totals']['read_activity'] == {
    'audits': 2,
    'violating_audits': 1,
    'advisories': 1,
    'invalid_audits': 1,
    'tool_calls': 10,
    'tool_turns': 5,
    'tool_output_bytes': 350,
    'max_tool_output_bytes': 200,
    'recognized_tool_calls': 0,
    'source_read_calls': 0,
    'source_read_batches': 0,
    'packet_shards': 0,
    'packet_bytes': 0,
    'packet_ranges': 0,
    'opened_source_ranges': 0,
    'finding_citations': 0,
    'patch_proof_calls': 0,
    'patch_proof_turns': 0,
    'patch_proof_visible_bytes': 0,
    'expected_patch_chunks': 0,
    'opened_patch_chunks': 0,
    'window_seats': 0,
    'chunk_seats': 0,
}, d
assert s['calls'] == {'completed': 4, 'metered': 6, 'unmetered': 1}, s
assert s['prompts']['code'] == {'count': 1, 'words': 2}, s
assert s['prompts']['plan'] == {'count': 2, 'words': 6}, s
assert s['results']['code'] == {'calls': 3, 'findings': 1}, s
assert s['results']['plan'] == {'calls': 1, 'findings': 0}, s
assert s['providers']['gemini']['processed_tokens'] == 1200, s
assert s['providers']['gemini']['calls'] == 1, s
assert s['providers']['agent']['completed_calls'] == 1, s
assert s['providers']['agent']['unmetered_calls'] == 1, s
assert s['providers']['claude']['metered_calls'] == 3, s
assert s['providers']['claude']['completed_calls'] == 0, s
assert s['providers']['claude']['cached_input_tokens'] == 0, s
assert s['providers']['claude']['cache_write_input_tokens'] == 20, s
assert s['providers']['claude']['cache_read_input_tokens'] == 30, s
assert s['providers']['codex']['cached_input_tokens'] == 20, s
assert s['providers']['codex']['cache_write_input_tokens'] == 11, s
assert s['providers']['codex']['cache_read_input_tokens'] == 0, s
assert s['providers']['grok']['cache_read_input_tokens'] == 7, s
assert s['read_activity'] == {
    'audits': 2,
    'violating_audits': 1,
    'advisories': 1,
    'invalid_audits': [
        {'audit': 'r2-gemini.read-audit.json', 'reason': 'malformed read audit JSON'},
    ],
    'tool_calls': 10,
    'tool_turns': 5,
    'tool_output_bytes': 350,
    'max_tool_output_bytes': 200,
    'recognized_tool_calls': 0,
    'source_read_calls': 0,
    'source_read_batches': 0,
    'packet_shards': 0,
    'packet_bytes': 0,
    'packet_ranges': 0,
    'opened_source_ranges': 0,
    'finding_citations': 0,
    'patch_proof_calls': 0,
    'patch_proof_turns': 0,
    'patch_proof_visible_bytes': 0,
    'expected_patch_chunks': 0,
    'opened_patch_chunks': 0,
    'window_seats': 0,
    'chunk_seats': 0,
}, s
assert old['prompts']['plan']['count'] == 0, old
assert old['results']['plan']['calls'] == 1, old
assert old['providers']['claude']['processed_tokens'] == 3, old
assert mixed['calls'] == {'completed': 1, 'metered': 0, 'unmetered': 1}, mixed
assert mixed['results']['code'] == {'calls': 1, 'findings': 0}, mixed
assert mixed['providers']['claude']['completed_calls'] == 1, mixed
assert malformed['calls'] == {'completed': 0, 'metered': 0, 'unmetered': 0}, malformed
PY
    assert_eq "profile accounts for providers, completions, and historical sessions" "$?" 0

    "$SCRIPTS/rev-profile.py" "$S" > "$S/profile.txt"
    assert_grep "text profile reports all call classes" "$S/profile.txt" 'completed=4 metered=6 unmetered=1'
    assert_grep "text profile separates provider cache metrics" "$S/profile.txt" \
      'cached_input=20 cache_write_input=31 cache_read_input=37'
    assert_grep "text profile separates bounded-read activity" "$S/profile.txt" \
      'read_activity=audits:2 violating:1 advisories:1 calls:10 turns:5 output_bytes:350 max_output_bytes:200 invalid:1'
    assert_grep "text profile explains invalid read audits" "$S/profile.txt" \
      'r2-gemini\.read-audit\.json: malformed read audit JSON'
    printf 'mutated\n' >> "$S/r1x-codex-sol.prompt.md"
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-stale-audit.json"
    python3 - "$S/profile-stale-audit.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
activity = d['sessions'][0]['read_activity']
assert activity == {
    'audits': 1,
    'violating_audits': 1,
    'advisories': 0,
    'invalid_audits': [
        {'audit': 'r1x-codex-sol.read-audit.json', 'reason': 'read audit prompt hash mismatch'},
        {'audit': 'r2-gemini.read-audit.json', 'reason': 'malformed read audit JSON'},
    ],
    'tool_calls': 6,
    'tool_turns': 2,
    'tool_output_bytes': 250,
    'max_tool_output_bytes': 200,
    'recognized_tool_calls': 0,
    'source_read_calls': 0,
    'source_read_batches': 0,
    'packet_shards': 0,
    'packet_bytes': 0,
    'packet_ranges': 0,
    'opened_source_ranges': 0,
    'finding_citations': 0,
    'patch_proof_calls': 0,
    'patch_proof_turns': 0,
    'patch_proof_visible_bytes': 0,
    'expected_patch_chunks': 0,
    'opened_patch_chunks': 0,
    'window_seats': 0,
    'chunk_seats': 0,
}, activity
assert d['totals']['processed_tokens'] == 1408, d
PY
    assert_eq "stale read audits are diagnosed and excluded without changing tokens" "$?" 0
  )
}

# Repeated current-provider launches retain every nonempty paid stream.
test_profile_retry_streams() {
  ( seat_env; local S="$T/profile-retries"; seat_roster "$S"
    printf '%s\n' 'use at most 4 repository tool calls before stopping this assignment.' 'review' > "$S/p.md"
    cp "$S/p.md" "$S/r1-codex-terra.prompt.md"
    cp "$S/p.md" "$S/r2-codex-terra.prompt.md"
    rm -f "$T/args.codex-calls"
    SHIM_MODE=ok "$SCRIPTS/rev-seat.sh" codex-terra "$S" 1 "$S/r1-codex-terra.prompt.md" >/dev/null
    SHIM_MODE=ok "$SCRIPTS/rev-seat.sh" codex-terra "$S" 1 "$S/r1-codex-terra.prompt.md" >/dev/null
    assert_eq "relaunch keeps one archived Terra attempt" "$(find "$S" -maxdepth 1 -name 'r1-codex-terra.stream.*.ndjson' | wc -l | tr -d ' ')" 1
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/internal.json"
    python3 - "$S/internal.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
assert d['totals']['calls'] == 4, d
assert d['totals']['processed_tokens'] == 2200, d
PY
    assert_eq "Terra relaunch contributes both metered attempts" "$?" 0

    SHIM_MODE=ok "$SCRIPTS/rev-seat.sh" codex-terra "$S" 2 "$S/r2-codex-terra.prompt.md" >/dev/null
    SHIM_MODE=ok "$SCRIPTS/rev-seat.sh" codex-terra "$S" 2 "$S/r2-codex-terra.prompt.md" >/dev/null
    assert_eq "same-label relaunch keeps one archived attempt" "$(find "$S" -maxdepth 1 -name 'r2-codex-terra.stream.*.ndjson' | wc -l | tr -d ' ')" 1
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/outer.json"
    python3 - "$S/outer.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
assert d['totals']['calls'] == 8, d
assert d['totals']['processed_tokens'] == 4400, d
PY
    assert_eq "same-label relaunch contributes both metered attempts" "$?" 0
  )
}

# Historical Grok usage decoding remains readable for frozen provider artifacts.
test_profile_accepts_historical_safe_nonnumeric_labels() {
  ( local S="$T/profile-safe-label"; mkdir -p "$S"
    cat > "$S/roster.json" <<'JSON'
{"seats":[
  {"seat":"codex-sol","adapter":"codex"},
  {"seat":"grok","adapter":"grok"},
  {"seat":"opus","adapter":"claude"},
  {"seat":"opus-2","adapter":"claude"},
  {"seat":"bad","adapter":"codex"}
]}
JSON
    printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":100,"cached_input_tokens":20,"output_tokens":10}}' \
      > "$S/rv1-codex-sol.stream.ndjson"
    printf '%s\n' '{"type":"end","usage":{"input_tokens":5,"cache_read_input_tokens":7,"output_tokens":3,"total_tokens":15,"cost_usd":0.5}}' \
      > "$S/rv1-grok.stream.ndjson"
    printf '%s\n' '{"type":"result","usage":{"input_tokens":10,"cache_creation_input_tokens":20,"cache_read_input_tokens":30,"output_tokens":4},"total_cost_usd":1.5}' \
      > "$S/rv1-opus.stream.ndjson"
    printf '%s\n' '{"type":"result","usage":{"input_tokens":8,"cache_creation_input_tokens":0,"cache_read_input_tokens":12,"output_tokens":2},"total_cost_usd":0.1}' \
      > "$S/rv1-opus-2.stream.ndjson"
    printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":-1,"output_tokens":1}}' \
      > "$S/rv1-bad.stream.ndjson"
    for seat in codex-sol grok opus opus-2 bad; do printf '2\n' > "$S/rv1-$seat.exit"; done
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile.json"
    python3 - "$S/profile.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1])); s = d['sessions'][0]; totals = d['totals']
assert s['calls'] == {'completed': 0, 'metered': 4, 'unmetered': 0}, s
assert totals['input_tokens'] == 192 and totals['output_tokens'] == 19, totals
assert totals['processed_tokens'] == 211 and totals['cost_usd'] == 2.1, totals
assert totals['cached_input_tokens'] == 20, totals
assert totals['cache_write_input_tokens'] == 20, totals
assert totals['cache_read_input_tokens'] == 49, totals
assert len(s['invalid_usage']) == 1 and s['invalid_usage'][0]['stream'] == 'rv1-bad.stream.ndjson', s
PY
    assert_eq "profiler meters invalid attempts with safe nonnumeric labels" "$?" 0
  )
}

# Invalid session arguments are rejected by argparse before any profile is aggregated.
test_profile_invalid_sessions() {
  ( local V="$T/profile-valid" M="$T/profile-missing" F="$T/profile-file"
    mkdir -p "$V"; printf 'not a directory\n' > "$F"
    expect_invalid_profile() {
      local label=$1 offending=$2; shift 2
      local mode rc
      for mode in text json; do
        if [ "$mode" = text ]; then
          "$SCRIPTS/rev-profile.py" "$@" > "$T/profile-$label-$mode.out" 2> "$T/profile-$label-$mode.err"
        else
          "$SCRIPTS/rev-profile.py" --json "$@" > "$T/profile-$label-$mode.out" 2> "$T/profile-$label-$mode.err"
        fi
        rc=$?
        [ "$rc" -ne 0 ] && ok "$label session is rejected in $mode mode" || fail "$label session is rejected in $mode mode" "exit $rc"
        assert_eq "$label session emits no partial output in $mode mode" "$(cat "$T/profile-$label-$mode.out")" ""
        assert_grep "$label error names the argument in $mode mode" "$T/profile-$label-$mode.err" "$offending"
      done
    }

    expect_invalid_profile missing "$M" "$M"
    expect_invalid_profile regular-file "$F" "$F"
    expect_invalid_profile mixed "$M" "$V" "$M"

    local U="$T/profile-unreadable"; mkdir -p "$U"; chmod 000 "$U"
    if [ ! -r "$U" ] || [ ! -x "$U" ]; then
      expect_invalid_profile unreadable "$U" "$U"
    else
      ok "unreadable-directory check skipped when permissions are not enforced"
    fi
    chmod 700 "$U"
  )
}

# Only an absent roster or a valid historical roster without receipt metadata may
# grandfather receiptless results. Present invalid metadata fails closed.
test_profile_invalid_receipt_metadata() {
  ( local ROOT="$T/profile-receipt-policy"; mkdir -p "$ROOT"
    make_session() {
      local name=$1 roster=$2 session
      session="$ROOT/$name"
      mkdir -p "$session"
      printf '%s' '{"summary":"receiptless","findings":[]}' > "$session/r1-opus.json"
      if [ "$roster" != absent ]; then printf '%s' "$roster" > "$session/roster.json"; fi
    }
    make_session absent absent
    make_session historical '{"seats":[{"seat":"opus","adapter":"claude"}]}'
    make_session corrupt '{'
    make_session nonobject '[]'
    make_session badversion '{"result_receipts":{"version":"1","legacy_no_exit_sha256":{}}}'
    make_session boolversion '{"result_receipts":{"version":true,"legacy_no_exit_sha256":{}}}'
    make_session zeroversion '{"result_receipts":{"version":0,"legacy_no_exit_sha256":{}}}'
    make_session badmap '{"result_receipts":{"version":1,"legacy_no_exit_sha256":[]}}'
    make_session baddigest '{"result_receipts":{"version":1,"legacy_no_exit_sha256":{"r1-opus.json":"abc"}}}'
    mkdir -p "$ROOT/unreadable/roster.json"
    printf '%s' '{"summary":"receiptless","findings":[]}' > "$ROOT/unreadable/r1-opus.json"

    "$SCRIPTS/rev-profile.py" --json "$ROOT"/* > "$ROOT/profile.json"
    python3 - "$ROOT/profile.json" <<'PY'
import json, sys
sessions = {item['session']: item for item in json.load(open(sys.argv[1]))['sessions']}
assert sessions['absent']['calls']['completed'] == 1, sessions
assert sessions['historical']['calls']['completed'] == 1, sessions
for name in ('corrupt', 'nonobject', 'badversion', 'boolversion', 'zeroversion',
             'badmap', 'baddigest', 'unreadable'):
    assert sessions[name]['calls']['completed'] == 0, (name, sessions[name])
PY
    assert_eq "invalid present receipt metadata cannot grandfather results" "$?" 0
  )
}

# Scope projections come only from intact evidence manifests, remain readable after the
# repository is gone, and never alter metered usage.
test_profile_evidence_scope() {
  ( local S="$T/profile-evidence" R="$T/profile-evidence-repo"
    export REV_SOURCE_CONTEXT=1 REV_PATCH_CHUNKS=1
    mkrepo "$R"; mkdir -p "$S"
    printf 'Review repository instruction words.\n' > "$R/AGENTS.md"
    git -C "$R" add AGENTS.md && git -C "$R" commit -qm 'add instructions'
    local base; base=$(git -C "$R" rev-parse HEAD)
    python3 - "$R" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
for file_number in range(3):
    lines = (['def source_0():\n']
             + [f'    value_0_{line} = "{line:04d}-' + 'x' * 70 + '"\n'
                for line in range(600)]
             + ['    return value_0_599\n']) if file_number == 0 else [
                 f'value_{file_number}_{line} = {line}\n' for line in range(350)]
    (root / f'source_{file_number}.py').write_text(''.join(lines))
PY
    printf "REV_ROOT='%s'\nREV_BASE='%s'\nREV_SCOPE='branch'\n" "$R" "$base" > "$S/scope.env"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"agent"},{"seat":"terra","adapter":"agent"},{"seat":"opus","adapter":"agent"},{"seat":"sonnet","adapter":"agent"}]}' > "$S/roster.json"
    : > "$S/files.txt"; : > "$S/untracked.txt"
    python3 "$SCRIPTS/rev-evidence.py" prepare "$S" 6 --phase discovery >/dev/null || {
      fail "profile fixture discovery prepares"; return;
    }
    local seat
    for seat in sol terra opus sonnet; do
      "$SCRIPTS/rev-prompt.sh" "$S" 6 "$seat" simplicity profile \
        --evidence "$S/r6-evidence.manifest.json" >/dev/null \
        || { fail "profile fixture discovery prompt renders"; return; }
      printf '%s' '{"summary":"checked","findings":[]}' > "$S/r6-$seat.json"
      printf '0\n' > "$S/r6-$seat.exit"
      python3 - "$S/r6-evidence.manifest.json" "$seat" "$S/r6-$seat.stream.ndjson" "$R/source_0.py" "$SCRIPTS/rev-evidence.py" <<'PY'
import hashlib, importlib.util, json, pathlib, re, sys
manifest_path, seat, stream_path, source_path, script = sys.argv[1:]
session = pathlib.Path(manifest_path).parent
manifest = json.load(open(manifest_path))
events = []
assignment = manifest['assignments'][seat]
patch = pathlib.Path(assignment['patch'])
patch_lines = patch.read_text().splitlines(keepends=True)
if assignment['patch_read_mode'] == 'chunks':
    for row in manifest['patch_sets'][assignment['patch_set']]['chunks']:
        path = session / row['artifact']; call_id = 'patch-' + str(row['index'])
        events.extend([
            {'type':'assistant','message':{'id':call_id,'content':[{
                'type':'tool_use','id':call_id,'name':'Read','input':{'file_path':str(path)}}]}},
            {'type':'user','message':{'content':[{
                'type':'tool_result','tool_use_id':call_id,'content':path.read_text()}]}},
        ])
else:
    for start in range(1, len(patch_lines) + 1, 240):
        end = min(start + 239, len(patch_lines)); call_id = 'patch-' + str(start)
        events.extend([
            {'type':'assistant','message':{'id':call_id,'content':[{
                'type':'tool_use','id':call_id,'name':'Read',
                'input':{'file_path':str(patch),'offset':start,'limit':end - start + 1}}]}},
            {'type':'user','message':{'content':[{
                'type':'tool_result','tool_use_id':call_id,
                'content':''.join(patch_lines[start - 1:end])}]}},
        ])
for index, shard in enumerate(manifest['source_context']['seats'][seat]['shards']):
    path = session / shard['artifact']; call_id = 'packet-' + str(index)
    events.extend([
        {'type':'assistant','message':{'id':call_id,'content':[{
            'type':'tool_use','id':call_id,'name':'Read','input':{'file_path':str(path)}}]}},
        {'type':'user','message':{'content':[{
            'type':'tool_result','tool_use_id':call_id,'content':path.read_text()}]}},
    ])
for required in manifest['source_context']['seats'][seat]['required_source_ranges']:
    for segment in required['segments']:
        source = session / segment['artifact']; call_id = 'source-' + str(segment['index'])
        events.extend([
            {'type':'assistant','message':{'id':call_id,'content':[{
                'type':'tool_use','id':call_id,'name':'Read',
                'input':{'file_path':str(source)}}]}},
            {'type':'user','message':{'content':[{
                'type':'tool_result','tool_use_id':call_id,
                'content':source.read_text()}]}},
        ])
index = session / f"r{manifest['label']}-evidence.md"
events.extend([
    {'type':'assistant','message':{'id':'evidence-index','content':[{
        'type':'tool_use','id':'evidence-index','name':'Read',
        'input':{'file_path':str(index)}}]}},
    {'type':'user','message':{'content':[{
        'type':'tool_result','tool_use_id':'evidence-index','content':index.read_text()}]}},
])
if manifest['source_context']['seats'][seat]['source_read_required']:
    target = re.search(r'^Required post-index original-source target: (.+):(\d+)-(\d+) '
                       r'tree (\w+) blob (\w+) content SHA-256 (\w+) reasons ',
                       (session / f"r{manifest['label']}-{seat}.prompt.md").read_text(), re.M)
    assert target
    path, start, end, tree, oid, content_hash = target.groups(); start, end = int(start), int(end)
    spec = importlib.util.spec_from_file_location('profile_evidence', script)
    evidence = importlib.util.module_from_spec(spec); spec.loader.exec_module(evidence)
    repository = evidence.Repository(session.resolve()); entry = repository.entries(tree)[path]
    assert tree == manifest['snapshot_tree'] and entry[1] == oid
    lines = evidence.split_lf_lines(repository.blob(entry))
    assert hashlib.sha256(b''.join(lines[start - 1:end])).hexdigest() == content_hash
    for first in range(start, end + 1, 240):
        last = min(first + 239, end); identity = 'current-source-' + str(first)
        events.extend([
            {'type': 'assistant', 'message': {'id': identity, 'content': [{
                'type':'tool_use','id':identity,'name':'Read',
                'input':{'file_path':str(repository.root / path),'offset':first,'limit':last-first+1}}]}},
            {'type': 'user', 'message': {'content': [{
                'type':'tool_result','tool_use_id':identity,
                'content':b''.join(lines[first-1:last]).decode()}]}},
        ])
with open(stream_path, 'w') as stream:
    for event in events:
        stream.write(json.dumps(event) + '\n')
PY
      python3 "$SCRIPTS/lib/review-read-audit.py" audit --adapter agent \
        --raw "$S/r6-$seat.stream.ndjson" --prompt "$S/r6-$seat.prompt.md" \
        --root "$R" --session "$S" --out "$S/r6-$seat.read-audit.json" || {
          fail "profile fixture Agent transcript audits"; return;
        }
    done
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-production-audits.json"
    python3 - "$S/profile-production-audits.json" "$S" <<'PY'
import json, pathlib, sys
profile = json.load(open(sys.argv[1])); session = pathlib.Path(sys.argv[2])
audits = [json.load(open(path)) for path in sorted(session.glob('r6-*.read-audit.json'))]
activity = profile['sessions'][0]['read_activity']
assert len(audits) == 4 and all(audit['schema_version'] == 2 for audit in audits), audits
assert all(audit['status'] == 'valid' for audit in audits), audits
assert activity['audits'] == 4 and activity['violating_audits'] == 0, activity
assert activity['invalid_audits'] == [], activity
assert profile['totals']['read_activity']['audits'] == 4, profile
PY
    assert_eq "profile accepts every schema-2 audit emitted by the production auditor" "$?" 0

    cp "$S/r6-sol.stream.ndjson" "$S/r6-sol.stream.valid"
    : > "$S/r6-sol.stream.ndjson"
    python3 "$SCRIPTS/lib/review-read-audit.py" audit --adapter agent \
      --raw "$S/r6-sol.stream.ndjson" --prompt "$S/r6-sol.prompt.md" \
      --root "$R" --session "$S" --out "$S/r6-sol.read-audit.json" >/dev/null 2>&1
    assert_eq "production auditor emits an early invalid schema-2 audit" "$?" 2
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-production-invalid.json"
    python3 - "$S/profile-production-invalid.json" "$S/r6-sol.read-audit.json" <<'PY'
import json, sys
profile = json.load(open(sys.argv[1])); audit = json.load(open(sys.argv[2]))
activity = profile['sessions'][0]['read_activity']
assert audit['schema_version'] == 2 and audit['status'] == 'invalid', audit
assert {'code': 'no-recognized-review-tools', 'tool': 'agent'} in audit['violations'], audit
assert activity['audits'] == 4 and activity['violating_audits'] == 1, activity
assert activity['invalid_audits'] == [], activity
assert profile['totals']['read_activity']['violating_audits'] == 1, profile
PY
    assert_eq "profile counts an early production audit rejection as violating" "$?" 0
    mv "$S/r6-sol.stream.valid" "$S/r6-sol.stream.ndjson"
    python3 "$SCRIPTS/lib/review-read-audit.py" audit --adapter agent \
      --raw "$S/r6-sol.stream.ndjson" --prompt "$S/r6-sol.prompt.md" \
      --root "$R" --session "$S" --out "$S/r6-sol.read-audit.json" || {
        fail "profile fixture Agent transcript restores"; return;
      }
    python3 "$SCRIPTS/rev-evidence.py" receipt "$S" 6 >/dev/null || {
      fail "profile fixture discovery receipt completes"; return;
    }
    python3 - "$R/source_0.py" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
path.write_text(path.read_text().replace('value_0_0 = "0000-', 'value_0_0 = "changed-', 1))
PY
    python3 "$SCRIPTS/rev-evidence.py" prepare "$S" 7 --phase verification \
      --assignment sol=correctness-boundaries \
      --assignment terra=security-state-api \
      --assignment opus=concurrency-resources-performance \
      --assignment sonnet=tests-observability-maintenance-regression >/dev/null || {
        fail "profile fixture verification prepares"; return;
      }
    "$SCRIPTS/rev-prompt.sh" "$S" 7 sol correctness-boundaries verification \
      --evidence "$S/r7-evidence.manifest.json" >/dev/null || return
    "$SCRIPTS/rev-prompt.sh" "$S" 7 terra security-state-api verification \
      --evidence "$S/r7-evidence.manifest.json" >/dev/null || return
    "$SCRIPTS/rev-prompt.sh" "$S" 7 opus concurrency-resources-performance verification \
      --evidence "$S/r7-evidence.manifest.json" >/dev/null || return
    "$SCRIPTS/rev-prompt.sh" "$S" 7 sonnet tests-observability-maintenance-regression verification \
      --evidence "$S/r7-evidence.manifest.json" >/dev/null || return
    cp "$S/r7-evidence.manifest.json" "$S/expected-evidence.manifest.json"
    printf '{' > "$S/r8-evidence.manifest.json"
    cat > "$S/r7-sol.stream.ndjson" <<'EOF'
{"type":"turn.completed","usage":{"input_tokens":12,"output_tokens":3}}
EOF
    rm -f "$S"/r6-* "$S/coverage-head.json"
    rm -rf "$R" "$S/evidence-objects"

    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile.json"
    python3 - "$S/profile.json" "$S/expected-evidence.manifest.json" "$R" "$S/evidence-objects" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
m = json.load(open(sys.argv[2]))
s = d['sessions'][0]
assert any(required['segments'] for packet in m['source_context']['seats'].values()
           for required in packet['required_source_ranges']), m['source_context']
assert s['usage']['processed_tokens'] == 15, s
session = __import__('pathlib').Path(sys.argv[2]).parent
evidence_words = len((session / 'r7-evidence.md').read_bytes().split())
instruction_words = len((session / 'r7-instructions.md').read_bytes().split())
assert instruction_words > 0, instruction_words
assert m['word_counts']['evidence'] == evidence_words + instruction_words, m['word_counts']
expected = {
    'valid_manifests': 1,
    'invalid_manifests': [{'manifest': 'r8-evidence.manifest.json', 'reason': 'malformed manifest JSON'}],
    'full_words': m['word_counts']['full'],
    'assigned_patch_words': m['word_counts']['assigned_patch'],
    'delta_words': m['word_counts']['delta'],
    'evidence_words': m['word_counts']['evidence'],
    'source_context_words': m['word_counts']['source_context'],
    'avoided_words': m['word_counts']['avoided'],
    'plan_words': 0,
    'closure_words': 0,
    'prepared_search_words': 0,
    'plan_specialist_patch_words': 0,
    'receipt_relative_plan_manifests': 0,
    'cumulative_plan_manifests': 0,
}

assert s['scope_projection'] == expected, (s, expected)
assert expected['avoided_words'] > 0, expected
assert expected['delta_words'] > 0, expected
assert d['totals']['processed_tokens'] == 15, d
assert d['totals']['scope_projection'] == {
    'valid_manifests': 1,
    'invalid_manifests': 1,
    'full_words': expected['full_words'],
    'assigned_patch_words': expected['assigned_patch_words'],
    'delta_words': expected['delta_words'],
    'evidence_words': expected['evidence_words'],
    'source_context_words': expected['source_context_words'],
    'avoided_words': expected['avoided_words'],
    'plan_words': 0,
    'closure_words': 0,
    'prepared_search_words': 0,
    'plan_specialist_patch_words': 0,
    'receipt_relative_plan_manifests': 0,
    'cumulative_plan_manifests': 0,
}, d
assert not __import__('pathlib').Path(sys.argv[3]).exists(), sys.argv[3]
assert not __import__('pathlib').Path(sys.argv[4]).exists(), sys.argv[4]
PY
    assert_eq "profile validates preserved evidence offline without changing provider usage" "$?" 0

    "$SCRIPTS/rev-profile.py" "$S" > "$S/profile.txt"
    local full assigned delta evidence avoided
    read -r full assigned delta evidence avoided < <(python3 - "$S/expected-evidence.manifest.json" <<'PY'
import json, sys
w = json.load(open(sys.argv[1]))['word_counts']
print(w['full'], w['assigned_patch'], w['delta'], w['evidence'], w['avoided'])
PY
)
    assert_grep "text profile labels projected scope words" "$S/profile.txt" \
      "projected_scope_words=full:$full assigned:$assigned delta:$delta evidence:$evidence avoided:$avoided"
    assert_grep "text profile labels invalid evidence" "$S/profile.txt" 'evidence_invalid=1'
    assert_grep "text profile explains invalid evidence" "$S/profile.txt" \
      'r8-evidence\.manifest\.json: malformed manifest JSON'
    [ ! -e "$S/evidence-objects" ] && ok "offline profiling does not recreate evidence objects" || \
      fail "offline profiling does not recreate evidence objects"

    rm "$S/r7-sol.prompt.md"
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-unused.json"
    python3 - "$S/profile-unused.json" <<'PY'
import json, sys
scope = json.load(open(sys.argv[1]))['sessions'][0]['scope_projection']
assert scope == {
    'valid_manifests': 0,
    'invalid_manifests': [
        {'manifest': 'r7-evidence.manifest.json', 'reason': 'evidence prompt unavailable: sol'},
        {'manifest': 'r8-evidence.manifest.json', 'reason': 'malformed manifest JSON'},
    ],
    'full_words': 0,
    'assigned_patch_words': 0,
    'delta_words': 0,
    'evidence_words': 0,
    'source_context_words': 0,
    'avoided_words': 0,
    'plan_words': 0,
    'closure_words': 0,
    'prepared_search_words': 0,
    'plan_specialist_patch_words': 0,
    'receipt_relative_plan_manifests': 0,
    'cumulative_plan_manifests': 0,
}, scope
PY
    assert_eq "manifest without every hashed prompt cannot claim projected savings" "$?" 0
  )
}

test_profile_source_context_activity() {
  ( local S="$T/profile-source-context"; mkdir -p "$S"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"}]}' > "$S/roster.json"
    printf '{}\n' > "$S/r4-evidence.manifest.json"
    printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":10,"output_tokens":2}}' > "$S/r4-sol.stream.ndjson"
    printf '%s\n' '{"summary":"checked","findings":[]}' > "$S/r4-sol.json"
    printf '0\n' > "$S/r4-sol.exit"
    python3 - "$S" <<'PY'
import hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1])
manifest = root / 'r4-evidence.manifest.json'
manifest_hash = hashlib.sha256(manifest.read_bytes()).hexdigest()
(root / 'r4-sol.prompt.md').write_text('Evidence manifest SHA-256: ' + manifest_hash + '\nAssigned scope: semantic\n')
prompt = root / 'r4-sol.prompt.md'; stream = root / 'r4-sol.stream.ndjson'; result = root / 'r4-sol.json'
audit = {
    'schema_version': 2, 'status': 'valid', 'narrow': True, 'adapter': 'codex',
    'prompt_sha256': hashlib.sha256(prompt.read_bytes()).hexdigest(),
    'stream_sha256': hashlib.sha256(stream.read_bytes()).hexdigest(),
    'result_sha256': hashlib.sha256(result.read_bytes()).hexdigest(),
    'evidence_manifest_sha256': manifest_hash, 'violations': [],
    'tool_calls': 3, 'tool_turns': 2, 'tool_output_bytes': 1200, 'max_tool_output_bytes': 700,
    'recognized_tool_calls': 3, 'source_read_calls': 1, 'source_read_batches': 1, 'packet_shards': 2,
    'packet_bytes': 900, 'packet_ranges': 4, 'opened_source_ranges': 1,
    'patch_proof_mode': 'chunks', 'patch_proof_calls': 2, 'patch_proof_turns': 2,
    'patch_proof_visible_bytes': 280, 'expected_patch_chunks': 2, 'opened_patch_chunks': 2,
    'finding_citations': 0, 'source_ranges': [
        {'path':'src/a.py','line_start':1,'line_end':20,'origin':'packet'},
        {'path':'src/a.py','line_start':30,'line_end':40,'origin':'packet'},
        {'path':'src/c.py','line_start':1,'line_end':10,'origin':'packet'},
        {'path':'src/d.py','line_start':5,'line_end':15,'origin':'packet'},
        {'path':'src/b.py','line_start':40,'line_end':60,'origin':'tool'},
    ],
}

(root / 'r4-sol.read-audit.json').write_text(json.dumps(audit))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile.json"
    python3 - "$S/profile.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1])); a = d['sessions'][0]['read_activity']
assert a['packet_shards'] == 2 and a['packet_bytes'] == 900, a
assert a['packet_ranges'] == 4 and a['opened_source_ranges'] == 1, a
assert a['source_read_calls'] == 1 and a['recognized_tool_calls'] == 3, a
assert a['source_read_batches'] == 1, a
assert a['finding_citations'] == 0, a
assert a['patch_proof_calls'] == 2 and a['patch_proof_turns'] == 2, a
assert a['patch_proof_visible_bytes'] == 280, a
assert a['expected_patch_chunks'] == a['opened_patch_chunks'] == 2, a
assert a['chunk_seats'] == 1 and a['window_seats'] == 0, a
assert d['totals']['read_activity']['packet_bytes'] == 900, d
assert d['totals']['read_activity']['patch_proof_calls'] == 2, d
assert d['totals']['processed_tokens'] == 12, d
PY
    assert_eq "profile separates packet bytes and source-range activity from raw tokens" "$?" 0
    "$SCRIPTS/rev-profile.py" "$S" > "$S/profile.txt"
    assert_grep "text profile reports packet and source ranges separately" "$S/profile.txt" \
      'packet_shards:2 packet_bytes:900 packet_ranges:4 source_reads:1 source_batches:1 opened_ranges:1 finding_citations:0'
    assert_grep "text profile reports patch proof activity separately" "$S/profile.txt" \
      'patch_proof_calls:2 patch_proof_turns:2 patch_proof_bytes:280 expected_chunks:2 opened_chunks:2 patch_modes:window:0,chunk:1'
    python3 - "$S/r4-sol.read-audit.json" <<'PY'
import json, sys
path = sys.argv[1]; audit = json.load(open(path)); audit['packet_ranges'] = 5
open(path, 'w').write(json.dumps(audit))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-unbound-surplus.json"
    python3 - "$S/profile-unbound-surplus.json" <<'PY'
import json, sys
a = json.load(open(sys.argv[1]))['sessions'][0]['read_activity']
assert a['audits'] == 0 and a['packet_ranges'] == 0, a
assert any('invalid source evidence audit structure' in item['reason'] for item in a['invalid_audits']), a
PY
    assert_eq "profile rejects an unbound packet_ranges surplus" "$?" 0
    python3 - "$S" <<'PY'
import hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1]); manifest = root / 'r4-evidence.manifest.json'
manifest.write_text(json.dumps({'source_context': {'seats': {'sol': {'shards': [{'ranges': [{}, {}, {}, {}, {}]}]}}}}))
digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
prompt = root / 'r4-sol.prompt.md'; prompt.write_text('Evidence manifest SHA-256: ' + digest + '\nAssigned scope: semantic\n')
path = root / 'r4-sol.read-audit.json'; audit = json.loads(path.read_text())
audit['evidence_manifest_sha256'] = digest; audit['prompt_sha256'] = hashlib.sha256(prompt.read_bytes()).hexdigest()
audit['status'] = 'valid'; audit['violations'] = []; audit['packet_ranges'] = 5; audit['opened_source_ranges'] = 1
audit['source_ranges'] = [{'path': f'src/{i}.py', 'line_start': 1, 'line_end': 2, 'origin': 'packet'} for i in range(5)] + [audit['source_ranges'][-1]]
path.write_text(json.dumps(audit))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-malformed-ranges.json"
    python3 - "$S/profile-malformed-ranges.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
a = d['sessions'][0]['read_activity']
scope = d['sessions'][0]['scope_projection']
assert a['audits'] == 0 and a['packet_ranges'] == 0, a
assert d['totals']['read_activity']['packet_ranges'] == 0, d
assert any('invalid source evidence audit structure' in item['reason'] for item in a['invalid_audits']), a
assert scope['valid_manifests'] == 0, scope
assert any(item['manifest'] == 'r4-evidence.manifest.json' for item in scope['invalid_manifests']), scope
PY
    assert_eq "profile rejects malformed shard ranges" "$?" 0
    python3 - "$S" <<'PY'
import hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1]); manifest = root / 'r4-evidence.manifest.json'
manifest.write_text(json.dumps({'source_context': {'seats': {'sol': {'shards': None}}}}))
digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
prompt = root / 'r4-sol.prompt.md'; prompt.write_text('Evidence manifest SHA-256: ' + digest + '\nAssigned scope: semantic\n')
path = root / 'r4-sol.read-audit.json'; audit = json.loads(path.read_text())
audit['evidence_manifest_sha256'] = digest; audit['prompt_sha256'] = hashlib.sha256(prompt.read_bytes()).hexdigest()
audit['packet_ranges'] = sum(row['origin'] == 'packet' for row in audit['source_ranges'])
path.write_text(json.dumps(audit))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-invalid-shards.json"
    python3 - "$S/profile-invalid-shards.json" <<'PY'
import json, sys
a = json.load(open(sys.argv[1]))['sessions'][0]['read_activity']
assert a['audits'] == 0, a
assert any('invalid source evidence audit structure' in item['reason'] for item in a['invalid_audits']), a
PY
    assert_eq "profile rejects malformed shard binding" "$?" 0

    local B="$T/profile-base-tree" R="$T/profile-base-tree-repo"
    export REV_SOURCE_CONTEXT=1 REV_PATCH_CHUNKS=1
    mkrepo "$R"; mkdir -p "$B"
    printf 'value = 1\n' > "$R/emptied.py"
    git -C "$R" add emptied.py && git -C "$R" commit -qm 'empty context base'
    local base; base=$(git -C "$R" rev-parse HEAD)
    printf "REV_ROOT='%s'\nREV_BASE='%s'\nREV_SCOPE='branch'\n" "$R" "$base" > "$B/scope.env"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"agent"},{"seat":"terra","adapter":"agent"},{"seat":"opus","adapter":"agent"},{"seat":"sonnet","adapter":"agent"}]}' > "$B/roster.json"
    : > "$B/files.txt"; : > "$B/untracked.txt"
    : > "$R/emptied.py"
    python3 "$SCRIPTS/rev-evidence.py" prepare "$B" 4 --phase discovery >/dev/null || {
      fail "profile base-tree discovery prepares"; return;
    }
    python3 - "$B" > "$T/base-tree-counts.txt" <<'PY' || { fail "profile base-tree shard range"; return; }
import hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1])
manifest_path = root / 'r4-evidence.manifest.json'
manifest = json.loads(manifest_path.read_text())
base_tree = manifest['base_tree']
snapshot_tree = manifest['snapshot_tree']
seat = next(name for name, packet in manifest['source_context']['seats'].items()
            if any(row['path'] == 'emptied.py' and row['blob_tree'] == base_tree
                   for shard in packet['shards'] for row in shard['ranges']))
packet = manifest['source_context']['seats'][seat]
ranges = [row for shard in packet['shards'] for row in shard['ranges']]
total = sum(len(shard['ranges']) for shard in packet['shards'])
snapshot_rows = [row for row in ranges if row['blob_tree'] == snapshot_tree]
assert total > len(snapshot_rows), (total, len(snapshot_rows))
assignment = manifest['assignments'][seat]
prompt = root / f'r4-{seat}.prompt.md'
stream = root / f'r4-{seat}.stream.ndjson'
result = root / f'r4-{seat}.json'
digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
prompt.write_text('Evidence manifest SHA-256: ' + digest + '\nAssigned scope: semantic\n')
stream.write_text('{"type":"turn.completed","usage":{"input_tokens":10,"output_tokens":2}}\n')
result.write_text('{"summary":"checked","findings":[]}\n')
(root / f'r4-{seat}.exit').write_text('0\n')
mode = assignment['patch_read_mode']
if mode == 'chunks':
    patch_calls = len(manifest['patch_sets'][assignment['patch_set']]['chunks'])
    expected = opened = patch_calls
else:
    assert mode == 'windows', mode
    patch_calls, expected, opened = 1, 0, 0
tool_calls = max(3, patch_calls, 1)
source_ranges = [
    {'path': row['path'], 'line_start': row['line_start'], 'line_end': row['line_end'], 'origin': 'packet'}
    for row in snapshot_rows
] + [{'path': 'emptied.py', 'line_start': 1, 'line_end': 1, 'origin': 'tool'}]
audit = {
    'schema_version': 2, 'status': 'valid', 'narrow': True, 'adapter': assignment['adapter'],
    'prompt_sha256': hashlib.sha256(prompt.read_bytes()).hexdigest(),
    'stream_sha256': hashlib.sha256(stream.read_bytes()).hexdigest(),
    'result_sha256': hashlib.sha256(result.read_bytes()).hexdigest(),
    'evidence_manifest_sha256': digest, 'violations': [],
    'tool_calls': tool_calls, 'tool_turns': 1, 'tool_output_bytes': 1200, 'max_tool_output_bytes': 700,
    'recognized_tool_calls': 1, 'source_read_calls': 1, 'source_read_batches': 1,
    'packet_shards': len(packet['shards']),
    'packet_bytes': sum(shard['bytes'] for shard in packet['shards']),
    'packet_ranges': total, 'opened_source_ranges': 1, 'finding_citations': 0,
    'source_ranges': source_ranges, 'patch_proof_mode': mode,
    'patch_proof_calls': patch_calls, 'patch_proof_turns': patch_calls,
    'patch_proof_visible_bytes': 280, 'expected_patch_chunks': expected, 'opened_patch_chunks': opened,
}
audit_path = root / f'r4-{seat}.read-audit.json'
audit_path.write_text(json.dumps(audit))
print(audit_path)
print(total)
print(len(snapshot_rows))
PY
    local audit_path range_total snapshot_ranges
    {
      read -r audit_path
      read -r range_total
      read -r snapshot_ranges
    } < "$T/base-tree-counts.txt"
    "$SCRIPTS/rev-profile.py" --json "$B" > "$B/profile-base-packet.json"
    python3 - "$B/profile-base-packet.json" "$range_total" "$audit_path" <<'PY'
import json, sys
d = json.load(open(sys.argv[1])); a = d['sessions'][0]['read_activity']
audit = json.load(open(sys.argv[3]))
packet_rows = sum(row['origin'] == 'packet' for row in audit['source_ranges'])
total = int(sys.argv[2])
assert a['audits'] == 1 and a['invalid_audits'] == [], a
assert a['finding_citations'] == 0, a
assert a['packet_ranges'] == total > packet_rows, (a, total, packet_rows)
PY
    assert_eq "profile counts base-tree packet ranges without claiming citation credit" "$?" 0
    for offset in 1 -1; do
      python3 - "$audit_path" "$range_total" "$offset" <<'PY'
import json, sys
path, total, offset = sys.argv[1:]
audit = json.load(open(path)); audit['packet_ranges'] = int(total) + int(offset)
open(path, 'w').write(json.dumps(audit))
PY
      "$SCRIPTS/rev-profile.py" --json "$B" > "$B/profile-shard-count-$offset.json"
      python3 - "$B/profile-shard-count-$offset.json" <<'PY'
import json, sys
a = json.load(open(sys.argv[1]))['sessions'][0]['read_activity']
assert a['audits'] == 0 and a['packet_ranges'] == 0, a
assert any('invalid source evidence audit structure' in item['reason'] for item in a['invalid_audits']), a
PY
      local status=$?
      if [ "$offset" = 1 ]; then
        assert_eq "profile rejects packet_ranges above the opened shard total" "$status" 0
      else
        assert_eq "profile rejects packet_ranges below the opened shard total" "$status" 0
      fi
    done
    python3 - "$audit_path" "$snapshot_ranges" <<'PY'
import json, sys
path = sys.argv[1]; audit = json.load(open(path)); audit['packet_ranges'] = int(sys.argv[2]) - 1
open(path, 'w').write(json.dumps(audit))
PY
    "$SCRIPTS/rev-profile.py" --json "$B" > "$B/profile-invalid-packets.json"
    assert_grep "profile rejects fewer packets than credited packet ranges" \
      "$B/profile-invalid-packets.json" 'invalid source evidence audit structure'
    python3 - "$audit_path" "$range_total" <<'PY'
import json, sys
path = sys.argv[1]; audit = json.load(open(path))
audit['packet_ranges'] = int(sys.argv[2]); audit['source_read_batches'] = audit['source_read_calls'] + 1
open(path, 'w').write(json.dumps(audit))
PY
    "$SCRIPTS/rev-profile.py" --json "$B" > "$B/profile-invalid-batches.json"
    assert_grep "profile rejects more source batches than source read calls" \
      "$B/profile-invalid-batches.json" 'invalid source evidence audit structure'
    python3 - "$audit_path" "$snapshot_ranges" <<'PY'
import json, sys
path = sys.argv[1]; audit = json.load(open(path))
audit['status'] = 'invalid'; audit['violations'] = [{'code': 'missing-source-packet'}]
audit['source_read_batches'] = audit['source_read_calls']; audit['packet_ranges'] = int(sys.argv[2])
open(path, 'w').write(json.dumps(audit))
PY
    "$SCRIPTS/rev-profile.py" --json "$B" > "$B/profile-partial-invalid.json"
    python3 - "$B/profile-partial-invalid.json" "$snapshot_ranges" <<'PY'
import json, sys
a = json.load(open(sys.argv[1]))['sessions'][0]['read_activity']
assert a['audits'] == 1 and a['violating_audits'] == 1 and a['invalid_audits'] == [], a
assert a['packet_ranges'] == int(sys.argv[2]), a
PY
    assert_eq "profile retains partial invalid packet metrics" "$?" 0
    python3 - "$audit_path" "$range_total" <<'PY'
import json, sys
path = sys.argv[1]; audit = json.load(open(path)); audit['packet_ranges'] = int(sys.argv[2]) + 1
open(path, 'w').write(json.dumps(audit))
PY
    "$SCRIPTS/rev-profile.py" --json "$B" > "$B/profile-invalid-overcount.json"
    assert_grep "profile rejects invalid audit packet overcount" "$B/profile-invalid-overcount.json" \
      'invalid source evidence audit structure'
  )
}

# Historical Grok usage decoding rejects malformed frozen provider metrics.
test_profile_rejects_invalid_usage_numbers() {
  ( local S="$T/profile-invalid-numbers"; mkdir -p "$S"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"grok","adapter":"grok"}]}' > "$S/roster.json"
    printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":10,"output_tokens":2}}' > "$S/r1-sol.stream.ndjson"
    printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":-8,"output_tokens":1}}' > "$S/r2-sol.stream.ndjson"
    printf '%s\n' '{"type":"turn.completed","usage":{"input_tokens":true,"output_tokens":1}}' > "$S/r3-sol.stream.ndjson"
    printf '%s\n' '{"type":"end","usage":{"total_tokens":2,"output_tokens":3}}' > "$S/r4-grok.stream.ndjson"
    printf '%s\n' '{"type":"end","usage":{"input_tokens":4,"output_tokens":1,"cost_usd":NaN}}' > "$S/r5-grok.stream.ndjson"
    printf '%s\n' '{"type":"end","usage":{"input_tokens":4,"output_tokens":1},"cost_usd":false}' > "$S/r6-grok.stream.ndjson"
    printf '%s\n' '{"type":"turn.completed","usage":false}' > "$S/r7-sol.stream.ndjson"
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile.json"
    python3 - "$S/profile.json" <<'PY'
import json, math, sys
raw = open(sys.argv[1]).read()
assert 'NaN' not in raw and 'Infinity' not in raw, raw
d = json.loads(raw); s = d['sessions'][0]
assert d['totals']['calls'] == 1 and d['totals']['processed_tokens'] == 12, d
assert len(s['invalid_usage']) == 6, s
assert all(math.isfinite(value) for value in (d['totals']['cost_usd'],)), d
PY
    assert_eq "profile excludes invalid numeric usage without reducing valid totals" "$?" 0
    "$SCRIPTS/rev-profile.py" "$S" > "$S/profile.txt"
    assert_grep "text profile reports rejected provider usage" "$S/profile.txt" 'usage_invalid=6'
  )
}

test_profile_requires_complete_evidence_patch_proofs() {
  ( local S="$T/profile-patch-proof-completeness"; mkdir -p "$S"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"}]}' > "$S/roster.json"
    printf 'prompt\n' > "$S/r1-sol.prompt.md"
    printf '%s\n' '{"summary":"checked","findings":[]}' > "$S/r1-sol.json"
    printf '{}\n' > "$S/r1-sol.stream.ndjson"
    printf '{}\n' > "$S/r1-evidence.manifest.json"
    python3 - "$S" <<'PY'
import hashlib, json, pathlib, sys
s = pathlib.Path(sys.argv[1]); prompt=s/'r1-sol.prompt.md'; result=s/'r1-sol.json'
stream=s/'r1-sol.stream.ndjson'; manifest=s/'r1-evidence.manifest.json'
base={
 'schema_version':2,'status':'valid','narrow':True,'adapter':'codex','violations':[],
 'prompt_sha256':hashlib.sha256(prompt.read_bytes()).hexdigest(),
 'stream_sha256':hashlib.sha256(stream.read_bytes()).hexdigest(),
 'result_sha256':hashlib.sha256(result.read_bytes()).hexdigest(),
 'evidence_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
 'tool_calls':3,'tool_turns':3,'tool_output_bytes':100,'max_tool_output_bytes':50,
 'recognized_tool_calls':3,'source_read_calls':0,'packet_shards':0,'packet_bytes':0,
 'packet_ranges':0,'opened_source_ranges':0,'finding_citations':0,'source_ranges':[],
 'patch_proof_mode':'chunks','patch_proof_calls':2,'patch_proof_turns':2,
 'patch_proof_visible_bytes':80,'expected_patch_chunks':2,'opened_patch_chunks':1,
}
(s/'r1-sol.read-audit.json').write_text(json.dumps(base))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile.json"
    python3 - "$S/profile.json" <<'PY'
import json, sys
d=json.load(open(sys.argv[1])); a=d['sessions'][0]['read_activity']
assert a['audits']==0 and a['violating_audits']==0, a
assert a['invalid_audits']==[{
    'audit':'r1-sol.read-audit.json',
    'reason':'invalid patch proof audit structure',
}], a
assert d['totals']['read_activity']['invalid_audits']==1, d
PY
    assert_eq "profile diagnoses an incomplete valid patch proof exactly" "$?" 0
    python3 - "$S/r1-sol.read-audit.json" <<'PY'
import json, sys
p=sys.argv[1]; d=json.load(open(p)); d['opened_patch_chunks']=d['expected_patch_chunks']
open(p,'w').write(json.dumps(d))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-complete.json"
    python3 - "$S/profile-complete.json" <<'PY'
import json, sys
d=json.load(open(sys.argv[1])); a=d['sessions'][0]['read_activity']
assert a['audits']==1 and a['violating_audits']==0, a
assert a['invalid_audits']==[], a
assert a['expected_patch_chunks']==a['opened_patch_chunks']==2, a
assert d['totals']['read_activity']['audits']==1, d
assert d['totals']['read_activity']['invalid_audits']==0, d
PY
    assert_eq "profile counts one complete valid patch proof" "$?" 0
    python3 - "$S/r1-sol.read-audit.json" <<'PY'
import json, sys
p=sys.argv[1]; d=json.load(open(p)); d['status']='invalid'
d['violations']=[{'code':'missing-assigned-patch-chunk','tool':'codex'}]
d['opened_patch_chunks']=d['expected_patch_chunks']-1
open(p,'w').write(json.dumps(d))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-invalid.json"
    python3 - "$S/profile-invalid.json" <<'PY'
import json,sys
a=json.load(open(sys.argv[1]))['sessions'][0]['read_activity']
assert a['audits']==1 and a['violating_audits']==1 and not a['invalid_audits'], a
PY
    assert_eq "profile keeps incomplete counters for invalid diagnostics" "$?" 0
    printf '%s\n' '{"summary":"uncited","findings":[{"severity":"P1","file":"src/x.ts","line_start":1,"line_end":1,"claim":"x","evidence":"x","suggested_fix":"x","confidence":0.9}]}' > "$S/r1-sol.json"
    python3 - "$S/r1-sol.read-audit.json" "$S/r1-sol.json" <<'PY'
import hashlib,json,sys
p,result=sys.argv[1:]; d=json.load(open(p))
d['violations']=[{'code':'unsubstantiated-finding-range','tool':'codex'}]
d['finding_citations']=0; d['opened_patch_chunks']=d['expected_patch_chunks']
d['result_sha256']=hashlib.sha256(open(result,'rb').read()).hexdigest()
open(p,'w').write(json.dumps(d))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-uncited.json"
    python3 - "$S/profile-uncited.json" <<'PY'
import json,sys
a=json.load(open(sys.argv[1]))['sessions'][0]['read_activity']
assert a['audits']==1 and a['violating_audits']==1 and not a['invalid_audits'], a
PY
    assert_eq "profile counts a well-formed invalid uncited-finding audit" "$?" 0
    rm "$S/r1-sol.json"
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-discarded.json"
    python3 - "$S/profile-discarded.json" <<'PY'
import json,sys
a=json.load(open(sys.argv[1]))['sessions'][0]['read_activity']
assert a['audits']==1 and a['violating_audits']==1 and not a['invalid_audits'], a
PY
    assert_eq "profile counts an invalid audit after the runner discards its result" "$?" 0
    python3 - "$S/r1-sol.read-audit.json" <<'PY'
import json,sys
p=sys.argv[1]; d=json.load(open(p)); d.pop('patch_proof_mode'); open(p,'w').write(json.dumps(d))
PY
    "$SCRIPTS/rev-profile.py" --json "$S" > "$S/profile-missing.json"
    assert_grep "profile rejects evidence audits without patch mode" "$S/profile-missing.json" \
      'evidence audit lacks patch proof counters'
  )
}

test_profile_plan_label_classification() {
  python3 - "$SCRIPTS/rev-profile.py" <<'PY'
import importlib.util, pathlib, sys
spec=importlib.util.spec_from_file_location('profile',sys.argv[1])
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
for name in ('r1p-opus.prompt.md','r1pf-opus.prompt.md','r12-plan-opus.json'):
    assert module.is_plan(pathlib.Path(name)), name
for name in ('r1-sol.prompt.md','r1-performance.json','r2-planner.stream.ndjson','r3x-plan-opus.json'):
    assert not module.is_plan(pathlib.Path(name)), name
PY
  assert_eq "profile recognizes plan fallback labels without code false positives" "$?" 0
}

test_profile_reports_panel_render_timing() {
  ( local S="$T/profile-render-timing"; mkdir -p "$S"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"opus","adapter":"claude"}]}' > "$S/roster.json"
    printf '%s\n' '{"schema_version": 1, "seats": {"sol": 40, "opus": 60}, "total_ms": 900}' > "$S/r1-render.json"
    printf '%s\n' '{"schema_version": 1, "seats": {"sol": 5}, "total_ms": 20}' > "$S/r2p-render.json"
    printf '%s\n' '{"schema_version": 1, "seats": {"sol": -1}, "total_ms": 20}' > "$S/r3-render.json"
    "$SCRIPTS/rev-profile.py" --json "$S" > "$T/profile-render-timing.json" || return
    python3 - "$T/profile-render-timing.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
timing = d['sessions'][0]['render_timing']
assert timing['panels'] == [
    {'label': '1', 'seats': {'sol': 40, 'opus': 60}, 'total_ms': 900},
    {'label': '2p', 'seats': {'sol': 5}, 'total_ms': 20},
], timing
assert timing['invalid'] == [{'timing': 'r3-render.json', 'reason': 'invalid render timing'}], timing
assert d['totals']['render_timing'] == {'panels': 2, 'total_ms': 920, 'seat_ms': 105, 'invalid': 1}, d['totals']
assert d['sessions'][0]['prompts']['code']['count'] == 0, d['sessions'][0]['prompts']
PY
    assert_eq "profile reports per-seat panel render time" "$?" 0
    "$SCRIPTS/rev-profile.py" "$S" > "$T/profile-render-timing.txt" || return
    assert_grep "text profile lists each panel's seat render time" "$T/profile-render-timing.txt" \
      '^  render_timing=1:total_ms:900,sol:40,opus:60;2p:total_ms:20,sol:5$'
    assert_grep "text profile names invalid render timing" "$T/profile-render-timing.txt" \
      '^  render_timing_invalid_detail=r3-render\.json: invalid render timing$'
    assert_grep "text profile totals render time" "$T/profile-render-timing.txt" \
      '^TOTAL_RENDER_TIMING panels=2 total_ms=920 seat_ms=105 invalid=1$'
  )
}
