# The default schedule must preserve the independent discovery and verification
# panels without paying for eight unconditional full-panel rounds.
assert_flat_fixed() {
  local name=$1 file=$2 expected=$3 flat
  flat="$T/flat-$(basename "$file")-$RANDOM"
  tr '\n' ' ' < "$file" | tr -s ' ' > "$flat"
  grep -Fq -- "$expected" "$flat" && ok "$name" || fail "$name" "missing fixed text in $file"
}

assert_flat_absent() {
  local name=$1 file=$2 pattern=$3 flat
  flat="$T/flat-absent-$(basename "$file")-$RANDOM"
  tr '\n' ' ' < "$file" | tr -s ' ' > "$flat"
  grep -Eq -- "$pattern" "$flat" && fail "$name" "found /$pattern/ in $file" || ok "$name"
}

test_adaptive_schedule_contract() {
  local K src dest file
  for src in "$SK/skills/rev" "$SK/codex-skills/rev"; do
    dest="$T/$(basename "$(dirname "$src")")-rev.md"
    cat "$src/SKILL.md" > "$dest"
    if [ -d "$src/phases" ]; then
      for file in "$src"/phases/*.md; do
        [ -f "$file" ] || continue
        printf '\n' >> "$dest"
        cat "$file" >> "$dest"
      done
    fi
  done
  local K
  local timing='One four-bundle verification panel reviews the latest material state: the current combined panel when no fix follows, a separate panel after simplicity-only discovery, or a fresh panel after fixes.'
  local plan_trigger='Run the plan panel when accepted findings require a nontrivial change; skip it when there is no accepted fix or every accepted fix is a P3 or one-line P2.'
  local extras='Adaptive default panels use core seats and omit extras. Explicit numeric round plans may include extras in their configured rounds.'
  local repair="Do not certify an adaptive panel until every assignment has a valid result, either its own result or one selected successful replacement's result."
  local numeric_continue="Only numeric mode continues past its requested minimum while any of these hold: the last numbered code panel produced a new P0/P1; the last numbered panel's fixes were nontrivial; any P0/P1 remains open; or a lens or major changed file remains unreviewed."
  local numeric_stop='Numeric mode stops only after the requested minimum numbered code panels ran, two consecutive numbered code panels produced no new P0/P1, no P0/P1 remains open, and gates are at or better than baseline. Plan panels do not count as numbered code panels.'
  local receipt='Current-session completion and finding yield require a schema-valid result with a successful exit receipt. Only exact hashed receiptless results recorded in a versioned legacy roster policy may omit one. Usage-bearing failed attempts remain metered.'
  for K in "$T/skills-rev.md" "$T/codex-skills-rev.md"; do
    assert_nogrep "$(basename "$(dirname "$(dirname "$K")")") has no eight-round floor" "$K" 'minimum[^[:alnum:]]{0,12}(8|eight)|8 rounds|eight rounds' -i
    assert_flat_fixed "ordinary schedule retains eight code seats and one conditional plan" "$K" 'normal review uses eight code-seat launches plus one conditional plan.'
    assert_flat_fixed "combined schedule retains four separate verification seats after a fix" "$K" 'If any fix follows the combined panel, run four separate verification launches; a one-seat plan then gives totals of 17 or 13 respectively.'
    assert_grep "reuse is based on fresh coverage" "$K" 'current-coverage.*\$S'
    assert_flat_fixed "all-lens plan panels restore four plan launches" "$K" 'With `"plan_seats": "all"`, every plan panel launches all four core seats instead of one.'
    assert_flat_absent "four-seat plan counts are gone" "$K" 'plans 12 seat launches|four conditional plan|plans 20 by|plans 16 by'
    assert_grep "large threshold names 25 files" "$K" 'more than 25 changed files'
    assert_grep "large threshold names 1500 lines" "$K" 'more than 1,500 changed lines'
    assert_flat_fixed "verification timing is canonical" "$K" "$timing"
    assert_flat_fixed "plan trigger is canonical" "$K" "$plan_trigger"
    assert_flat_fixed "extras policy is canonical" "$K" "$extras"
    assert_flat_fixed "assignment replacement is canonical" "$K" "$repair"
    assert_grep "explicit round count is named" "$K" '[Ee]xplicit round count'
    assert_grep "explicit rounds remain a minimum override" "$K" 'minimum override'
    assert_grep "numeric schedule preserves round 8 regression" "$K" '\| 8 \|[^|]*\| regression \|'
    assert_grep "numeric mode exclusively uses the legacy schedule" "$K" '[Ee]xplicit numeric.*(exclusively|instead).*legacy'
    assert_nogrep "numeric schedule has no additional-round ambiguity" "$K" 'additional requested rounds|legacy lens rotation for any additional'
    assert_flat_fixed "numeric continuation is restored" "$K" "$numeric_continue"
    assert_flat_fixed "numeric stop is restored" "$K" "$numeric_stop"
    assert_flat_fixed "adaptive completion covers every bundle" "$K" 'A certified risk or verification panel therefore has all four bundles.'
    assert_nogrep "verification is not duplicated after a fix" "$K" 'always.*verification.*after discovery.*again|after discovery.*and again' -i
    assert_nogrep "bundle repair is not limited by roster size" "$K" 'only three core seats|a four-seat panel loses|three-seat panel or failed bundle owner' -i
    assert_nogrep "legacy plan trigger is absent" "$K" 'Before fixing after round 1'
    assert_grep "code launch records exact seats" "$K" 'phase=fan-out round=<N> "seats=\$LAUNCHED_SEATS"'
    assert_grep "replacement launch records its selected child label and seat" "$K" \
      'phase=repair .*round=\$CHILD_LABEL.*seats=\[.*\$EXECUTOR.*\]'
    assert_grep "plan launch records exact seats" "$K" 'phase=plan round=<N>p "seats=\$PLAN_SEATS"'
    assert_grep "all-lens plan panel restores every surviving core seat" "$K" '"plan_seats": "all"`, set `PLAN_SEATS` to the JSON array of every surviving non-extra seat'
    assert_grep "default plan panel uses the resolved workhorse" "$K" 'plan-completeness` seat on the resolved workhorse'
    assert_grep "missing workhorse falls back to a non-agent core seat" "$K" '`PLAN_COMPLETENESS_SEAT` to the first surviving non-extra seat in roster order, preferring one whose adapter is not `agent`'
    assert_grep "seat lists are rebuilt rather than accumulated" "$K" '[Rr]ebuild.*seat.*list.*before every|[Ee]xtra.*absent from the next panel'
    assert_grep "collect state retains exact seats" "$K" 'phase=collect round=<N> "seats=\$LAUNCHED_SEATS"'
    assert_grep "exit 5 is documented as retryable" "$K" '[Ee]xit 5 is retryable'
    assert_grep "exit 6 is documented as permanent" "$K" '[Ee]xit 6 is permanent'
    assert_flat_fixed "receipt completion policy is canonical" "$K" "$receipt"
    assert_grep "cumulative ledger is forbidden in prompts" "$K" '[Nn]ever.*cumulative findings ledger|cumulative findings ledger.*never'
  done

  assert_flat_fixed "Claude simplicity contract uses the exact adaptive row" \
    "$T/skills-rev.md" '| Simplicity discovery | always | simplicity for every seat |'
  assert_flat_fixed "Codex simplicity contract uses the exact adaptive sentence" \
    "$T/codex-skills-rev.md" '1. **Simplicity discovery:** every core seat gets `simplicity`. Keep all four seats;'

  assert_flat_fixed "Claude numeric schedule keeps its round 5 lenses" "$T/skills-rev.md" '| 5 | API & contract, compatibility | api-contract, data-state, readability | - |'
  assert_flat_fixed "Codex numeric schedule keeps its round 5 lenses" "$T/codex-skills-rev.md" '| 5 | Contracts and compatibility | api-contract, readability, maintainability | - |'
  for K in "$T/skills-rev.md" "$T/codex-skills-rev.md"; do
    assert_grep "numeric schedule restores Emphasis column" "$K" '^\| Round \| Emphasis \| Lenses(, in order)? \| Extra( seat)? \|$'
    assert_grep "numeric round 3 restores its extra" "$K" '^\| 3 \|.*\| security, data-state \| `?codex-review`?.*\|$'
    assert_grep "numeric round 4 has no retired provider extra" "$K" '^\| 4 \|.*\| concurrency, resources, performance \| - \|$'
  done

  local ST
  for ST in "$SK/skills/stack/SKILL.md" "$SK/codex-skills/stack/SKILL.md"; do
    assert_grep "stack names numeric legacy continuation" "$ST" 'numeric.*continue.*past.*minimum' -i
    assert_grep "stack says plan panels do not count" "$ST" '[Pp]lan panels do not count'
    assert_grep "stack exit 5 is retryable" "$ST" '[Ee]xit 5 is retryable'
    assert_grep "stack exit 6 is permanent" "$ST" '[Ee]xit 6 is permanent'
  done
  assert_grep "stack example documents numeric continuation" "$SK/scripts/stack.example.sh" 'numeric mode may continue past it'
  assert_grep "stack example excludes plan panels from count" "$SK/scripts/stack.example.sh" '[Pp]lan panels do not count'

  local D
  for D in "$SK/../../README.md" "$SK/../../docs/codex.md"; do
    assert_nogrep "$(basename "$D") has no undefined two-provider spot check" "$D" 'two-provider|two different providers|two providers' -i
    assert_flat_fixed "$(basename "$D") uses canonical verification timing" "$D" "$timing"
  done
  assert_flat_fixed "README uses canonical extras policy" "$SK/../../README.md" "$extras"
  assert_flat_fixed "historical design retains its recorded verification timing" "$SK/../../docs/superpowers/specs/2026-09-11-token-efficient-council-design.md" 'One four-bundle verification panel reviews the latest material state: directly after discovery when no nontrivial fix follows, or after the latest nontrivial fix.'
  assert_flat_fixed "Codex guide budgets one plan seat" "$SK/../../docs/codex.md" 'normal changes plan 9 seat launches: four simplicity, one conditional plan, and four final verification launches.'
  for D in "$SK/../../README.md" "$SK/../../docs/codex.md"; do
    assert_flat_absent "$(basename "$D") has no four-seat plan counts" "$D" 'plan 12 seat launches|plans 12 seat launches|four conditional plan|plans 20 by|plans 16 by'
  done
  assert_grep "README table budgets one plan seat for ordinary changes" "$SK/../../README.md" '^\| ordinary, with one plan panel \| 9 \|$'
  assert_grep "README table budgets one plan seat for large changes" "$SK/../../README.md" '^\| large or high-risk, with one plan panel \| 17 \|$'
  assert_grep "unchanged eligible large review removes four launches" "$SK/../../README.md" '^\| large or high-risk, no fix, current enforced combined receipt \| 12 \|$'
  assert_grep "unchanged ineligible large review retains separate verification" "$SK/../../README.md" '^\| large or high-risk, no fix, combined receipt ineligible \| 16 \|$'
  assert_grep "unchanged eligible important review removes four launches" "$SK/../../README.md" '^\| important or adversarial, no fix, current enforced combined receipt \| 8 \|$'
  assert_grep "unchanged ineligible important review retains separate verification" "$SK/../../README.md" '^\| important or adversarial, no fix, combined receipt ineligible \| 12 \|$'
}

test_assert_grep_honors_flags() {
  printf 'UPPERCASE CONTRACT\n' > "$T/grep-flags"
  assert_grep "assert_grep honors case-insensitive matching" "$T/grep-flags" 'uppercase contract' -i
}

test_bounded_reviewer_contract() {
  local A="$SK/agents/rev-reviewer.md" B="$SK/../../eval/bench-case.sh"
  assert_nogrep "reviewer has no blanket surrounding-code read" "$A" 'Read the surrounding code'
  assert_grep "reviewer follows prompt ordering before evidence reads" "$A" 'ordering rule in the prompt'
  assert_grep "reviewer locates symbols and references" "$A" 'enclosing symbol or named section.*direct references'
  assert_grep "reviewer reads narrow windows" "$A" 'smallest useful line window'
  assert_grep "reviewer expands for a concrete question" "$A" 'concrete question.*prove or refute'
  assert_grep "reviewer stops answered evidence paths" "$A" 'Stop that evidence path when the question is answered'
  assert_nogrep "benchmark launcher has no unlimited-work wording" "$B" 'no time or token budget|unlimited work|Reason at maximum depth' -i
}
