#!/bin/bash

test_deleted_symbol_caller_evidence() {
  python3 - "$SCRIPTS/rev-evidence.py" <<'PY'
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

script = sys.argv[1]
with tempfile.TemporaryDirectory(prefix='deleted-symbol-') as tmp:
    root = Path(tmp) / 'repo'
    session = Path(tmp) / 'session'
    root.mkdir(); session.mkdir()
    git_config = Path(tmp) / 'gitconfig'
    git_config.write_text('')
    git_env = dict(os.environ, GIT_CONFIG_GLOBAL=str(git_config), GIT_CONFIG_NOSYSTEM='1')

    def git(*args):
        return subprocess.check_output(
            ['git', '-C', str(root), *args], env=git_env).decode().strip()

    git('init', '-q')
    git('config', 'user.name', 'Test')
    git('config', 'user.email', 'test@invalid')
    git('config', 'commit.gpgsign', 'false')
    (root / 'deleted.py').write_text('def gone(value):\n    return value + 1\n')
    (root / 'mixed.py').write_text(
        'def removed(value):\n    return value + 2\n\n'
        'def removed(value, extra):\n    return value + extra\n')
    (root / 'containers.py').write_text(
        'class A:\n    def duplicate(self):\n        return 1\n\n'
        'class B:\n    def duplicate(self):\n        return 2\n')
    signature_body = ''.join(f'    value_{index} = {index}\n' for index in range(500))
    (root / 'signature.py').write_text('def compute(value):\n' + signature_body)
    (root / 'overload.ts').write_text(
        'export function parse(value: string): string;\n'
        'export function parse(value: number): number;\n'
        'export function parse(value: string | number): string | number { return value; }\n')
    (root / 'caller.py').write_text(
        'from deleted import gone\nfrom mixed import removed\nfrom containers import A\n\n'
        'first = gone(1)\nsecond = removed(1)\nthird = A().duplicate()\n')
    (root / 'caller.ts').write_text(
        'import { parse } from "./overload";\nconst fourth = parse("1");\n')
    git('add', '.')
    git('commit', '-qm', 'base')
    base = git('rev-parse', 'HEAD')
    (root / 'deleted.py').unlink()
    (root / 'mixed.py').write_text(
        'def removed(value, extra):\n    return value + extra\n')
    (root / 'containers.py').write_text(
        'class RenamedB:\n  def duplicate(self):\n    return 2\n')
    (root / 'signature.py').write_text(
        'def compute(value, extra=0):\n' + signature_body)
    (root / 'overload.ts').write_text(
        'export function parse(value: number, radix?: number): number;\n'
        'export function parse(value: string | number): string | number { return value; }\n')
    (session / 'scope.env').write_text(
        f"REV_BASE='{base}'\nREV_ROOT='{root}'\nREV_SCOPE='branch'\n")
    (session / 'roster.json').write_text(json.dumps({'seats': [
        {'seat': 'sol', 'adapter': 'codex'},
        {'seat': 'terra', 'adapter': 'codex'},
        {'seat': 'opus', 'adapter': 'claude'},
        {'seat': 'sonnet', 'adapter': 'claude'},
    ]}))
    (session / 'files.txt').write_text('')
    (session / 'untracked.txt').write_text('')
    env = dict(git_env, REV_PATCH_CHUNKS='1', REV_SOURCE_CONTEXT='1')
    subprocess.run(
        [sys.executable, script, 'prepare', str(session), '1', '--phase', 'discovery'],
        env=env, check=True, capture_output=True)
    evidence = json.loads((session / 'r1-evidence.json').read_text())
    manifest = json.loads((session / 'r1-evidence.manifest.json').read_text())
    assert any(row['path'] == 'deleted.py' and row['name'] == 'gone'
               for row in evidence['symbols']), evidence['symbols']
    assert any(row['path'] == 'mixed.py' and row['name'] == 'removed'
               for row in evidence['symbols']), evidence['symbols']
    assert any(row['path'] == 'caller.py' and row['name'] == 'gone'
               for row in evidence['call_sites']), evidence['call_sites']
    assert any(row['path'] == 'caller.py' and row['name'] == 'removed'
               for row in evidence['call_sites']), evidence['call_sites']
    assert any(row['path'] == 'containers.py' and row['name'] == 'duplicate'
               and row['blob_tree'] == manifest['base_tree']
               and row['line'] == 2 and row['line_end'] == 3
               for row in evidence['symbols']), evidence['symbols']
    assert any(row['source'] == 'caller.py' and row['target'] == 'containers.py'
               and row['kind'] == 'local-import'
               for row in evidence['dependencies']), evidence['dependencies']
    assert not any(row['path'] == 'caller.py' and row['name'] == 'duplicate'
                   for row in evidence['call_sites']), evidence['call_sites']
    compute = [row for row in evidence['symbols']
               if row['path'] == 'signature.py' and row['name'] == 'compute']
    assert len(compute) == 1 and compute[0]['blob_tree'] == manifest['snapshot_tree'], compute
    old_parse = [row for row in evidence['symbols']
                 if row['path'] == 'overload.ts' and row['name'] == 'parse'
                 and row['blob_tree'] == manifest['base_tree']]
    assert len(old_parse) == 1 and old_parse[0]['line'] == 1, old_parse
    assert any(row['path'] == 'caller.ts' and row['name'] == 'parse'
               for row in evidence['call_sites']), evidence['call_sites']
    ranges = [row for packet in manifest['source_context']['seats'].values()
              for shard in packet['shards'] for row in shard['ranges']]
    ranges += [row for packet in manifest['source_context']['seats'].values()
               for row in packet['required_source_ranges']]
    assert any(row['path'] == 'mixed.py' and row['blob_tree'] == manifest['base_tree']
               and 'declaration:removed' in row['reasons'] for row in ranges), ranges
    assert any(row['path'] == 'caller.py' and row['blob_tree'] == manifest['snapshot_tree']
               and 'production-caller:removed' in row['reasons'] for row in ranges), ranges
    assert any(row['path'] == 'containers.py' and row['blob_tree'] == manifest['base_tree']
               and 'declaration:duplicate' in row['reasons'] for row in ranges), ranges
    assert not any(row['path'] == 'signature.py' and row['blob_tree'] == manifest['base_tree']
                   and 'declaration:compute' in row['reasons'] for row in ranges), ranges
PY
  assert_eq "deleted declarations retain surviving caller evidence" "$?" 0
}

test_generated_lexical_callers_do_not_become_source_obligations() {
  ( local R="$T/generated-caller-root" S="$T/generated-caller-session"
    mkrepo "$R"; mkdir -p "$R/src" "$S"
    python3 - "$R" <<'PY'
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
(root / 'src/main.py').write_text('def options(value):\n    return value + 1\n')
(root / 'src/consumer.py').write_text(
    'from src.main import options\n\ndef consume():\n    return options(1)\n')
(root / 'src/original.py').write_text(
    'from src.main import options\n\ndef consume_original():\n    return options(2)\n')
source_map = json.dumps({
    'version': 3, 'file': 'bundle.js', 'sources': ['../src/original.py'],
    'sourcesContent': ['options(2);\n' + 'x' * (20 * 1024)],
    'names': ['options'], 'mappings': '',
}, separators=(',', ':')) + '\n'
outputs = {
    '00-first.js.map': source_map,
    'zz-last.js.map': source_map,
    'dist/bundle.min.js': 'options(2);\n',
    'generated/bundle.js': 'options(2);\n',
    'emitted/bundle.js': '// @generated\noptions(2);\n',
}
for path, body in outputs.items():
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(body)
PY
    git -C "$R" add . && git -C "$R" commit -qm "generated caller base"
    local base manifest
    base=$(git -C "$R" rev-parse HEAD)
    printf 'def options(value):\n    return value + 2\n' > "$R/src/main.py"
    printf "REV_BASE='%s'\nREV_ROOT='%s'\nREV_SCOPE='branch'\n" "$base" "$R" > "$S/scope.env"
    : > "$S/files.txt"; : > "$S/untracked.txt"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"terra","adapter":"codex"},{"seat":"opus","adapter":"claude"},{"seat":"sonnet","adapter":"claude"}]}' > "$S/roster.json"
    manifest=$(REV_PATCH_CHUNKS=auto REV_SOURCE_CONTEXT=1 \
      python3 "$SCRIPTS/rev-evidence.py" prepare "$S" 1 --phase discovery) || return
    python3 - "$manifest" <<'PY'
import json
from pathlib import Path
import sys

path = Path(sys.argv[1])
manifest = json.loads(path.read_text())
rows = [row for packet in manifest['source_context']['seats'].values()
        for shard in packet['shards'] for row in shard['ranges']]
rows += [row for packet in manifest['source_context']['seats'].values()
         for row in packet['required_source_ranges']]
for caller in ('src/consumer.py', 'src/original.py'):
    assert any(row['path'] == caller and any(
        reason in ('production-caller:options', 'extra-caller:options')
        for reason in row['reasons']) for row in rows), (caller, rows)
generated = {'00-first.js.map', 'zz-last.js.map', 'dist/bundle.min.js',
             'generated/bundle.js', 'emitted/bundle.js'}
selected = [row for row in rows if row['path'] in generated]
assert not selected, ('unchanged generated lexical callers became source obligations', selected)
assert any(row['path'] in ('src/consumer.py', 'src/original.py')
           and 'production-caller:options' in row['reasons'] for row in rows), rows
PY
    assert_eq "generated lexical noise leaves authored caller proof selected" "$?" 0
  )
}

test_generated_declarations_and_changed_outputs_remain_reviewable() {
  ( local R="$T/generated-proof-root" S="$T/generated-proof-session" cargo_home="$T/generated-proof-cargo"
    mkrepo "$R"; mkdir -p "$R/src" "$R/generated" "$S"
    printf 'def options(value):\n    return value + 1\n' > "$R/src/main.py"
    printf '// @generated\nexport function options(value: number): number;\n' > "$R/generated/api.d.ts"
    printf '{"version":3,"sourcesContent":["options(1);"],"mappings":""}\n' > "$R/generated/bundle.js.map"
    cat > "$R/Cargo.lock" <<'EOF'
version = 3

[[package]]
name = "pinned"
version = "1.0.0"
source = "registry+https://github.com/rust-lang/crates.io-index"
checksum = "0000000000000000000000000000000000000000000000000000000000000000"
EOF
    local dependency="$cargo_home/registry/src/index.crates.io-0/pinned-1.0.0"
    mkdir -p "$dependency/src"
    printf '// @generated\npub fn options() {}\n' > "$dependency/src/lib.rs"
    git -C "$R" add . && git -C "$R" commit -qm "generated proof base"
    local base manifest
    base=$(git -C "$R" rev-parse HEAD)
    printf 'def options(value):\n    return value + 2\n' > "$R/src/main.py"
    printf '// @generated\nexport function options(value: number, strict: boolean): number;\n' > "$R/generated/api.d.ts"
    printf '{"version":3,"sourcesContent":["options(2);"],"mappings":""}\n' > "$R/generated/bundle.js.map"
    printf "REV_BASE='%s'\nREV_ROOT='%s'\nREV_SCOPE='branch'\n" "$base" "$R" > "$S/scope.env"
    : > "$S/files.txt"; : > "$S/untracked.txt"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"terra","adapter":"codex"},{"seat":"opus","adapter":"claude"},{"seat":"sonnet","adapter":"claude"}]}' > "$S/roster.json"
    manifest=$(env -u REV_DEPS_DIR CARGO_HOME="$cargo_home" REV_PATCH_CHUNKS=auto REV_SOURCE_CONTEXT=1 \
      python3 "$SCRIPTS/rev-evidence.py" prepare "$S" 1 --phase discovery) || return
    python3 - "$manifest" "$dependency" "$SCRIPTS/rev-prompt.sh" <<'PY'
import json
import os
from pathlib import Path
import subprocess
import sys

path = Path(sys.argv[1])
manifest = json.loads(path.read_text())
owner = manifest['mechanical_owner']
patch = Path(manifest['assignments'][owner]['patch']).read_text()
assert 'generated/api.d.ts' in patch and 'strict: boolean' in patch, patch
assert 'generated/bundle.js.map' in patch and 'options(2);' in patch, patch
rows = [row for packet in manifest['source_context']['seats'].values()
        for shard in packet['shards'] for row in shard['ranges']]
rows += [row for packet in manifest['source_context']['seats'].values()
         for row in packet['required_source_ranges']]
assert any(row['path'] == 'generated/api.d.ts' and 'declaration:options' in row['reasons']
           and row['blob_tree'] == manifest['snapshot_tree'] for row in rows), rows
view = manifest['dependency_view']
assert view['crates'] == ['pinned-1.0.0'], view
linked = Path(view['path']) / 'pinned-1.0.0/src/lib.rs'
assert linked.resolve() == Path(sys.argv[2]).resolve() / 'src/lib.rs'
assert linked.read_text() == '// @generated\npub fn options() {}\n'
env = dict(os.environ)
env.pop('REV_DEPS_DIR', None)
prompt_path = subprocess.check_output(
    [sys.argv[3], str(path.parent), '1', owner, manifest['assignments'][owner]['bundle'],
     'generated proof', '--evidence', str(path)], env=env, text=True).strip()
prompt = Path(prompt_path).read_text()
assert f'Read pinned dependency source only under {view["path"]}.' in prompt, prompt
PY
    assert_eq "generated declarations, changed output and explicit pinned dependencies stay reviewable" "$?" 0
  )
}

test_pr_scope_refuses_pinned_head_or_base_drift() {
  ( local R="$T/pr-head-drift-root" S="$T/pr-head-drift-session" base pinned other bin="$T/pr-live-bin" drift live_head live_base live_branch live_state live_base_branch
    mkrepo "$R"; mkdir -p "$S"; git -C "$R" checkout -qb feat
    printf 'reviewed change\n' > "$R/change.txt"
    git -C "$R" add change.txt && git -C "$R" commit -qm "reviewed head"
    base=$(git -C "$R" rev-parse main); pinned=$(git -C "$R" rev-parse HEAD)
    printf "REV_BASE='%s'\nREV_BRANCH='feat'\nREV_BASE_BRANCH='main'\nREV_ROOT='%s'\nREV_SCOPE='branch'\nREV_PR_NUMBER='71'\nREV_PR_REPO='acme/repo'\nREV_PR_HEAD='%s'\nREV_PR_BASE_HEAD='%s'\nREV_PR_BASE_REF='refs/heads/main'\n" \
      "$base" "$R" "$pinned" "$base" > "$S/scope.env"
    printf '%s\n' 'change.txt' > "$S/files.txt"; : > "$S/untracked.txt"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"terra","adapter":"codex"},{"seat":"opus","adapter":"claude"},{"seat":"sonnet","adapter":"claude"}]}' > "$S/roster.json"
    mkdir -p "$bin"
    cat > "$bin/gh" <<'SH'
#!/bin/sh
printf '%s\n' "$*" >> "$GH_PR_CALLS"
[ "$1" = pr ] && [ "$2" = view ] && [ "$3" = 71 ] \
  && [ "$4" = --repo ] && [ "$5" = acme/repo ] || exit 2
printf '{"number":71,"url":"https://github.com/acme/repo/pull/71","state":"%s","headRefName":"%s","headRefOid":"%s","baseRefName":"%s","baseRefOid":"%s"}\n' \
  "$GH_PR_STATE" "$GH_PR_BRANCH" "$GH_PR_HEAD" "$GH_PR_BASE_BRANCH" "$GH_PR_BASE"
SH
    chmod +x "$bin/gh"
    export PATH="$bin:$PATH" GH_PR_CALLS="$T/pr-live.calls"
    export GH_PR_STATE=OPEN GH_PR_BRANCH=feat GH_PR_HEAD="$pinned" GH_PR_BASE_BRANCH=main GH_PR_BASE="$base"
    env -u REV_DEPS_DIR python3 "$SCRIPTS/rev-evidence.py" prepare "$S" live-match --phase discovery \
      > "$T/pr-live-match.out" 2> "$T/pr-live-match.err"
    assert_eq "evidence preparation accepts an unchanged live PR identity" "$?" 0
    assert_grep "evidence preparation queries the pinned PR number and repository" \
      "$T/pr-live.calls" '^pr view 71 --repo acme/repo --json '
    for drift in state branch head base-branch base; do
      live_state=OPEN; live_branch=feat; live_head=$pinned; live_base_branch=main; live_base=$base
      case "$drift" in
        state) live_state=CLOSED;;
        branch) live_branch=other;;
        head) live_head=0000000000000000000000000000000000000009;;
        base-branch) live_base_branch=next;;
        base) live_base=$pinned;;
      esac
      GH_PR_STATE=$live_state GH_PR_BRANCH=$live_branch GH_PR_HEAD=$live_head \
        GH_PR_BASE_BRANCH=$live_base_branch GH_PR_BASE=$live_base \
        env -u REV_DEPS_DIR python3 "$SCRIPTS/rev-evidence.py" prepare "$S" "live-$drift" --phase discovery \
        > "$T/pr-live-$drift.out" 2> "$T/pr-live-$drift.err"
      assert_eq "evidence preparation refuses live PR $drift drift" "$?" 2
      assert_grep "live PR $drift drift names the frozen PR mismatch" \
        "$T/pr-live-$drift.err" 'live PR #71 identity no longer matches preflight scope'
      assert_exit "live PR $drift drift publishes no evidence" 0 \
        test ! -e "$S/rlive-$drift-evidence.manifest.json"
    done
    git -C "$R" checkout -qb unrelated
    printf 'unrelated source\n' > "$R/unrelated.txt"
    git -C "$R" add unrelated.txt && git -C "$R" commit -qm 'unrelated source'
    other=$(git -C "$R" rev-parse HEAD)
    git -C "$R" checkout -q feat
    env -u REV_DEPS_DIR python3 "$SCRIPTS/rev-evidence.py" prepare "$S" wrong-source \
      --phase discovery --head "$other" \
      > "$T/pr-wrong-source.out" 2> "$T/pr-wrong-source.err"
    assert_eq "evidence preparation refuses a source selector outside the pinned PR head" "$?" 2
    assert_grep "source selector refusal identifies the pinned PR" "$T/pr-wrong-source.err" \
      'explicit source selector conflicts with pinned PR #71 head'
    assert_exit "source selector refusal publishes no evidence" 0 \
      test ! -e "$S/rwrong-source-evidence.manifest.json"

    git -C "$R" checkout -q main
    printf 'base moved\n' > "$R/base-only.txt"
    git -C "$R" add base-only.txt && git -C "$R" commit -qm 'advance base'
    git -C "$R" checkout -q feat
    env -u REV_DEPS_DIR python3 "$SCRIPTS/rev-evidence.py" prepare "$S" base-drift --phase discovery \
      > "$T/pr-base-drift.out" 2> "$T/pr-base-drift.err"
    assert_eq "evidence preparation refuses a changed PR base" "$?" 2
    assert_grep "base drift refusal identifies the pinned PR" "$T/pr-base-drift.err" \
      'local base for pinned PR #71 no longer matches its recorded base head'
    assert_exit "base drift refusal publishes no evidence" 0 \
      test ! -e "$S/rbase-drift-evidence.manifest.json"
    git -C "$R" branch -f main "$base"
    printf 'stale checkout change\n' >> "$R/change.txt"
    git -C "$R" add change.txt && git -C "$R" commit -qm "later local head"
    env -u REV_DEPS_DIR python3 "$SCRIPTS/rev-evidence.py" prepare "$S" 1 --phase discovery \
      > "$T/pr-head-drift.out" 2> "$T/pr-head-drift.err"
    assert_eq "evidence preparation refuses a changed PR checkout" "$?" 2
    assert_grep "head drift refusal identifies the pinned PR" "$T/pr-head-drift.err" \
      'checked out HEAD does not match pinned PR #71 head'
    assert_exit "head drift refusal happens before publishing evidence" 0 \
      test ! -e "$S/r1-evidence.manifest.json"

    git -C "$R" reset --hard -q "$pinned"
    printf 'uncommitted post-preflight edit\n' >> "$R/change.txt"
    env -u REV_DEPS_DIR python3 "$SCRIPTS/rev-evidence.py" prepare "$S" dirty --phase discovery \
      > "$T/pr-dirty.out" 2> "$T/pr-dirty.err"
    assert_eq "evidence preparation refuses a dirty PR checkout" "$?" 2
    assert_grep "dirty checkout refusal identifies the pinned PR" "$T/pr-dirty.err" \
      'pinned PR #71 checkout has uncommitted changes'
    assert_exit "dirty checkout refusal publishes no evidence" 0 \
      test ! -e "$S/rdirty-evidence.manifest.json"

    python3 - "$SCRIPTS/rev-evidence.py" <<'PY'
import importlib.util
import sys

spec = importlib.util.spec_from_file_location('rev_evidence', sys.argv[1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
try:
    module.validate_pinned_pr_checkout({'REV_PR_BASE_REF': 'refs/heads/main'})
except ValueError as error:
    assert str(error) == 'invalid pinned PR identity', error
else:
    raise AssertionError('partial PR identity was accepted')
PY
    assert_eq "partial pinned PR metadata is rejected" "$?" 0
  )
}
