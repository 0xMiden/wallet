"""Timeout propagation/origin regressions; import the adjacent candidate, never its CLI."""
import importlib.util
import io
import json
from contextlib import redirect_stderr
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch


class PrepareTimeoutOriginTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = Path(__file__).resolve().parents[1] / 'scripts' / 'rev-evidence.py'
        spec = importlib.util.spec_from_file_location('timeout_origin_evidence', compiler)
        cls.evidence = importlib.util.module_from_spec(spec)
        with patch.object(sys, 'path', sys.path[:]):
            spec.loader.exec_module(cls.evidence)

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='prepare-timeout-origin-')
        self.addCleanup(temporary.cleanup)
        self.session = Path(temporary.name)
        self.manifest_path = self.session / 'r1-evidence.manifest.json'
        # Only the receipt-to-validator boundary is real; lineage is mocked, not certified.
        raw = json.dumps({'manifest': self.manifest_path.name}).encode()
        (self.session / 'r1-coverage.receipt.json').write_bytes(raw)
        (self.session / 'coverage-head.json').write_text(json.dumps({
            'receipt': 'r1-coverage.receipt.json', 'sha256': self.evidence.digest(raw),
        }))
        self.repo = Mock()

    def test_prior_coverage_propagates_same_prepare_timeout(self):
        timeout = self.evidence.PrepareTimeout('preparation timed out during prior-coverage')
        with patch.object(self.evidence, 'validate_receipt_lineage'), \
                patch.object(self.evidence, 'validated_manifest', side_effect=timeout) as validate:
            with self.assertRaises(self.evidence.PrepareTimeout) as raised:
                self.evidence.prior_coverage(self.session, self.repo, 'base-tree')
            self.assertIs(raised.exception, timeout)
            validate.assert_called_once_with(self.manifest_path, fresh=False, seen=None)

    def test_prior_coverage_value_error_remains_invalid(self):
        with patch.object(self.evidence, 'validate_receipt_lineage'), \
                patch.object(self.evidence, 'validated_manifest',
                             side_effect=ValueError('malformed predecessor')) as validate:
            result = self.evidence.prior_coverage(self.session, self.repo, 'base-tree')
            validate.assert_called_once_with(self.manifest_path, fresh=False, seen=None)
        self.assertEqual(result, {
            'status': 'invalid', 'coverage': None,
            'reason': 'invalid coverage predecessor: malformed predecessor',
        })

    def test_expired_prepare_stage_records_requested_stage(self):
        with patch.dict(self.evidence.PREPARE_PROGRESS, {
                'active': True, 'stage': 'prior-coverage', 'deadline': 10.0,
                'timed_out': False, 'refusals': None,
        }, clear=True), patch.object(self.evidence.time, 'monotonic', return_value=11.0), \
                redirect_stderr(io.StringIO()):
            with self.assertRaises(self.evidence.PrepareTimeout) as raised:
                self.evidence.prepare_stage('source-context')
            self.assertTrue(self.evidence.PREPARE_PROGRESS['timed_out'])
            self.assertEqual(self.evidence.PREPARE_PROGRESS['stage'], 'source-context')
            self.assertEqual(str(raised.exception),
                             'preparation timed out during source-context')


if __name__ == '__main__':
    unittest.main()
