#!/bin/bash
# Also runnable directly, without the suite harness.
test_evidence_contract() {
  python3 - "$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)/rev-evidence.py" <<'PY'
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

script = sys.argv[1]
spec = importlib.util.spec_from_file_location('evidence', script)
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
unknown_parent = {'seat': 'custom', 'adapter': 'codex', 'model': 'custom-model'}
unknown_child = {'seat': 'custom-next', 'adapter': 'claude', 'model': 'custom-model', 'extra': False}
try:
    module.validate_replacement_edge(unknown_parent, unknown_child)
except ValueError as error:
    assert str(error) == 'replacement executor must be on the default model chain', error
else:
    raise AssertionError('unknown root replacement executor was accepted')
module.validate_replacement_edge(
    unknown_parent,
    {'seat': 'opus', 'adapter': 'claude', 'model': 'opus', 'extra': False})
with tempfile.TemporaryDirectory(prefix='evidence-test-') as tmp:
    root = Path(tmp) / 'repo'; root.mkdir()
    session = Path(tmp) / 'session'; session.mkdir()
    def git(*args):
        return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.PIPE).decode().strip()
    def write(path, data):
        p = root / path; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(data)
    def run(*args, good=True):
        env = dict(os.environ, REV_PATCH_CHUNKS='auto', REV_SOURCE_CONTEXT='1')
        p = subprocess.run([sys.executable, script, *map(str, args)], capture_output=True, text=True, env=env)
        assert (p.returncode == 0) == good, (args, p.returncode, p.stdout, p.stderr)
        return p.stdout
    def prepare(label, phase='discovery', *extra):
        run('prepare', session, label, '--phase', phase, *extra)
        return json.loads((session / f'r{label}-evidence.manifest.json').read_text())
    def agent_audit(label, seat, manifest):
        assignment = manifest['assignments'][seat]
        packet = manifest['source_context']['seats'][seat]
        proof_keys = ('path', 'line_start', 'line_end', 'blob_tree', 'blob_oid', 'content_sha256')
        proofs = [{key: required[key] for key in proof_keys}
                  for required in packet['required_source_ranges']]
        repository = module.Repository(session.resolve())
        entries = repository.entries(manifest['snapshot_tree'])
        packet_ranges = [{'path': row['path'], 'line_start': row['line_start'],
                          'line_end': row['line_end'], 'origin': 'packet'}
                         for shard in packet['shards'] for row in shard['ranges']
                         if row['blob_tree'] == manifest['snapshot_tree']]
        tool_ranges = []
        source_calls = 0
        source_bytes = 0
        source_output_sizes = []
        for required in packet['required_source_ranges']:
            for segment in required['segments']:
                raw = (session / segment['artifact']).read_bytes()
                assert len(raw) == segment['raw_bytes']
                assert module.digest(raw) == segment['content_sha256']
                source_calls += 1; source_bytes += len(raw)
                source_output_sizes.append(len(raw))
                if required['blob_tree'] == manifest['snapshot_tree']:
                    tool_ranges.append({'path': required['path'], 'line_start': segment['line_start'],
                                        'line_end': segment['line_end'], 'origin': 'tool'})
        post_index_ranges = []
        if packet['source_read_required']:
            prompt = (session / f'r{label}-{seat}.prompt.md').read_text()
            match = re.search(r'^Required post-index original-source target: (.+):(\d+)-(\d+) '
                              r'tree (\w+) blob (\w+) content SHA-256 (\w+) reasons ', prompt, re.M)
            assert match, 'required current target must be rendered'
            path, start, end, tree, oid, content_hash = match.groups()
            start, end = int(start), int(end)
            assert tree == manifest['snapshot_tree'] and entries[path][1] == oid
            lines = module.split_lf_lines(repository.blob(entries[path]))
            assert 1 <= start <= end <= len(lines)
            assert module.digest(b''.join(lines[start - 1:end])) == content_hash
            for first in range(start, end + 1, 240):
                last = min(first + 239, end)
                post_index_ranges.append({'path': path, 'line_start': first,
                                          'line_end': last, 'origin': 'tool'})
                size = len(b''.join(lines[first - 1:last]))
                source_calls += 1; source_bytes += size; source_output_sizes.append(size)
        tool_ranges.extend(post_index_ranges)
        ranges = sorted({(row['path'], row['line_start'], row['line_end'], row['origin'])
                         for row in packet_ranges + tool_ranges})
        ranges = [{'path': path, 'line_start': start, 'line_end': end, 'origin': origin}
                  for path, start, end, origin in ranges]
        post_index_ranges = [row for row in ranges if row['origin'] == 'tool' and row in post_index_ranges]
        stream = session / f'r{label}-{seat}.stream.ndjson'; stream.write_text('{}\n')
        prompt = session / f'r{label}-{seat}.prompt.md'; result = session / f'r{label}-{seat}.json'
        patch = Path(assignment['patch']); patch_raw = patch.read_bytes(); patch_lines = len(patch_raw.splitlines())
        patch_mode = assignment['patch_read_mode']
        chunks = manifest['patch_sets'][assignment['patch_set']]['chunks'] if patch_mode == 'chunks' else []
        patch_ranges = [] if chunks else [{'line_start': start, 'line_end': min(start + 239, patch_lines)}
                                          for start in range(1, patch_lines + 1, 240)]
        patch_reads = 0 if not patch_raw else len(chunks) if chunks else max(1, len(patch_ranges))
        patch_output_sizes = ([chunk['bytes'] for chunk in chunks] if chunks else [
            len(b''.join(patch_raw.splitlines(keepends=True)[row['line_start'] - 1:row['line_end']]))
            for row in patch_ranges])
        calls = max(1, len(packet['shards']) + source_calls + patch_reads)
        packet_bytes = sum(shard['bytes'] for shard in packet['shards'])
        audit = {'schema_version':2, 'status':'valid', 'narrow':assignment['scope'] != 'full', 'adapter':'agent',
                 'prompt_sha256':hashlib.sha256(prompt.read_bytes()).hexdigest(),
                 'stream_sha256':hashlib.sha256(stream.read_bytes()).hexdigest(),
                 'result_sha256':hashlib.sha256(result.read_bytes()).hexdigest(),
                 'evidence_manifest_sha256':hashlib.sha256((session / f'r{label}-evidence.manifest.json').read_bytes()).hexdigest(),
                 'violations':[], 'tool_calls':calls, 'tool_turns':calls,
                 'tool_output_bytes':packet_bytes + source_bytes + len(patch_raw),
                 'max_tool_output_bytes':max([0] + [shard['bytes'] for shard in packet['shards']] + source_output_sizes + patch_output_sizes),
                 'recognized_tool_calls':calls, 'source_read_calls':source_calls,
                 'packet_shards':len(packet['shards']), 'packet_bytes':packet_bytes,
                 'packet_ranges':sum(len(shard['ranges']) for shard in packet['shards']),
                 'post_index_source_ranges':post_index_ranges,
                 'opened_source_ranges':sum(1 for row in ranges if row['origin'] == 'tool'),
                 'finding_citations':0, 'source_ranges':ranges,
                 'required_source_ranges_covered':len(packet['required_source_ranges']),
                 'required_source_range_proofs':proofs,
                 'assigned_patch_sha256':hashlib.sha256(patch_raw).hexdigest(),
                 'assigned_patch_bytes':len(patch_raw), 'assigned_patch_lines':patch_lines,
                 'assigned_patch_reads':patch_reads, 'assigned_patch_ranges':patch_ranges,
                 'patch_proof_mode':patch_mode, 'patch_proof_calls':patch_reads,
                 'patch_proof_turns':patch_reads, 'patch_proof_visible_bytes':len(patch_raw),
                 'expected_patch_chunks':len(chunks), 'opened_patch_chunks':len(chunks)}
        (session / f'r{label}-{seat}.read-audit.json').write_text(json.dumps(audit))
    def results(label):
        manifest_path = session / f'r{label}-evidence.manifest.json'; manifest = json.loads(manifest_path.read_text())
        for seat in manifest['assignments']:
            (session / f'r{label}-{seat}.prompt.md').write_text(run('render', manifest_path, seat))
            (session / f'r{label}-{seat}.json').write_text('{"summary":"checked","findings":[]}')
            (session / f'r{label}-{seat}.exit').write_text('0\n')
            agent_audit(label, seat, manifest)
    def fingerprint():
        return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in (root / '.git').rglob('*') if p.is_file()}
    git('init', '-q'); git('config', 'user.name', 'Test'); git('config', 'user.email', 'test@example.invalid')
    git('config', 'commit.gpgsign', 'false')
    write('main.py', 'def calculate():\n    return 1\n' + '\n' * 15 + 'def stable():\n    return 1\n')
    write('deleted.py', 'gone\n'); write('package-lock.json', '{}\n')
    write('replaced.txt', 'old file\n')
    write('test_main.py', 'from main import calculate\nassert calculate() == 1\n')
    write('package.json', '{"scripts":{"test":"pytest","lint":"ruff check ."}}\n')
    write('.gitattributes', '*.py filter=tripwire\n')
    git('add', '.'); git('commit', '-qm', 'base'); base = git('rev-parse', 'HEAD')
    git('config', 'filter.tripwire.clean', 'touch FILTER_RAN; cat')
    write('main.py', 'def calculate():\n    return 2\n' + '\n' * 15 + 'def stable():\n    return 2\n')
    (root / 'deleted.py').unlink()
    (root / 'replaced.txt').unlink(); write('replaced.txt/child.py', 'new child\n')
    for name in ['package-lock.json', 'generated/types.ts', '__snapshots__/one.snap', 'locales/fr.json',
                 'i18n/config.ts', 'build/app.ts', 'fixtures/input.json', 'golden/value.txt', 'vendor/code.c']:
        write(name, 'updated content\n')
    write('new.py', 'def fresh():\n    return calculate()\n')
    write('image.bin', 'opaque extension with text content\n')
    (root / 'shortcut').symlink_to('main.py')
    (session / 'scope.env').write_text(f"REV_BASE='{base}'\nREV_ROOT='{root}'\nREV_SCOPE='branch'\n")
    (session / 'files.txt').write_text('')
    (session / 'untracked.txt').write_text('')
    seats = ['sol', 'terra', 'opus', 'sonnet']
    bundles = ['correctness-boundaries', 'security-state-api', 'concurrency-resources-performance', 'tests-observability-maintenance-regression']
    (session / 'roster.json').write_text(json.dumps({'seats': [{'seat': s, 'extra': False, 'adapter': 'agent'} for s in seats]}))
    before = fingerprint(); first = prepare('1')
    assert fingerprint() == before, 'snapshot modified repository Git state'
    assert not (root / 'FILTER_RAN').exists(), 'clean filter ran'
    deleted_context = [row for packet in first['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']
                       if row['path'] == 'deleted.py']
    deleted_context += [row for packet in first['source_context']['seats'].values()
                        for row in packet['required_source_ranges'] if row['path'] == 'deleted.py']
    assert deleted_context and all(row['blob_tree'] == first['base_tree'] for row in deleted_context)
    assert first['mechanical_owner'] == 'sol'
    assert first['assignments']['sol']['scope'] == 'full'
    assert first['assignments']['terra']['scope'] == 'semantic'
    full = (session / 'r1-full.patch').read_text(); semantic = (session / 'r1-semantic.patch').read_text()
    for name in ['package-lock.json', 'generated/types.ts', '__snapshots__/one.snap', 'locales/fr.json']:
        assert name in full and name not in semantic, name
    for name in ['i18n/config.ts', 'build/app.ts', 'fixtures/input.json', 'golden/value.txt', 'vendor/code.c', 'image.bin', 'shortcut', 'deleted.py', 'new.py']:
        assert name in semantic, name
    facts = json.loads((session / 'r1-evidence.json').read_text())
    assert any(x['name'] == 'calculate' for x in facts['symbols'])
    assert any(x['path'] == 'test_main.py' for x in facts['call_sites'])
    assert {'path': 'test_main.py', 'line': 2, 'name': 'calculate', 'kind': 'lexical name( match, not resolved dispatch'} in facts['call_sites']
    assert any(x['path'] == 'test_main.py' for x in facts['related_tests'])
    assert {'path': 'package.json', 'line': 1, 'command': '{"scripts":{"test":"pytest","lint":"ruff check ."}}', 'kind': 'lexical gate candidate'} in facts['gates']
    assert run('render', session / 'r1-evidence.manifest.json', 'terra') == run('render', session / 'r1-evidence.manifest.json', 'terra')
    frozen = {p.name: p.read_bytes() for p in session.glob('r1-*')}; prepare('1')
    assert all((session / name).read_bytes() == data for name, data in frozen.items()), 'nondeterministic prepare'
    results('1'); run('receipt', session, '1')
    head = (session / 'coverage-head.json').read_bytes()
    args = [a for s, b in zip(seats, bundles) for a in ['--assignment', s + '=' + b]]
    nofix = prepare('2', 'verification', *args)
    assert nofix['assignments']['sonnet']['scope'] == 'full', nofix
    assert all(nofix['assignments'][seat]['scope'] == 'semantic' for seat in seats[:-1]), nofix
    assert nofix['fallback_reason'] is None and nofix['predecessor'] is None
    write('main.py', (root / 'main.py').read_text().replace('return 2', 'return 3', 1))
    run('render', session / 'r2-evidence.manifest.json', 'sol', good=False)
    larger = prepare('2b', 'verification', *args)
    assert larger['assignments']['sonnet']['scope'] == 'full', larger
    assert all(larger['assignments'][seat]['scope'] == 'semantic' for seat in seats[:-1]), larger
    assert larger['fallback_reason'] is None and larger['predecessor'] is None
    # Make the cumulative semantic patch much larger than the evidence packet.
    for i in range(8):
        write(f'src/unit{i}.py', f'def unit{i}():\n' + ''.join(f'    value_{j} = {j}\n' for j in range(400)))
    prepare('3'); results('3'); run('receipt', session, '3')
    oldfacts = json.loads((session / 'r3-evidence.json').read_text())
    write('main.py', (root / 'main.py').read_text().replace('return 3', 'return 4', 1))
    delta = prepare('4', 'verification', *args)
    assert delta['assignments']['sonnet']['scope'] == 'full'
    assert delta['assignments']['sol']['scope'] == 'delta', delta['fallback_reason']
    patch = (session / 'r4-delta.patch').read_text()
    assert '-    return 3' in patch and '+    return 4' in patch
    assert 'def stable' not in patch and 'src/unit' not in patch
    newfacts = json.loads((session / 'r4-evidence.json').read_text())
    oldhashes = [h['sha256'] for h in oldfacts['hunks'] if h['path'] == 'main.py']
    newhashes = [h['sha256'] for h in newfacts['hunks'] if h['path'] == 'main.py']
    assert len(set(oldhashes) & set(newhashes)) == 1, 'unchanged hunk lost identity'
    assert len(set(newhashes) - set(oldhashes)) == 1, 'changed hunk not isolated'
    results('4'); head = (session / 'coverage-head.json').read_bytes()
    for suffix, bad in [('exit', '1'), ('json', '{"summary":"missing findings"}'), ('prompt.md', 'wrong hash')]:
        p = session / ('r4-sol.' + suffix); saved = p.read_bytes(); p.write_text(bad)
        run('receipt', session, '4', good=False); assert (session / 'coverage-head.json').read_bytes() == head
        p.write_bytes(saved)
    run('receipt', session, '4'); receipt = (session / 'r4-coverage.receipt.json').read_bytes()
    run('receipt', session, '4'); assert (session / 'r4-coverage.receipt.json').read_bytes() == receipt
    write('main.py', (root / 'main.py').read_text() + '# later\n')
    run('receipt', session, '4', good=False)
    prepare('5', 'verification', *args); results('5')
    (session / 'r5-evidence.md').write_text('tampered')
    run('render', session / 'r5-evidence.manifest.json', 'sol', good=False)
    repair = prepare('6', 'repair', '--assignment', 'terra=security-state-api')
    assert list(repair['assignments']) == ['terra'] and repair['assignments']['terra']['scope'] == 'full'
    results('6'); run('receipt', session, '6', good=False)
    (session / 'coverage-head.json').write_text('{bad')
    missing = prepare('7', 'verification', *args)
    assert all(a['scope'] == 'full' for a in missing['assignments'].values())
    risk = prepare('8', 'risk')
    assert all(a['scope'] == 'full' for a in risk['assignments'].values()), 'ambiguous risk must widen'
    unknown = prepare('9', 'verification', '--head', 'unknown-reviewed-ref', *args)
    assert all(a['scope'] == 'full' for a in unknown['assignments'].values())
    assert unknown['fallback_reason']
    (session / 'coverage-head.json').unlink()
    seed = prepare('10', 'discovery', '--head', base)
    results('10'); run('receipt', session, '10')
    assert seed['snapshot_tree'] == git('rev-parse', base + '^{tree}')
    small = prepare('11', 'verification', *args)
    results('11'); run('receipt', session, '11')
    (root / 'image.bin').unlink(); (root / 'image.bin').symlink_to('main.py')
    unsafe = prepare('12', 'verification', *args)
    assert all(a['scope'] == 'full' for a in unsafe['assignments'].values()) and 'unsafe' in unsafe['fallback_reason']
    manifest_path = session / 'r12-evidence.manifest.json'
    saved_manifest = manifest_path.read_bytes()
    for key, value in [('patch', '/tmp/other.patch'), ('full_state', False)]:
        corrupt = json.loads(saved_manifest)
        corrupt['assignments']['sonnet'][key] = value
        manifest_path.write_text(json.dumps(corrupt))
        run('render', manifest_path, 'sonnet', good=False)
    manifest_path.write_bytes(saved_manifest)
    write('nested/item.py', 'original\n')
    git('-c', 'filter.tripwire.clean=cat', 'add', 'nested/item.py')
    git('commit', '-qm', 'nested file')
    external = Path(tmp) / 'external'; external.mkdir()
    (external / 'item.py').write_text('OUTSIDE_CONTENT_MUST_NOT_BE_READ\n')
    (root / 'nested/item.py').unlink(); (root / 'nested').rmdir()
    (root / 'nested').symlink_to(external, target_is_directory=True)
    prepare('12a')
    assert 'OUTSIDE_CONTENT_MUST_NOT_BE_READ' not in (session / 'r12a-full.patch').read_text()
    (root / 'main.py').unlink(); os.mkfifo(root / 'main.py')
    run('prepare', session, '12b', '--phase', 'discovery', good=False)
    assert not list(session.glob('r12b-*'))
    (session / 'scope.env').write_text(f"REV_BASE='{base}'\nREV_ROOT='{root}'\nREV_SCOPE='branch'\nREV_EVIL=$(touch UNWANTED)\n")
    run('prepare', session, '13', '--phase', 'discovery', good=False)
    assert not (root / 'UNWANTED').exists()
    print('PASS evidence snapshots, routing, deterministic facts, hunk identity, delta, freshness, receipts and fallback')
PY
  local rc=$?
  if declare -F ok >/dev/null && declare -F fail >/dev/null; then
    if [ "$rc" -eq 0 ]; then ok "evidence state machine contract"; else fail "evidence state machine contract" "exit $rc"; fi
  fi
  return "$rc"
}

test_prepare_and_input_install_are_serialized() {
  python3 - "$SCRIPTS/rev-evidence.py" "$T/evidence-input-lock" <<'PY'
import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import importlib.util
import json
import multiprocessing
import os
from pathlib import Path
import subprocess
import sys
import time

evidence_path = Path(sys.argv[1])
base = Path(sys.argv[2])
lib_dir = evidence_path.parent / 'lib'
sys.path.insert(0, str(lib_dir))
import session_inputs

spec = importlib.util.spec_from_file_location('rev_evidence_input_lock_test', evidence_path)
evidence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evidence)
standard_inputs = session_inputs.STANDARD_INPUTS
context = multiprocessing.get_context('fork')


def wait_for(*paths):
    deadline = time.monotonic() + 10
    while time.monotonic() < deadline:
        for path in paths:
            if path.exists():
                return path
        time.sleep(0.01)
    raise AssertionError('synchronization marker was not published: ' + ', '.join(map(str, paths)))


def join(process):
    process.join(10)
    if process.is_alive():
        process.terminate()
        process.join()
        raise AssertionError('worker did not exit')


def write_status(path, error=None):
    path.write_text('ok' if error is None else 'error:' + type(error).__name__ + ':' + str(error))


def observed_lock(session, blocked, acquired):
    @contextmanager
    def lock(_session):
        descriptor = os.open(Path(session) / '.session-inputs.lock', os.O_RDWR | os.O_CREAT, 0o600)
        try:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                blocked.touch()
                fcntl.flock(descriptor, fcntl.LOCK_EX)
            else:
                acquired.touch()
            yield Path(session) / '.session-inputs.lock'
        finally:
            os.close(descriptor)
    return lock


def prepare_args(session, label):
    return argparse.Namespace(
        session=str(session), label=label, phase='discovery', head=None, assignment=[],
        full_seat=None, plan=None, plan_sha256=None, parent_assignment=None)


def install_while_holding(session, staging, locked, release, status):
    original = session_inputs.assert_unsealed
    def pause(path):
        locked.touch()
        wait_for(release)
        return original(path)
    session_inputs.assert_unsealed = pause
    try:
        values = session_inputs.validate_standard_inputs(staging, require_all=True)
        session_inputs.install_inputs(session, values, complete=True)
    except Exception as error:
        write_status(status, error)
    else:
        write_status(status)


def prepare_with_observed_lock(session, label, blocked, acquired, status):
    evidence.session_input_lock = observed_lock(session, blocked, acquired)
    try:
        evidence.prepare(prepare_args(session, label))
    except Exception as error:
        write_status(status, error)
    else:
        write_status(status)


def prepare_at_manifest_publication(session, label, boundary, release, status):
    original = evidence.publish
    manifest_name = f'r{label}-evidence.manifest.json'
    def pause(path, data):
        if Path(path).name == manifest_name:
            boundary.touch()
            wait_for(release)
        return original(path, data)
    evidence.publish = pause
    try:
        evidence.prepare(prepare_args(session, label))
    except Exception as error:
        write_status(status, error)
    else:
        write_status(status)


def install_with_observed_lock(session, roster, blocked, acquired, status):
    session_inputs.session_input_lock = observed_lock(session, blocked, acquired)
    try:
        session_inputs.install_inputs(
            session, {'roster.json': roster.read_bytes()}, complete=False)
    except Exception as error:
        write_status(status, error)
    else:
        write_status(status)


def make_repository(path):
    path.mkdir(parents=True)
    subprocess.run(['git', '-C', str(path), 'init', '-q'], check=True)
    subprocess.run(['git', '-C', str(path), 'config', 'user.name', 'Test'], check=True)
    subprocess.run(['git', '-C', str(path), 'config', 'user.email', 'test@example.invalid'], check=True)
    subprocess.run(['git', '-C', str(path), 'config', 'commit.gpgsign', 'false'], check=True)
    subprocess.run(['git', '-C', str(path), 'config', 'core.hooksPath', '/dev/null'], check=True)
    (path / 'a.txt').write_text('old\n')
    subprocess.run(['git', '-C', str(path), 'add', 'a.txt'], check=True)
    subprocess.run(['git', '-C', str(path), 'commit', '-qm', 'base'], check=True)
    base_ref = subprocess.check_output(['git', '-C', str(path), 'rev-parse', 'HEAD'], text=True).strip()
    (path / 'a.txt').write_text('changed\n')
    return base_ref


def input_generation(root, base_ref, generation):
    return {
        'scope.env': (f"REV_BASE='{base_ref}'\nREV_ROOT='{root}'\nREV_SCOPE='branch'\n"
                      f'# {generation}\n').encode(),
        'roster.json': json.dumps({'generation': generation, 'seats': [
            {'seat': 'sol', 'adapter': 'codex'},
            {'seat': 'terra', 'adapter': 'codex'},
            {'seat': 'opus', 'adapter': 'claude'},
            {'seat': 'sonnet', 'adapter': 'claude'},
        ]}, separators=(',', ':')).encode(),
        'files.txt': b'a.txt\n' if generation == 'old' else b'a.txt\n\n',
        'untracked.txt': b'' if generation == 'old' else b'\n',
    }


def write_generation(path, values):
    path.mkdir(parents=True)
    for name, value in values.items():
        (path / name).write_bytes(value)


def manifest_hashes(session, label):
    return json.loads((session / f'r{label}-evidence.manifest.json').read_text())['inputs']


base.mkdir(parents=True)
root = base / 'repo'
base_ref = make_repository(root)
old = input_generation(root, base_ref, 'old')
new = input_generation(root, base_ref, 'new')

install_first = base / 'install-first'
staging = base / 'new-inputs'
install_first.mkdir()
write_generation(staging, new)
install_locked = base / 'install-first.locked'
install_release = base / 'install-first.release'
install_status = base / 'install-first.status'
prepare_blocked = base / 'install-first.prepare-blocked'
prepare_acquired = base / 'install-first.prepare-acquired'
prepare_status = base / 'install-first.prepare-status'
installer = context.Process(target=install_while_holding, args=(
    install_first, staging, install_locked, install_release, install_status))
preparer = context.Process(target=prepare_with_observed_lock, args=(
    install_first, 'install-first', prepare_blocked, prepare_acquired, prepare_status))
try:
    installer.start()
    wait_for(install_locked)
    preparer.start()
    wait_for(prepare_blocked, prepare_status)
finally:
    install_release.touch()
join(installer)
join(preparer)
assert install_status.read_text() == 'ok', install_status.read_text()
assert prepare_status.read_text() == 'ok', prepare_status.read_text()
assert prepare_blocked.exists() and not prepare_acquired.exists()
assert manifest_hashes(install_first, 'install-first') == {
    name: hashlib.sha256(value).hexdigest() for name, value in new.items()}

prepare_first = base / 'prepare-first'
replacement = base / 'replacement-roster.json'
write_generation(prepare_first, old)
replacement.write_bytes(new['roster.json'])
publication_boundary = base / 'prepare-first.publication-boundary'
prepare_release = base / 'prepare-first.release'
prepare_status = base / 'prepare-first.prepare-status'
install_blocked = base / 'prepare-first.install-blocked'
install_acquired = base / 'prepare-first.install-acquired'
install_status = base / 'prepare-first.install-status'
preparer = context.Process(target=prepare_at_manifest_publication, args=(
    prepare_first, 'prepare-first', publication_boundary, prepare_release, prepare_status))
installer = context.Process(target=install_with_observed_lock, args=(
    prepare_first, replacement, install_blocked, install_acquired, install_status))
try:
    preparer.start()
    wait_for(publication_boundary)
    assert not (prepare_first / 'rprepare-first-evidence.manifest.json').exists()
    installer.start()
    wait_for(install_blocked, install_status)
finally:
    prepare_release.touch()
join(preparer)
join(installer)
assert prepare_status.read_text() == 'ok', prepare_status.read_text()
assert install_status.read_text().startswith('error:SessionInputsSealedError:'), install_status.read_text()
assert install_blocked.exists() and not install_acquired.exists()
assert {name: (prepare_first / name).read_bytes() for name in standard_inputs} == old
assert manifest_hashes(prepare_first, 'prepare-first') == {
    name: hashlib.sha256(value).hexdigest() for name, value in old.items()}
PY
  local rc=$?
  if [ "$rc" -eq 0 ]; then
    ok "evidence preparation and input installation are serialized"
  else
    fail "evidence preparation and input installation are serialized" "exit $rc"
  fi
  return "$rc"
}

test_malformed_manifest_seals_inputs() {
  ( local B="$T/evidence-malformed-seal" S G name
    S="$B/session"; G="$B/generation"
    mkdir -p "$S" "$G"
    for name in scope.env roster.json files.txt untracked.txt; do
      printf 'new-%s' "$name" > "$G/$name"
    done
    printf '{' > "$S/rbroken-evidence.manifest.json"
    python3 "$SCRIPTS/lib/session_inputs.py" install "$S" "$G" > "$B/out" 2> "$B/err"
    assert_eq "malformed evidence manifest seals session inputs" "$?" 1
    assert_grep "malformed seal refusal names the evidence seal" "$B/err" \
      'sealed by rbroken-evidence\.manifest\.json'
    for name in scope.env roster.json files.txt untracked.txt; do
      assert_exit "malformed seal publishes no $name" 1 test -e "$S/$name"
    done
  )
}

test_session_input_install_recovers_partial_generation() {
  python3 - "$SCRIPTS/lib/session_inputs.py" "$T/session-input-retry" <<'PY'
import importlib.util
from pathlib import Path
import sys

module_path = Path(sys.argv[1])
base = Path(sys.argv[2])
spec = importlib.util.spec_from_file_location('session_input_retry_test', module_path)
session_inputs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(session_inputs)
values = {name: f'value:{name}\n'.encode() for name in session_inputs.STANDARD_INPUTS}

for fail_after in range(1, len(session_inputs.STANDARD_INPUTS)):
    session = base / str(fail_after)
    session.mkdir(parents=True)
    original_replace = session_inputs.os.replace
    replacements = 0
    def interrupted_replace(source, target):
        global replacements
        if replacements == fail_after:
            raise OSError('injected replacement failure')
        original_replace(source, target)
        replacements += 1
    session_inputs.os.replace = interrupted_replace
    try:
        try:
            session_inputs.install_inputs(session, values, complete=True)
        except session_inputs.SessionInputsError:
            pass
        else:
            raise AssertionError('injected replacement failure did not fail installation')
    finally:
        session_inputs.os.replace = original_replace
    assert sum((session / name).exists() for name in values) == fail_after
    session_inputs.install_inputs(session, values, complete=True)
    assert {name: (session / name).read_bytes() for name in values} == values
    session_inputs.install_inputs(session, values, complete=True)

conflict = base / 'conflict'
conflict.mkdir(parents=True)
(conflict / 'scope.env').write_bytes(b'other generation\n')
try:
    session_inputs.install_inputs(conflict, values, complete=True)
except session_inputs.SessionInputsError:
    pass
else:
    raise AssertionError('conflicting partial generation was accepted')
assert (conflict / 'scope.env').read_bytes() == b'other generation\n'
PY
  local rc=$?
  if [ "$rc" -eq 0 ]; then
    ok "partial session-input generations are retry-safe"
  else
    fail "partial session-input generations are retry-safe" "exit $rc"
  fi
  return "$rc"
}

test_evidence_source_identity_match() {
  ( local R="$T/source-identity-repo" P="$T/source-identity-parent"
    mkrepo "$R"; git -C "$R" checkout -qb feat
    printf 'tracked-one\n' > "$R/a.txt"
    printf 'staged-one\n' > "$R/staged.txt"; git -C "$R" add staged.txt
    printf 'untracked-one\n' > "$R/untracked.txt"
    local base; base=$(git -C "$R" rev-parse main)
    make_session() {
      local S=$1; mkdir -p "$S"
      printf "REV_BASE='%s'\nREV_BRANCH='feat'\nREV_DEFAULT='main'\nREV_ROOT='%s'\nREV_SCOPE='branch'\n" \
        "$base" "$R" > "$S/scope.env"
      printf 'a.txt\nstaged.txt\nuntracked.txt\n' > "$S/files.txt"
      printf 'untracked.txt\n' > "$S/untracked.txt"
      printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"terra","adapter":"codex"},{"seat":"opus","adapter":"claude"},{"seat":"sonnet","adapter":"claude"}]}' > "$S/roster.json"
    }
    prepare_identity() {
      local S=$1 label=$2; make_session "$S"
      REV_SOURCE_CONTEXT=0 REV_PATCH_CHUNKS=0 \
        python3 "$SCRIPTS/rev-evidence.py" prepare "$S" "$label" --phase verification >/dev/null || return
    }
    prepare_identity "$P" parent

    local C="$T/source-identity-same"; prepare_identity "$C" same
    python3 "$SCRIPTS/rev-evidence.py" same-source \
      "$P/rparent-evidence.manifest.json" "$C/rsame-evidence.manifest.json" >/dev/null
    assert_eq "byte-identical scope snapshots match across sessions" "$?" 0

    cp "$P/rparent-evidence.manifest.json" "$C/malformed-parent.manifest.json"
    cp "$C/rsame-evidence.manifest.json" "$C/malformed-candidate.manifest.json"
    python3 - "$C/malformed-parent.manifest.json" "$C/malformed-candidate.manifest.json" <<'PY'
import json, sys
for path in sys.argv[1:]:
    value = json.load(open(path))
    value['snapshot_tree'] = 'not-a-tree'
    open(path, 'w').write(json.dumps(value))
PY
    python3 "$SCRIPTS/rev-evidence.py" same-source \
      "$C/malformed-parent.manifest.json" "$C/malformed-candidate.manifest.json" \
      > /dev/null 2> "$C/malformed.err"
    assert_eq "malformed fallback source identity fails closed" "$?" 2
    assert_grep "malformed fallback names manifest validation" "$C/malformed.err" \
      'invalid source identity manifest'

    cp "$P/rparent-evidence.manifest.json" "$C/missing-parent.manifest.json"
    cp "$C/rsame-evidence.manifest.json" "$C/missing-candidate.manifest.json"
    python3 - "$C/missing-parent.manifest.json" "$C/missing-candidate.manifest.json" <<'PY'
import json, sys
for path in sys.argv[1:]:
    value = json.load(open(path)); value.pop('source')
    open(path, 'w').write(json.dumps(value))
PY
    python3 "$SCRIPTS/rev-evidence.py" same-source \
      "$C/missing-parent.manifest.json" "$C/missing-candidate.manifest.json" \
      > /dev/null 2> "$C/missing.err"
    assert_eq "matching missing source identities fail closed" "$?" 2
    assert_grep "missing source identity names manifest validation" "$C/missing.err" \
      'invalid source identity manifest'

    printf 'tracked-two\n' > "$R/a.txt"
    C="$T/source-identity-tracked"; prepare_identity "$C" tracked
    python3 "$SCRIPTS/rev-evidence.py" same-source \
      "$P/rparent-evidence.manifest.json" "$C/rtracked-evidence.manifest.json" \
      >/dev/null 2> "$C/changed.err"
    assert_eq "same-path tracked content mutation changes source identity" "$?" 2
    assert_grep "tracked mutation names the changed tree" "$C/changed.err" \
      'source identity changed: snapshot_tree'
    printf 'tracked-one\n' > "$R/a.txt"

    printf 'staged-two\n' > "$R/staged.txt"; git -C "$R" add staged.txt
    C="$T/source-identity-staged"; prepare_identity "$C" staged
    python3 "$SCRIPTS/rev-evidence.py" same-source \
      "$P/rparent-evidence.manifest.json" "$C/rstaged-evidence.manifest.json" \
      >/dev/null 2> "$C/changed.err"
    assert_eq "same-path staged content mutation changes source identity" "$?" 2
    assert_grep "staged mutation names the changed tree" "$C/changed.err" \
      'source identity changed: snapshot_tree'
    printf 'staged-one\n' > "$R/staged.txt"; git -C "$R" add staged.txt

    printf 'untracked-two\n' > "$R/untracked.txt"
    C="$T/source-identity-untracked"; prepare_identity "$C" untracked
    python3 "$SCRIPTS/rev-evidence.py" same-source \
      "$P/rparent-evidence.manifest.json" "$C/runtracked-evidence.manifest.json" \
      >/dev/null 2> "$C/changed.err"
    assert_eq "same-path untracked content mutation changes source identity" "$?" 2
    assert_grep "untracked mutation names the changed tree" "$C/changed.err" \
      'source identity changed: snapshot_tree'
  )
}

test_evidence_provider_contract_binding() {
  ( local R="$T/evidence-contract-root" S="$T/evidence-contract-session"
    mkrepo "$R"; mkdir -p "$R/plugins/review-council/.codex-plugin" \
      "$R/plugins/review-council/scripts" "$R/src" "$S"
    printf '{}\n' > "$R/plugins/review-council/.codex-plugin/plugin.json"
    printf 'provider boundary v1\n' > "$R/plugins/review-council/scripts/rev-prompt.sh"
    printf 'value = 1\n' > "$R/src/value.py"
    git -C "$R" add . && git -C "$R" commit -qm 'evidence contract base'
    local base; base=$(git -C "$R" rev-parse HEAD)
    printf 'value = 2\n' > "$R/src/value.py"
    printf "REV_BASE='%s'\nREV_BRANCH='feature'\nREV_DEFAULT='main'\nREV_ROOT='%s'\nREV_SCOPE='branch'\n" \
      "$base" "$R" > "$S/scope.env"
    printf 'src/value.py\n' > "$S/files.txt"; : > "$S/untracked.txt"
    cat > "$S/roster.json" <<'JSON'
{"seats":[
 {"seat":"sol","adapter":"codex","model":"gpt-5.6-sol","effort":"max","extra":false},
 {"seat":"terra","adapter":"codex","model":"gpt-5.6-terra","effort":"max","extra":false},
 {"seat":"opus","adapter":"claude","model":"opus","effort":"max","extra":false},
 {"seat":"sonnet","adapter":"claude","model":"sonnet","effort":"max","extra":false}]}
JSON
    local runner="$T/evidence-contract-runner" calls="$T/evidence-contract.calls"
    cat > "$runner" <<'SH'
#!/bin/bash
printf '%s\n' "$1" >> "$CONTRACT_CALLS"
SH
    chmod +x "$runner"; : > "$calls"
    local -a contract_env=(env REVIEW_COUNCIL_CONTRACT_RUNNER="$runner" CONTRACT_CALLS="$calls"
      'REVIEW_COUNCIL_CONTRACT_PROVIDER_VERSIONS={"claude":"1","codex":"1"}'
      REVIEW_COUNCIL_CACHE_DIR="$T/evidence-contract-cache")

    local no_boundary
    no_boundary=$("${contract_env[@]}" REV_SOURCE_CONTEXT=0 python3 "$SCRIPTS/rev-evidence.py" \
      prepare "$S" no-boundary --phase discovery) || return
    python3 - "$no_boundary" <<'PY'
import json, sys
manifest = json.load(open(sys.argv[1]))
assert set(manifest['inputs']) == {'scope.env','roster.json','files.txt','untracked.txt'}
PY
    assert_eq "repository without a changed boundary needs no contract receipt" "$?" 0

    printf 'provider boundary v2\n' > "$R/plugins/review-council/scripts/rev-prompt.sh"
    printf '%s\n' src/value.py plugins/review-council/scripts/rev-prompt.sh > "$S/files.txt"
    local receipt manifest receipt_name
    receipt=$("${contract_env[@]}" python3 "$SCRIPTS/rev-contract-check.py" \
      --root "$R" --session "$S" --base "$base" --roster "$S/roster.json") || return
    manifest=$("${contract_env[@]}" REV_SOURCE_CONTEXT=0 python3 "$SCRIPTS/rev-evidence.py" \
      prepare "$S" boundary --phase discovery) || return
    receipt_name=$(basename "$receipt")
    python3 - "$manifest" "$receipt_name" <<'PY'
import hashlib, json, pathlib, sys
manifest_path = pathlib.Path(sys.argv[1]); receipt_name = sys.argv[2]
manifest = json.loads(manifest_path.read_text())
assert set(manifest['inputs']) == {
    'scope.env','roster.json','files.txt','untracked.txt',receipt_name}
receipt = manifest_path.parent / receipt_name
assert manifest['inputs'][receipt_name] == hashlib.sha256(receipt.read_bytes()).hexdigest()
assert receipt_name == 'contract-pass-' + json.loads(receipt.read_text())['key'] + '.json'
PY
    assert_eq "boundary evidence binds the exact receipt name hash and key" "$?" 0

    rm "$receipt"
    assert_exit "fresh validation rejects a deleted bound receipt" 2 \
      "${contract_env[@]}" python3 "$SCRIPTS/rev-evidence.py" verify "$manifest"
    receipt=$("${contract_env[@]}" python3 "$SCRIPTS/rev-contract-check.py" \
      --root "$R" --session "$S" --base "$base" --roster "$S/roster.json") || return
    local saved; saved=$(cat "$receipt"); printf '{}\n' > "$receipt"
    assert_exit "fresh validation rejects a corrupt bound receipt" 2 \
      "${contract_env[@]}" python3 "$SCRIPTS/rev-evidence.py" verify "$manifest"
    printf '%s\n' "$saved" > "$receipt"
    assert_exit "restored exact receipt recovers fresh validation" 0 \
      "${contract_env[@]}" python3 "$SCRIPTS/rev-evidence.py" verify "$manifest"

    assert_exit "fresh validation rejects a provider version mismatch" 2 env \
      REVIEW_COUNCIL_CONTRACT_RUNNER="$runner" CONTRACT_CALLS="$calls" \
      'REVIEW_COUNCIL_CONTRACT_PROVIDER_VERSIONS={"claude":"2","codex":"1"}' \
      REVIEW_COUNCIL_CACHE_DIR="$T/evidence-contract-cache" \
      python3 "$SCRIPTS/rev-evidence.py" verify "$manifest"
    cp "$S/roster.json" "$S/roster.saved.json"
    sed 's/"model":"sonnet"/"model":"opus"/' "$S/roster.saved.json" > "$S/roster.json"
    assert_exit "fresh validation rejects a core roster mismatch" 2 \
      "${contract_env[@]}" python3 "$SCRIPTS/rev-evidence.py" verify "$manifest"
    mv "$S/roster.saved.json" "$S/roster.json"

    printf 'provider boundary v3\n' > "$R/plugins/review-council/scripts/rev-prompt.sh"
    assert_exit "offline validation remains independent of live boundary state" 0 \
      "${contract_env[@]}" python3 "$SCRIPTS/rev-evidence.py" render "$manifest" sol --offline
    "${contract_env[@]}" python3 "$SCRIPTS/rev-evidence.py" verify "$manifest" \
      > "$T/evidence-contract.out" 2> "$T/evidence-contract.err"
    assert_eq "fresh validation rejects a boundary mutation" "$?" 2
    assert_grep "boundary mutation reports a missing matching contract receipt" "$T/evidence-contract.err" \
      'matching provider contract receipt is missing'
    receipt=$("${contract_env[@]}" python3 "$SCRIPTS/rev-contract-check.py" \
      --root "$R" --session "$S" --base "$base" --roster "$S/roster.json") || return
    manifest=$("${contract_env[@]}" REV_SOURCE_CONTEXT=0 python3 "$SCRIPTS/rev-evidence.py" \
      prepare "$S" recovered --phase discovery) || return
    assert_exit "rerun receipt recovers preparation and fresh validation" 0 \
      "${contract_env[@]}" python3 "$SCRIPTS/rev-evidence.py" verify "$manifest"
    assert_eq "foreign target mutation reruns the trusted contract tests" \
      "$(wc -l < "$calls" | tr -d ' ')" 8
  )
}

evidence_hardening() {
  python3 - "$(cd "$(dirname "${BASH_SOURCE[0]}")/../scripts" && pwd)/rev-evidence.py" <<'PY'
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

script = Path(sys.argv[1]); spec = importlib.util.spec_from_file_location('evidence', script)
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
seats = ['sol', 'terra', 'opus', 'sonnet']
bundles = ['correctness-boundaries', 'security-state-api', 'concurrency-resources-performance', 'tests-observability-maintenance-regression']
assign = [a for s, b in zip(seats, bundles) for a in ('--assignment', s + '=' + b)]

def write_agent_audit(session, label, seat):
    manifest_path = session / f'r{label}-evidence.manifest.json'; manifest = json.loads(manifest_path.read_text())
    assignment = manifest['assignments'][seat]
    packet = manifest['source_context']['seats'][seat]
    proof_keys = ('path', 'line_start', 'line_end', 'blob_tree', 'blob_oid', 'content_sha256')
    proofs = [{key: required[key] for key in proof_keys}
              for required in packet['required_source_ranges']]
    repository = module.Repository(session.resolve())
    entries = repository.entries(manifest['snapshot_tree'])
    packet_ranges = [{'path': row['path'], 'line_start': row['line_start'],
                      'line_end': row['line_end'], 'origin': 'packet'}
                     for shard in packet['shards'] for row in shard['ranges']
                     if row['blob_tree'] == manifest['snapshot_tree']]
    tool_ranges = []
    source_calls = 0
    source_bytes = 0
    source_output_sizes = []
    for required in packet['required_source_ranges']:
        for segment in required['segments']:
            raw = (session / segment['artifact']).read_bytes()
            assert len(raw) == segment['raw_bytes']
            assert module.digest(raw) == segment['content_sha256']
            source_calls += 1; source_bytes += len(raw)
            source_output_sizes.append(len(raw))
            if required['blob_tree'] == manifest['snapshot_tree']:
                tool_ranges.append({'path': required['path'], 'line_start': segment['line_start'],
                                    'line_end': segment['line_end'], 'origin': 'tool'})
    post_index_ranges = []
    if packet['source_read_required']:
        prompt = (session / f'r{label}-{seat}.prompt.md').read_text()
        match = re.search(r'^Required post-index original-source target: (.+):(\d+)-(\d+) '
                          r'tree (\w+) blob (\w+) content SHA-256 (\w+) reasons ', prompt, re.M)
        assert match, 'required current target must be rendered'
        path, start, end, tree, oid, content_hash = match.groups()
        start, end = int(start), int(end)
        assert tree == manifest['snapshot_tree'] and entries[path][1] == oid
        lines = module.split_lf_lines(repository.blob(entries[path]))
        assert 1 <= start <= end <= len(lines)
        assert module.digest(b''.join(lines[start - 1:end])) == content_hash
        for first in range(start, end + 1, 240):
            last = min(first + 239, end)
            post_index_ranges.append({'path': path, 'line_start': first,
                                      'line_end': last, 'origin': 'tool'})
            size = len(b''.join(lines[first - 1:last]))
            source_calls += 1; source_bytes += size; source_output_sizes.append(size)
    tool_ranges.extend(post_index_ranges)
    findings = json.loads((session / f'r{label}-{seat}.json').read_text())['findings']
    missing = [finding for finding in findings if not any(
        row['path'] == finding['file'] and row['line_start'] <= finding['line_end']
        and finding['line_start'] <= row['line_end'] for row in packet_ranges + tool_ranges)]
    for finding in missing:
        assert finding['file'] in entries, 'historical-only findings cannot earn current citation proof'
        lines = module.split_lf_lines(repository.blob(entries[finding['file']]))
        assert 1 <= finding['line_start'] <= finding['line_end'] <= len(lines)
        for first in range(finding['line_start'], finding['line_end'] + 1, 240):
            last = min(first + 239, finding['line_end'])
            row = {'path': finding['file'], 'line_start': first, 'line_end': last, 'origin': 'tool'}
            tool_ranges.append(row); post_index_ranges.append(row)
            size = len(b''.join(lines[first - 1:last]))
            source_calls += 1; source_bytes += size; source_output_sizes.append(size)
    ranges = sorted({(row['path'], row['line_start'], row['line_end'], row['origin'])
                     for row in packet_ranges + tool_ranges})
    ranges = [{'path': path, 'line_start': start, 'line_end': end, 'origin': origin}
              for path, start, end, origin in ranges]
    post_index_ranges = [row for row in ranges if row['origin'] == 'tool' and row in post_index_ranges]
    stream = session / f'r{label}-{seat}.stream.ndjson'; stream.write_text('{}\n')
    prompt = session / f'r{label}-{seat}.prompt.md'; result = session / f'r{label}-{seat}.json'
    packet_bytes = sum(shard['bytes'] for shard in packet['shards'])
    patch = Path(assignment['patch']); patch_raw = patch.read_bytes(); patch_lines = len(patch_raw.splitlines())
    patch_mode = assignment['patch_read_mode']
    chunks = manifest['patch_sets'][assignment['patch_set']]['chunks'] if patch_mode == 'chunks' else []
    patch_ranges = [] if chunks else [{'line_start': start, 'line_end': min(start + 239, patch_lines)}
                                      for start in range(1, patch_lines + 1, 240)]
    patch_reads = 0 if not patch_raw else len(chunks) if chunks else max(1, len(patch_ranges))
    patch_output_sizes = ([chunk['bytes'] for chunk in chunks] if chunks else [
        len(b''.join(patch_raw.splitlines(keepends=True)[row['line_start'] - 1:row['line_end']]))
        for row in patch_ranges])
    calls = max(1, len(packet['shards']) + source_calls + patch_reads)
    cited = sum(any(row['path'] == finding['file'] and row['line_start'] <= finding['line_end']
                    and finding['line_start'] <= row['line_end'] for row in ranges) for finding in findings)
    audit = {'schema_version':2, 'status':'valid', 'narrow':assignment['scope'] != 'full',
             'adapter':assignment['adapter'],
             'prompt_sha256':module.digest(prompt.read_bytes()), 'stream_sha256':module.digest(stream.read_bytes()),
             'result_sha256':module.digest(result.read_bytes()),
             'evidence_manifest_sha256':module.digest(manifest_path.read_bytes()), 'violations':[],
             'tool_calls':calls, 'tool_turns':calls, 'tool_output_bytes':packet_bytes + source_bytes + len(patch_raw),
             'max_tool_output_bytes':max([0] + [shard['bytes'] for shard in packet['shards']] + source_output_sizes + patch_output_sizes),
             'recognized_tool_calls':calls, 'source_read_calls':source_calls,
             'packet_shards':len(packet['shards']), 'packet_bytes':packet_bytes,
             'packet_ranges':sum(len(shard['ranges']) for shard in packet['shards']),
             'post_index_source_ranges':post_index_ranges,
             'opened_source_ranges':sum(row['origin'] == 'tool' for row in ranges),
             'finding_citations':cited, 'source_ranges':ranges,
             'required_source_ranges_covered':len(packet['required_source_ranges']),
             'required_source_range_proofs':proofs,
             'assigned_patch_sha256':module.digest(patch_raw), 'assigned_patch_bytes':len(patch_raw),
             'assigned_patch_lines':patch_lines, 'assigned_patch_reads':patch_reads,
             'assigned_patch_ranges':patch_ranges,
             'patch_proof_mode':patch_mode, 'patch_proof_calls':patch_reads,
             'patch_proof_turns':patch_reads, 'patch_proof_visible_bytes':len(patch_raw),
             'expected_patch_chunks':len(chunks), 'opened_patch_chunks':len(chunks)}
    (session / f'r{label}-{seat}.read-audit.json').write_text(json.dumps(audit))

@contextlib.contextmanager
def fixture(name='repo', object_format=None, adapter='agent'):
    with tempfile.TemporaryDirectory(prefix='evidence-hardening-') as tmp:
        root = Path(tmp) / name; root.mkdir(); session = Path(tmp) / 'session'; session.mkdir()
        def git(*args):
            return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.PIPE).decode().strip()
        def write(name, text):
            p = root / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text)
        def call(*args, good=True, timeout=30, env=None, error=None, entrypoint=None):
            run_env = dict(os.environ, REV_PATCH_CHUNKS='auto', REV_SOURCE_CONTEXT='1')
            run_env.update(env or {})
            p = subprocess.run([sys.executable, str(entrypoint or script), *map(str, args)], capture_output=True, text=True, timeout=timeout, env=run_env)
            assert 'Traceback' not in p.stderr, p.stderr
            assert (p.returncode == 0) == good, (p.returncode, p.stdout, p.stderr)
            if error is not None:
                assert error in p.stderr, (error, p.stderr)
            return p.stdout
        def prepare(label='1', phase='discovery', *extra, **kw):
            call('prepare', session, label, '--phase', phase, *extra, **kw)
            return json.loads((session / f'r{label}-evidence.manifest.json').read_text())
        def finish(label='1'):
            mpath = session / f'r{label}-evidence.manifest.json'
            for seat in json.loads(mpath.read_text())['assignments']:
                (session / f'r{label}-{seat}.prompt.md').write_text(call('render', mpath, seat))
                (session / f'r{label}-{seat}.json').write_text('{"summary":"verified","findings":[]}')
                (session / f'r{label}-{seat}.exit').write_text('0\n')
                write_agent_audit(session, label, seat)
            call('receipt', session, label)
        git('init', '-q', *(['--object-format=' + object_format] if object_format else []))
        git('config', 'user.name', 'Test'); git('config', 'user.email', 'test@example.invalid'); git('config', 'commit.gpgsign', 'false')
        write('main.py', 'def first():\n    return 1\n\ndef second():\n    return 1\n')
        write('test_calls.py', 'from main import first, second\nassert first() == 1\nassert second() == 1\n')
        write('package.json', '{"scripts":{"test":"pytest"}}\n')
        git('add', '.'); git('commit', '-qm', 'base'); base = git('rev-parse', 'HEAD')
        (session / 'scope.env').write_text(''.join(k + '=' + shlex.quote(v) + '\n' for k, v in [('REV_BASE', base), ('REV_ROOT', str(root)), ('REV_SCOPE', 'branch')]))
        (session / 'files.txt').write_text('')
        (session / 'untracked.txt').write_text('')
        (session / 'roster.json').write_text(json.dumps({'seats': [{'seat': s, 'extra': False, 'adapter': adapter} for s in seats]}))
        write('main.py', (root / 'main.py').read_text().replace('return 1', 'return 2'))
        yield root, session, git, write, call, prepare, finish

def storage_redirects():
    for nested in (False, True):
        with fixture() as (root, session, git, write, call, prepare, finish):
            target = root / '.git/objects'; store = session / 'evidence-objects'
            if nested:
                store.mkdir(); (store / 'aa').symlink_to(target, target_is_directory=True)
            else:
                store.symlink_to(target, target_is_directory=True)
            before = {str(p): p.read_bytes() for p in target.rglob('*') if p.is_file()}
            call('prepare', session, '1', '--phase', 'discovery', good=False)
            assert before == {str(p): p.read_bytes() for p in target.rglob('*') if p.is_file()}
    with fixture() as (root, session, git, write, call, prepare, finish):
        prepare()
        assert not (session / 'evidence-repository').exists()

def quoted_paths():
    with fixture('r\u00e9po space\'"colon:back\\slash') as (root, session, git, write, call, prepare, finish):
        prepare(); call('render', session / 'r1-evidence.manifest.json', 'sol')

def changed_symbols():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('_locales/en/messages.json', '{"hello":{"message":"Hello"}}\n')
        write('weird.py', 'prefix\rform\fstill one LF line\ndef target():\n    return 1\n')
        prepare(); facts = json.loads((session / 'r1-evidence.json').read_text())
        assert {s['name'] for s in facts['symbols'] if s['path'] == 'main.py'} == {'first', 'second'}
        assert {(c['name'], c['line']) for c in facts['call_sites'] if c['path'] == 'test_calls.py'} == {('first', 2), ('second', 3)}
        assert any(symbol['path'] == 'weird.py' and symbol['name'] == 'target'
                   and symbol['line'] == 2 for symbol in facts['symbols'])
        assert facts['mechanical']['_locales/en/messages.json'] == 'locale'

    with fixture() as (root, session, git, write, call, prepare, finish):
        write('test_unresolved_calls.py', 'assert first() == 1\nassert second() == 1\n')
        prepare(); facts = json.loads((session / 'r1-evidence.json').read_text())
        calls = [row for row in facts['call_sites'] if row['path'] == 'test_unresolved_calls.py']
        assert {(row['name'], row['line']) for row in calls} == {('first', 1), ('second', 2)}
        assert all(row.get('resolution') == 'unresolved name search required' for row in calls), calls
        assert any(row['path'] == 'test_unresolved_calls.py' for row in facts['related_tests']), facts['related_tests']
        assert not any(row['source'] == 'test_unresolved_calls.py' and row['target'] == 'main.py'
                       for row in facts['dependencies']), facts['dependencies']

    with fixture() as (root, session, git, write, call, prepare, finish):
        write('main.py', 'def first():\n    return 2\n\nsecond()\n')
        prepare(); facts = json.loads((session / 'r1-evidence.json').read_text())
        assert any(row['path'] == 'main.py' and row['name'] == 'second'
                   and row['kind'] == 'deleted lexical declaration'
                   for row in facts['symbols']), facts['symbols']
        assert any(row['path'] == 'test_calls.py' and row['name'] == 'second'
                   and row.get('resolution') == 'unresolved name search required'
                   for row in facts['call_sites']), facts['call_sites']
        assert any(row['path'] == 'main.py' and row['name'] == 'second'
                   and row.get('resolution') == 'unresolved name search required'
                   for row in facts['call_sites']), facts['call_sites']

    with fixture() as (root, session, git, write, call, prepare, finish):
        write('main.py', 'def _private():\n    return 1\n')
        write('caller.py', 'def call_private():\n    return _private()\n')
        git('add', 'main.py', 'caller.py'); git('commit', '-qm', 'base private declaration')
        base = git('rev-parse', 'HEAD')
        (session / 'scope.env').write_text(
            f"REV_BASE='{base}'\nREV_ROOT='{root}'\nREV_SCOPE='branch'\n")
        write('main.py', 'def public():\n    return 1\n')
        prepare(); facts = json.loads((session / 'r1-evidence.json').read_text())
        assert not any(row['path'] == 'caller.py' and row['name'] == '_private'
                       for row in facts['call_sites']), facts['call_sites']

def empty_patch_needs_no_fake_read():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('main.py', (root / 'main.py').read_text().replace('return 2', 'return 1'))
        manifest = prepare('empty')
        assert all(assignment['patch_bytes'] == 0 and assignment['patch_lines'] == 0
                   for assignment in manifest['assignments'].values())
        for seat in manifest['assignments']:
            prompt = call('render', session / 'rempty-evidence.manifest.json', seat)
            assert 'Assigned patch is empty; no assigned-patch read is required.' in prompt
            assert "sed -n '1,0p'" not in prompt
            (session / f'rempty-{seat}.prompt.md').write_text(prompt)
            (session / f'rempty-{seat}.json').write_text('{"summary":"no changes","findings":[]}')
            (session / f'rempty-{seat}.exit').write_text('0\n')
            write_agent_audit(session, 'empty', seat)
        call('receipt', session, 'empty')

def conservative_mechanical_classification():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('src/i18n/api/config.json', '{"handwritten":true}\n')
        write('src/generated-looking.ts', '// Generated code handles account recovery.\nexport const recovery = 1;\n')
        write('generated/actual.ts', '// @generated\nexport const actual = 1;\n')
        m = prepare(); facts = json.loads((session / 'r1-evidence.json').read_text())
        assert 'src/i18n/api/config.json' in m['semantic_paths']
        assert 'src/generated-looking.ts' in m['semantic_paths']
        assert facts['mechanical']['generated/actual.ts'] == 'generated'

def bounded_navigation_markdown():
    with fixture() as (root, session, git, write, call, prepare, finish):
        huge = 'x' * 100000
        write('package.json', '{"scripts":{"test":"' + huge + '"}}\n')
        call('prepare', session, '1', '--phase', 'discovery',
             env=dict(os.environ, REV_SOURCE_CONTEXT='0'))
        packet = (session / 'r1-evidence.md').read_bytes()
        assert len(packet) <= 16384
        assert huge.encode() not in packet
        assert b'complete list SHA-256:' in packet and b'Omitted:' in packet

        sections = ('symbols', 'call_sites', 'related_tests', 'unresolved_imports', 'gates', 'instructions')
        data = {section: [{'path': f'file{index}.ts', 'detail': 'x' * 900}
                          for index in range(12)] for section in sections}
        data['limitations'] = [f'limitation{index}: ' + ('é' * 70 if index == 0 else 'y' * 70)
                               for index in range(7)]
        try:
            packet = module.markdown(data, Path('complete-facts.json'))
        except ValueError as error:
            raise AssertionError(
                f'optional rows must fit with complete navigation metadata: {error}') from error
        text = packet.decode()
        assert len(packet) <= 16384
        assert text.count('Omitted:') == len(sections)
        assert all(limitation in text for limitation in data['limitations'])
        labels = {section: ('Unresolved or aliased import proof obligations'
                            if section == 'unresolved_imports'
                            else section.replace('_', ' ').title())
                  for section in sections}
        for section in sections:
            encoded_rows = (json.dumps(data[section], sort_keys=True, ensure_ascii=True,
                                       indent=2) + '\n').encode()
            assert hashlib.sha256(encoded_rows).hexdigest() in text
            start = text.index(labels[section] + ':\n') + len(labels[section]) + 2
            section_lines = text[start:].splitlines()
            footer_index = next((index for index, line in enumerate(section_lines)
                                 if line.startswith('Omitted: ')), None)
            assert footer_index is not None, section
            included = sum(line.startswith('- ') for line in section_lines[:footer_index])
            omitted = re.match(r'^Omitted: (\d+);', section_lines[footer_index])
            assert omitted and included + int(omitted.group(1)) == len(data[section]), section

        empty = {section: [] for section in sections}
        empty['limitations'] = ['preserve ✓']
        empty_packet = module.markdown(empty, Path('complete-facts.json'))
        empty_text = empty_packet.decode()
        assert len(empty_packet) <= 16384
        assert empty_text.count('Omitted: 0;') == len(sections)
        encoded_empty = (json.dumps([], sort_keys=True, ensure_ascii=True, indent=2) + '\n').encode()
        empty_rows_hash = hashlib.sha256(encoded_empty).hexdigest()
        assert empty_text.count(empty_rows_hash) == len(sections)
        assert 'preserve ✓' in empty_text

        too_large = {section: [] for section in sections}
        too_large['limitations'] = ['x' * 16384]
        try:
            module.markdown(too_large, Path('complete-facts.json'))
        except ValueError as error:
            assert str(error) == 'navigation packet exceeds byte limit'
        else:
            raise AssertionError('fixed navigation metadata above the packet limit must fail closed')

def opaque_transitions():
    for reverse in (False, True):
        with fixture() as (root, session, git, write, call, prepare, finish):
            write('generated/data.txt', 'ordinary text\n'); write('package-lock.json', '{}\n')
            if not reverse:
                (root / 'generated/data.txt').write_bytes(b'\0binary')
                (root / 'package-lock.json').unlink(); (root / 'package-lock.json').symlink_to('main.py')
            git('add', '.'); git('commit', '-qm', 'transition base')
            base = git('rev-parse', 'HEAD')
            scope = (session / 'scope.env').read_text(); scope = '\n'.join('REV_BASE=' + base if s.startswith('REV_BASE=') else s for s in scope.splitlines()) + '\n'; (session / 'scope.env').write_text(scope)
            (root / 'package-lock.json').unlink()
            if reverse:
                (root / 'package-lock.json').symlink_to('main.py'); (root / 'generated/data.txt').write_bytes(b'\0binary')
            else:
                write('package-lock.json', '{}\n'); write('generated/data.txt', 'ordinary text\n')
            prepare(); patch = (session / 'r1-semantic.patch').read_text()
            assert 'package-lock.json' in patch and 'generated/data.txt' in patch

def invalid_manifests():
    with fixture() as (root, session, git, write, call, prepare, finish):
        prepare(); mpath = session / 'r1-evidence.manifest.json'; original = mpath.read_bytes()
        bad = json.loads(original)
        for seat in seats[1:]:
            bad['assignments'][seat].update(scope='delta', patch=str(session.resolve() / 'r1-delta.patch'), full_state=False)
        mpath.write_text(json.dumps(bad)); call('render', mpath, 'terra', good=False)
        mpath.write_bytes(original)
        call('prepare', session, 'bad-owner', '--phase', 'verification', *assign, '--full-seat', 'sol', good=False)
        for key, value in [('source', None), ('assignments', []), ('artifacts', []), ('snapshot_unsafe', {}), ('word_counts', None)]:
            bad = json.loads(original); bad[key] = value; mpath.write_text(json.dumps(bad))
            call('render', mpath, 'sol', good=False)
        mpath.write_bytes(original); finish()
        headpath = session / 'coverage-head.json'; saved_head = headpath.read_bytes()
        receiptpath = session / 'r1-coverage.receipt.json'; saved_receipt = receiptpath.read_bytes()
        for key, value in [('source', None), ('assignments', []), ('artifacts', []), ('word_counts', None)]:
            bad = json.loads(original); bad[key] = value; raw = json.dumps(bad).encode(); mpath.write_bytes(raw)
            receipt = json.loads(saved_receipt); receipt['manifest_sha256'] = hashlib.sha256(raw).hexdigest()
            raw_receipt = json.dumps(receipt).encode(); receiptpath.write_bytes(raw_receipt)
            head = json.loads(saved_head); head['sha256'] = hashlib.sha256(raw_receipt).hexdigest(); headpath.write_text(json.dumps(head))
            widened = prepare('fallback-' + key, 'verification', *assign)
            assert all(a['scope'] == 'full' for a in widened['assignments'].values())

def opaque_mode_transition():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('generated/tool.py', '# generated file\nprint(1)\n'); git('add','.'); git('commit','-qm','mode base')
        base=git('rev-parse','HEAD'); text=(session/'scope.env').read_text()
        (session/'scope.env').write_text('\n'.join('REV_BASE='+base if s.startswith('REV_BASE=') else s for s in text.splitlines())+'\n')
        (root/'generated/tool.py').chmod(0o755); prepare()
        assert 'generated/tool.py' in (session/'r1-semantic.patch').read_text()

def phase_and_predecessor_integrity():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('padding.py', ''.join(f'value_{i} = {i}\n' for i in range(1000)))
        prepare(); mpath = session / 'r1-evidence.manifest.json'; epath = session / 'r1-evidence.json'
        original = mpath.read_bytes(); original_evidence = epath.read_bytes()
        def replace(manifest, evidence, mpath, epath):
            raw = json.dumps(evidence).encode(); epath.write_bytes(raw)
            manifest['artifacts'][epath.name]['sha256'] = hashlib.sha256(raw).hexdigest()
            manifest['artifacts'][epath.name]['words'] = len(raw.split())
            mpath.write_text(json.dumps(manifest))
        for mode in ('delta', 'full'):
            bad = json.loads(original); evidence = json.loads(original_evidence)
            for seat in seats[1:]:
                bad['assignments'][seat].update(scope=mode, patch=str(session.resolve() / f'r1-{mode}.patch'), full_state=mode == 'full')
            evidence['assignments'] = bad['assignments']; replace(bad, evidence, mpath, epath)
            call('render', mpath, 'sol', good=False)
            call('receipt', session, '1', good=False)
        mpath.write_bytes(original); epath.write_bytes(original_evidence); finish()
        write('main.py', (root / 'main.py').read_text().replace('return 2', 'return 3', 1))
        delta = prepare('2', 'verification', *assign)
        assert delta['assignments']['sol']['scope'] == 'delta'
        mpath = session / 'r2-evidence.manifest.json'; epath = session / 'r2-evidence.json'
        original = mpath.read_bytes(); original_evidence = epath.read_bytes()
        for field, value in [('predecessor', None), ('predecessor', {'receipt': 'missing.json', 'sha256': '0' * 64}), ('mechanical_owner', 'sol')]:
            bad = json.loads(original); evidence = json.loads(original_evidence)
            bad[field] = value; evidence[field] = value; replace(bad, evidence, mpath, epath)
            call('render', mpath, 'sol', good=False)
        mpath.write_bytes(original); epath.write_bytes(original_evidence)
        prior = session / 'r1-coverage.receipt.json'; prior.write_text('{"manifest":null}')
        call('render', mpath, 'sol', good=False)

def coverage_reference(session, label):
    path = session / f'r{label}-coverage.receipt.json'
    raw = path.read_bytes()
    return {'receipt': path.name, 'sha256': module.digest(raw)}

def source_context_inputs_batches_uncached_blobs():
    with fixture() as (root, session, git, write, call, prepare, finish):
        paths = [f'src/batch{i}.py' for i in range(12)]
        for i, path in enumerate(paths):
            write(path, f'def batch{i}():\n    return {i}\n')
        manifest = prepare('batch', 'risk', *assign)
        repo = module.Repository(session.resolve())
        original_git = repo.git
        single_blob_reads = []
        def traced_git(*args, **kwargs):
            if args[:2] == ('cat-file', 'blob'):
                single_blob_reads.append(args[2])
            return original_git(*args, **kwargs)
        repo.git = traced_git
        evidence = {'symbols': [], 'call_sites': [], 'related_tests': [], 'unresolved_imports': [], 'gates': []}
        entries, _, blobs, _ = module.source_context_inputs(
            repo, manifest['snapshot_tree'], manifest['base_tree'], evidence,
            [{'files': paths, 'boundary': []}])
        for i, path in enumerate(paths):
            assert blobs[entries[path]] == f'def batch{i}():\n    return {i}\n'.encode()
        assert not single_blob_reads, f'source inputs launched {len(single_blob_reads)} per-blob Git reads'
        large = b'x' * 2_000_001
        (root / 'large.bin').write_bytes(large)
        oid = git('hash-object', '-w', 'large.bin')
        entry = ('100644', oid)
        assert dict(repo.iter_blobs({'large.bin': entry}))['large.bin'] == module.OVERSIZED_BLOB
        assert dict(repo.iter_blobs({'large.bin': entry}, max_bytes=None))['large.bin'] == large

def source_context_memo_validation_guards():
    with fixture() as (root, session, git, write, call, prepare, finish):
        prepare('seed', 'risk', *assign)
        manifest_path = session / 'rseed-evidence.manifest.json'
        manifest, _ = module.validated_manifest(manifest_path, fresh=False)
        shards = [shard for packet in manifest['source_context']['seats'].values()
                  for shard in packet['shards']]
        assert shards
        artifact = session / shards[0]['artifact']
        original_artifact = artifact.read_bytes()
        artifact.write_bytes(original_artifact + b' tampered')
        try:
            module.validated_manifest(manifest_path, fresh=False)
        except ValueError:
            pass
        else:
            raise AssertionError('a memo hit must not accept a changed source-context shard')
        artifact.write_bytes(original_artifact)
        module.validated_manifest(manifest_path, fresh=False)
        try:
            module.validated_manifest(
                manifest_path, fresh=False, seen={str(manifest_path.resolve())})
        except ValueError as error:
            assert 'cyclic coverage predecessor' in str(error), error
        else:
            raise AssertionError('cycle detection must run before a memo lookup')

    with fixture() as (root, session, git, write, call, prepare, finish):
        prepare('retry', 'risk', *assign)
        manifest_path = session / 'rretry-evidence.manifest.json'
        original = module.plan_source_context
        attempts = 0

        def fail_once(*args, **kwargs):
            nonlocal attempts
            attempts += 1
            if attempts == 1:
                raise ValueError('injected reconstruction failure')
            return original(*args, **kwargs)

        module.plan_source_context = fail_once
        try:
            try:
                module.validated_manifest(manifest_path, fresh=False)
            except ValueError as error:
                assert 'injected reconstruction failure' in str(error), error
            else:
                raise AssertionError('the injected reconstruction failure was ignored')
            module.validated_manifest(manifest_path, fresh=False)
        finally:
            module.plan_source_context = original
        assert attempts == 2, 'a failed reconstruction must not seed a memo entry'

    with fixture() as (root, session, git, write, call, prepare, finish):
        prepare('seed', 'risk', *assign)
        finish('seed')
        write('main.py', (root / 'main.py').read_text().replace('return 2', 'return 3', 1))
        child = prepare('verify', 'verification', *assign)
        repo = module.Repository(session.resolve())
        _, hunks, categories, _ = repo.changes(child['base_tree'], child['snapshot_tree'])
        prior = module.prior_coverage(
            session, repo, child['base_tree'], child['predecessor'])
        assert prior['status'] == 'valid', prior
        _, delta_hunks, delta_categories, _ = repo.changes(
            prior['coverage']['snapshot_tree'], child['snapshot_tree'])
        assert delta_hunks and all(row['path'] in {hunk['path'] for hunk in hunks}
                                   for row in delta_hunks)
        original = module.plan_source_context
        calls = {}

        def count_child(*args, **kwargs):
            calls[args[6]] = calls.get(args[6], 0) + 1
            return original(*args, **kwargs)

        module.plan_source_context = count_child
        child_manifest_hash = module.digest(
            (session / 'rverify-evidence.manifest.json').read_bytes())
        try:
            module.validate_source_context_snapshot(
                repo, session, child, (hunks, categories), (delta_hunks, delta_categories),
                child_manifest_hash)
            changed_delta = list(delta_hunks)
            changed_delta[0] = dict(changed_delta[0], sha256='0' * 64)
            module.validate_source_context_snapshot(
                repo, session, child, (hunks, categories),
                (changed_delta, delta_categories), child_manifest_hash)
        finally:
            module.plan_source_context = original
        assert calls.get('rverify') == 2, calls

        key_builder = getattr(module, '_source_context_reconstruction_key', None)
        if key_builder is not None:
            manifest, manifest_hash = module.validated_manifest(
                session / 'rverify-evidence.manifest.json', fresh=False)
            changes = (hunks, categories)
            delta = (delta_hunks, delta_categories)
            key = key_builder(repo, session.resolve(), manifest, manifest_hash, changes, delta)
            assert key == key_builder(
                repo, session.resolve(), manifest, manifest_hash, changes, delta)
            assert key != key_builder(
                repo, session.resolve(), manifest, '0' * 64, changes, delta)
            changed_predecessor = dict(
                manifest, predecessor={'receipt': 'other-coverage.json', 'sha256': '0' * 64})
            assert key != key_builder(
                repo, session.resolve(), changed_predecessor, manifest_hash, changes, delta)
            other_session = session.parent / 'other-session'
            assert key != key_builder(
                repo, other_session, manifest, manifest_hash, changes, delta)
            other_root = session.parent / 'other-repository'
            shutil.copytree(root, other_root)
            scope_path = session / 'scope.env'
            saved_scope = scope_path.read_bytes()
            try:
                scope_path.write_text(saved_scope.decode().replace(str(root), str(other_root)))
                other_repo = module.Repository(session.resolve())
            finally:
                scope_path.write_bytes(saved_scope)
            assert key != key_builder(
                other_repo, session.resolve(), manifest, manifest_hash, changes, delta)

        memo = getattr(module, 'SOURCE_CONTEXT_RECONSTRUCTION_MEMO', None)
        if memo is not None:
            memo[('prepare-clear-sentinel',)] = {}
            validate_inputs = module.validate_standard_inputs
            prepare_locked = module._prepare_locked
            module.validate_standard_inputs = lambda *_args, **_kwargs: None
            module._prepare_locked = lambda *_args, **_kwargs: 'prepared'
            try:
                args = type('Args', (), {'session': str(session)})()
                assert module.prepare(args) == 'prepared'
            finally:
                module.validate_standard_inputs = validate_inputs
                module._prepare_locked = prepare_locked
            assert not memo

def source_context_memo_reuses_shared_predecessor_reconstruction():
    with fixture() as (root, session, git, write, call, prepare, finish):
        for i in range(8):
            write(f'src/unit{i}.py', f'def unit{i}():\n' + ''.join(f'    value_{j} = {j}\n' for j in range(400)))
        seed = prepare('seed', 'risk', *assign)
        finish('seed')
        seed_reference = coverage_reference(session, 'seed')
        write('main.py', (root / 'main.py').read_text().replace('return 2', 'return 3', 1))
        branch_a = prepare('branch-a', 'verification', *assign)
        assert branch_a['predecessor'] == seed_reference
        assert any(assignment['scope'] == 'delta' for assignment in branch_a['assignments'].values())
        finish('branch-a')
        (session / 'coverage-head.json').write_bytes(module.encoded(seed_reference))
        write('main.py', (root / 'main.py').read_text().replace('return 3', 'return 4', 1))
        branch_b = prepare('branch-b', 'verification', *assign)
        assert branch_b['predecessor'] == seed_reference
        assert any(assignment['scope'] == 'delta' for assignment in branch_b['assignments'].values())
        finish('branch-b')
        repo = module.Repository(session.resolve())
        calls = {}
        memo = getattr(module, 'SOURCE_CONTEXT_RECONSTRUCTION_MEMO', None)
        if memo is not None:
            memo.clear()
        original = module.plan_source_context

        def count_reconstruction(*args, **kwargs):
            label = args[6]
            calls[label] = calls.get(label, 0) + 1
            return original(*args, **kwargs)

        module.plan_source_context = count_reconstruction
        try:
            for label in ('branch-a', 'branch-b'):
                result = module.prior_coverage(
                    session, repo, seed['base_tree'], coverage_reference(session, label))
                assert result['status'] == 'valid', result
        finally:
            module.plan_source_context = original
        expected = {'rseed': 1, 'rbranch-a': 1, 'rbranch-b': 1}
        assert calls == expected, f'expected one reconstruction per manifest, got {calls}'

def cumulative_verification_routing():
    with fixture() as (root, session, git, write, call, prepare, finish):
        semantic = prepare('semantic', 'verification', *assign)
        assert semantic['assignments']['sonnet']['scope'] == 'full'
        assert all(semantic['assignments'][seat]['scope'] == 'semantic' for seat in seats[:-1])
        assert semantic['fallback_reason'] is None and semantic['predecessor'] is None
        mpath = session / 'rsemantic-evidence.manifest.json'
        epath = session / 'rsemantic-evidence.json'
        original = mpath.read_bytes(); original_evidence = epath.read_bytes()
        def replace(manifest, evidence):
            raw = json.dumps(evidence).encode(); epath.write_bytes(raw)
            manifest['artifacts'][epath.name]['sha256'] = hashlib.sha256(raw).hexdigest()
            manifest['artifacts'][epath.name]['words'] = len(raw.split())
            mpath.write_text(json.dumps(manifest))
        bad = json.loads(original); evidence = json.loads(original_evidence)
        bad['predecessor'] = {'receipt':'rprior-coverage.receipt.json','sha256':'0' * 64}
        evidence['predecessor'] = bad['predecessor']; replace(bad, evidence)
        call('render', mpath, 'sol', good=False)
        mpath.write_bytes(original); epath.write_bytes(original_evidence)
        bad = json.loads(original); evidence = json.loads(original_evidence)
        assignment = bad['assignments']['sol']; owner = bad['assignments']['sonnet']
        for key in ('scope', 'full_state', 'patch', 'patch_sha256', 'patch_bytes',
                    'patch_lines', 'patch_set', 'patch_read_mode', 'components'):
            assignment[key] = owner[key]
        evidence['assignments'] = bad['assignments']; replace(bad, evidence)
        call('render', mpath, 'sol', good=False)
        mpath.write_bytes(original); epath.write_bytes(original_evidence)
        finish('semantic')
        first_head = json.loads((session / 'coverage-head.json').read_text())
        same = prepare('same', 'verification', *assign)
        assert same['assignments']['sonnet']['scope'] == 'full'
        assert all(same['assignments'][seat]['scope'] == 'semantic' for seat in seats[:-1])
        assert same['fallback_reason'] is None and same['predecessor'] is None
        finish('same')
        second_head = json.loads((session / 'coverage-head.json').read_text())
        assert first_head != second_head and second_head['receipt'] == 'rsame-coverage.receipt.json'
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('main.py', 'def first():\n    return 1\n\ndef second():\n    return 1\n')
        write('package-lock.json', '{}\n')
        mechanical = prepare('mechanical', 'verification', *assign)
        assert all(assignment['scope'] == 'full'
                   for assignment in mechanical['assignments'].values())
        assert mechanical['fallback_reason'] == 'no semantic components'

def verification_source_context_change(change):
    with fixture(adapter='codex') as (root, session, git, write, call, prepare, finish):
        write('padding.py', ''.join(f'value_{i} = {i}\n' for i in range(1000)))
        (session / 'files.txt').write_text('main.py\npadding.py\n')
        (session / 'untracked.txt').write_text('padding.py\n')
        frozen_inputs = {name: (session / name).read_bytes() for name in (
            'scope.env', 'roster.json', 'files.txt', 'untracked.txt')}
        reviewed = prepare('reviewed', 'risk', *assign)
        assert reviewed['source_context']['enabled'] is True
        assert set(reviewed['assignments']) == set(seats)
        assert {a['bundle'] for a in reviewed['assignments'].values()} == set(bundles)
        assert reviewed['mechanical_owner'] == 'sonnet'
        finish('reviewed')
        prior_reference = json.loads((session / 'coverage-head.json').read_text())
        sealed = {path.name: path.read_bytes() for path in session.glob('rreviewed-*')}
        repository = module.Repository(session.resolve())
        prior = module.prior_coverage(session, repository, reviewed['base_tree'])
        assert prior['status'] == 'valid', prior
        assert prior['coverage']['snapshot_tree'] == reviewed['snapshot_tree']
        assert prior_reference == {
            'receipt': 'rreviewed-coverage.receipt.json',
            'sha256': hashlib.sha256(sealed['rreviewed-coverage.receipt.json']).hexdigest()}
        original = git('show', git('rev-parse', 'HEAD') + ':main.py') + '\n'
        if change == 'restored':
            write('main.py', original)
            assert (root / 'main.py').read_bytes() == original.encode()
            assert git('diff', 'HEAD', '--', 'main.py') == ''
        elif change == 'ordinary':
            write('main.py', (root / 'main.py').read_text().replace('return 2', 'return 3', 1))
        elif change == 'partial-deletion':
            write('main.py', 'def second():\n    return 2\n')
        elif change == 'deleted':
            (root / 'main.py').unlink()
        else:
            raise AssertionError('unknown verification source fixture: ' + change)
        snapshot, unsafe = repository.snapshot()
        assert unsafe == []
        cumulative, _, categories, opaque = repository.changes(reviewed['base_tree'], snapshot)
        delta, _, delta_categories, delta_opaque = repository.changes(reviewed['snapshot_tree'], snapshot)
        assert opaque == delta_opaque == []
        assert [path for path, _ in delta] == ['main.py']
        assert delta_categories == {'main.py': 'semantic'}
        expected_paths = ['padding.py'] if change == 'restored' else ['main.py', 'padding.py']
        assert [path for path, _ in cumulative] == expected_paths
        assert {name: (session / name).read_bytes() for name in frozen_inputs} == frozen_inputs
        manifest = prepare('verify', 'verification', *assign)
        assert (manifest['snapshot_tree'], manifest['base_tree']) == (snapshot, reviewed['base_tree'])
        assert manifest['source_context']['enabled'] is True
        assert manifest['inputs'] == {name: hashlib.sha256(raw).hexdigest()
                                      for name, raw in frozen_inputs.items()}
        assert manifest['semantic_paths'] == [path for path in expected_paths
                                              if categories[path] == 'semantic']
        assert manifest['delta_paths'] == ['main.py']
        assert manifest['predecessor'] == prior_reference
        assert (session / 'rverify-delta.patch').read_bytes() == delta[0][1]
        assert (session / 'rverify-full.patch').read_bytes() == b''.join(raw for _, raw in cumulative)
        owner = manifest['mechanical_owner']
        assert manifest['assignments'][owner]['full_state'] is True
        assert manifest['assignments'][owner]['scope'] == 'full'
        component = next(component for component in manifest['components']
                         if 'main.py' in component['files'])
        assert component['full_state_owner'] == owner and component['specialists']
        assert any('diff --git a/main.py b/main.py' in Path(assignment['patch']).read_text()
                   for seat, assignment in manifest['assignments'].items() if seat != owner)
        for seat, assignment in manifest['assignments'].items():
            if component['id'] not in assignment['components']:
                continue
            packet = manifest['source_context']['seats'][seat]
            rows = [row for shard in packet['shards'] for row in shard['ranges']]
            rows += packet['required_source_ranges'] + packet['omitted_source_ranges']
            expected_tree = reviewed['base_tree'] if change == 'deleted' else snapshot
            assert any(row['path'] == 'main.py' and row['blob_tree'] == expected_tree
                       and component['id'] in row['component_ids'] for row in rows), (change, seat)
            for row in rows:
                entries = repository.entries(row['blob_tree'])
                entry = entries[row['path']]
                assert (row['blob_mode'], row['blob_oid']) == entry
                lines = module.split_lf_lines(repository.blob(entry))
                raw = b''.join(lines[row['line_start'] - 1:row['line_end']])
                assert raw and row['content_sha256'] == hashlib.sha256(raw).hexdigest()
        call('verify', session / 'rverify-evidence.manifest.json')
        finish('verify')
        coverage = json.loads(call('current-coverage', session))
        assert coverage['eligible'] is True, coverage
        assert coverage['snapshot_tree'] == snapshot
        assert {name: (session / name).read_bytes() for name in frozen_inputs} == frozen_inputs
        assert {name: (session / name).read_bytes() for name in sealed} == sealed

def verification_delta_retains_restored_path_source_context():
    verification_source_context_change('restored')

def verification_delta_source_context_controls():
    for change in ('ordinary', 'partial-deletion', 'deleted'):
        verification_source_context_change(change)

def verification_nested_instruction_restoration(large=False):
    with fixture(adapter='codex') as (root, session, git, write, call, prepare, finish):
        write('main.py', git('show', 'HEAD:main.py') + '\n')
        original = 'def nested():\n    return 1\n'
        instruction = 'rule ' * 6000 + '\n' if large else 'Keep nested return values consistent.\n'
        write('src/main.py', original)
        write('src/AGENTS.md', instruction)
        git('add', '.'); git('commit', '-qm', 'nested instruction base')
        base = git('rev-parse', 'HEAD')
        (session / 'scope.env').write_text(''.join(
            key + '=' + shlex.quote(value) + '\n' for key, value in (
                ('REV_BASE', base), ('REV_ROOT', str(root)), ('REV_SCOPE', 'branch'))))
        write('padding.py', ''.join(f'value_{i} = {i}\n' for i in range(1000)))
        write('src/main.py', original.replace('return 1', 'return 2'))
        (session / 'files.txt').write_text('padding.py\nsrc/main.py\n')
        (session / 'untracked.txt').write_text('padding.py\n')
        frozen = {name: (session / name).read_bytes() for name in (
            'scope.env', 'roster.json', 'files.txt', 'untracked.txt')}
        reviewed = prepare('nested-reviewed', 'risk', *assign)
        instruction_row = {'path': 'src/AGENTS.md',
                           'sha256': hashlib.sha256(instruction.encode()).hexdigest()}
        assert reviewed['instructions'] == [instruction_row]
        finish('nested-reviewed')
        reference = json.loads((session / 'coverage-head.json').read_text())
        sealed = {path.name: path.read_bytes() for path in session.glob('rnested-reviewed-*')}
        repository = module.Repository(session.resolve())
        prior = module.prior_coverage(session, repository, reviewed['base_tree'])
        assert prior['status'] == 'valid', prior
        assert prior['coverage']['snapshot_tree'] == reviewed['snapshot_tree']
        write('src/main.py', original)
        assert git('diff', base, '--', 'src/main.py', 'src/AGENTS.md') == ''
        snapshot, unsafe = repository.snapshot()
        cumulative, _, _, cumulative_unsafe = repository.changes(reviewed['base_tree'], snapshot)
        delta, _, _, delta_unsafe = repository.changes(reviewed['snapshot_tree'], snapshot)
        assert unsafe == cumulative_unsafe == delta_unsafe == []
        assert [path for path, _ in cumulative] == ['padding.py']
        assert [path for path, _ in delta] == ['src/main.py']
        assert {name: (session / name).read_bytes() for name in frozen} == frozen
        label = 'nested-verify'
        env = dict(os.environ, REV_PATCH_CHUNKS='auto', REV_SOURCE_CONTEXT='1')
        result = subprocess.run(
            [sys.executable, str(script), 'prepare', str(session), label,
             '--phase', 'verification', *assign], env=env, capture_output=True, text=True, timeout=30)
        assert 'Traceback' not in result.stderr, result.stderr
        assert result.returncode in (0, 2), (result.returncode, result.stdout, result.stderr)
        if result.returncode == 2:
            assert large, ('short nested instruction closure must prepare', result.stderr)
            assert 'source context instruction expansion exceeds delta budget' in result.stderr, result.stderr
            assert not list(session.glob('rnested-verify-*')), 'refusal must precede evidence publication'
            assert {name: (session / name).read_bytes() for name in frozen} == frozen
            assert {name: (session / name).read_bytes() for name in sealed} == sealed
            return
        mpath = session / 'rnested-verify-evidence.manifest.json'
        manifest = json.loads(mpath.read_text())
        assert manifest['snapshot_tree'] == snapshot and manifest['base_tree'] == reviewed['base_tree']
        assert manifest['source_context']['enabled'] is True
        assert manifest['predecessor'] == reference
        assert manifest['inputs'] == {name: hashlib.sha256(raw).hexdigest() for name, raw in frozen.items()}
        assert (session / 'rnested-verify-full.patch').read_bytes() == b''.join(raw for _, raw in cumulative)
        assert (session / 'rnested-verify-delta.patch').read_bytes() == delta[0][1]
        assert manifest['instructions'] == [instruction_row]
        expected_packet = ('# src/AGENTS.md\n\n' + instruction.rstrip() + '\n').encode()
        packet_path = session / 'rnested-verify-instructions.md'
        assert packet_path.read_bytes() == expected_packet
        assert manifest['artifacts'][packet_path.name]['sha256'] == hashlib.sha256(expected_packet).hexdigest()
        assert (root / 'src/AGENTS.md').read_bytes() == instruction.encode()
        owner = manifest['mechanical_owner']
        assert manifest['assignments'][owner]['full_state'] is True
        components = [component for component in manifest['components'] if 'src/main.py' in component['files']]
        assert len(components) == 1, 'successful preparation must retain the restored source obligation'
        component = components[0]
        assert component['full_state_owner'] == owner and component['specialists']
        assert any('diff --git a/src/main.py b/src/main.py' in Path(assignment['patch']).read_text()
                   for seat, assignment in manifest['assignments'].items() if seat != owner)
        expected_oid = git('rev-parse', base + ':src/main.py')
        for seat, assignment in manifest['assignments'].items():
            if component['id'] not in assignment['components']:
                continue
            context = manifest['source_context']['seats'][seat]
            rows = [row for shard in context['shards'] for row in shard['ranges']]
            rows += context['required_source_ranges'] + context['omitted_source_ranges']
            rows = [row for row in rows if row['path'] == 'src/main.py'
                    and component['id'] in row['component_ids']]
            assert rows, ('restored source context is required', seat)
            for row in rows:
                assert (row['blob_tree'], row['blob_mode'], row['blob_oid']) == (snapshot, '100644', expected_oid)
                raw = b''.join(original.encode().splitlines(keepends=True)[row['line_start'] - 1:row['line_end']])
                assert raw and row['content_sha256'] == hashlib.sha256(raw).hexdigest()
        verified = subprocess.run([sys.executable, str(script), 'verify', str(mpath)],
                                  env=env, capture_output=True, text=True, timeout=30)
        assert verified.returncode == 0, (
            'successful prepare published nested restoration evidence rejected by verify',
            verified.returncode, verified.stdout, verified.stderr)
        finish(label)
        coverage = json.loads(call('current-coverage', session))
        assert coverage['eligible'] is True and coverage['snapshot_tree'] == snapshot, coverage
        assert {name: (session / name).read_bytes() for name in frozen} == frozen
        assert {name: (session / name).read_bytes() for name in sealed} == sealed

def verification_nested_restoration_retains_instruction_context():
    verification_nested_instruction_restoration()

def verification_nested_restoration_refuses_unusable_instruction_budget():
    verification_nested_instruction_restoration(large=True)

def coverage_head_publication_is_monotonic():
    with fixture() as (root, session, git, write, call, prepare, finish):
        prepare('first'); finish('first')
        first_reference = json.loads((session / 'coverage-head.json').read_text())
        prepare('second'); finish('second')
        head_path = session / 'coverage-head.json'
        second_bytes = head_path.read_bytes()
        assert json.loads(second_bytes.decode())['receipt'] == 'rsecond-coverage.receipt.json'
        call('receipt', session, 'first')
        assert head_path.read_bytes() == second_bytes
        head_path.unlink()
        call('receipt', session, 'first')
        assert json.loads(head_path.read_text()) == first_reference

        valid_receipt = session / 'rfirst-coverage.receipt.json'
        valid_bytes = valid_receipt.read_bytes()
        cases = []
        head_path.write_text('{bad')
        cases.append(('malformed', lambda: head_path.read_bytes()))
        for name, before in cases:
            call('receipt', session, 'first', good=False,
                 error='invalid coverage head')
            assert head_path.read_bytes() == before()

        head_path.unlink()
        head_path.symlink_to(valid_receipt.name)
        target_before = valid_receipt.read_bytes()
        call('receipt', session, 'first', good=False,
             error='invalid coverage head')
        assert head_path.is_symlink() and valid_receipt.read_bytes() == target_before

        head_path.unlink()
        os.link(valid_receipt, head_path)
        inode = head_path.stat().st_ino
        call('receipt', session, 'first', good=False,
             error='invalid coverage head')
        assert head_path.stat().st_ino == inode and valid_receipt.read_bytes() == valid_bytes

        head_path.unlink()
        head_path.write_bytes(second_bytes)
        head_path.chmod(0)
        inode = head_path.stat().st_ino
        try:
            call('receipt', session, 'first', good=False,
                 error='invalid coverage head')
            assert head_path.stat().st_ino == inode
        finally:
            head_path.chmod(0o600)
        assert head_path.read_bytes() == second_bytes

def same_stat_and_index_flags():
    with fixture() as (root, session, git, write, call, prepare, finish):
        for flag in ('--assume-unchanged', '--skip-worktree'):
            git('update-index', '--no-assume-unchanged', '--no-skip-worktree', 'main.py')
            git('update-index', flag, 'main.py')
            before = (root / 'main.py').stat()
            write('main.py', (root / 'main.py').read_text().replace('return 2', 'return 3'))
            os.utime(root / 'main.py', ns=(before.st_atime_ns, before.st_mtime_ns))
            label = flag.lstrip('-'); prepare(label)
            assert '+    return 3' in (session / f'r{label}-full.patch').read_text()
            write('main.py', (root / 'main.py').read_text().replace('return 3', 'return 2'))
            os.utime(root / 'main.py', ns=(before.st_atime_ns, before.st_mtime_ns))
            call('render', session / f'r{label}-evidence.manifest.json', 'sol', good=False)

def cstyle_enclosing_bodies():
    assert not module.brace_spans(['export default function() {', '  return 2;', '}'], '.js'), 'anonymous functions need file scope'
    assert not module.brace_spans(['object.method()', '{', '  changed();', '}'], '.js'), 'calls followed by blocks are not declarations'
    signatures = {
        'ts': ('export function alpha(): number', 'export function gamma(): number', 'export function beta(): number'),
        'js': ('export const alpha = () =>', 'function gamma()', 'function beta()'),
        'rs': ('pub fn alpha() -> i32', 'fn gamma() -> i32', 'fn beta() -> i32'),
        'go': ('func alpha() int', 'func gamma() int', 'func beta() int'),
        'java': ('public static int alpha()', 'public static int gamma()', 'public static int beta()'),
        'c': ('static int alpha(void)', 'int gamma(void)', 'int beta(void)'),
        'cpp': ('static int alpha() noexcept', 'int gamma()', 'int beta()'),
    }
    with fixture() as (root, session, git, write, call, prepare, finish):
        for extension, (alpha, gamma, beta) in signatures.items():
            source = (alpha + ' {\n  /* a misleading close: } */\n  if (true) {\n    return 1;\n  }\n}\n'
                      + gamma + ' {\n  return 1;\n}\n' + beta + ' {\n  return alpha();\n}\n')
            if extension == 'java':
                source = 'class Example {\n' + source + '}\n'
            elif extension == 'cpp':
                source = source.replace('if (true)', 'if constexpr (true)')
            elif extension == 'go':
                source = source.replace('if (true)', 'if check()')
            write('body.' + extension, source)
        write('quoted.ts', 'export function quoted() {\n  const text = "}";\n  const pattern = /[{}]/;\n  if (text) {\n    return 1;\n  }\n}\nexport function caller() { return quoted(); }\n')
        write('body_only.ts', 'export function alpha() {\n  return 1;\n}\nexport function beta() {\n  return alpha();\n}\n')
        write('receiver.go', 'func (r Receiver) method() int {\n  if true {\n    return 1\n  }\n  return 0\n}\nfunc caller() int { return r.method() }\n')
        write('ambiguous.ts', 'export function unfinished() {\n  return 1;\n')
        git('add', '.'); git('commit', '-qm', 'brace baseline')
        base = git('rev-parse', 'HEAD'); text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join('REV_BASE=' + base if s.startswith('REV_BASE=') else s for s in text.splitlines()) + '\n')
        for name in [*('body.' + extension for extension in signatures), 'quoted.ts', 'body_only.ts', 'receiver.go', 'ambiguous.ts']:
            write(name, (root / name).read_text().replace('return 1', 'return 2'))
        prepare(); facts = json.loads((session / 'r1-evidence.json').read_text())
        for extension in signatures:
            path = 'body.' + extension
            actual = {s['name'] for s in facts['symbols'] if s['path'] == path}
            assert actual == {'alpha', 'gamma'}, (path, actual)
            assert len([h for h in facts['hunks'] if h['path'] == path]) == 1, path
            expected_line = (root / path).read_text().splitlines().index('  return alpha();') + 1
            assert any(c['path'] == path and c['name'] == 'alpha' and c['line'] == expected_line for c in facts['call_sites']), path
        assert {s['name'] for s in facts['symbols'] if s['path'] == 'quoted.ts'} == {'quoted'}
        assert any(c['path'] == 'quoted.ts' and c['name'] == 'quoted' and c['line'] == 8 for c in facts['call_sites'])
        assert {s['name'] for s in facts['symbols'] if s['path'] == 'body_only.ts'} == {'alpha'}
        assert any(c['path'] == 'body_only.ts' and c['name'] == 'alpha' and c['line'] == 5 for c in facts['call_sites'])
        assert {s['name'] for s in facts['symbols'] if s['path'] == 'receiver.go'} == {'method'}
        assert any(c['path'] == 'receiver.go' and c['name'] == 'method' and c['line'] == 7 for c in facts['call_sites'])
        assert any(s['path'] == 'ambiguous.ts' and s['name'] is None for s in facts['symbols'])

def wallet_scale():
    with fixture() as (root, session, git, write, call, prepare, finish):
        for i in range(1600):
            write(f'src/unchanged_{i}.py', ''.join(f'value_{j} = "unique_{i}_{j}_stable_payload"\n' for j in range(120)))
        source = ''.join(f'def changed_{i}():\n    return 1\n\n' for i in range(500))
        write('main.py', source); git('add', '.'); git('commit', '-qm', 'large baseline')
        base = git('rev-parse', 'HEAD'); text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join('REV_BASE=' + base if s.startswith('REV_BASE=') else s for s in text.splitlines()) + '\n')
        write('main.py', source.replace('return 1', 'return 2'))
        gitbin = subprocess.check_output(['which', 'git'], text=True).strip()
        bindir = session / 'bin'; bindir.mkdir(); log = session / 'git-calls.log'
        wrapper = bindir / 'git'; wrapper.write_text('#!/bin/sh\nprintf "%s\\n" "$*" >> "$EVIDENCE_GIT_LOG"\nexec ' + shlex.quote(gitbin) + ' "$@"\n'); wrapper.chmod(0o755)
        env = dict(os.environ, PATH=str(bindir) + os.pathsep + os.environ['PATH'], EVIDENCE_GIT_LOG=str(log))
        started = time.monotonic(); prepare(env=env, timeout=25); elapsed = time.monotonic() - started
        calls = log.read_text().splitlines()
        assert sum('hash-object' in line for line in calls) <= 2, 'worktree hashing must use bounded raw batches'
        assert len(calls) < 100, ('nonlinear Git calls', len(calls))
        objects = [p for p in (session / 'evidence-objects').rglob('*') if p.is_file()]
        assert len(objects) < 20 and sum(p.stat().st_size for p in objects) < 100000
        facts = json.loads((session / 'r1-evidence.json').read_text())
        assert len({s['name'] for s in facts['symbols'] if s['path'] == 'main.py'}) == 500
        print(f'SCALE files=1603 symbols=500 elapsed={elapsed:.2f}s git_calls={len(calls)} objects={len(objects)}')

def literal_scope_and_inventories():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('inside/a.py', 'value = 1\n'); write('outside.py', 'SIBLING_SECRET = 1\n')
        git('add', '.'); git('commit', '-qm', 'path base')
        base = git('rev-parse', 'HEAD')
        write('inside/a.py', 'value = 2\n'); write('inside/new.py', 'new = 1\n')
        write('outside.py', 'SIBLING_SECRET = 2\n'); write('outside-new.py', 'UNTRACKED_SECRET = 3\n')
        git('add', 'outside.py'); git('commit', '-qm', 'out of scope commit')
        (session / 'scope.env').write_text(''.join(k + '=' + shlex.quote(v) + '\n' for k, v in [('REV_BASE', base), ('REV_ROOT', str(root)), ('REV_SCOPE', 'inside')]))
        (session / 'files.txt').write_text('inside/a.py\ninside/new.py\n'); (session / 'untracked.txt').write_text('inside/new.py\n')
        m = prepare()
        for p in session.glob('r1-*'):
            assert b'SIBLING_SECRET' not in p.read_bytes() and b'outside-new.py' not in p.read_bytes(), p
        assert 'files.txt' in m['inputs'] and 'untracked.txt' in m['inputs']
        (session / 'files.txt').write_text('inside/a.py\n')
        call('render', session / 'r1-evidence.manifest.json', 'sol', good=False)

def sparse_gitlink_and_special():
    with fixture() as (root, session, git, write, call, prepare, finish):
        git('update-index', '--skip-worktree', 'test_calls.py'); (root / 'test_calls.py').unlink()
        prepare(); assert 'test_calls.py' not in (session / 'r1-full.patch').read_text()
        git('update-index', '--no-skip-worktree', 'test_calls.py')
        prepare('2'); assert 'deleted file mode' in (session / 'r2-full.patch').read_text()
        (root / 'main.py').unlink(); os.mkfifo(root / 'main.py')
        call('prepare', session, 'special', '--phase', 'discovery', good=False)
        assert not list(session.glob('rspecial-*'))
    with fixture() as (root, session, git, write, call, prepare, finish):
        pointer = git('rev-parse', 'HEAD')
        git('update-index', '--add', '--cacheinfo', '160000', pointer, 'module')
        prepare(); patch = (session / 'r1-full.patch').read_text()
        assert 'module' in patch and 'Subproject commit ' + pointer in patch
        finish()

def roster_bundle_coverage():
    for count in (3, 5):
        with fixture() as (root, session, git, write, call, prepare, finish):
            panel = ['sol', 'terra', 'opus'] if count == 3 else seats + ['fifth']
            (session / 'roster.json').write_text(json.dumps({'seats': [{'seat': s, 'adapter': 'agent'} for s in panel]}))
            dealt = [bundles[0] + '+' + bundles[3], bundles[1], bundles[2]] if count == 3 else bundles + [bundles[0]]
            args = [part for seat, bundle in zip(panel, dealt) for part in ('--assignment', seat + '=' + bundle)]
            m = prepare('1', 'risk', *args); finish()
            assert set(b for a in m['assignments'].values() for b in a['bundles']) == set(bundles)
            assert sum(a['full_state'] for a in m['assignments'].values()) == 1
            if count == 3:
                repeated = args[2:] + ['--assignment', panel[0] + '=' + bundles[0], '--assignment', panel[0] + '=' + bundles[3]]
                again = prepare('repeated', 'risk', *repeated)
                assert again['assignments'][panel[0]]['bundles'] == [bundles[0], bundles[3]]
                assert again['assignments'][panel[0]]['bundle'] == bundles[0] + '+' + bundles[3]
    with fixture() as (root, session, git, write, call, prepare, finish):
        (session / 'roster.json').write_text(json.dumps({'seats': [{'seat': 'sol', 'adapter': 'agent'}]}))
        call('prepare', session, 'too-small', '--phase', 'discovery', good=False)
    with fixture() as (root, session, git, write, call, prepare, finish):
        skewed = [bundles[0] + '+' + bundles[1], bundles[2], bundles[3], bundles[0]]
        args = [part for seat, bundle in zip(seats, skewed) for part in ('--assignment', seat + '=' + bundle)]
        call('prepare', session, 'skewed', '--phase', 'risk', *args, good=False)

def source_context_packets():
    with fixture(adapter='codex') as (root, session, git, write, call, prepare, finish):
        write('main.py',
              'def first(value):\n    return value + 1\n\n'
              'def second(value):\n    return value + 2\n\n'
              'class Alternate:\n'
              '    def first(self, value):\n'
              '        return value + 3\n')
        write('consumer.py',
              'from main import first, second\n\n'
              'def use_first():\n    return first(4)\n\n'
              'def use_second():\n    return second(5)\n')
        write('tests/test_main.py',
              'from main import first, second\n\n'
              'def test_first():\n    assert first(1) == 2\n\n'
              'def test_second():\n    assert second(1) == 3\n')
        write('pyproject.toml', '[tool.pytest.ini_options]\naddopts = "--strict-markers"\n')
        git('add', '.'); git('commit', '-qm', 'packet base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join('REV_BASE=' + base if row.startswith('REV_BASE=') else row for row in scope_text.splitlines()) + '\n')
        write('main.py', (root / 'main.py').read_text().replace('value + 1', 'value + 10')
              .replace('value + 2', 'value + 20').replace('value + 3', 'value + 30'))
        m = prepare(); context = m['source_context']
        assert context['schema_version'] == 3 and context['enabled'] is True and context['snapshot_tree'] == m['snapshot_tree']
        assert 'object_repository' not in context
        assert context['max_shard_bytes'] == 16384
        context_artifacts = [shard['artifact'] for packet in context['seats'].values()
                             for shard in packet['shards']]
        context_artifacts.extend(segment['artifact'] for packet in context['seats'].values()
                                 for required in packet['required_source_ranges']
                                 for segment in required['segments'])
        context_words = sum(len((session / name).read_bytes().split()) for name in context_artifacts)
        assert m['word_counts']['source_context'] == context_words
        assert m['word_counts']['avoided'] == max(
            0, len(m['assignments']) * m['word_counts']['full']
            - m['word_counts']['assigned_patch'] - len(m['assignments']) * m['word_counts']['evidence']
            - context_words)
        owner = m['mechanical_owner']
        for seat, packet in context['seats'].items():
            assert packet['role'] == ('integration' if seat == owner else 'specialist')
            assert 0 < len(packet['shards']) <= (3 if seat == owner else 1)
            for shard in packet['shards']:
                path = session / shard['artifact']; raw = path.read_bytes()
                assert shard['bytes'] == len(raw) <= 16384
                assert shard['predicted_visible_bytes'] == len(raw) + len(raw.splitlines()) * 8 <= 16384
                assert shard['sha256'] == hashlib.sha256(raw).hexdigest()
                body = json.loads(raw)
                assert body['snapshot_tree'] == m['snapshot_tree'] and body['seat'] == seat
                assert [{key: value for key, value in entry.items() if key != 'content'}
                        for entry in body['entries']] == shard['ranges']
                for entry in body['entries']:
                    assert 1 <= entry['line_start'] <= entry['line_end']
                    assert entry['component_ids'] and len(entry['hunk_binding_sha256']) == 64
                    assert 'hunk_sha256' not in entry
                    expected = ''.join((root / entry['path']).read_text().splitlines(keepends=True)[entry['line_start'] - 1:entry['line_end']])
                    assert entry['content'] == expected
        integration = [json.loads((session / shard['artifact']).read_text())
                       for shard in context['seats'][owner]['shards']]
        reasons = [reason for shard in integration for entry in shard['entries'] for reason in entry['reasons']]
        assert all(len(entry['reasons']) == len(set(entry['reasons']))
                   for shard in integration for entry in shard['entries'])
        assert {'declaration:first', 'declaration:second'} <= set(reasons)
        assert {'production-caller:first', 'production-caller:second'} <= set(reasons)
        assert any(reason.startswith('related-test:') for reason in reasons)
        assert any(reason.startswith('gate:') for reason in reasons)
        prompt = call('render', session / 'r1-evidence.manifest.json', owner)
        assert 'Source context enabled: true' in prompt and 'Source context packet:' in prompt and 'Source read required:' in prompt
        assert ('Read the entire assigned patch in bounded windows of at most 160 lines, '
                + f"ending at line {m['assignments'][owner]['patch_lines']}: ") in prompt
        old = module.Repository
        try:
            module.Repository = lambda *_: (_ for _ in ()).throw(AssertionError('offline source-context validation used Git'))
            module.validated_manifest(session / 'r1-evidence.manifest.json', fresh=False, offline=True)
        finally:
            module.Repository = old
        manifest_path = session / 'r1-evidence.manifest.json'
        call('verify', manifest_path)
        call('render', manifest_path, owner, '--offline')
        source_before = (root / 'main.py').read_text()
        write('main.py', source_before + '# changed after verification\n')
        call('render', manifest_path, owner, '--offline')
        call('verify', manifest_path, good=False)
        write('main.py', source_before)

        evidence_path = session / 'r1-evidence.json'
        original = {path: path.read_bytes() for path in session.glob('r1-*')}
        def restore():
            for path, raw in original.items(): path.write_bytes(raw)
        def reseal(transform):
            manifest = json.loads(manifest_path.read_text()); evidence = json.loads(evidence_path.read_text())
            seat = owner; shard_meta = manifest['source_context']['seats'][seat]['shards'][0]
            artifact = session / shard_meta['artifact']; payload = json.loads(artifact.read_text())
            metadata_update = transform(manifest, payload) or {}
            artifact.write_bytes(module.encoded(payload))
            shard_meta = manifest['source_context']['seats'][seat]['shards'][0]
            shard_meta.update(sha256=module.digest(artifact.read_bytes()), bytes=len(artifact.read_bytes()),
                              predicted_visible_bytes=(len(artifact.read_bytes())
                                                       + len(artifact.read_bytes().splitlines()) * 8),
                              ranges=[{key: value for key, value in entry.items() if key != 'content'}
                                      for entry in payload['entries']], entries=len(payload['entries']))
            shard_meta.update(metadata_update)
            evidence['source_context'] = manifest['source_context']
            evidence_path.write_bytes(module.encoded(evidence))
            manifest['artifacts'][artifact.name] = {'sha256': module.digest(artifact.read_bytes()),
                                                    'words': len(artifact.read_bytes().split())}
            manifest['artifacts'][evidence_path.name] = {'sha256': module.digest(evidence_path.read_bytes()),
                                                        'words': len(evidence_path.read_bytes().split())}
            manifest_path.write_bytes(module.encoded(manifest))

        def replace_content_with_valid_hash(manifest, payload):
            entry = payload['entries'][0]
            original = entry['content']
            replacement = ('X' if original[:1] != 'X' else 'Y') + original[1:]
            entry.update(content=replacement, content_sha256=module.digest(replacement.encode()))

        mutations = [
            lambda m, p: {'predicted_visible_bytes': 0},
            lambda m, p: p['entries'][0].update(path='../escape.py'),
            lambda m, p: p['entries'][0].update(line_start=p['entries'][0]['line_end'] + 1),
            lambda m, p: p['entries'][0].update(content=p['entries'][0]['content'][:-1]),
            lambda m, p: p['entries'][0].update(component_ids=[]),
            lambda m, p: p['entries'][0].update(hunk_binding_sha256='0' * 64),
            lambda m, p: p['entries'][0].update(blob_oid='0' * 40),
            replace_content_with_valid_hash,
            lambda m, p: p['entries'].reverse(),
            lambda m, p: p['entries'][0].update(content='x' * 40000),
        ]
        for mutation in mutations:
            restore(); reseal(mutation)
            call('render', manifest_path, owner, good=False)
        restore()
        source_path = session / context['seats'][owner]['shards'][0]['artifact']
        source_path.write_text(source_path.read_text() + ' ')
        call('render', manifest_path, owner, good=False)

    with fixture() as (root, session, git, write, call, prepare, finish):
        disabled_env = dict(os.environ, REV_SOURCE_CONTEXT='0')
        call('prepare', session, 'disabled', '--phase', 'discovery', env=disabled_env)
        m = json.loads((session / 'rdisabled-evidence.manifest.json').read_text())
        assert m['source_context']['enabled'] is False
        assert m['components'] and any(a['scope'] == 'semantic' for a in m['assignments'].values())
        assert m['word_counts']['source_context'] == 0
        assert all(not packet['shards'] and packet['source_read_required']
                   for packet in m['source_context']['seats'].values())
        assert not list(session.glob('rdisabled-*-source-context-*.json'))
        prompt = call('render', session / 'rdisabled-evidence.manifest.json', 'sol')
        assert 'Source context enabled: false' in prompt
        assert 'Source context packet:' not in prompt and 'Source read required: true' in prompt
        bad_env = dict(os.environ, REV_SOURCE_CONTEXT='maybe')
        call('prepare', session, 'badflag', '--phase', 'discovery', env=bad_env, good=False)

def provider_visible_source_packet_limit():
    for content in ('', 'plain', '"\\', '\b\f\n\r\t', ''.join(map(chr, range(32))),
                    '\x7f', '\u00e9\u6f22\U0001f600'):
        options = {'sort_keys': True, 'ensure_ascii': True, 'indent': 2}
        assert module.json_content_bytes(content) == len(json.dumps(content, **options).encode()) - 2
        payload = {'schema_version': 1, 'snapshot_tree': '1' * 40, 'base_tree': '2' * 40,
                   'seat': 'sol', 'shard_index': 1, 'shard_count': 3,
                   'entries': [{'content': content, 'path': 'main.py'}]}
        raw = (json.dumps(payload, **options) + '\n').encode()
        measured = module.source_payload_metrics(
            '1' * 40, '2' * 40, 'sol', 1, 3, [{'content': '', 'path': 'main.py'}],
            module.json_content_bytes(content))
        assert measured == (len(raw), len(raw) + len(raw.splitlines()) * 8)

    class Repo:
        def __init__(self, raw):
            self.raw = raw
        def entries(self, tree):
            return {'main.py': ('100644', 'a' * 40)}
        def blob(self, entry):
            return self.raw

    raw = ('def boundary():\n' + ''.join(
        f'    value_{index} = "' + 'x' * 80 + '"\n' for index in range(313))).encode()
    evidence = {
        'hunks': [{'path': 'main.py', 'sha256': 'b' * 64}],
        'symbols': [{'path': 'main.py', 'line': 1, 'line_end': 314,
                     'name': 'boundary', 'blob_tree': '1' * 40}],
        'call_sites': [], 'related_tests': [], 'gates': [], 'unresolved_imports': [],
    }
    components = [{'id': 'component', 'files': ['main.py'], 'boundary': ['main.py']}]
    assignments = {'sol': {'components': ['component'], 'adapter': 'codex'}}
    context, artifacts = module.source_context(
        Repo(raw), '1' * 40, '2' * 40, evidence, components, assignments, 'sol', 'r1')
    packet = context['seats']['sol']
    assert not packet['shards']
    required = packet['required_source_ranges']
    assert len(required) == 1
    required = required[0]
    entry = {key: value for key, value in required.items()
             if key not in ('required_payload_bytes', 'required_payload_predicted_visible_bytes',
                            'segments')}
    entry['content'] = raw.decode()
    candidate = module.encoded({
        'schema_version': 1, 'snapshot_tree': '1' * 40, 'base_tree': '2' * 40,
        'seat': 'sol', 'shard_index': 1, 'shard_count': 3, 'entries': [entry],
    })
    rendered_bytes = len(candidate) + len(candidate.splitlines()) * 8
    assert len(candidate) == required['required_payload_bytes'] <= 32768
    assert rendered_bytes == required['required_payload_predicted_visible_bytes'] > 32768
    assert b''.join(artifacts[segment['artifact']] for segment in required['segments']) == raw
    with tempfile.TemporaryDirectory(prefix='provider-visible-packet-') as tmp:
        session = Path(tmp)
        for name, content in artifacts.items():
            (session / name).write_bytes(content)
        manifest = {
            'source_context': context, 'snapshot_tree': '1' * 40, 'base_tree': '2' * 40,
            'assignments': assignments, 'components': components, 'mechanical_owner': 'sol',
            'label': '1', 'phase': 'discovery', 'scope': '.',
        }
        evidence['source_context'] = context
        module.validate_source_context(session, manifest, evidence)
        module.validate_source_context_bytes(Repo(raw), session, manifest)

def source_context_prefers_named_production_and_maps_gates():
    class Repo:
        def __init__(self, bodies):
            self.bodies = bodies
        def entries(self, tree):
            return {path: ('100644', hashlib.sha1(body).hexdigest())
                    for path, body in self.bodies.items()}
        def blob(self, entry):
            return next(body for body in self.bodies.values()
                        if hashlib.sha1(body).hexdigest() == entry[1])

    bodies = {
        'docs/notes.md': (('background ' + 'x' * 70 + '\n') * 360).encode(),
        'src/main.py': ('def important():\n' + ''.join(
            f'    value_{index} = "' + 'x' * 70 + '"\n' for index in range(500))
            + '    return value_499\n').encode(),
        'src/caller.py': b'from main import important\n\ndef use():\n    return important()\n',
        'tests/test_main.py': b'from main import important\n\ndef test_it():\n    assert important()\n',
        'pyproject.toml': b'[tool.pytest.ini_options]\naddopts = "-q"\n',
        'global.cfg': b'check = true\n',
    }
    evidence = {
        'hunks': [
            {'path': 'src/main.py', 'sha256': '1' * 64},
            {'path': 'src/other.py', 'sha256': '2' * 64},
        ],
        'symbols': [
            {'path': 'docs/notes.md', 'line': 1, 'line_end': 360, 'name': None,
             'blob_tree': 'a' * 40},
            {'path': 'src/main.py', 'line': 1, 'line_end': 502, 'name': 'important',
             'blob_tree': 'a' * 40},
        ],
        'call_sites': [
            {'path': 'src/caller.py', 'line': 4, 'name': 'important'},
            {'path': 'tests/test_main.py', 'line': 4, 'name': 'important'},
        ],
        'related_tests': [{'path': 'tests/test_main.py'}],
        'gates': [
            {'path': 'pyproject.toml', 'line': 2},
            {'path': 'global.cfg', 'line': 1},
        ],
        'unresolved_imports': [],
    }
    components = [
        {'id': 'main', 'files': ['src/main.py'],
         'boundary': ['docs/notes.md', 'src/main.py', 'src/caller.py',
                      'tests/test_main.py', 'pyproject.toml']},
        {'id': 'other', 'files': ['src/other.py'], 'boundary': ['src/other.py']},
    ]
    assignments = {
        'owner': {'components': ['main', 'other'], 'adapter': 'codex'},
        'specialist': {'components': ['main', 'other'], 'adapter': 'codex'},
    }
    with tempfile.TemporaryDirectory(prefix='source-ranking-') as tmp:
        context, artifacts = module.source_context(
            Repo(bodies), 'a' * 40, 'b' * 40, evidence, components,
            assignments, 'owner', 'r1')
        packet = context['seats']['specialist']
        assert len(packet['shards']) == 1
        artifact = artifacts[packet['shards'][0]['artifact']]
        entries = json.loads(artifact)['entries']
        reasons = [reason for entry in entries for reason in entry['reasons']]
        assert 'production-caller:important' in reasons or any(
            reason.startswith('related-test:') for reason in reasons), reasons
        useful = min(index for index, reason in enumerate(reasons)
                     if reason == 'production-caller:important'
                     or reason.startswith('related-test:'))
        assert 'declaration:changed-line-anchor' not in reasons[:useful], reasons
        all_entries = []
        for seat_packet in context['seats'].values():
            for shard in seat_packet['shards']:
                all_entries.extend(json.loads(artifacts[shard['artifact']])['entries'])
            all_entries.extend(seat_packet['required_source_ranges'])
        mapped = next(entry for entry in all_entries
                      if 'gate:pyproject.toml:2' in entry['reasons'])
        global_gate = next(entry for entry in all_entries
                           if 'gate:global.cfg:1' in entry['reasons'])
        assert mapped['component_ids'] == ['main'], mapped
        assert global_gate['component_ids'] == ['main', 'other'], global_gate

def local_names_do_not_expand_cross_file_proof():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('src/history.ts',
              'export const readHistory = (input: number) => {\n'
              '  const row = input + 1;\n'
              '  const page = row + 1;\n'
              '  return page;\n'
              '};\n')
        write('tsconfig.json', '{"compilerOptions":{"baseUrl":"src"},"include":["src","tests"]}\n')
        write('tsconfig-utility.json',
              '{"compilerOptions":{"baseUrl":"utility"},"include":["src","utility"]}\n')
        write('utility/history.ts', 'export const readHistory = () => 999;\n')
        write('src/consumer.ts',
              'import { readHistory } from "history";\n'
              'export const consumeHistory = () => readHistory(1);\n')
        write('src/unrelated.ts',
              'export const unrelated = () => {\n'
              '  const row = 1;\n'
              '  const page = row + 1;\n'
              '  return page;\n'
              '};\n')
        write('tests/history.test.ts',
              'import { readHistory } from "history";\n'
              'test("reads history", () => expect(readHistory(1)).toBe(3));\n')
        write('tests/unrelated.test.ts',
              'const page = 1;\n'
              'test("uses a local page", () => expect(page).toBe(1));\n')
        write('docs/notes.md', 'row page value are common words in this design note.\n')
        git('add', '.'); git('commit', '-qm', 'proof scope base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.ts', (root / 'src/history.ts').read_text().replace(
            'const page = row + 1;', 'const page = row + 2;'))

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        public = next(row for row in facts['symbols'] if row['name'] == 'readHistory')
        assert public['cross_file'] is True, public
        assert any(row['name'] == 'page' and row['cross_file'] is False for row in facts['symbols'])
        assert any(row['path'] == 'src/consumer.ts' and row['name'] == 'readHistory'
                   for row in facts['call_sites'])
        assert any(row['source'] == 'src/consumer.ts' and row['target'] == 'utility/history.ts'
                   and row['kind'] == 'ambiguous-import'
                   for row in facts['dependencies']), facts['dependencies']
        assert not any(row['source'] == 'src/consumer.ts' and row['target'] == 'utility/history.ts'
                       and row['kind'] == 'lexical-reference'
                       for row in facts['dependencies']), facts['dependencies']
        assert any(row.get('path') == 'src/consumer.ts'
                   and {'src/history.ts', 'utility/history.ts'} <= set(row.get('candidate_targets', []))
                   for row in facts['unresolved_imports']), facts['unresolved_imports']
        assert any(row['path'] == 'tests/history.test.ts' for row in facts['related_tests'])
        assert not any(row['path'] in {'src/unrelated.ts', 'tests/unrelated.test.ts', 'docs/notes.md'}
                       for row in facts['call_sites'] + facts['related_tests'])
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        assert 'src/consumer.ts' in proof_paths and 'tests/history.test.ts' in proof_paths, proof_paths
        assert not proof_paths & {'src/unrelated.ts', 'tests/unrelated.test.ts', 'docs/notes.md'}, proof_paths

def wildcard_reexports_use_exact_source_proof():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('src/history-implementation.ts',
              'export const readHistory = (input: number) => {\n'
              '  const page = input + 1;\n'
              '  return page;\n'
              '};\n')
        write('src/history/index.ts', '// retain the route line after a header\n'
              'export *\n  from "../history-exports";\n'
              + '// unrelated barrel content\n' * 80)
        write('src/history-exports.ts',
              'export * from "./history-implementation";\n')
        write('src/consumer.ts',
              'import { readHistory } from "./history";\n'
              'export const consumeHistory = () => readHistory(1);\n')
        git('add', '.'); git('commit', '-qm', 'wildcard re-export base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history-implementation.ts',
              (root / 'src/history-implementation.ts').read_text().replace(
                  'input + 1', 'input + 2'))

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/consumer.ts')
        assert not any(row['path'] == 'src/history/index.ts'
                       for row in obligation['candidate_search_ranges']), obligation
        assert any(row == {'path': 'src/history/index.ts', 'line_start': 2,
                           'line_end': 2, 'name': 'readHistory',
                           'blob_tree': manifest['snapshot_tree']}
                   for row in obligation['candidate_route_symbols']), obligation
        assert any(row == {'path': 'src/history-exports.ts', 'line_start': 1,
                           'line_end': 1, 'name': 'readHistory',
                           'blob_tree': manifest['snapshot_tree']}
                   for row in obligation['candidate_route_symbols']), obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        assert {'src/history/index.ts', 'src/history-exports.ts'} <= proof_paths, proof_paths
        proof_ranges = [row for packet in manifest['source_context']['seats'].values()
                        for shard in packet['shards'] for row in shard['ranges']]
        proof_ranges.extend(required
                            for packet in manifest['source_context']['seats'].values()
                            for required in packet['required_source_ranges'])
        assert any(row['path'] == 'src/history/index.ts'
                   and row['line_start'] <= 2 <= row['line_end']
                   and row['blob_tree'] == manifest['snapshot_tree'] for row in proof_ranges), proof_ranges
        assert any(row['path'] == 'src/history-exports.ts'
                   and row['line_start'] <= 1 <= row['line_end']
                   and row['blob_tree'] == manifest['snapshot_tree'] for row in proof_ranges), proof_ranges

def wildcard_reexport_syntax_preserves_start_lines():
    assert module.ts_wildcard_references([
        'export * from "../single-implementation";',
        '// line before the multiline route',
        'export *',
        '  from "../multiline-implementation";',
    ]) == [(1, '../single-implementation'), (3, '../multiline-implementation')]
    assert module.ts_wildcard_references(module.split_lf_text(
        'export * from "../single-crlf-implementation";\r\n'
        '// line before the multiline CRLF route\r\n'
        'export *\r\n'
        '  from "../multiline-crlf-implementation";\r\n'
    )) == [(1, '../single-crlf-implementation'), (3, '../multiline-crlf-implementation')]

def rust_use_imports_keep_cross_file_callers():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('Cargo.toml', '[package]\nname = "fixture_wallet"\nversion = "0.1.0"\n')
        write('src/lib.rs', 'pub mod consumer;\npub mod history;\n')
        write('src/history.rs', 'pub fn read_history() -> usize { 1 }\n')
        write('src/consumer.rs',
              'use crate::history::read_history;\n'
              'pub fn consume_history() -> usize { read_history() }\n')
        git('add', '.'); git('commit', '-qm', 'rust import base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.rs', 'pub fn read_history() -> usize { 2 }\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        assert any(row['path'] == 'src/consumer.rs' and row['name'] == 'read_history'
                   for row in facts['call_sites']), facts['call_sites']
        assert any(row['source'] == 'src/consumer.rs' and row['target'] == 'src/history.rs'
                   and row['kind'] == 'local-import' for row in facts['dependencies']), facts['dependencies']
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        assert 'src/consumer.rs' in proof_paths, proof_paths

def rust_grouped_use_alias_is_a_capacity_counted_obligation():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('Cargo.toml', '[package]\nname = "fixture_wallet"\nversion = "0.1.0"\n')
        write('src/lib.rs', 'pub mod consumer;\npub mod history;\n')
        write('src/history.rs', 'pub fn read_history() -> usize { 1 }\n')
        write('src/consumer.rs',
              'use crate::{history::read_history /* , } note */ as load_history};\n'
              'pub fn consume_history() -> usize { load_history() }\n')
        git('add', '.'); git('commit', '-qm', 'grouped rust import base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.rs', 'pub fn read_history() -> usize { 2 }\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        call_site = next(row for row in facts['call_sites']
                         if row['path'] == 'src/consumer.rs' and row['name'] == 'read_history')
        assert call_site['local_name'] == 'load_history', call_site
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/consumer.rs')
        assert obligation['imported_name'] == 'read_history', obligation
        assert obligation['local_name'] == 'load_history', obligation
        assert obligation['line_start'] == 1 and obligation['line_end'] == 1, obligation
        assert any(row['path'] == 'src/history.rs' and row['name'] == 'read_history'
                   for row in obligation['candidate_symbols']), obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        proof_paths.update(row['path']
                           for capacity in manifest['task_capacity']['seats'].values()
                           for row in capacity['mandatory_window_rows'])
        assert {'src/consumer.rs', 'src/history.rs'} <= proof_paths, proof_paths

def ts_default_import_alias_is_a_capacity_counted_obligation():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('src/history.ts',
              'export default function readHistory() { return 1; }\n')
        write('src/consumer.ts',
              'import loadHistory from "./history";\n'
              'export function consumeHistory() { return loadHistory(); }\n')
        git('add', '.'); git('commit', '-qm', 'default import base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.ts',
              'export default function readHistory() { return 2; }\n')

        manifest = prepare('default-import')
        facts = json.loads((session / 'rdefault-import-evidence.json').read_text())
        call_site = next(row for row in facts['call_sites']
                         if row['path'] == 'src/consumer.ts' and row['name'] == 'readHistory')
        assert call_site['local_name'] == 'loadHistory', call_site
        assert call_site['import_line_start'] == 1, call_site
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/consumer.ts')
        assert obligation['imported_name'] == 'default', obligation
        assert obligation['local_name'] == 'loadHistory', obligation
        assert any(row['path'] == 'src/history.ts' and row['name'] == 'readHistory'
                   for row in obligation['candidate_symbols']), obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        proof_paths.update(row['path']
                           for capacity in manifest['task_capacity']['seats'].values()
                           for row in capacity['mandatory_window_rows'])
        assert {'src/consumer.ts', 'src/history.ts'} <= proof_paths, proof_paths

def rust_module_alias_and_self_import_keep_qualified_callers():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('Cargo.toml', '[package]\nname = "fixture_wallet"\nversion = "0.1.0"\n')
        write('src/lib.rs', 'pub mod alias_consumer;\npub mod self_consumer;\npub mod history;\n')
        write('src/history.rs', 'pub fn read_history() -> usize { 1 }\n')
        write('src/alias_consumer.rs',
              'use crate::history as h;\n'
              'pub fn consume_history() -> usize { h::read_history() }\n')
        write('src/self_consumer.rs',
              'use crate::history::{self};\n'
              'pub fn consume_history() -> usize { history::read_history() }\n')
        git('add', '.'); git('commit', '-qm', 'rust module import base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.rs', 'pub fn read_history() -> usize { 2 }\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        for path, alias in [('src/alias_consumer.rs', 'h::read_history'),
                            ('src/self_consumer.rs', 'history::read_history')]:
            assert any(row['path'] == path and row['name'] == 'read_history'
                       and row.get('local_name') == alias for row in facts['call_sites']), facts['call_sites']
            assert any(row['source'] == path and row['target'] == 'src/history.rs'
                       for row in facts['dependencies']), facts['dependencies']
        rust_candidates = [target for row in facts['unresolved_imports']
                           for target in row.get('candidate_targets', [])]
        assert rust_candidates and all((root / target).is_file()
                                       for target in rust_candidates), facts['unresolved_imports']
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        assert {'src/alias_consumer.rs', 'src/self_consumer.rs'} <= proof_paths, proof_paths

def rust_grouped_root_reexport_is_a_capacity_counted_obligation():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('Cargo.toml', '[package]\nname = "fixture_wallet"\nversion = "0.1.0"\n')
        write('src/lib.rs', 'pub mod history;\npub use history::read_history;\n')
        write('src/history.rs', 'pub fn read_history() -> usize { 1 }\n')
        write('src/consumer.rs',
              'use crate::{read_history as load_history};\n'
              'pub fn consume_history() -> usize { load_history() }\n')
        git('add', '.'); git('commit', '-qm', 'rust grouped root import base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.rs', 'pub fn read_history() -> usize { 2 }\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        call_site = next(row for row in facts['call_sites']
                         if row['path'] == 'src/consumer.rs' and row['name'] == 'read_history')
        assert call_site['local_name'] == 'load_history', call_site
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/consumer.rs')
        assert obligation['imported_name'] == 'read_history', obligation
        assert 'src/lib.rs' in {row['path'] for row in obligation['candidate_search_ranges']}, obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        proof_paths.update(row['path']
                           for capacity in manifest['task_capacity']['seats'].values()
                           for row in capacity['mandatory_window_rows'])
        assert {'src/consumer.rs', 'src/lib.rs', 'src/history.rs'} <= proof_paths, proof_paths

def ts_namespace_alias_missing_target_is_a_capacity_counted_obligation():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('tsconfig.json',
              '{\n  "compilerOptions": {\n    "baseUrl": ".",\n'
              '    "paths": { "@history": ["missing/history"] }\n  }\n}\n')
        write('src/history.ts', 'export const readHistory = () => 1;\n')
        write('src/consumer.ts',
              'import * as history from "@history";\n'
              'export const consumeHistory = () => history.readHistory();\n')
        git('add', '.'); git('commit', '-qm', 'namespace path import base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.ts', 'export const readHistory = () => 2;\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        call_site = next(row for row in facts['call_sites']
                         if row['path'] == 'src/consumer.ts' and row['name'] == 'readHistory')
        assert call_site['local_name'] == 'history.readHistory', call_site
        assert call_site['resolution'] == 'unresolved import search required', call_site
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/consumer.ts')
        assert obligation['reference'] == '@history', obligation
        assert any(row['path'] == 'src/history.ts' and row['name'] == 'readHistory'
                   for row in obligation['candidate_symbols']), obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        proof_paths.update(row['path']
                           for capacity in manifest['task_capacity']['seats'].values()
                           for row in capacity['mandatory_window_rows'])
        assert {'src/consumer.ts', 'src/history.ts', 'tsconfig.json'} <= proof_paths, proof_paths

def coexisting_ts_projects_are_explicitly_ambiguous_with_matching_base_url():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('tsconfig.json',
              '{\n  "compilerOptions": {\n    "baseUrl": ".",\n'
              '    "paths": { "@history": ["src/history"] }\n  }\n}\n')
        write('src/tsconfig.json',
              '{\n  "compilerOptions": {\n    "baseUrl": "../",\n'
              '    "paths": { "@history": ["missing/history"] }\n  },\n'
              '  "include": ["consumer.ts"]\n}\n')
        write('src/history.ts', 'export const readHistory = () => 1;\n')
        write('src/consumer.ts',
              'import { readHistory } from "@history";\n'
              'export const consumeHistory = () => readHistory();\n')
        git('add', '.'); git('commit', '-qm', 'coexisting ts projects base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.ts', 'export const readHistory = () => 2;\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/consumer.ts')
        assert obligation['candidate_targets'] == ['src/history.ts'], obligation
        assert {row['path'] for row in obligation['config_ranges']} == {
            'tsconfig.json', 'src/tsconfig.json'}, obligation
        assert any(row['kind'] == 'ambiguous-import' and row['source'] == 'src/consumer.ts'
                   and row['target'] == 'src/history.ts' for row in facts['dependencies']), facts['dependencies']
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        assert {'src/consumer.ts', 'src/history.ts', 'tsconfig.json', 'src/tsconfig.json'} <= proof_paths, proof_paths

def ambiguous_ts_configs_are_explicit_search_obligations():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('tsconfig.json',
              '{"compilerOptions":{"baseUrl":"src"},"include":["src"]}\n')
        write('src/tsconfig-alt.json',
              '{"compilerOptions":{"baseUrl":"../lib"},"include":["*.ts"]}\n')
        write('src/history.ts', 'export const readHistory = () => 1;\n')
        write('lib/history.ts', 'export const readHistory = () => 2;\n')
        write('src/consumer.ts',
              'import { readHistory } from "history";\n'
              'export const consumeHistory = () => readHistory();\n')
        git('add', '.'); git('commit', '-qm', 'ambiguous config base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.ts', 'export const readHistory = () => 3;\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/consumer.ts')
        assert set(obligation['candidate_targets']) == {
            'src/history.ts', 'lib/history.ts'}, obligation
        assert any(row['source'] == 'src/consumer.ts' and row['target'] == 'src/history.ts'
                   and row['kind'] == 'ambiguous-import' for row in facts['dependencies']), facts['dependencies']
        assert any(row['source'] == 'src/consumer.ts' and row['target'] == 'lib/history.ts'
                   and row['kind'] == 'ambiguous-import' for row in facts['dependencies']), facts['dependencies']
        assert any(row['path'] == 'src/consumer.ts' and row['name'] == 'readHistory'
                   for row in facts['call_sites']), facts['call_sites']
        assert any(row['path'] == 'src/consumer.ts' and row.get('resolution') ==
                   'unresolved import search required' for row in facts['call_sites']), facts['call_sites']
        assert {row['path'] for row in obligation['config_ranges']} == {
            'tsconfig.json', 'src/tsconfig-alt.json'}, obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        proof_paths.update(row['path']
                           for capacity in manifest['task_capacity']['seats'].values()
                           for row in capacity['mandatory_window_rows'])
        assert any(row['path'] == 'lib/history.ts'
                   for row in obligation['candidate_symbols']), obligation
        assert {'src/consumer.ts', 'src/history.ts', 'lib/history.ts',
                'tsconfig.json', 'src/tsconfig-alt.json'} <= proof_paths, proof_paths
        proof_ranges = [row for packet in manifest['source_context']['seats'].values()
                        for shard in packet['shards'] for row in shard['ranges']]
        proof_ranges.extend(row for packet in manifest['source_context']['seats'].values()
                            for row in packet['required_source_ranges'])
        proof_ranges.extend(row for capacity in manifest['task_capacity']['seats'].values()
                            for row in capacity['mandatory_window_rows'])
        assert any(row['path'] == 'lib/history.ts' and row['line_start'] <= 1 <= row['line_end']
                   for row in proof_ranges), proof_ranges
        closure = module.plan_closure_paths(
            [{'id': 'history', 'paths': [{'path': 'src/consumer.ts'}]}],
            facts['dependencies'], ['src/history.ts'])
        assert 'src/history.ts' in closure, closure

def ts_paths_alias_and_missing_targets_are_capacity_counted():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('tsconfig.json',
              '{\n  "extends": "./configs/tsconfig.base.json",\n'
              '  "include": ["src"]\n}\n')
        write('configs/tsconfig.base.json',
              '{\n  "compilerOptions": {\n    "baseUrl": "../",\n'
              '    "paths": { "@history": ["src/history"] }\n  }\n}\n')
        write('src/history.ts', 'export const readHistory = () => 1;\n')
        write('src/consumer.ts',
              'import { readHistory as loadHistory } from "@history";\n'
              'export const consumeHistory = () => loadHistory();\n')
        git('add', '.'); git('commit', '-qm', 'aliased paths import base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.ts', 'export const readHistory = () => 2;\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        call_site = next(row for row in facts['call_sites']
                         if row['path'] == 'src/consumer.ts' and row['name'] == 'readHistory')
        assert call_site['local_name'] == 'loadHistory', call_site
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/consumer.ts')
        assert obligation['imported_name'] == 'readHistory', obligation
        assert obligation['local_name'] == 'loadHistory', obligation
        assert obligation['candidate_targets'] == ['src/history.ts'], obligation
        assert {row['path'] for row in obligation['config_ranges']} == {
            'tsconfig.json', 'configs/tsconfig.base.json'}, obligation
        assert any(row['path'] == 'src/history.ts' and row['name'] == 'readHistory'
                   for row in obligation['candidate_symbols']), obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        proof_paths.update(row['path']
                           for capacity in manifest['task_capacity']['seats'].values()
                           for row in capacity['mandatory_window_rows'])
        assert {'src/consumer.ts', 'src/history.ts', 'tsconfig.json',
                'configs/tsconfig.base.json'} <= proof_paths, proof_paths

def ts_transitive_excluded_file_uses_project_path_aliases():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('tsconfig.json',
              '{\n  "extends": "./configs/tsconfig.base.json",\n'
              '  "include": ["src/main.ts"],\n'
              '  "exclude": ["src/transitive.ts"]\n}\n')
        write('configs/tsconfig.base.json',
              '{\n  "compilerOptions": {\n    "baseUrl": "../",\n'
              '    "paths": { "@history": ["src/history"] }\n  }\n}\n')
        write('src/history.ts', 'export const readHistory = () => 1;\n')
        write('src/main.ts', 'import "./transitive";\n')
        write('src/transitive.ts',
              'import { readHistory } from "@history";\n'
              'export const consumeHistory = () => readHistory();\n')
        git('add', '.'); git('commit', '-qm', 'transitive ts path import base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.ts', 'export const readHistory = () => 2;\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        assert any(row['path'] == 'src/transitive.ts' and row['name'] == 'readHistory'
                   for row in facts['call_sites']), facts['call_sites']
        assert any(row['source'] == 'src/transitive.ts' and row['target'] == 'src/history.ts'
                   for row in facts['dependencies']), facts['dependencies']
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'src/transitive.ts')
        assert obligation['candidate_targets'] == ['src/history.ts'], obligation
        assert obligation['reason'] == 'path-mapped import matching a changed export', obligation
        assert {row['path'] for row in obligation['config_ranges']} == {
            'tsconfig.json', 'configs/tsconfig.base.json'}, obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        proof_paths.update(row['path']
                           for capacity in manifest['task_capacity']['seats'].values()
                           for row in capacity['mandatory_window_rows'])
        assert {'src/transitive.ts', 'src/history.ts', 'tsconfig.json',
                'configs/tsconfig.base.json'} <= proof_paths, proof_paths

def ts_explicit_files_root_keeps_path_aliases_outside_config_and_exclude():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('configs/tsconfig.json',
              '{\n  "compilerOptions": {\n    "baseUrl": "../",\n'
              '    "paths": { "@history": ["src/history"] }\n  },\n'
              '  "files": ["../consumer.ts"],\n'
              '  "exclude": ["../consumer.ts"]\n}\n')
        write('src/history.ts', 'export const readHistory = () => 1;\n')
        write('consumer.ts',
              'import { readHistory } from "@history";\n'
              'export const consumeHistory = () => readHistory();\n')
        git('add', '.'); git('commit', '-qm', 'explicit tsconfig file root base'); base = git('rev-parse', 'HEAD')
        scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/history.ts', 'export const readHistory = () => 2;\n')

        manifest = prepare()
        facts = json.loads((session / 'r1-evidence.json').read_text())
        obligation = next(row for row in facts['unresolved_imports']
                          if row['path'] == 'consumer.ts')
        assert obligation['reference'] == '@history', obligation
        assert obligation['candidate_targets'] == ['src/history.ts'], obligation
        assert any(row['path'] == 'consumer.ts' and row['name'] == 'readHistory'
                   for row in facts['call_sites']), facts['call_sites']
        assert {row['path'] for row in obligation['config_ranges']} == {
            'configs/tsconfig.json'}, obligation
        proof_paths = {row['path'] for packet in manifest['source_context']['seats'].values()
                       for shard in packet['shards'] for row in shard['ranges']}
        proof_paths.update(required['path']
                           for packet in manifest['source_context']['seats'].values()
                           for required in packet['required_source_ranges'])
        assert {'consumer.ts', 'src/history.ts', 'configs/tsconfig.json'} <= proof_paths, proof_paths

def complete_declaration_context():
    with fixture() as (root, session, git, write, call, prepare, finish):
        body = ('def long_function():\n'
                + ''.join(f'    value_{i} = {i}\n' for i in range(100))
                + '    return value_99\n')
        write('main.py', body); git('add', '.'); git('commit', '-qm', 'long declaration base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        changed = body.replace('value_50 = 50', 'value_50 = 500'); write('main.py', changed)
        manifest = prepare(); owner = manifest['mechanical_owner']
        facts = json.loads((session / 'r1-evidence.json').read_text())
        symbol = next(row for row in facts['symbols'] if row['name'] == 'long_function')
        assert symbol['line'] == 1 and symbol['line_end'] == 102
        entries = [entry for shard in manifest['source_context']['seats'][owner]['shards']
                   for entry in json.loads((session / shard['artifact']).read_text())['entries']]
        declaration = next(entry for entry in entries if 'declaration:long_function' in entry['reasons'])
        assert declaration['line_start'] == 1 and declaration['line_end'] == 102
        assert declaration['content'] == changed

    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        body = ('def oversized():\n'
                + ''.join(f'    value_{i} = "{i:04d}-' + 'x' * 50 + '"\n' for i in range(6000))
                + '    return value_5999\n')
        write('main.py', body); git('add', '.'); git('commit', '-qm', 'oversized declaration base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('main.py', body.replace('value_4000 =', 'value_4000_changed ='))
        manifest = prepare(); owner = manifest['mechanical_owner']
        packet = manifest['source_context']['seats'][owner]
        assert packet['omitted']['declaration'] >= 1 and packet['source_read_required'] is True
        required = packet['required_source_ranges']
        declaration = next(row for row in required if 'declaration:oversized' in row['reasons'])
        source_artifacts = [shard['artifact'] for value in manifest['source_context']['seats'].values()
                            for shard in value['shards']]
        source_artifacts.extend(segment['artifact'] for value in manifest['source_context']['seats'].values()
                                for parent in value['required_source_ranges'] for segment in parent['segments'])
        assert manifest['word_counts']['source_context'] == sum(
            len((session / name).read_bytes().split()) for name in source_artifacts)
        assert declaration['path'] == 'main.py' and declaration['line_start'] == 1 and declaration['line_end'] == 6002
        assert declaration['blob_tree'] == manifest['snapshot_tree']
        assert declaration['blob_oid'] and declaration['content_sha256']
        assert declaration['required_payload_bytes'] > manifest['source_context']['max_shard_bytes']
        assert (declaration['required_payload_predicted_visible_bytes']
                > manifest['source_context']['max_shard_bytes'])
        segments = declaration['segments']
        assert len(segments) > 1
        assert [row['index'] for row in segments] == list(range(1, len(segments) + 1))
        assert segments[0]['line_start'] == declaration['line_start']
        assert segments[-1]['line_end'] == declaration['line_end']
        assert all(right['line_start'] == left['line_end'] + 1
                   for left, right in zip(segments, segments[1:]))
        assert all(row['line_end'] - row['line_start'] + 1 <= 240
                   and row['predicted_visible_bytes'] <= 32768 // 2
                   and row['raw_bytes'] > 0
                   and len(row['content_sha256']) == 64 for row in segments)
        blob = (root / declaration['path']).read_bytes()
        lines = blob.splitlines(keepends=True)
        rebuilt = b''
        for range_index, required in enumerate(packet['required_source_ranges'], 1):
            for segment in required['segments']:
                expected_name = (f'r1-{owner}-source-segment-{range_index:03d}-'
                                 f"{segment['index']:03d}.txt")
                assert segment['artifact'] == expected_name
                artifact = session / expected_name
                assert artifact.is_file() and not artifact.is_symlink() and artifact.stat().st_nlink == 1
                raw = artifact.read_bytes()
                expected = b''.join(lines[segment['line_start'] - 1:segment['line_end']])
                assert raw == expected
                assert manifest['artifacts'][expected_name]['sha256'] == hashlib.sha256(raw).hexdigest()
                if required is declaration:
                    rebuilt += raw
        assert hashlib.sha256(rebuilt).hexdigest() == declaration['content_sha256']
        rendered = call('render', session / 'r1-evidence.manifest.json', owner)
        assert 'Required source range: main.py:1-6002' in rendered
        for segment in segments:
            assert ("use Read to read " + str(Path(manifest['session']) / segment['artifact'])
                    + ' in full') in rendered
        assert 'git --git-dir=' not in rendered and 'evidence-repository' not in rendered
        reasons = [reason for shard in packet['shards']
                   for entry in json.loads((session / shard['artifact']).read_text())['entries']
                   for reason in entry['reasons']]
        assert 'declaration:oversized' not in reasons
        for seat in manifest['assignments']:
            (session / f'r1-{seat}.prompt.md').write_text(call('render', session / 'r1-evidence.manifest.json', seat))
            (session / f'r1-{seat}.json').write_text('{"summary":"checked","findings":[]}')
            (session / f'r1-{seat}.exit').write_text('0\n')
            write_agent_audit(session, '1', seat)
        call('receipt', session, '1')
        audit_path = session / f'r1-{owner}.read-audit.json'; saved_audit = audit_path.read_bytes()
        audit = json.loads(saved_audit)
        audit['source_ranges'] = [row for row in audit['source_ranges']
                                  if row['origin'] == 'packet' or (row['path'] == 'main.py' and row['line_start'] == 1)]
        audit['source_read_calls'] = 1; audit['opened_source_ranges'] = 1
        audit['required_source_ranges_covered'] = 0
        audit_path.write_text(json.dumps(audit)); call('receipt', session, '1', good=False)
        audit_path.write_bytes(saved_audit)

        manifest_path = session / 'r1-evidence.manifest.json'; evidence_path = session / 'r1-evidence.json'
        saved_manifest = manifest_path.read_bytes(); saved_evidence = evidence_path.read_bytes()
        for key, bad in [('line_end', 6001), ('blob_tree', manifest['base_tree']),
                         ('content_sha256', '0' * 64), ('required_payload_bytes', 32768),
                         ('required_payload_predicted_visible_bytes', 32768)]:
            changed_manifest = json.loads(saved_manifest); changed_evidence = json.loads(saved_evidence)
            row = next(value for value in changed_manifest['source_context']['seats'][owner]['required_source_ranges']
                       if 'declaration:oversized' in value['reasons'])
            row[key] = bad
            changed_evidence['source_context'] = changed_manifest['source_context']
            evidence_path.write_bytes(module.encoded(changed_evidence))
            changed_manifest['artifacts'][evidence_path.name] = {
                'sha256': module.digest(evidence_path.read_bytes()),
                'words': len(evidence_path.read_bytes().split())}
            manifest_path.write_bytes(module.encoded(changed_manifest))
            call('render', manifest_path, owner, good=False)
        segment_mutations = [
            lambda rows: rows.pop(),
            lambda rows: rows[1].update(line_start=rows[0]['line_end']),
            lambda rows: rows.reverse(),
            lambda rows: rows[0].update(artifact='wrong-source-segment.txt'),
            lambda rows: rows[0].update(content_sha256='0' * 64),
            lambda rows: rows[0].update(raw_bytes=rows[0]['raw_bytes'] + 1),
            lambda rows: rows[0].update(predicted_visible_bytes=32768 // 2 + 1),
        ]
        for mutate in segment_mutations:
            changed_manifest = json.loads(saved_manifest); changed_evidence = json.loads(saved_evidence)
            row = next(value for value in changed_manifest['source_context']['seats'][owner]['required_source_ranges']
                       if 'declaration:oversized' in value['reasons'])
            mutate(row['segments'])
            changed_evidence['source_context'] = changed_manifest['source_context']
            evidence_path.write_bytes(module.encoded(changed_evidence))
            changed_manifest['artifacts'][evidence_path.name] = {
                'sha256': module.digest(evidence_path.read_bytes()),
                'words': len(evidence_path.read_bytes().split())}
            manifest_path.write_bytes(module.encoded(changed_manifest))
            call('render', manifest_path, owner, good=False)
        manifest_path.write_bytes(saved_manifest); evidence_path.write_bytes(saved_evidence)

        segment_path = session / declaration['segments'][0]['artifact']
        segment_raw = segment_path.read_bytes()
        redirect = session / 'segment-redirect.txt'; redirect.write_bytes(segment_raw)
        segment_path.unlink(); segment_path.symlink_to(redirect)
        call('render', manifest_path, owner, good=False)
        segment_path.unlink(); os.link(redirect, segment_path)
        call('render', manifest_path, owner, good=False)
        segment_path.unlink(); segment_path.write_bytes(segment_raw); redirect.unlink()

    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        base_body = ('def provenance():\n'
                     + ''.join(f'    value_{i} = "base-{i:04d}-' + 'x' * 45 + '"\n'
                               for i in range(600))
                     + '    return value_599\n')
        write('provenance.py', base_body); git('add', '.'); git('commit', '-qm', 'provenance base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        head_body = base_body.replace('base-0300-', 'head-0300-')
        write('provenance.py', head_body); git('add', '.'); git('commit', '-qm', 'provenance head')
        head = git('rev-parse', 'HEAD'); git('checkout', '-q', base)
        call('prepare', session, 'named', '--phase', 'discovery', '--head', head)
        manifest_path = session / 'rnamed-evidence.manifest.json'
        manifest = json.loads(manifest_path.read_text()); owner = manifest['mechanical_owner']
        required = manifest['source_context']['seats'][owner]['required_source_ranges'][0]
        assert required['blob_tree'] == manifest['snapshot_tree'] == git('rev-parse', head + '^{tree}')
        for seat in manifest['assignments']:
            (session / f'rnamed-{seat}.prompt.md').write_text(call('render', manifest_path, seat))
            (session / f'rnamed-{seat}.json').write_text('{"summary":"checked","findings":[]}')
            (session / f'rnamed-{seat}.exit').write_text('0\n')
            write_agent_audit(session, 'named', seat)
        call('receipt', session, 'named')
        audit_path = session / f'rnamed-{owner}.read-audit.json'
        audit = json.loads(audit_path.read_text())
        proof = audit['required_source_range_proofs'][0]
        proof.update(blob_tree=manifest['base_tree'], blob_oid=git('rev-parse', base + ':provenance.py'),
                     content_sha256=module.digest(base_body.encode()))
        audit_path.write_text(json.dumps(audit))
        call('receipt', session, 'named', good=False)

    with fixture() as (root, session, git, write, call, prepare, finish):
        body = ('def oversized_line():\n    value = "' + 'x' * 40000
                + '"\n    return value\n')
        write('wide.py', body); git('add', '.'); git('commit', '-qm', 'wide line base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('wide.py', body.replace('return value', 'return value + "changed"'))
        manifest = prepare('wide-line')
        owner = manifest['mechanical_owner']
        packet = manifest['source_context']['seats'][owner]
        assert packet['required_source_ranges'] == []
        assert packet['omitted_source_ranges'] == []
        assert packet['source_read_required'] is False
        assert packet['omitted']['declaration'] >= 1

    with fixture() as (root, session, git, write, call, prepare, finish):
        body = 'value = "' + 'x' * 2_000_010 + '"\n'
        write('huge.py', body); git('add', '.'); git('commit', '-qm', 'huge text base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('huge.py', body[:-2] + 'y"\n')
        call('prepare', session, 'unrepresentable', '--phase', 'discovery', good=False)

    with fixture(object_format='sha256') as (root, session, git, write, call, prepare, finish):
        body = ('def sha256_source():\n'
                + ''.join(f'    value_{i} = "{i:04d}-' + 'x' * 80 + '"\n' for i in range(500))
                + '    return value_499\n')
        write('sha256.py', body); git('add', '.'); git('commit', '-qm', 'sha256 source base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('sha256.py', body.replace('value_400 =', 'value_400_changed ='))
        manifest = prepare('sha256'); owner = manifest['mechanical_owner']
        required = manifest['source_context']['seats'][owner]['required_source_ranges'][0]
        assert len(required['blob_oid']) == 64 and required['segments']
        assert not (session / 'evidence-repository').exists()
        rebuilt = b''.join((session / segment['artifact']).read_bytes()
                           for segment in required['segments'])
        assert hashlib.sha256(rebuilt).hexdigest() == required['content_sha256']
        call('render', session / 'rsha256-evidence.manifest.json', owner)

    with fixture() as (root, session, git, write, call, prepare, finish):
        (root / 'unrepresentable.py').write_bytes(b'\0binary source')
        prepare('binary')
        binary_patch = (session / 'rbinary-full.patch').read_bytes()
        assert b'GIT binary patch' not in binary_patch
        assert b'Binary-File-Pointer' in binary_patch
        assert b'unrepresentable.py' in binary_patch
        assert b'\0' not in binary_patch

def budget_omissions_are_segmented_or_retained():
    with fixture() as (root, session, git, write, call, prepare, finish):
        for unit in range(9):
            values = 260 if unit == 0 else 140
            body = (f'def unit_{unit}():\n'
                    + ''.join(f'    value_{index} = "{unit}-{index:04d}-' + 'x' * 55 + '"\n'
                              for index in range(values))
                    + f'    return value_{values - 1}\n')
            write(f'unit_{unit}.py', body)
        manifest = prepare('budget-omissions')
        omitted = [packet for packet in manifest['source_context']['seats'].values()
                   if packet['omitted']['declaration']]
        assert omitted
        assert all(packet['source_read_required'] for packet in omitted)
        assert any(packet['required_source_ranges'] for packet in omitted)
        assert any(packet['omitted_source_ranges'] for packet in omitted)
        for packet in omitted:
            required = packet['required_source_ranges']
            retained = packet['omitted_source_ranges']
            assert sum(len(row['reasons']) for row in [*required, *retained]) \
                == sum(packet['omitted'].values())
            required_ids = {(row['path'], row['line_start'], row['line_end']) for row in required}
            retained_ids = {(row['path'], row['line_start'], row['line_end']) for row in retained}
            assert not required_ids & retained_ids
            for row in required:
                assert row['path'] == 'unit_0.py' and row['line_start'] == 1
                assert row['line_end'] == 262 and row['segments']
                cursor = row['line_start']
                for segment in row['segments']:
                    assert segment['line_start'] == cursor
                    assert segment['predicted_visible_bytes'] <= 16384
                    cursor = segment['line_end'] + 1
                assert cursor == row['line_end'] + 1
            for row in retained:
                if any(reason.startswith('gate:') for reason in row['reasons']):
                    assert row['path'] == 'package.json' and row['line_start'] == row['line_end'] == 1
                else:
                    assert row['path'].startswith('unit_') and row['line_start'] == 1
                    assert row['path'] != 'unit_0.py' and row['line_end'] == 142
                assert row['reasons'] and row['component_ids']
                assert row['blob_tree'] == manifest['snapshot_tree']
                assert len(row['blob_oid']) in (40, 64)
                assert len(row['content_sha256']) == 64
                assert 'content' not in row and 'segments' not in row
        call('verify', session / 'rbudget-omissions-evidence.manifest.json')

def innermost_declarations_and_bounded_anchors():
    with fixture() as (root, session, git, write, call, prepare, finish):
        method = ('    def changed_method(self):\n'
                  + ''.join(f'        value_{index} = "{index:04d}-' + 'x' * 45 + '"\n'
                            for index in range(280))
                  + '        return value_279\n')
        stable = ('    def stable_method(self):\n'
                  + ''.join(f'        stable_{index} = "{index:04d}-' + 'y' * 45 + '"\n'
                            for index in range(900))
                  + '        return stable_899\n')
        body = 'MODULE_FLAG = 1\n\nclass Large:\n' + method + '\n' + stable
        write('large.py', body); git('add', '.'); git('commit', '-qm', 'large class base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        changed = body.replace('MODULE_FLAG = 1', 'MODULE_FLAG = 2').replace(
            'value_140 = "0140-', 'value_140_changed = "0140-')
        write('large.py', changed)
        manifest = prepare('bounded-anchor'); facts = json.loads(
            (session / 'rbounded-anchor-evidence.json').read_text())
        symbols = [row for row in facts['symbols'] if row['path'] == 'large.py']
        declaration = next(row for row in symbols if row['name'] == 'changed_method')
        anchors = [row for row in symbols if row['kind'] == 'changed-line anchor']
        assert not any(row['name'] == 'Large' for row in symbols)
        assert declaration['line_end'] - declaration['line'] + 1 == 282
        assert len(anchors) == 1 and anchors[0]['line_end'] - anchors[0]['line'] + 1 <= 17
        owner = manifest['mechanical_owner']; packet = manifest['source_context']['seats'][owner]
        assert packet['source_read_required'] is True
        required = [row for row in packet['required_source_ranges'] if row['path'] == 'large.py']
        assert len(required) == 1 and 'declaration:changed_method' in required[0]['reasons']
        assert all(segment['predicted_visible_bytes'] <= 16384 for segment in required[0]['segments'])
        entries = [entry for shard in packet['shards']
                   for entry in json.loads((session / shard['artifact']).read_text())['entries']]
        assert not any('declaration:changed_method' in row['reasons'] for row in entries)
        assert any('declaration:changed-line-anchor' in row['reasons'] for row in entries)
        before_words = len(changed.split())
        after_words = sum(len((session / shard['artifact']).read_bytes().split())
                          for shard in packet['shards'])
        print(f'ANCHOR before_mandatory=1 direct_source_ranges={len(required)} '
              f'before_words={before_words} packet_words={after_words}')
        finish('bounded-anchor')

def high_confidence_component_union():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('src/core.ts', 'import { dep } from "./dep";\nconst version = 1;\nexport function alpha() { return dep(); }\n')
        write('src/dep.ts', 'export function dep() { return 1; }\n')
        write('src/other.ts', 'export function other() { return 1; }\n')
        write('tests/multi.test.ts',
              'import { alpha } from "../src/core";\nimport { other } from "../src/other";\n'
              '// version 1\ntest("both", () => alpha() + other());\n')
        write('a.py', 'def same_stem():\n    return 1\n')
        write('test_a.py', 'assert same_stem() == 1\n')
        write('a.md', 'version 1 same_stem alpha dep\n')
        git('add', '.'); git('commit', '-qm', 'component base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        for name in ('src/core.ts', 'src/dep.ts', 'src/other.ts', 'tests/multi.test.ts',
                     'a.py', 'test_a.py', 'a.md'):
            write(name, (root / name).read_text().replace('1', '2', 1))
        manifest = prepare('component-policy')
        components = manifest['components']
        assert {path for component in components for path in component['files']} == set(manifest['semantic_paths'])
        assert len([path for component in components for path in component['files']]) == len(manifest['semantic_paths'])
        imported = next(component for component in components if 'src/core.ts' in component['files'])
        assert {'src/core.ts', 'src/dep.ts'} <= set(imported['files'])
        same_stem = next(component for component in components if 'a.py' in component['files'])
        assert 'test_a.py' in same_stem['files'] and 'a.md' not in same_stem['files']
        multi = next(component for component in components if 'tests/multi.test.ts' in component['files'])
        assert multi['files'] == ['tests/multi.test.ts']
        other = next(component for component in components if 'src/other.ts' in component['files'])
        assert 'tests/multi.test.ts' in imported['boundary'] and 'tests/multi.test.ts' in other['boundary']
        prose = next(component for component in components if 'a.md' in component['files'])
        assert prose['files'] == ['a.md']
        evidence = json.loads((session / 'rcomponent-policy-evidence.json').read_text())
        repo = module.Repository(session.resolve()); snapshot, _ = repo.snapshot()
        changes, _, categories, _ = repo.changes(repo.tree(base), snapshot)
        patches = {path: patch for path, patch in changes if categories[path] == 'semantic'}
        roster = json.loads((session / 'roster.json').read_text())
        chosen = {row['seat']: manifest['assignments'][row['seat']]['bundle']
                  for row in roster['seats']}
        assert components == module.components_for(
            patches, list(reversed(evidence['dependencies'])), chosen,
            manifest['mechanical_owner'])
        specialist_files = {path for component in components if component['specialists']
                            for path in component['files']}
        assert specialist_files == set(manifest['semantic_paths'])
        owner_patch = Path(manifest['assignments'][manifest['mechanical_owner']]['patch']).read_text()
        assert all(path in owner_patch for path in manifest['semantic_paths'])

def components_ownership_and_instructions():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        write('AGENTS.md', 'Repository constraint.\n'); write('src/AGENTS.md', 'Source constraint.\n')
        write('src/a.ts', 'import { dependency } from "./dep";\nexport function alpha() { return dependency(); }\n')
        write('src/dep.ts', 'export function dependency() { return 1; }\n')
        write('separate.py', 'def separate():\n    return 1\n')
        write('large.py', ''.join(f'value_{i} = {i}\n' for i in range(1200)))
        m = prepare()
        component = next(c for c in m['components'] if 'src/a.ts' in c['files'])
        assert 'src/dep.ts' in component['files'] and component['edges']
        covered = {p for c in m['components'] if c['specialists'] for p in c['files']}
        assert covered == set(m['semantic_paths'])
        assert (session / 'r1-instructions.md').read_text().count('Repository constraint.') == 1
        assert 'Source constraint.' in (session / 'r1-instructions.md').read_text()
        assert any(p.endswith('-terra.patch') for p in m['artifacts'])
        finding_owner = component['specialists'][0]
        finding = {'severity':'P2','file':'src/a.ts','line_start':2,'line_end':2,'claim':'Dependency result needs validation','evidence':'The result is returned directly.','suggested_fix':'Validate it.','confidence':0.9}
        for seat in m['assignments']:
            (session / f'r1-{seat}.prompt.md').write_text(call('render', session / 'r1-evidence.manifest.json', seat))
            (session / f'r1-{seat}.json').write_text(json.dumps({'summary':'checked','findings':[finding] if seat == finding_owner else []}))
            (session / f'r1-{seat}.exit').write_text('0\n')
        for seat in m['assignments']:
            write_agent_audit(session, '1', seat)
        advisory_path = session / f'r1-{finding_owner}.read-audit.json'
        advisory_audit = json.loads(advisory_path.read_text())
        advisory_audit['advisories'] = [{'code':'missing-evidence-index', 'tool':'Read'}]
        advisory_path.write_text(json.dumps(advisory_audit))
        call('receipt', session, '1')
        receipt = json.loads((session / 'r1-coverage.receipt.json').read_text())
        assert receipt['findings'][0]['owners'] == [finding_owner] and len(receipt['findings'][0]['id']) == 64
        assert receipt['advisories'] == {
            finding_owner: [{'code':'missing-evidence-index', 'tool':'Read'}]}
        write('src/dep.ts', 'export function dependency() { return 2; }\n')
        later = prepare('2', 'verification', *assign)
        changed = next(c for c in later['components'] if 'src/dep.ts' in c['files'])
        assert finding_owner in changed['specialists'] or finding_owner == later['mechanical_owner']
        old = module.Repository
        try:
            module.Repository = lambda *_: (_ for _ in ()).throw(AssertionError('offline validator used Git'))
            module.validated_manifest(session / 'r2-evidence.manifest.json', fresh=False, offline=True)
        finally:
            module.Repository = old

def overlapping_boundaries_keep_prior_owner_routing():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        write('src/core.ts', 'export function alpha() { return 1; }\n')
        write('src/other.ts', 'export function other() { return 1; }\n')
        write('tests/multi.test.ts',
              'import { alpha } from "../src/core";\nimport { other } from "../src/other";\n'
              'test("both", () => alpha() + other());\n')
        write('large.py', ''.join(f'value_{i} = {i}\n' for i in range(1200)))
        m = prepare()
        by_files = {tuple(c['files']): c for c in m['components']}
        assert 'tests/multi.test.ts' in by_files[('src/other.ts',)]['boundary']
        finding_owner = by_files[('src/core.ts',)]['specialists'][0]
        finding = {'severity':'P2','file':'src/core.ts','line_start':1,'line_end':1,'claim':'Alpha needs a bound','evidence':'It returns a constant.','suggested_fix':'Bound it.','confidence':0.9}
        for seat in m['assignments']:
            (session / f'r1-{seat}.prompt.md').write_text(call('render', session / 'r1-evidence.manifest.json', seat))
            (session / f'r1-{seat}.json').write_text(json.dumps({'summary':'checked','findings':[finding] if seat == finding_owner else []}))
            (session / f'r1-{seat}.exit').write_text('0\n')
            write_agent_audit(session, '1', seat)
        call('receipt', session, '1')
        for name in ('src/core.ts', 'src/other.ts', 'tests/multi.test.ts'):
            write(name, (root / name).read_text().replace('1', '2', 1) if name != 'tests/multi.test.ts'
                  else (root / name).read_text() + '// changed\n')
        later = prepare('2', 'verification', *assign)
        assert any(a['scope'] == 'delta' for a in later['assignments'].values()), later['fallback_reason']
        by_files = {tuple(c['files']): c for c in later['components']}
        # The multi-import test's first file sits inside other.ts's boundary, but only core.ts carries the finding.
        assert finding_owner in by_files[('tests/multi.test.ts',)]['prior_owners']
        assert finding_owner not in by_files[('src/other.ts',)]['prior_owners']
        mpath = session / 'r2-evidence.manifest.json'
        for seat in later['assignments']:
            call('render', mpath, seat)
        call('verify', mpath)
        module.validated_manifest(mpath, fresh=False, offline=True)
        m, ep = json.loads(mpath.read_text()), session / 'r2-evidence.json'
        e = json.loads(ep.read_text())
        other = next(c for c in m['components'] if c['files'] == ['src/other.ts'])
        other['prior_owners'] = [next(s for s in m['assignments'] if s != m['mechanical_owner']
                                      and s not in other['specialists'])]
        e['components'] = m['components']; ep.write_bytes(module.encoded(e))
        m['artifacts'][ep.name] = {'sha256': module.digest(ep.read_bytes()), 'words': len(ep.read_bytes().split())}
        mpath.write_bytes(module.encoded(m))
        call('verify', mpath, good=False)
        try:
            module.validated_manifest(mpath, fresh=False, offline=True)
        except ValueError as error:
            assert 'component routing is not canonical' in str(error), error
        else:
            raise AssertionError('offline validation accepted owners the routing does not follow')

def instruction_override_precedence():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('AGENTS.md', 'root ordinary\n'); write('AGENTS.override.md', 'root override\n')
        write('src/AGENTS.md', 'src ordinary\n'); write('src/AGENTS.override.md', 'src override\n')
        write('src/deep/AGENTS.md', 'deep ordinary\n')
        write('src/deep/main.py', 'def target():\n    return 1\n')
        write('consumer/AGENTS.md', 'consumer rules\n')
        write('consumer/use.py', 'from src.deep.main import target\nvalue = target()\n')
        git('add', '.'); git('commit', '-qm', 'instruction base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('src/deep/main.py', 'def target():\n    return 2\n')
        worktree = prepare('override-worktree')
        assert [row['path'] for row in worktree['instructions']] == [
            'AGENTS.override.md', 'consumer/AGENTS.md', 'src/AGENTS.override.md',
            'src/deep/AGENTS.md']
        packet = (session / 'roverride-worktree-instructions.md').read_text()
        assert all(value in packet for value in (
            'root override', 'src override', 'deep ordinary', 'consumer rules'))
        assert 'root ordinary' not in packet and 'src ordinary' not in packet

        write('src/deep/AGENTS.override.md', 'deep snapshot override\n')
        git('add', '.'); git('commit', '-qm', 'named instruction head'); head = git('rev-parse', 'HEAD')
        git('checkout', '-q', base)
        named = prepare('override-ref', 'discovery', '--head', head)
        assert [row['path'] for row in named['instructions']] == [
            'AGENTS.override.md', 'consumer/AGENTS.md', 'src/AGENTS.override.md',
            'src/deep/AGENTS.override.md']
        assert 'deep snapshot override' in (session / 'roverride-ref-instructions.md').read_text()
        manifest_path = session / 'roverride-ref-evidence.manifest.json'
        manifest = json.loads(manifest_path.read_text()); evidence_path = session / 'roverride-ref-evidence.json'
        evidence = json.loads(evidence_path.read_text())
        manifest['instructions'][0]['path'] = 'AGENTS.md'; evidence['instructions'] = manifest['instructions']
        evidence_path.write_bytes(module.encoded(evidence))
        manifest['artifacts'][evidence_path.name] = {
            'sha256': module.digest(evidence_path.read_bytes()), 'words': len(evidence_path.read_bytes().split())}
        manifest_path.write_bytes(module.encoded(manifest))
        call('render', manifest_path, 'sol', good=False)
        (root / 'AGENTS.override.md').write_bytes(b'\xff')
        call('prepare', session, 'unreadable-override', '--phase', 'discovery', good=False)

def empty_source_context():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write('emptied.py', 'value = 1\n'); write('deleted-empty.py', '')
        git('add', '.'); git('commit', '-qm', 'empty context base')
        base = git('rev-parse', 'HEAD'); scope_text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope_text.splitlines()) + '\n')
        write('emptied.py', ''); (root / 'deleted-empty.py').unlink(); write('added-empty.py', '')
        manifest = prepare('empty-context')
        assert not manifest['snapshot_unsafe']
        owner = manifest['mechanical_owner']; packet = manifest['source_context']['seats'][owner]
        entries = [entry for shard in packet['shards']
                   for entry in json.loads((session / shard['artifact']).read_text())['entries']]
        emptied = next(entry for entry in entries if entry['path'] == 'emptied.py')
        assert emptied['content'] == 'value = 1\n' and emptied['blob_tree'] == manifest['base_tree']
        assert all(row['path'] not in ('added-empty.py', 'deleted-empty.py')
                   for row in [*entries, *packet['required_source_ranges']])
        finish('empty-context')

def bounded_work_and_memory():
    import tracemalloc
    with fixture() as (root, session, git, write, call, prepare, finish):
        for i in range(60): write(f'changed/{i}.py', f'value = {i}\n')
        for i in range(200): write(f'unchanged/{i}.txt', '# ' + 'x' * 100000 + f'{i}\n')
        git('add', '.'); git('commit', '-qm', 'bounded baseline')
        base = git('rev-parse', 'HEAD'); text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join('REV_BASE=' + base if s.startswith('REV_BASE=') else s for s in text.splitlines()) + '\n')
        for i in range(60): write(f'changed/{i}.py', f'value = {i + 1}\n')
        repo = module.Repository(session.resolve()); tree, _ = repo.snapshot(); _, hunks, cats, _ = repo.changes(repo.tree(base), tree)
        tracemalloc.start(); module.facts(repo, tree, hunks, cats); _, peak = tracemalloc.get_traced_memory(); tracemalloc.stop()
        assert peak < 16 * 1024 * 1024, ('repository-sized retained memory', peak)
        gitbin = subprocess.check_output(['which','git'], text=True).strip(); bindir=session/'bin'; bindir.mkdir(); log=session/'calls'
        wrapper=bindir/'git'; wrapper.write_text('#!/bin/sh\nprintf "%s\\n" "$*" >> "$EVIDENCE_GIT_LOG"\nexec '+shlex.quote(gitbin)+' "$@"\n'); wrapper.chmod(0o755)
        env=dict(os.environ, PATH=str(bindir)+os.pathsep+os.environ['PATH'], EVIDENCE_GIT_LOG=str(log))
        prepare(env=env)
        assert len(log.read_text().splitlines()) < 50, 'Git commands scale with changed paths'
        original_source_context = module.source_context
        def unexpected_source_context(*args, **kwargs):
            raise AssertionError('fresh validation rebuilt source context')
        module.source_context = unexpected_source_context
        try:
            module.validated_manifest(session / 'r1-evidence.manifest.json')
        finally:
            module.source_context = original_source_context
        assert os.access(script, os.X_OK), 'evidence entry point is not executable'

failures = []
def receipt_read_audits():
    with fixture() as (root, session, git, write, call, prepare, finish):
        roster = json.loads((session / 'roster.json').read_text()); roster['seats'][0]['adapter'] = 'codex'
        (session / 'roster.json').write_text(json.dumps(roster)); m = prepare()
        for seat in m['assignments']:
            (session / f'r1-{seat}.prompt.md').write_text(call('render', session / 'r1-evidence.manifest.json', seat))
            (session / f'r1-{seat}.json').write_text('{"summary":"checked","findings":[]}')
            (session / f'r1-{seat}.exit').write_text('0\n')
            if seat != 'sol':
                write_agent_audit(session, '1', seat)
        call('receipt', session, '1', good=False)
        stream = session / 'r1-sol.stream.ndjson'; stream.write_text('{}\n')
        manifest_path = session / 'r1-evidence.manifest.json'
        manifest = json.loads(manifest_path.read_text()); packet = manifest['source_context']['seats']['sol']
        packet_ranges = [{'path': row['path'], 'line_start': row['line_start'], 'line_end': row['line_end'], 'origin': 'packet'}
                         for shard in packet['shards'] for row in shard['ranges']]
        audit = {'schema_version':2,'status':'valid','narrow':False,'adapter':'codex',
                 'prompt_sha256':module.digest((session / 'r1-sol.prompt.md').read_bytes()),
                 'stream_sha256':module.digest(stream.read_bytes()),'violations':[],
                 'result_sha256':module.digest((session / 'r1-sol.json').read_bytes()),
                 'evidence_manifest_sha256':module.digest(manifest_path.read_bytes()),
                 'tool_calls':max(1, len(packet['shards'])),'tool_turns':max(1, len(packet['shards'])),
                 'tool_output_bytes':sum(shard['bytes'] for shard in packet['shards']),
                 'max_tool_output_bytes':max([shard['bytes'] for shard in packet['shards']] or [0]),
                 'recognized_tool_calls':max(1, len(packet['shards'])), 'source_read_calls':0,
                 'packet_shards':len(packet['shards']), 'packet_bytes':sum(shard['bytes'] for shard in packet['shards']),
                 'packet_ranges':len(packet_ranges), 'opened_source_ranges':0,
                 'finding_citations':0, 'required_source_ranges_covered':0,
                 'required_source_range_proofs':[],
                 'source_ranges':sorted(packet_ranges, key=lambda row: (row['path'], row['line_start'], row['line_end'], row['origin']))}
        path = session / 'r1-sol.read-audit.json'
        patch = Path(manifest['assignments']['sol']['patch'])
        assignment = manifest['assignments']['sol']; patch_mode = assignment['patch_read_mode']
        chunks = manifest['patch_sets'][assignment['patch_set']]['chunks'] if patch_mode == 'chunks' else []
        audit.update(assigned_patch_sha256=module.digest(patch.read_bytes()),
                     assigned_patch_bytes=len(patch.read_bytes()), assigned_patch_lines=assignment['patch_lines'],
                     assigned_patch_reads=len(chunks) if chunks else max(1, (assignment['patch_lines'] + 239) // 240),
                     assigned_patch_ranges=[] if chunks or assignment['patch_lines'] == 0 else [{'line_start':1, 'line_end':assignment['patch_lines']}],
                     patch_proof_mode=patch_mode,
                     patch_proof_calls=len(chunks) if chunks else max(1, (assignment['patch_lines'] + 239) // 240),
                     patch_proof_turns=len(chunks) if chunks else max(1, (assignment['patch_lines'] + 239) // 240),
                     patch_proof_visible_bytes=len(patch.read_bytes()),
                     expected_patch_chunks=len(chunks), opened_patch_chunks=len(chunks))
        audit['advisories'] = [{'code':'unbounded-shell-output','tool':'Bash'}]
        path.write_text(json.dumps(audit))
        call('receipt', session, '1')
        cases = [
            ('status','invalid','invalid or stale read audit'),
            ('prompt_sha256','0'*64,'invalid or stale read audit'),
            ('stream_sha256','0'*64,'invalid or stale read audit'),
            ('result_sha256','0'*64,'invalid or stale read audit'),
            ('evidence_manifest_sha256','0'*64,'invalid or stale read audit'),
            ('adapter','agent','invalid or stale read audit'),
            ('narrow',True,'invalid or stale read audit'),
            ('violations',['outside'],'invalid or stale read audit'),
            ('advisories',['outside'],'invalid or stale read audit'),
            ('tool_calls',None,'invalid read audit counters'),
            ('recognized_tool_calls',0,'invalid read audit counters'),
            ('packet_bytes',0,'read audit evidence coverage mismatch'),
            ('finding_citations',1,'read audit evidence coverage mismatch'),
            ('source_ranges',[],'read audit packet ranges do not match complete assigned shards'),
        ]
        for key, bad, error in cases:
            path.write_text(json.dumps(dict(audit, **{key:bad})))
            call('receipt', session, '1', good=False, error=error)
        for key, bad in [('assigned_patch_sha256','0'*64), ('assigned_patch_bytes',0),
                         ('assigned_patch_lines',0), ('assigned_patch_reads',0),
                         ('assigned_patch_ranges',[{'line_start':2,'line_end':assignment['patch_lines']}])]:
            path.write_text(json.dumps(dict(audit, **{key:bad}))); call('receipt', session, '1', good=False)
        path.write_text(json.dumps(audit)); call('receipt', session, '1')
        stream.write_text('changed\n'); call('receipt', session, '1', good=False, error='invalid or stale read audit')

def seat_local_recovery():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        roster = {'seats': [
            {'seat': seat, 'extra': False,
             'adapter': 'codex' if seat == 'terra' else 'claude',
             'model': ('gpt-5.6-luna' if seat == 'terra' else
                       'sonnet' if seat == 'sol' else 'model-' + seat),
             'effort': 'high' if seat in ('terra', 'sol') else 'max'} for seat in seats]}
        (session / 'roster.json').write_text(json.dumps(roster))
        parent = prepare('parent', 'risk', *assign)
        parent_path = session / 'rparent-evidence.manifest.json'
        for seat in parent['assignments']:
            (session / f'rparent-{seat}.prompt.md').write_text(call('render', parent_path, seat))
            (session / f'rparent-{seat}.json').write_text('{"summary":"parent","findings":[]}')
            (session / f'rparent-{seat}.exit').write_text('0\n')
            write_agent_audit(session, 'parent', seat)
        (session / 'rparent-terra.exit').write_text('1\n')
        call('receipt', session, 'parent', good=False, error='seat failed: terra')
        (session / 'rparent-terra.audit-invalid.json').write_text('{"summary":"kept","findings":[]}\n')
        child_args = ('--assignment', 'sol=' + bundles[1],
                      '--parent-assignment', 'parent:terra')
        child = prepare('parentx', 'repair', *child_args)
        binding = child['parent_assignment']
        assert binding == {
            'manifest': parent_path.name,
            'manifest_sha256': module.digest(parent_path.read_bytes()),
            'seat': 'terra', 'snapshot_tree': parent['snapshot_tree'],
            'roster_sha256': parent['inputs']['roster.json'],
            'assignment_sha256': module.digest(module.encoded(parent['assignments']['terra'])),
            'bundle': bundles[1], 'adapter': 'codex',
            'model': 'gpt-5.6-luna', 'effort': 'high',
            'patch_chunks_mode': 'auto', 'source_context_enabled': True}
        assert child['assignments']['sol']['scope'] == 'full'
        assert child['patch_chunks_mode'] == parent['patch_chunks_mode'] == 'auto'
        assert child['source_context']['enabled'] is parent['source_context']['enabled'] is True
        call('prepare', session, 'parentx', '--phase', 'repair', *child_args,
             good=False, env={'REV_PATCH_CHUNKS':'0'},
             error='repair patch chunk setting conflicts with parent assignment')
        call('prepare', session, 'parentx', '--phase', 'repair', *child_args,
             good=False, env={'REV_SOURCE_CONTEXT':'0'},
             error='repair source context setting conflicts with parent assignment')
        call('prepare', session, 'parentx', '--phase', 'repair',
             *child_args, '--head', git('rev-parse', 'HEAD'), good=False,
             error='explicit source selector conflicts with parent assignment')
        child_path = session / 'rparentx-evidence.manifest.json'
        (session / 'rparentx-sol.prompt.md').write_text(call('render', child_path, 'sol'))
        (session / 'rparentx-sol.json').write_text('{"summary":"child","findings":[]}')
        (session / 'rparentx-sol.exit').write_text('0\n')
        write_agent_audit(session, 'parentx', 'sol')
        output = call('verify-panel', session, 'parent', '--replacement', 'terra=parentx')
        verified = json.loads(output)
        assert verified['replacements'] == {'terra': 'parentx'}
        assert {seat: (row['label'], row['seat']) for seat, row in verified['selected_generations'].items()} == {
            'sol': ('parent', 'sol'), 'terra': ('parentx', 'sol'), 'opus': ('parent', 'opus'),
            'sonnet': ('parent', 'sonnet')}
        call('receipt', session, 'parent', '--replacement', 'terra=parentx')
        receipt = json.loads((session / 'rparent-coverage.receipt.json').read_text())
        assert receipt['schema_version'] == 2
        assert receipt['selected_generations'] == verified['selected_generations']
        assert receipt['results'] == verified['results']
        assert receipt['selected_generations']['sol']['result_sha256'] == module.digest(
            (session / 'rparent-sol.json').read_bytes())
        call('receipt', session, 'parent', '--replacement', 'terra=parentx')
        follow = prepare('follow', 'verification', *assign)
        assert follow['fallback_reason'] is None
        call('verify-panel', session, 'parent', '--replacement', 'terra=parentx',
             '--replacement', 'terra=parentx', good=False, error='duplicate replacement seat')
        (session / 'rparent-terra.exit').write_text('0\n')
        (session / 'rparent-opus.exit').write_text('1\n')
        call('verify-panel', session, 'parent', '--replacement', 'opus=parentx',
             good=False, error='replacement child is bound to another parent assignment')
        (session / 'rparent-terra.exit').write_text('1\n')
        (session / 'rparent-opus.exit').write_text('0\n')

        original_manifest = child_path.read_bytes()
        original_evidence = (session / 'rparentx-evidence.json').read_bytes()
        for key, value in (
                ('snapshot_tree', parent['base_tree']), ('roster_sha256', '0' * 64),
                ('assignment_sha256', '0' * 64), ('bundle', bundles[0]),
                ('adapter', 'other'), ('model', 'other'), ('effort', 'xhigh'),
                ('patch_chunks_mode', '0'), ('source_context_enabled', False)):
            changed = json.loads(original_manifest); evidence = json.loads(original_evidence)
            changed['parent_assignment'][key] = value
            evidence['parent_assignment'][key] = value
            evidence_raw = module.encoded(evidence)
            (session / 'rparentx-evidence.json').write_bytes(evidence_raw)
            changed['artifacts']['rparentx-evidence.json'] = {
                'sha256': module.digest(evidence_raw), 'words': len(evidence_raw.split())}
            child_path.write_bytes(module.encoded(changed))
            call('verify-panel', session, 'parent', '--replacement', 'terra=parentx', good=False)
        child_path.write_bytes(original_manifest)
        (session / 'rparentx-evidence.json').write_bytes(original_evidence)
        changed = json.loads(original_manifest)
        changed['task_capacity']['seats']['sol']['projected_turns'] += 1
        child_path.write_bytes(module.encoded(changed))
        call('verify', child_path, good=False, error='invalid task capacity contract')
        child_path.write_bytes(original_manifest)

        # The executor's own parent-panel generation is valid there and must not pass as the child.
        # (Both streams are the fixture's identical '{}', so only the other artifacts can differ.)
        for suffix in ('prompt.md', 'json', 'read-audit.json'):
            target = session / ('rparentx-sol.' + suffix); saved = target.read_bytes()
            target.write_bytes((session / ('rparent-sol.' + suffix)).read_bytes())
            call('verify-panel', session, 'parent', '--replacement', 'terra=parentx', good=False)
            target.write_bytes(saved)

        git('add', 'main.py'); git('commit', '-qm', 'reviewed ref')
        reviewed_ref = git('rev-parse', 'HEAD')
        parent_ref = prepare('parent-ref', 'risk', '--head', reviewed_ref, *assign)
        (session / 'rparent-ref-terra.audit-invalid.json').write_text('{"summary":"kept","findings":[]}\n')
        inherited = prepare('parent-refx', 'repair', '--assignment', 'sol=' + bundles[1],
                            '--parent-assignment', 'parent-ref:terra')
        assert inherited['source'] == parent_ref['source'] == {
            'mode': 'ref', 'ref': reviewed_ref}
        assert inherited['snapshot_tree'] == parent_ref['snapshot_tree']
        explicit = prepare('parent-refx', 'repair', '--assignment', 'sol=' + bundles[1],
                           '--parent-assignment', 'parent-ref:terra', '--head', reviewed_ref)
        assert explicit['source'] == parent_ref['source']
        call('prepare', session, 'parent-refx', '--phase', 'repair',
             '--assignment', 'sol=' + bundles[1],
             '--parent-assignment', 'parent-ref:terra', '--head', git('rev-parse', 'HEAD^'),
             good=False, error='explicit source selector conflicts with parent assignment')

        ordinary = prepare('ordinary')
        for seat in ordinary['assignments']:
            path = session / 'rordinary-evidence.manifest.json'
            (session / f'rordinary-{seat}.prompt.md').write_text(call('render', path, seat))
            (session / f'rordinary-{seat}.json').write_text('{"summary":"ordinary","findings":[]}')
            (session / f'rordinary-{seat}.exit').write_text('0\n')
            write_agent_audit(session, 'ordinary', seat)
        call('receipt', session, 'ordinary')
        ordinary_receipt = json.loads((session / 'rordinary-coverage.receipt.json').read_text())
        assert ordinary_receipt['schema_version'] == 1
        assert 'selected_generations' not in ordinary_receipt and 'replacements' not in ordinary_receipt

def replacement_runs_on_another_seat():
    attempt = script.parent / 'lib' / 'rev-attempt.py'
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        chain_identities = {
            'sol': ('claude', 'sonnet', 'high'),
            'terra': ('codex', 'gpt-5.6-sol', 'high'),
            'opus': ('codex', 'gpt-5.6-luna', 'high'),
            'sonnet': ('agent', 'sonnet', 'high'),
        }
        roster = {'seats': [
            {'seat': seat, 'extra': False,
             'adapter': chain_identities[seat][0], 'model': chain_identities[seat][1],
             'effort': chain_identities[seat][2]} for seat in seats]}
        (session / 'roster.json').write_text(json.dumps(roster))
        parent = prepare('4', 'risk', *assign, '--full-seat', 'sonnet')
        path = session / 'r4-evidence.manifest.json'
        for seat in parent['assignments']:
            (session / f'r4-{seat}.prompt.md').write_text(call('render', path, seat))
            (session / f'r4-{seat}.json').write_text('{"summary":"parent","findings":[]}')
            (session / f'r4-{seat}.exit').write_text('0\n')
            if seat != 'sonnet':
                write_agent_audit(session, '4', seat)
        (session / 'r4-sol.exit').write_text('2\n')
        child_args = ('--assignment', 'terra=' + bundles[0], '--parent-assignment', '4:sol')
        call('prepare', session, '4x', '--phase', 'repair', *child_args, good=False,
             error='parent assignment has no recorded terminal failure')
        prompt = session / 'r4-sol.prompt.md'
        for code in ('1', '2'):
            assert reserve_launch(session, '4', 'sol', prompt).returncode == 0
            assert record_launch(session, '4', 'sol', prompt, code).returncode == 0
            (session / 'r4-sol.exit').write_text(code + '\n')
        (session / 'r4-sol.audit-invalid.json').write_text('{"summary":"kept","findings":[]}\n')
        call('prepare', session, '4x', '--phase', 'repair', '--assignment', 'sol=' + bundles[0],
             '--parent-assignment', '4:sol', good=False,
             error='replacement executor must differ from the parent seat')
        call('prepare', session, '4x', '--phase', 'repair', '--assignment', 'sonnet=' + bundles[0],
             '--parent-assignment', '4:sol', good=False,
             error='replacement executor must be an enforced seat')
        call('prepare', session, '4y', '--phase', 'repair', *child_args, good=False,
             error='replacement label must be in the root assignment namespace')
        call('prepare', session, '4x', '--phase', 'repair', '--assignment', 'terra=' + bundles[1],
             '--parent-assignment', '4:sol', good=False,
             error='repair assignment does not match its parent')
        child = prepare('4x', 'repair', *child_args)
        assert list(child['assignments']) == ['terra'], child['assignments']
        assert child['assignments']['terra']['bundle'] == parent['assignments']['sol']['bundle']
        assert child['assignments']['terra']['scope'] == 'full'
        assert child['parent_assignment']['seat'] == 'sol'
        assert child['parent_assignment']['adapter'] == 'claude'
        assert prepare('4x', 'repair', *child_args) == child, 'the same replacement re-prepares'
        (session / 'r4-opus.exit').write_text('2\n')
        (session / 'r4-opus.audit-invalid.json').write_text('{"summary":"kept","findings":[]}\n')
        call('prepare', session, '4x', '--phase', 'repair', '--assignment', 'sol=' + bundles[2],
             '--parent-assignment', '4:opus', good=False,
             error='replacement label is already bound to another parent assignment')
        call('prepare', session, '4x', '--phase', 'repair', '--assignment', 'terra=' + bundles[2],
             '--parent-assignment', '4:opus', good=False,
             error='replacement label is already bound to another parent assignment')
        (session / 'r4-opus.exit').write_text('0\n')
        (session / 'r4-opus.audit-invalid.json').unlink()
        child_path = session / 'r4x-evidence.manifest.json'
        (session / 'r4x-terra.prompt.md').write_text(call('render', child_path, 'terra'))
        (session / 'r4x-terra.json').write_text(json.dumps({'summary': 'child', 'findings': [
            {'severity': 'P2', 'file': 'main.py', 'line_start': 2, 'line_end': 2, 'claim': 'child claim',
             'evidence': 'e', 'suggested_fix': 'f', 'confidence': 0.9}]}))
        (session / 'r4x-terra.exit').write_text('2\n')
        write_agent_audit(session, '4x', 'terra')
        call('receipt', session, '4', '--replacement', 'sol=4x', good=False, error='seat failed: terra')
        assert not (session / 'r4-coverage.receipt.json').exists(), 'a failed replacement seals nothing'
        (session / 'r4x-terra.exit').write_text('0\n')
        call('verify-panel', session, '4', '--replacement', 'sol=4x', '--replacement', 'opus=4x',
             good=False, error='replacement child labels must be unique')
        (session / 'r4-opus.exit').write_text('2\n')
        (session / 'r4-opus.audit-invalid.json').write_text('{"summary":"kept","findings":[]}\n')
        second_child = prepare('4x2', 'repair', '--assignment', 'sol=' + bundles[2],
                               '--parent-assignment', '4:opus')
        second_path = session / 'r4x2-evidence.manifest.json'
        (session / 'r4x2-sol.prompt.md').write_text(call('render', second_path, 'sol'))
        (session / 'r4x2-sol.json').write_text(json.dumps({'summary': 'second child', 'findings': [
            {'severity': 'P2', 'file': 'main.py', 'line_start': 2, 'line_end': 2,
             'claim': 'second child claim', 'evidence': 'e', 'suggested_fix': 'f', 'confidence': 0.9}]}))
        (session / 'r4x2-sol.exit').write_text('0\n')
        write_agent_audit(session, '4x2', 'sol')
        assert second_child['parent_assignment']['seat'] == 'opus'
        verified = json.loads(call('verify-panel', session, '4', '--replacement', 'sol=4x',
                                   '--replacement', 'opus=4x2'))
        assert verified['replacements'] == {'sol': '4x', 'opus': '4x2'}
        call('receipt', session, '4', '--replacement', 'sol=4x', '--replacement', 'opus=4x2')
        receipt = json.loads((session / 'r4-coverage.receipt.json').read_text())
        rows = receipt['selected_generations']
        assert (rows['sol']['label'], rows['sol']['seat'], rows['sol']['adapter'],
                rows['sol']['enforced']) == ('4x', 'terra', 'codex', True), rows['sol']
        assert rows['sol']['result_sha256'] == module.digest((session / 'r4x-terra.json').read_bytes())
        assert (rows['opus']['label'], rows['opus']['seat']) == ('4x2', 'sol'), rows['opus']
        assert receipt['selected_generations']['terra']['label'] == '4'
        assert [(f['claim'], f['owners']) for f in receipt['findings']] == [
            ('child claim', ['sol']), ('second child claim', ['opus'])], receipt['findings']

    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        chain_identities = {
            'sol': ('claude', 'sonnet'),
            'terra': ('codex', 'gpt-5.6-sol'),
            'opus': ('claude', 'opus'),
            'sonnet': ('codex', 'gpt-5.6-luna'),
        }
        roster = {'seats': [
            {'seat': seat, 'extra': False, 'adapter': chain_identities[seat][0],
             'model': chain_identities[seat][1], 'effort': 'high'} for seat in seats]}
        (session / 'roster.json').write_text(json.dumps(roster))
        parent = prepare('5', 'risk', *assign, '--full-seat', 'sonnet')
        owner = parent['mechanical_owner']
        assert parent['assignments'][owner]['scope'] == 'full'
        path = session / 'r5-evidence.manifest.json'
        prompt = session / f'r5-{owner}.prompt.md'; prompt.write_text(call('render', path, owner))
        def launch(code):
            assert subprocess.run([sys.executable, str(attempt), 'reserve', session, '5', owner, prompt]).returncode == 0
            assert subprocess.run([sys.executable, str(attempt), 'record', session, '5', owner, prompt, code]).returncode == 0
            (session / f'r5-{owner}.exit').write_text(code + '\n')
        executor = next(seat for seat in seats if seat != owner)
        bundle = parent['assignments'][owner]['bundle']
        args = ('--assignment', executor + '=' + bundle, '--parent-assignment', '5:' + owner)
        launch('1')
        call('prepare', session, '5x', '--phase', 'repair', *args, good=False,
             error='parent assignment has no recorded terminal failure')
        launch('2')
        child = prepare('5x', 'repair', *args)
        assert child['assignments'][executor]['scope'] == 'full'
        assert child['assignments'][executor]['full_state'] is True
        assert child['assignments'][executor]['bundle'] == bundle

def replacement_accepts_only_durable_provider_exit_3():
    for code in ('3', '4'):
        with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
            chain_identities = {
                'sol': ('claude', 'sonnet', 'high'),
                'terra': ('codex', 'gpt-5.6-sol', 'high'),
                'opus': ('codex', 'gpt-5.6-luna', 'high'),
                'sonnet': ('agent', 'sonnet', 'high'),
            }
            roster = {'seats': [
                {'seat': seat, 'extra': False, 'adapter': chain_identities[seat][0],
                 'model': chain_identities[seat][1], 'effort': chain_identities[seat][2]}
                for seat in seats]}
            (session / 'roster.json').write_text(json.dumps(roster))
            parent = prepare('9', 'risk', *assign, '--full-seat', 'sonnet')
            prompt = session / 'r9-sol.prompt.md'
            prompt.write_text('review\n')
            token = '1' * 32
            assert reserve_launch_bound(session, '9', 'sol', prompt, token).returncode == 0
            assert record_launch_bound(session, '9', 'sol', prompt, code, token).returncode == 0
            (session / 'r9-sol.exit').write_text(code + '\n')
            child_args = ('--assignment', 'terra=' + parent['assignments']['sol']['bundle'],
                          '--parent-assignment', '9:sol')
            if code == '3':
                child = prepare('9x', 'repair', *child_args)
                assert child['parent_assignment']['seat'] == 'sol'
                assert list(child['assignments']) == ['terra']
            else:
                call('prepare', session, '9x', '--phase', 'repair', *child_args, good=False,
                     error='parent assignment has no recorded terminal failure')

def replacement_requires_quota_disabled_escalation_record():
    attempt_script = Path(script).parent / 'lib' / 'rev-attempt.py'

    def prepare_exit_4(session, prepare, env, retry_code=None):
        chain_identities = {
            'sol': ('claude', 'sonnet', 'high'),
            'terra': ('codex', 'gpt-5.6-sol', 'high'),
            'opus': ('codex', 'gpt-5.6-luna', 'high'),
            'sonnet': ('agent', 'sonnet', 'high'),
        }
        roster = {'seats': [
            {'seat': seat, 'extra': False, 'adapter': identity[0],
             'model': identity[1], 'effort': identity[2]}
            for seat, identity in chain_identities.items()]}
        (session / 'roster.json').write_text(json.dumps(roster))
        parent = prepare('11', 'risk', *assign, '--full-seat', 'sonnet', env=env)
        prompt = session / 'r11-sol.prompt.md'
        prompt.write_text('review\n')
        token = '2' * 32
        assert reserve_launch_bound(session, '11', 'sol', prompt, token).returncode == 0
        assert record_launch_bound(session, '11', 'sol', prompt, '4', token).returncode == 0
        final_exit = '4'
        if retry_code is not None:
            retry_token = '3' * 32
            assert reserve_launch_bound(session, '11', 'sol', prompt, retry_token).returncode == 0
            assert record_launch_bound(
                session, '11', 'sol', prompt, retry_code, retry_token).returncode == 0
            final_exit = retry_code
        (session / 'r11-sol.exit').write_text(final_exit + '\n')
        child_args = ('--assignment', 'terra=' + parent['assignments']['sol']['bundle'],
                      '--parent-assignment', '11:sol')
        return prompt, child_args

    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        config = session / 'review-council-config.json'
        config.write_text('{}\n')
        env = {'REVIEW_COUNCIL_CONFIG': str(config)}
        prompt, child_args = prepare_exit_4(session, prepare, env)
        call('prepare', session, '11x', '--phase', 'repair', *child_args, env=env,
             good=False, error='parent assignment has no recorded terminal failure')
        attempt_path = next((session / 'attempts').glob('*.json'))
        config_sha = hashlib.sha256(b'{}').hexdigest()
        marker = {
            'schema_version': 1, 'panel': '11', 'failed_seat': 'sol', 'failed_exit': 4,
            'replacement_seat': 'terra', 'quota_fallback': False,
            'config_sha256': config_sha,
            'prompt_sha256': hashlib.sha256(prompt.read_bytes()).hexdigest(),
            'attempt_sha256': hashlib.sha256(attempt_path.read_bytes()).hexdigest(),
        }
        marker_path = session / 'r11-sol.quota-disabled-escalation.json'
        marker_path.write_text(json.dumps(marker) + '\n')
        marker_path.chmod(0o600)
        marker['panel'] = '10'
        marker_path.write_text(json.dumps(marker) + '\n')
        marker_path.chmod(0o600)
        call('prepare', session, '11x2', '--phase', 'repair', *child_args, env=env,
             good=False, error='parent assignment has no recorded terminal failure')
        marker['panel'] = '11'
        marker_path.write_text(json.dumps(marker) + '\n')
        marker_path.chmod(0o600)
        child = prepare('11x', 'repair', *child_args, env=env)
        assert child['parent_assignment']['seat'] == 'sol'
        assert child['replacement_executor']['seat'] == 'terra'
        assert list(child['assignments']) == ['terra']
        marker_path.unlink()
        call('record-quota-disabled-escalation', session, '11', 'sol', 'terra', env=env,
             entrypoint=attempt_script)
        child = prepare('11x', 'repair', *child_args, env=env)
        prompt.write_text('changed prompt\n')
        call('prepare', session, '11x2', '--phase', 'repair', *child_args, env=env,
             good=False, error='parent assignment has no recorded terminal failure')
        prompt.write_text('review\n')
        config.write_text('{"extra":true}\n')
        call('prepare', session, '11x3', '--phase', 'repair', *child_args, env=env,
             good=False, error='parent assignment has no recorded terminal failure')

    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        config = session / 'review-council-config.json'
        config.write_text('{}\n')
        env = {'REVIEW_COUNCIL_CONFIG': str(config)}
        prompt, child_args = prepare_exit_4(session, prepare, env, retry_code='2')
        call('record-quota-disabled-escalation', session, '11', 'sol', 'terra', env=env,
             entrypoint=attempt_script)
        child = prepare('11x', 'repair', *child_args, env=env)
        assert child['parent_assignment']['seat'] == 'sol'
        assert child['replacement_executor']['seat'] == 'terra'
        assert list(child['assignments']) == ['terra']

    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        config = session / 'review-council-config.json'
        config.write_text('{}\n')
        env = {'REVIEW_COUNCIL_CONFIG': str(config)}
        prompt, child_args = prepare_exit_4(session, prepare, env, retry_code='1')
        call('record-quota-disabled-escalation', session, '11', 'sol', 'terra', env=env,
             good=False, entrypoint=attempt_script)
        call('prepare', session, '11x', '--phase', 'repair', *child_args, env=env,
             good=False, error='parent assignment has no recorded terminal failure')

    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        config = session / 'review-council-config.json'
        config.write_text('{}\n')
        env = {'REVIEW_COUNCIL_CONFIG': str(config)}
        prompt, child_args = prepare_exit_4(session, prepare, env)
        call('record-quota-disabled-escalation', session, '11', 'sol', 'opus', env=env,
             entrypoint=attempt_script)
        call('prepare', session, '11x', '--phase', 'repair', *child_args, env=env,
             good=False, error='parent assignment has no recorded terminal failure')

    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        config = session / 'review-council-config.json'
        config.write_text('{"quota_fallback":true}\n')
        env = {'REVIEW_COUNCIL_CONFIG': str(config)}
        prompt, child_args = prepare_exit_4(session, prepare, env)
        call('record-quota-disabled-escalation', session, '11', 'sol', 'terra', env=env,
             good=False, entrypoint=attempt_script)
        call('prepare', session, '11x', '--phase', 'repair', *child_args, env=env,
             good=False, error='parent assignment has no recorded terminal failure')

def replacement_accepts_only_a_recorded_owned_provider_cancellation():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        chain_identities = {
            'sol': ('claude', 'opus', 'high'),
            'terra': ('codex', 'gpt-5.6-sol', 'high'),
            'opus': ('codex', 'gpt-5.6-luna', 'high'),
            'sonnet': ('agent', 'sonnet', 'high'),
            'unassigned': ('codex', 'gpt-5.6-luna', 'high'),
        }
        roster = {'seats': [
            {'seat': seat, 'extra': seat == 'unassigned', 'adapter': chain_identities[seat][0],
             'model': chain_identities[seat][1], 'effort': chain_identities[seat][2]}
            for seat in chain_identities]}
        (session / 'roster.json').write_text(json.dumps(roster))
        parent = prepare('10', 'risk', *assign, '--full-seat', 'sonnet')
        trigger_prompt = session / 'r10-opus.prompt.md'
        cancelled_prompt = session / 'r10-terra.prompt.md'
        trigger_prompt.write_text('trigger review\n')
        cancelled_prompt.write_text('cancelled sibling review\n')
        assert reserve_launch_bound(session, '10', 'opus', trigger_prompt, '2' * 32).returncode == 0
        assert record_launch_bound(session, '10', 'opus', trigger_prompt, '3', '2' * 32).returncode == 0
        (session / 'r10-opus.exit').write_text('3\n')
        assert reserve_launch_bound(session, '10', 'terra', cancelled_prompt, '3' * 32).returncode == 0
        assert record_launch_bound(session, '10', 'terra', cancelled_prompt, '130', '3' * 32).returncode == 0
        (session / 'r10-terra.exit').write_text('130\n')
        started = 'cli\n33828\nMon Oct 26 21:41:50 2026\n'
        (session / 'r10-terra.started').write_text(started)
        unassigned_prompt = session / 'r10-unassigned.prompt.md'
        unassigned_prompt.write_text('unassigned trigger\n')
        assert reserve_launch_bound(session, '10', 'unassigned', unassigned_prompt, '6' * 32).returncode == 0
        assert record_launch_bound(session, '10', 'unassigned', unassigned_prompt, '3', '6' * 32).returncode == 0
        (session / 'r10-unassigned.exit').write_text('3\n')
        child_args = ('--assignment', 'sol=' + parent['assignments']['terra']['bundle'],
                      '--parent-assignment', '10:terra')
        call('prepare', session, '10x', '--phase', 'repair', *child_args, good=False,
             error='parent assignment has no recorded terminal failure')
        recovery = {
            'trigger_seat': 'opus',
            'trigger_exit': 3,
            'diagnostic': 'provider exited and its sibling was cancelled',
            'claim': 'controller-owned cancellation',
            'cancelled_sibling': 'terra',
            'owned_execution_handle': 33828,
            'started_identity': started,
            'cancellation_result': 130,
            'preserved_valid': 'sol',
            'source_unchanged': True,
        }
        (session / 'r10-provider-recovery.json').write_text(json.dumps(recovery))
        child = prepare('10x', 'repair', *child_args)
        assert child['parent_assignment']['seat'] == 'terra'
        assert list(child['assignments']) == ['sol']
        recovery['trigger_seat'] = 'unassigned'
        (session / 'r10-provider-recovery.json').write_text(json.dumps(recovery))
        call('prepare', session, '10x2', '--phase', 'repair', *child_args, good=False,
             error='parent assignment has no recorded terminal failure')
        recovery['trigger_seat'] = '../../etc/passwd'
        (session / 'r10-provider-recovery.json').write_text(json.dumps(recovery))
        call('prepare', session, '10x3', '--phase', 'repair', *child_args, good=False,
             error='parent assignment has no recorded terminal failure')
        recovery['started_identity'] = 'cli\n99999\nchanged start identity\n'
        recovery['trigger_seat'] = 'opus'
        (session / 'r10-provider-recovery.json').write_text(json.dumps(recovery))
        call('prepare', session, '10x2', '--phase', 'repair', *child_args, good=False,
             error='parent assignment has no recorded terminal failure')

def record_provider_cancellation_binds_the_finished_attempts():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        chain_identities = {
            'sol': ('claude', 'opus', 'high'),
            'terra': ('codex', 'gpt-5.6-sol', 'high'),
            'opus': ('codex', 'gpt-5.6-luna', 'high'),
            'sonnet': ('agent', 'sonnet', 'high'),
        }
        roster = {'seats': [
            {'seat': seat, 'extra': False, 'adapter': chain_identities[seat][0],
             'model': chain_identities[seat][1], 'effort': chain_identities[seat][2]}
            for seat in seats]}
        (session / 'roster.json').write_text(json.dumps(roster))
        parent = prepare('11', 'risk', *assign, '--full-seat', 'sonnet')
        trigger_prompt = session / 'r11-opus.prompt.md'
        cancelled_prompt = session / 'r11-terra.prompt.md'
        trigger_prompt.write_text('trigger review\n')
        cancelled_prompt.write_text('cancelled sibling review\n')
        for seat, prompt, code, token in (('opus', trigger_prompt, '3', '4' * 32),
                                          ('terra', cancelled_prompt, '130', '5' * 32)):
            assert reserve_launch_bound(session, '11', seat, prompt, token).returncode == 0
            assert record_launch_bound(session, '11', seat, prompt, code, token).returncode == 0
            (session / f'r11-{seat}.exit').write_text(code + '\n')
        (session / 'r11-terra.started').write_text('cli\n33829\nMon Oct 26 21:42:00 2026\n')
        attempt = script.parent / 'lib' / 'rev-attempt.py'
        recorded = subprocess.run([
            sys.executable, str(attempt), 'record-provider-cancellation', session,
            '11', 'opus', 'terra', 'task-33829'], capture_output=True, text=True)
        assert recorded.returncode == 0, recorded.stderr
        event = json.loads((session / 'r11-terra.provider-recovery.json').read_text())
        assert event['schema_version'] == 1
        assert event['trigger_exit'] == 3 and event['cancellation_result'] == 130
        child = prepare('11x', 'repair', '--assignment', 'sol=' + parent['assignments']['terra']['bundle'],
                        '--parent-assignment', '11:terra')
        assert child['parent_assignment']['seat'] == 'terra'
        event['cancelled_attempt_sha256'] = '0' * 64
        (session / 'r11-terra.provider-recovery.json').write_text(json.dumps(event))
        call('prepare', session, '11x2', '--phase', 'repair', '--assignment',
             'sol=' + parent['assignments']['terra']['bundle'], '--parent-assignment', '11:terra',
             good=False, error='parent assignment has no recorded terminal failure')

def replacement_chain_reaches_opus():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        root_seats = ['codex-luna', 'codex-luna-2', 'codex-luna-3', 'codex-luna-4']
        roster = {'seats': [
            {'seat': seat, 'extra': False, 'adapter': 'codex',
             'model': 'gpt-5.6-luna', 'effort': 'high'} for seat in root_seats]}
        (session / 'roster.json').write_text(json.dumps(roster))
        root_assignments = [
            '--assignment', root_seats[0] + '=' + bundles[0],
            '--assignment', root_seats[1] + '=' + bundles[1],
            '--assignment', root_seats[2] + '=' + bundles[2],
            '--assignment', root_seats[3] + '=' + bundles[3],
            '--full-seat', root_seats[3],
        ]
        parent = prepare('chain', 'risk', *root_assignments)
        root_path = session / 'rchain-evidence.manifest.json'
        for seat in parent['assignments']:
            (session / f'rchain-{seat}.prompt.md').write_text(call('render', root_path, seat))
            (session / f'rchain-{seat}.json').write_text('{"summary":"root","findings":[]}')
            (session / f'rchain-{seat}.exit').write_text('0\n')
            if seat != root_seats[0]:
                write_agent_audit(session, 'chain', seat)
        (session / f'rchain-{root_seats[0]}.exit').write_text('2\n')
        (session / f'rchain-{root_seats[0]}.audit-invalid.json').write_text(
            '{"summary":"terminal failure","findings":[]}\n')
        failed_bundle = parent['assignments'][root_seats[0]]['bundle']

        replacements = [
            ('chainx', 'chain', root_seats[0], 'escalate-sonnet', 'sonnet',
             'claude', 'sonnet', 'high'),
            ('chainx2', 'chainx', 'escalate-sonnet', 'escalate-sol', 'sol',
             'codex', 'gpt-5.6-sol', 'high'),
            ('chainx3', 'chainx2', 'escalate-sol', 'escalate-opus', 'opus',
             'claude', 'opus', 'high'),
        ]
        for index, (label, parent_label, parent_seat, executor, family,
                    adapter, model, effort) in enumerate(replacements):
            (session / 'escalation.json').write_text(json.dumps({
                'version': 1, 'seat': executor, 'family': family,
                'lab': 'openai' if family == 'sol' else 'anthropic',
                'adapter': adapter, 'model': model, 'effort': effort,
                'extra': False,
            }))
            child = prepare(label, 'repair', '--assignment', executor + '=' + failed_bundle,
                            '--parent-assignment', parent_label + ':' + parent_seat)
            assert child['replacement_executor'] == {
                'seat': executor, 'family': family, 'adapter': adapter,
                'model': model, 'effort': effort, 'extra': False,
            }, child['replacement_executor']
            child_path = session / f'r{label}-evidence.manifest.json'
            (session / f'r{label}-{executor}.prompt.md').write_text(
                call('render', child_path, executor))
            (session / f'r{label}-{executor}.json').write_text(
                '{"summary":"replacement","findings":[]}')
            if index < len(replacements) - 1:
                (session / f'r{label}-{executor}.exit').write_text('2\n')
                (session / f'r{label}-{executor}.audit-invalid.json').write_text(
                    '{"summary":"terminal failure","findings":[]}\n')
            else:
                (session / f'r{label}-{executor}.exit').write_text('0\n')
                write_agent_audit(session, label, executor)

        (session / 'rchainx3-escalate-opus.exit').write_text('2\n')
        (session / 'rchainx3-escalate-opus.audit-invalid.json').write_text(
            '{"summary":"terminal failure","findings":[]}\n')
        (session / 'escalation.json').write_text(json.dumps({
            'version': 1, 'seat': 'escalate-sol', 'family': 'sol', 'lab': 'openai',
            'adapter': 'codex', 'model': 'gpt-5.6-sol', 'effort': 'high', 'extra': False,
        }))
        call('prepare', session, 'chainx4', '--phase', 'repair', '--assignment',
             'escalate-sol=' + failed_bundle, '--parent-assignment',
             'chainx3:escalate-opus', good=False,
             error='replacement executor must advance the default model chain')
        (session / 'rchainx3-escalate-opus.exit').write_text('0\n')
        (session / 'rchainx3-escalate-opus.audit-invalid.json').unlink()

        verified = json.loads(call('verify-panel', session, 'chain', '--replacement',
                                   root_seats[0] + '=chainx3'))
        assert verified['replacements'] == {root_seats[0]: 'chainx3'}
        selected = verified['selected_generations']
        assert (selected[root_seats[0]]['label'], selected[root_seats[0]]['seat']) == (
            'chainx3', 'escalate-opus')
        assert all(selected[seat]['label'] == 'chain' for seat in root_seats[1:])
        call('receipt', session, 'chain', '--replacement', root_seats[0] + '=chainx3')

def incomplete_proof_panel(session, call, prepare, summary='INCOMPLETE PROOF: assigned source remains unread', phase='risk'):
    """A risk panel whose sol seat exits 0 with `summary` and a valid read audit."""
    roster = {'seats': [{'seat': seat, 'extra': False,
                         'adapter': 'codex' if seat == 'sol' else 'claude',
                         'model': 'gpt-5.6-luna' if seat == 'sol' else
                         'sonnet' if seat == 'terra' else 'model-' + seat,
                         'effort': 'high' if seat in ('sol', 'terra') else 'max'}
                        for seat in seats]}
    (session / 'roster.json').write_text(json.dumps(roster))
    path = session / 'r6-evidence.manifest.json'
    for seat in prepare('6', phase, *assign)['assignments']:
        (session / f'r6-{seat}.prompt.md').write_text(call('render', path, seat))
        (session / f'r6-{seat}.json').write_text(json.dumps(
            {'summary': summary if seat == 'sol' else 'parent', 'findings': []}))
        (session / f'r6-{seat}.exit').write_text('0\n')
        write_agent_audit(session, '6', seat)

def reserve_launch(session, label, seat, prompt):
    return subprocess.run([sys.executable, str(script.parent / 'lib' / 'rev-attempt.py'), 'reserve',
                           session, label, seat, prompt], capture_output=True, text=True)

def reserve_launch_bound(session, label, seat, prompt, token):
    return subprocess.run([sys.executable, str(script.parent / 'lib' / 'rev-attempt.py'), 'reserve',
                           session, label, seat, prompt, token], capture_output=True, text=True)

def record_launch(session, label, seat, prompt, code):
    return subprocess.run([sys.executable, str(script.parent / 'lib' / 'rev-attempt.py'), 'record',
                           session, label, seat, prompt, code], capture_output=True, text=True)

def record_launch_bound(session, label, seat, prompt, code, token):
    return subprocess.run([sys.executable, str(script.parent / 'lib' / 'rev-attempt.py'), 'record',
                           session, label, seat, prompt, code, token], capture_output=True, text=True)

def incomplete_proof_is_never_a_valid_result():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare)
        for command in ('verify-panel', 'receipt'):
            call(command, session, '6', good=False, error='incomplete proof: sol')
        assert not (session / 'r6-coverage.receipt.json').exists(), 'an incomplete proof seals nothing'

def semantic_rejection_revokes_sealed_coverage():
    with fixture(adapter='codex') as (root, session, git, write, call, prepare, finish):
        manifest = prepare('semantic', 'verification', *assign)
        finish('semantic')
        before = json.loads(call('current-coverage', session))
        assert before['eligible'] is True, before
        stem = 'rsemantic-sol'
        hashes, generation = module.result_generation(
            session, manifest, module.digest((session / 'rsemantic-evidence.manifest.json').read_bytes()), 'sol')
        record = {'schema_version': 1, 'label': 'semantic', 'seat': 'sol',
                  'generation': generation, 'obligation': 'Read the entire assigned patch',
                  'evidence': 'verified', 'reason': 'The mandatory assertion review was left unfinished.'}
        (session / (stem + '.semantic-rejection.json')).write_bytes(module.encoded(record))
        after = json.loads(call('current-coverage', session))
        assert after['eligible'] is False, 'a semantically rejected selected generation cannot remain reusable'
        assert 'semantic rejection' in after['reason'], after
        call('receipt', session, 'semantic', good=False, error='semantic rejection')
        assert all((session / name).read_bytes() and module.digest((session / name).read_bytes()) == digest
                   for name, digest in hashes.items()), 'semantic rejection preserves observed provider artifacts'

def reject_semantic_generation(session, call, label='6', seat='sol', **overrides):
    manifest_path = session / f'r{label}-evidence.manifest.json'
    manifest = json.loads(manifest_path.read_text())
    _, generation = module.result_generation(session, manifest, module.digest(manifest_path.read_bytes()), seat)
    values = {'manifest-sha256': generation['manifest_sha256'],
              'prompt-sha256': generation['prompt_sha256'], 'result-sha256': generation['result_sha256'],
              'obligation': 'Read the entire assigned patch', 'evidence': 'unfinished',
              'reason': 'The returned summary explicitly leaves its mandatory check unfinished.'}
    values.update(overrides)
    arguments = [part for name, value in values.items() for part in ('--' + name, value)]
    return call('reject-result', session, label, seat, *arguments)

def semantic_rejection_checks_identity_and_preserves_siblings():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare, 'The assertion check is unfinished.', phase='verification')
        call('receipt', session, '6')
        original = {p.name: p.read_bytes() for p in session.glob('r6-*') if p.is_file()}
        for key in ('manifest-sha256', 'prompt-sha256', 'result-sha256'):
            try:
                reject_semantic_generation(session, call, **{key: '0' * 64})
            except AssertionError as error:
                assert 'semantic rejection identity mismatch' in str(error), error
            else:
                raise AssertionError('a forged expected ' + key + ' was accepted')
        assert json.loads(call('current-coverage', session))['eligible'] is True
        path = Path(reject_semantic_generation(session, call).strip())
        record = json.loads(path.read_text())
        raw = path.read_bytes()
        assert record['generation']['exit_sha256'] == module.digest(b'0\n')
        assert all((session / name).read_bytes() == data for name, data in original.items())
        assert reserve_launch(session, '6', 'sol', session / 'r6-sol.prompt.md').returncode == 2
        assert reserve_launch(session, '6', 'terra', session / 'r6-terra.prompt.md').returncode == 0
        (session / 'state.json').write_text(json.dumps({'round': '6', 'phase': 'collect', 'seats': ['sol', 'terra']}))
        status = subprocess.check_output([str(script.parent / 'rev-status.sh'), str(session)], text=True)
        assert 'sol: semantic rejection' in status and 'terra: done' in status, status
        values = [part for key, value in (
            ('manifest-sha256', record['generation']['manifest_sha256']),
            ('prompt-sha256', record['generation']['prompt_sha256']),
            ('result-sha256', record['generation']['result_sha256']),
            ('obligation', record['obligation']), ('evidence', record['evidence']), ('reason', record['reason']))
            for part in ('--' + key, value)]
        call('reject-result', session, '6', 'sol', *values)
        assert path.read_bytes() == raw, 'an identical rejection is idempotent'
        call('reject-result', session, '6', 'sol', *values[:-1], 'another reason',
             good=False, error='semantic rejection is immutable')
        prepare('unrelated', 'verification', *assign)
        finish('unrelated')
        assert json.loads(call('current-coverage', session))['eligible'] is True, 'unrelated coverage stays eligible'

def semantic_rejection_replaces_a_previously_sealed_child():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare, 'The assertion check is unfinished.', phase='verification')
        call('receipt', session, '6')
        original = (session / 'r6-coverage.receipt.json').read_bytes()
        sibling = (session / 'r6-terra.json').read_bytes()
        reject_semantic_generation(session, call)
        prepare('6x', 'repair', '--assignment', 'terra=' + bundles[0], '--parent-assignment', '6:sol')
        (session / 'r6x-terra.prompt.md').write_text(call('render', session / 'r6x-evidence.manifest.json', 'terra'))
        (session / 'r6x-terra.json').write_text('{"summary":"A mandatory check remains unfinished.","findings":[]}')
        (session / 'r6x-terra.exit').write_text('0\n')
        write_agent_audit(session, '6x', 'terra')
        first_path = Path(call('receipt', session, '6', '--replacement', 'sol=6x').strip())
        first_raw = first_path.read_bytes()
        first = json.loads(first_raw)
        assert first['supersedes']['sha256'] == module.digest(original)
        assert first['supersedes']['receipt'] == 'r6-coverage.receipt.json'
        assert json.loads(call('current-coverage', session))['eligible'] is True
        reject_semantic_generation(session, call, '6x', 'terra')
        assert json.loads(call('current-coverage', session))['eligible'] is False
        (session / 'escalation.json').write_text(json.dumps({
            'version': 1, 'seat': 'escalate-sol', 'family': 'sol', 'lab': 'openai',
            'adapter': 'codex', 'model': 'gpt-5.6-sol', 'effort': 'high', 'extra': False}))
        prepare('6x2', 'repair', '--assignment', 'escalate-sol=' + bundles[0], '--parent-assignment', '6x:terra')
        (session / 'r6x2-escalate-sol.prompt.md').write_text(
            call('render', session / 'r6x2-evidence.manifest.json', 'escalate-sol'))
        (session / 'r6x2-escalate-sol.json').write_text('{"summary":"verified","findings":[]}')
        (session / 'r6x2-escalate-sol.exit').write_text('0\n')
        write_agent_audit(session, '6x2', 'escalate-sol')
        second_path = Path(call('receipt', session, '6', '--replacement', 'sol=6x2').strip())
        second = json.loads(second_path.read_text())
        assert second['supersedes']['receipt'] == first_path.name
        assert second['supersedes']['sha256'] == module.digest(first_raw)
        assert 'r6x-terra.semantic-rejection.json' in second['supersedes']['rejections']
        coverage = json.loads(call('current-coverage', session))
        assert coverage['eligible'] is True, coverage
        assert coverage['selected_generations']['sol']['label'] == '6x2'
        assert coverage['selected_generations']['terra']['label'] == '6'
        assert (session / 'r6-coverage.receipt.json').read_bytes() == original
        assert first_path.read_bytes() == first_raw
        assert (session / 'r6-terra.json').read_bytes() == sibling
        assert call('receipt', session, '6', '--replacement', 'sol=6x2').strip() == str(second_path)
        call('verify-panel', session, '6', '--replacement', 'sol=6x', good=False, error='semantic rejection')
        call('review-origin', session, '6')
        before_head = (session / 'coverage-head.json').read_bytes()
        forged = dict(second)
        forged['supersedes'] = dict(second['supersedes'], sha256='0' * 64)
        forged_raw = module.encoded(forged)
        forged_path = session / ('r6-coverage.receipt-' + module.digest(forged_raw) + '.json')
        forged_path.write_bytes(forged_raw)
        (session / 'coverage-head.json').write_bytes(module.encoded(
            {'receipt': forged_path.name, 'sha256': module.digest(forged_raw)}))
        assert json.loads(call('current-coverage', session))['eligible'] is False
        (session / 'coverage-head.json').write_bytes(before_head)
        forged_path.unlink()

def semantic_rejection_retry_promotes_existing_successor():
    from types import SimpleNamespace
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare, 'The assertion check is unfinished.', phase='verification')
        original_path = Path(call('receipt', session, '6').strip())
        original_raw = original_path.read_bytes()
        reject_semantic_generation(session, call)
        prepare('6x', 'repair', '--assignment', 'terra=' + bundles[0], '--parent-assignment', '6:sol')
        (session / 'r6x-terra.prompt.md').write_text(call('render', session / 'r6x-evidence.manifest.json', 'terra'))
        (session / 'r6x-terra.json').write_text('{"summary":"verified","findings":[]}')
        (session / 'r6x-terra.exit').write_text('0\n')
        write_agent_audit(session, '6x', 'terra')
        args = SimpleNamespace(session=str(session), label='6', replacement=['sol=6x'])
        publish = module.publish
        def interrupt_before_head(path, raw):
            if path.name == 'coverage-head.json':
                raise OSError('simulated stop before advancing coverage head')
            publish(path, raw)
        module.publish = interrupt_before_head
        try:
            try:
                module.receipt(args)
            except OSError as error:
                assert str(error) == 'simulated stop before advancing coverage head'
            else:
                raise AssertionError('the simulated head publication stop did not occur')
        finally:
            module.publish = publish
        successor = module.receipt_path_for_label(session, '6')
        head_path = session / 'coverage-head.json'
        original_head = {'receipt': original_path.name, 'sha256': module.digest(original_raw)}
        assert json.loads(head_path.read_bytes()) == original_head
        assert json.loads(call('current-coverage', session))['eligible'] is False
        module.receipt(args)
        successor_raw = successor.read_bytes()
        successor_head = {'receipt': successor.name, 'sha256': module.digest(successor_raw)}
        assert json.loads(head_path.read_bytes()) == successor_head
        assert json.loads(call('current-coverage', session))['eligible'] is True
        prepare('later', 'verification', *assign)
        finish('later')
        call('receipt', session, 'later')
        later_head = head_path.read_bytes()
        assert json.loads(later_head)['receipt'] == 'rlater-coverage.receipt.json'
        module.receipt(args)
        assert head_path.read_bytes() == later_head

def semantic_rejection_replaces_a_different_original_sibling():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare, 'The assertion check is unfinished.', phase='verification')
        call('receipt', session, '6')
        original = (session / 'r6-coverage.receipt.json').read_bytes()
        reject_semantic_generation(session, call)
        prepare('6x', 'repair', '--assignment', 'terra=' + bundles[0], '--parent-assignment', '6:sol')
        (session / 'r6x-terra.prompt.md').write_text(call('render', session / 'r6x-evidence.manifest.json', 'terra'))
        (session / 'r6x-terra.json').write_text('{"summary":"verified","findings":[]}')
        (session / 'r6x-terra.exit').write_text('0\n')
        write_agent_audit(session, '6x', 'terra')
        first_path = Path(call('receipt', session, '6', '--replacement', 'sol=6x').strip())
        first_raw = first_path.read_bytes()
        reject_semantic_generation(session, call, '6', 'terra', evidence='parent')
        assert json.loads(call('current-coverage', session))['eligible'] is False
        try:
            module.validate_receipt_lineage(session, first_path.name, first_raw)
        except ValueError as error:
            raise AssertionError('later sibling rejection must preserve the historical successor edge') from error
        (session / 'escalation.json').write_text(json.dumps({
            'version': 1, 'seat': 'escalate-sol', 'family': 'sol', 'lab': 'openai',
            'adapter': 'codex', 'model': 'gpt-5.6-sol', 'effort': 'high', 'extra': False}))
        prepare('6x2', 'repair', '--assignment', 'escalate-sol=' + bundles[1], '--parent-assignment', '6:terra')
        (session / 'r6x2-escalate-sol.prompt.md').write_text(
            call('render', session / 'r6x2-evidence.manifest.json', 'escalate-sol'))
        (session / 'r6x2-escalate-sol.json').write_text('{"summary":"verified","findings":[]}')
        (session / 'r6x2-escalate-sol.exit').write_text('0\n')
        write_agent_audit(session, '6x2', 'escalate-sol')
        second_path = Path(call('receipt', session, '6', '--replacement', 'sol=6x',
                                '--replacement', 'terra=6x2').strip())
        second = json.loads(second_path.read_text())
        assert second['supersedes']['receipt'] == first_path.name
        assert set(second['supersedes']['rejections']) == {'r6-terra.semantic-rejection.json'}
        valid_binding = second['supersedes']['rejections']
        root_rejection = 'r6-sol.semantic-rejection.json'
        for invalid in ({}, {'r6-terra.semantic-rejection.json': '0' * 64},
                        dict(valid_binding, **{root_rejection: module.digest((session / root_rejection).read_bytes())})):
            forged = dict(second, supersedes=dict(second['supersedes'], rejections=invalid))
            forged_raw = module.encoded(forged)
            forged_name = 'r6-coverage.receipt-' + module.digest(forged_raw) + '.json'
            try:
                module.validate_receipt_lineage(session, forged_name, forged_raw)
            except ValueError:
                pass
            else:
                raise AssertionError('each historical edge requires authentic rejections of its own selected generations')
        coverage = json.loads(call('current-coverage', session))
        assert coverage['eligible'] is True, coverage
        assert coverage['selected_generations']['sol']['label'] == '6x'
        assert coverage['selected_generations']['terra']['label'] == '6x2'
        call('review-origin', session, '6')
        assert (session / 'r6-coverage.receipt.json').read_bytes() == original
        assert first_path.read_bytes() == first_raw

def semantic_rejection_refuses_redirected_and_stale_records():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare, 'The assertion check is unfinished.')
        path = Path(reject_semantic_generation(session, call).strip())
        raw = path.read_bytes()
        for field in ('manifest_sha256', 'prompt_sha256', 'result_sha256', 'audit_sha256'):
            bad = json.loads(raw); bad['generation'][field] = '0' * 64
            path.write_bytes(module.encoded(bad))
            call('prepare', session, '6x', '--phase', 'repair', '--assignment', 'terra=' + bundles[0],
                 '--parent-assignment', '6:sol', good=False, error='stale semantic rejection binding')
            path.write_bytes(raw)
        target = session / 'retained-rejection.json'
        path.rename(target)
        path.symlink_to(target.name)
        assert reserve_launch(session, '6', 'sol', session / 'r6-sol.prompt.md').returncode != 0
        path.unlink()
        os.link(target, path)
        assert reserve_launch(session, '6', 'sol', session / 'r6-sol.prompt.md').returncode != 0
        assert target.read_bytes() == raw

def linked_incomplete_proof_is_rejected(command, link_kind):
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare, 'Every assigned range was read')
        call('verify-panel', session, '6')
        result = session / 'r6-sol.json'
        result.write_text('{"summary":"INCOMPLETE PROOF: assigned source remains unread","findings":[]}')
        write_agent_audit(session, '6', 'sol')
        before = {path.name: path.read_bytes() for path in session.glob('r6-*') if path.is_file()}
        target = session / 'retained-result.json'
        if link_kind == 'hard':
            os.link(result, target)
        else:
            result.rename(target)
            result.symlink_to(target.name)
        assert module.digest(result.read_bytes()) == json.loads(
            (session / 'r6-sol.read-audit.json').read_text())['result_sha256']
        call(command, session, '6', good=False)
        assert not (session / 'r6-coverage.receipt.json').exists(), 'a linked incomplete result seals nothing'
        assert all((session / name).read_bytes() == raw for name, raw in before.items()), \
            'certification refusal retains every original result, prompt, stream and audit'

def hardlinked_incomplete_proof_cannot_verify():
    linked_incomplete_proof_is_rejected('verify-panel', 'hard')

def hardlinked_incomplete_proof_cannot_seal():
    linked_incomplete_proof_is_rejected('receipt', 'hard')

def symlinked_incomplete_proof_cannot_verify():
    linked_incomplete_proof_is_rejected('verify-panel', 'symbolic')

def symlinked_incomplete_proof_cannot_seal():
    linked_incomplete_proof_is_rejected('receipt', 'symbolic')

def incomplete_proof_is_replaced_at_once():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare)
        child = prepare('6x', 'repair', '--assignment', 'terra=' + bundles[0], '--parent-assignment', '6:sol')
        assert list(child['assignments']) == ['terra'] and child['parent_assignment']['seat'] == 'sol', child
        (session / 'r6x-terra.prompt.md').write_text(call('render', session / 'r6x-evidence.manifest.json', 'terra'))
        (session / 'r6x-terra.json').write_text('{"summary":"child","findings":[]}')
        (session / 'r6x-terra.exit').write_text('0\n')
        write_agent_audit(session, '6x', 'terra')
        call('receipt', session, '6', '--replacement', 'sol=6x')
        receipt = json.loads((session / 'r6-coverage.receipt.json').read_text())
        row = receipt['selected_generations']['sol']
        assert (row['label'], row['seat']) == ('6x', 'terra'), row
        assert row['result_sha256'] == module.digest((session / 'r6x-terra.json').read_bytes())
        assert receipt['selected_generations']['terra']['label'] == '6'

def incomplete_proof_latches_only_its_label_and_seat():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare)
        prompt = session / 'r6-sol.prompt.md'
        refused = reserve_launch(session, '6', 'sol', prompt)
        assert refused.returncode == 2, (refused.returncode, refused.stderr)
        assert 'sol under label 6 returned an INCOMPLETE PROOF result' in refused.stderr, refused.stderr
        assert 'hard evidence audit' not in refused.stderr, refused.stderr
        sibling = reserve_launch(session, '6', 'terra', session / 'r6-terra.prompt.md')
        assert sibling.returncode == 0, ('a sibling under the same label still launches', sibling.stderr)
        later = reserve_launch(session, '7', 'sol', prompt)
        assert later.returncode == 0, ('the same seat under a later label still launches', later.stderr)

def incomplete_proof_replacement_survives_a_changed_prompt():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare)
        prompt, result = session / 'r6-sol.prompt.md', session / 'r6-sol.json'
        proof = result.read_bytes()
        result.unlink()
        assert reserve_launch(session, '6', 'sol', prompt).returncode == 0
        result.write_bytes(proof)
        assert record_launch(session, '6', 'sol', prompt, '0').returncode == 0
        siblings = {path.name: path.read_bytes() for seat in ('terra', 'opus', 'sonnet')
                    for path in session.glob('r6-' + seat + '.*')}
        prompt.write_text(prompt.read_text() + '\nAlso check consumer ordering.\n')
        (session / 'r6-sol.exit').unlink()
        refused = reserve_launch(session, '6', 'sol', prompt)
        assert refused.returncode == 2, ('a changed prompt cannot reopen the assignment', refused.stderr)
        # finish() publishes the refused reservation's code without recording another provider launch.
        (session / 'r6-sol.exit').write_text(str(refused.returncode) + '\n')
        child = prepare('6x', 'repair', '--assignment', 'terra=' + bundles[0], '--parent-assignment', '6:sol')
        assert child['parent_assignment']['seat'] == 'sol' and list(child['assignments']) == ['terra'], child
        assert result.read_bytes() == proof, 'the incomplete result remains available for diagnosis'
        assert all((session / name).read_bytes() == raw for name, raw in siblings.items()), \
            'preparing the replacement cannot alter completed siblings'

def incomplete_proof_from_a_failed_launch_keeps_its_retry():
    for code in ('1', '2'):
        with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
            incomplete_proof_panel(session, call, prepare)
            prompt, result = session / 'r6-sol.prompt.md', session / 'r6-sol.json'
            proof = result.read_bytes()
            result.unlink()
            assert reserve_launch(session, '6', 'sol', prompt).returncode == 0
            result.write_bytes(proof)
            (session / 'r6-sol.exit').write_text(code + '\n')
            assert record_launch(session, '6', 'sol', prompt, code).returncode == 0
            call('prepare', session, '6x', '--phase', 'repair', '--assignment', 'terra=' + bundles[0],
                 '--parent-assignment', '6:sol', good=False, error='parent assignment has no recorded terminal failure')
            (session / 'r6-sol.exit').unlink()
            retry = reserve_launch(session, '6', 'sol', prompt)
            assert retry.returncode == 0, ('a failed incomplete proof keeps its exact retry', code, retry.stderr)
            call('prepare', session, '6x', '--phase', 'repair', '--assignment', 'terra=' + bundles[0],
                 '--parent-assignment', '6:sol', good=False, error='parent assignment has no recorded terminal failure')
            (session / 'r6-sol.exit').write_text(code + '\n')
            assert record_launch(session, '6', 'sol', prompt, code).returncode == 0
            child = prepare('6x', 'repair', '--assignment', 'terra=' + bundles[0], '--parent-assignment', '6:sol')
            assert list(child['assignments']) == ['terra'] and child['parent_assignment']['seat'] == 'sol', child

def unrecorded_failed_launch_after_success(session, call, prepare):
    incomplete_proof_panel(session, call, prepare, 'Every assigned range was read')
    prompt = session / 'r6-sol.prompt.md'
    assert reserve_launch(session, '6', 'sol', prompt).returncode == 0
    assert record_launch(session, '6', 'sol', prompt, '0').returncode == 0
    assert reserve_launch(session, '6', 'sol', prompt).returncode == 0
    (session / 'r6-sol.json').write_text('{"summary":"INCOMPLETE PROOF: failed launch left source unread","findings":[]}')
    (session / 'r6-sol.exit').write_text('1\n')
    records = [json.loads(path.read_text()) for path in (session / 'attempts').glob('*.json')]
    assert len(records) == 1 and records[0]['calls'] == 2 and records[0]['launches'] == [0], records
    return prompt

def old_success_cannot_retire_a_current_failed_launch():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        prompt = unrecorded_failed_launch_after_success(session, call, prepare)
        retry = reserve_launch(session, '6', 'sol', prompt)
        assert retry.returncode == 0, ('the current failed launch keeps its exact retry', retry.stderr)

def old_success_cannot_make_a_current_failed_launch_replaceable():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        unrecorded_failed_launch_after_success(session, call, prepare)
        call('prepare', session, '6x', '--phase', 'repair', '--assignment', 'terra=' + bundles[0],
             '--parent-assignment', '6:sol', good=False, error='parent assignment has no recorded terminal failure')

def incomplete_proof_is_only_a_summary_prefix():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        incomplete_proof_panel(session, call, prepare, 'Every assigned range was read; no INCOMPLETE PROOF remains')
        call('verify-panel', session, '6')
        call('prepare', session, '6x', '--phase', 'repair', '--assignment', 'terra=' + bundles[0],
             '--parent-assignment', '6:sol', good=False, error='parent assignment has no recorded terminal failure')
        call('receipt', session, '6')
        launched = reserve_launch(session, '6', 'sol', session / 'r6-sol.prompt.md')
        assert launched.returncode == 0, launched.stderr

def review_origin_counts_the_reviews_own_lines():
    state_script = script.parent / 'rev-state.sh'
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        chain_identities = {
            'sol': ('codex', 'gpt-5.6-luna', 'high'),
            'terra': ('codex', 'gpt-5.6-sol', 'high'),
            'opus': ('claude', 'sonnet', 'high'),
            'sonnet': ('claude', 'opus', 'high'),
        }
        roster = {'seats': [
            {'seat': seat, 'extra': False, 'adapter': chain_identities[seat][0],
             'model': chain_identities[seat][1], 'effort': chain_identities[seat][2]}
            for seat in seats]}
        (session / 'roster.json').write_text(json.dumps(roster))
        for name, text in (('head.py', 'a = 1\nb = 2\nc = 3\n'), ('tail.py', 'a = 1\nb = 2\nc = 3\n'),
                           ('empty.py', 'x = 1\n'), ('gone.py', 'y = 1\n')):
            write(name, text)
        git('add', 'head.py', 'tail.py', 'empty.py', 'gone.py'); git('commit', '-qm', 'review scope')
        def cite(path, start, end=None):
            return {'severity': 'P3', 'file': path, 'line_start': start, 'line_end': end or start,
                    'claim': f'{path}:{start}', 'evidence': 'e', 'suggested_fix': 'f', 'confidence': 0.5}
        def write_metric_input(label, manifest, routing):
            manifest_path = session / f'r{label}-evidence.manifest.json'
            result_hashes = {}
            for seat in manifest['assignments']:
                chosen = routing[seat]
                name = f"r{chosen['label']}-{chosen['seat']}.json"
                result_hashes[name] = module.digest((session / name).read_bytes())
            # Hash-bound metric input only; its filename is fixed by the consumer API.
            payload = {
                'fixture_kind': 'review-origin-metric-input',
                'manifest': manifest_path.name,
                'manifest_sha256': module.digest(manifest_path.read_bytes()),
                'snapshot_tree': manifest['snapshot_tree'],
                'selected_generations': routing,
                'results': result_hashes,
            }
            (session / f'r{label}-coverage.receipt.json').write_bytes(module.encoded(payload))
        def seal(label, cited, failed=None, executor=None):
            manifest = prepare(label, 'discovery')
            path = session / f'r{label}-evidence.manifest.json'
            routing = {seat: {'label': label, 'seat': seat} for seat in manifest['assignments']}
            for seat in manifest['assignments']:
                (session / f'r{label}-{seat}.prompt.md').write_text(call('render', path, seat))
                findings = cited.get(seat, [])
                (session / f'r{label}-{seat}.json').write_text(json.dumps({'summary': 's', 'findings': findings}))
                (session / f'r{label}-{seat}.exit').write_text('0\n')
            if failed:
                stem = session / f'r{label}-{failed}'
                Path(str(stem) + '.json').rename(Path(str(stem) + '.audit-invalid.json'))
                Path(str(stem) + '.exit').write_text('2\n')
                child = prepare(label + 'x', 'repair', '--assignment', executor + '=' + manifest['assignments'][failed]['bundle'],
                                '--parent-assignment', label + ':' + failed)
                child_path = session / f'r{label}x-evidence.manifest.json'
                (session / f'r{label}x-{executor}.prompt.md').write_text(call('render', child_path, executor))
                (session / f'r{label}x-{executor}.json').write_text(json.dumps({'summary': 's', 'findings': [cite('main.py', 2)]}))
                (session / f'r{label}x-{executor}.exit').write_text('0\n')
                routing[failed] = {'label': label + 'x', 'seat': executor}
            write_metric_input(label, manifest, routing)
        def origin(label):
            return json.loads(call('review-origin', session, label))
        def fix(label, **extra):
            args = [f'round={label}', 'open.P0=0', 'open.P1=0', 'open.P2=0', 'phase=fix',
                    *(f'{key}={value}' for key, value in extra.items())]
            return subprocess.run([str(state_script), str(session), *args], capture_output=True, text=True)
        def state():
            return json.loads((session / 'state.json').read_text())

        seal('1', {'sol': [cite('main.py', 2)], 'terra': [cite('head.py', 1)]})
        first = json.loads((session / 'r1-coverage.receipt.json').read_text())['snapshot_tree']
        assert origin('1') == {'label': '1', 'review_base_tree': first, 'citations': 0}, origin('1')
        assert fix('1').returncode == 0
        assert state()['review_base_tree'] == first and state()['review_origin'] == {'1': 0}, state()

        # Uncommitted review edits: a changed line, a first-line and a last-line deletion, an
        # emptied file and a deleted one. Every citation below is P3: severity has no effect.
        write('main.py', (root / 'main.py').read_text().replace('    return 2\n', '    return 3\n', 1))
        write('head.py', 'b = 2\nc = 3\n'); write('tail.py', 'a = 1\nb = 2\n'); write('empty.py', '')
        (root / 'gone.py').unlink()
        # Counted: main.py:2, head.py:1, tail.py:2 (the end-of-file anchor clamps to line 2),
        # empty.py, gone.py and the replacement's main.py:2. opus's own result was archived by its
        # hard failure and is not the chosen one; the rest lie outside every changed interval.
        seal('2', {'sol': [cite('main.py', 2), cite('main.py', 4, 5)],
                   'terra': [cite('head.py', 1), cite('head.py', 2), cite('tail.py', 2)],
                   'sonnet': [cite('tail.py', 1), cite('empty.py', 1), cite('gone.py', 1)],
                   'opus': [cite('main.py', 2)]}, failed='opus', executor='terra')
        expected = 6
        assert origin('2')['citations'] == expected, (origin('2'), expected)
        assert fix('2').returncode == 0, 'one nonzero round passes'
        assert state()['review_origin'] == {'1': 0, '2': expected}

        seal('3', {'sol': [cite('main.py', 2)]})
        refused = fix('3')
        assert refused.returncode == 2 and 'review_origin_ack=3' in refused.stderr, refused.stderr
        assert state()['round'] == 2 and '3' not in state()['review_origin'], 'a refusal leaves state unchanged'
        assert fix('3', review_origin_ack=3).returncode == 0
        seal('4', {'sol': [cite('main.py', 2)]})
        assert fix('4').returncode == 0, 'the acknowledgement starts a new window'
        seal('5', {'sol': [cite('main.py', 2)]})
        assert fix('5').returncode == 2, 'two more nonzero rounds trip it again'
        assert '5' not in state()['review_origin']
        assert fix('5', review_origin_ack=5).returncode == 0

        plan = subprocess.run([str(state_script), str(session), 'phase=plan', 'round=7p',
                               'seats=["sol"]', 'open.P0=0', 'open.P1=0', 'open.P2=0'], capture_output=True, text=True)
        assert plan.returncode == 0, plan.stderr
        assert fix('7p').returncode == 0 and '7' not in state()['review_origin'], 'a round without a receipt is ignored'

        fallback = session.parent / 'fallback'; fallback.mkdir()
        inherit = [str(state_script), str(fallback), 'inherit-breaker', str(session)]
        assert subprocess.run(inherit, capture_output=True).returncode == 0
        copied = json.loads((fallback / 'state.json').read_text())
        assert copied == {key: state()[key] for key in ('review_base_tree', 'review_origin', 'review_origin_ack')}, copied
        again = subprocess.run(inherit, capture_output=True, text=True)
        assert again.returncode == 2 and 'already has breaker state' in again.stderr, again.stderr

def narrow_seat_requires_proven_reads():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        write('main.py', 'def oversized():\n' + ''.join(
            f'    value_{index} = "{index:04d}-' + 'x' * 50 + '"\n' for index in range(1200))
              + '    return value_1199\n')
        manifest = prepare()
        for seat, assignment in manifest['assignments'].items():
            (session / f'r1-{seat}.prompt.md').write_text(call('render', session / 'r1-evidence.manifest.json', seat))
            (session / f'r1-{seat}.json').write_text('{"summary":"checked","findings":[]}')
            (session / f'r1-{seat}.exit').write_text('0\n')
            assert assignment['adapter'] == 'claude'
        for seat in manifest['assignments']:
            write_agent_audit(session, '1', seat)
        call('receipt', session, '1')
        manifest = prepare('narrow-corrupt')
        for seat in manifest['assignments']:
            (session / f'rnarrow-corrupt-{seat}.prompt.md').write_text(
                call('render', session / 'rnarrow-corrupt-evidence.manifest.json', seat))
            (session / f'rnarrow-corrupt-{seat}.json').write_text('{"summary":"checked","findings":[]}')
            (session / f'rnarrow-corrupt-{seat}.exit').write_text('0\n')
            write_agent_audit(session, 'narrow-corrupt', seat)
        call('receipt', session, 'narrow-corrupt')
        seat = next(seat for seat, assignment in manifest['assignments'].items()
                    if assignment['scope'] != 'full')
        path = session / f'rnarrow-corrupt-{seat}.read-audit.json'; audit = json.loads(path.read_text())
        required = manifest['source_context']['seats'][seat]['required_source_ranges']
        assert required
        audit['source_ranges'] = [row for row in audit['source_ranges'] if row['origin'] == 'packet']
        outside = required[0]['line_end'] + 1
        audit['source_ranges'].append({'path': required[0]['path'], 'line_start': outside,
                                       'line_end': outside, 'origin': 'tool'})
        audit['source_ranges'].sort(key=lambda row: (row['path'], row['line_start'], row['line_end'], row['origin']))
        audit['source_read_calls'] = 1; audit['opened_source_ranges'] = 1
        audit['required_source_ranges_covered'] = 0; audit['required_source_range_proofs'] = []
        path.write_text(json.dumps(audit))
        call('receipt', session, 'narrow-corrupt', good=False,
             error='read audit evidence coverage mismatch')

def full_seat_requires_proven_reads():
    with fixture(adapter='claude') as (root, session, git, write, call, prepare, finish):
        manifest = prepare('full-agent')
        seat = manifest['mechanical_owner']; manifest_path = session / 'rfull-agent-evidence.manifest.json'
        assert manifest['assignments'][seat]['scope'] == 'full'
        for assigned in manifest['assignments']:
            (session / f'rfull-agent-{assigned}.prompt.md').write_text(call('render', manifest_path, assigned))
            (session / f'rfull-agent-{assigned}.json').write_text('{"summary":"checked","findings":[]}')
            (session / f'rfull-agent-{assigned}.exit').write_text('0\n')
            write_agent_audit(session, 'full-agent', assigned)
        call('receipt', session, 'full-agent')
        manifest = prepare('full-agent-corrupt')
        seat = manifest['mechanical_owner']
        manifest_path = session / 'rfull-agent-corrupt-evidence.manifest.json'
        for assigned in manifest['assignments']:
            (session / f'rfull-agent-corrupt-{assigned}.prompt.md').write_text(
                call('render', manifest_path, assigned))
            (session / f'rfull-agent-corrupt-{assigned}.json').write_text(
                '{"summary":"checked","findings":[]}')
            (session / f'rfull-agent-corrupt-{assigned}.exit').write_text('0\n')
            write_agent_audit(session, 'full-agent-corrupt', assigned)
        (session / f'rfull-agent-corrupt-{seat}.read-audit.json').write_text('{}')
        call('receipt', session, 'full-agent-corrupt', good=False)

def write_agent_stream(session, label, seat):
    """Emit a Claude/Agent transcript that actually proves this seat's assigned reads.

    write_agent_audit fabricates an audit; this fabricates the TRANSCRIPT and lets the real
    auditor derive the audit from it, which is the only way to show that an agent seat can clear
    the gate at all.
    """
    manifest = json.loads((session / f'r{label}-evidence.manifest.json').read_text())
    assignment = manifest['assignments'][seat]
    context = manifest['source_context']['seats'][seat]
    events = []
    def read(identity, path, text, **extra):
        events.append({'type':'assistant','message':{'content':[
            {'type':'tool_use','id':identity,'name':'Read',
             'input':dict({'file_path':str(path)}, **extra)}]}})
        events.append({'type':'user','message':{'content':[
            {'type':'tool_result','tool_use_id':identity,'content':text}]}})
    if assignment['patch_read_mode'] == 'chunks':
        for row in manifest['patch_sets'][assignment['patch_set']]['chunks']:
            artifact = session / row['artifact']
            read('patch-%d' % row['index'], artifact, artifact.read_text())
    elif assignment['patch_bytes']:
        patch = Path(assignment['patch']); lines = patch.read_text().splitlines(keepends=True)
        for start in range(1, len(lines) + 1, 240):
            end = min(len(lines), start + 239)
            read('patch-%d' % start, patch, ''.join(lines[start - 1:end]),
                 offset=start, limit=end - start + 1)
    for index, shard in enumerate(context['shards'], 1):
        artifact = session / shard['artifact']
        read('packet-%d' % index, artifact, artifact.read_text())
    index_path = session / f'r{label}-evidence.md'
    read('evidence-index', index_path, index_path.read_text())
    for number, required in enumerate(context['required_source_ranges'], 1):
        for segment in required['segments']:
            artifact = session / segment['artifact']
            read('segment-%d-%d' % (number, segment['index']), artifact, artifact.read_text())
    (session / f'r{label}-{seat}.stream.ndjson').write_text(
        ''.join(json.dumps(event) + '\n' for event in events))

AUDIT_FLAG = 'REV_UNENFORCED_AUDIT'
AUDIT_ON = {AUDIT_FLAG: '1'}
AUDIT_OFF_REASON = 'advisory read audit is off; set REV_UNENFORCED_AUDIT=1 to run it'
RECEIPT_KEYS = {'schema_version', 'manifest', 'manifest_sha256', 'snapshot_tree', 'base_tree',
                'phase', 'assignments', 'results', 'advisories', 'findings', 'unenforced_audits'}

def unenforced_agent_seat_binds_only_its_prompt():
    # The default fixture roster is all `agent` - what a Claude Code host produces when no Claude
    # CLI is signed in. Such a CODE panel now runs evidence mode: every agent row is recorded in
    # `unenforced_seats` and reported `enforced: false`, so the panel is never certified. With
    # REV_UNENFORCED_AUDIT=1 its audit is produced anyway and its would-have-passed verdict
    # recorded, and nothing gates on either.
    # What unenforcement costs is pinned here too. With no enforced read audit, only the prompt
    # still binds a seat's artifacts to this manifest, because the prompt carries the manifest hash;
    # the transcript and the result are free, and a sibling panel's can be swapped in undetected.
    # That is inherent - nothing else names the panel - and it is why such a panel is not certified.
    # It is still strictly better than the rule it replaced, under which the whole panel was skipped
    # and no seat, agent or CLI, got a manifest, a receipt or any binding at all.
    with fixture() as (root, session, git, write, call, prepare, finish):
        manifest = prepare('code', 'risk', *assign)
        assert manifest['unenforced_seats'] == sorted(seats), manifest['unenforced_seats']
        prepare('sibling', 'risk', *assign)
        for label, summary, raw in (('code', 'checked', '{}\n'),
                                    ('sibling', 'sibling', '{"other":true}\n')):
            path = session / f'r{label}-evidence.manifest.json'
            for seat in manifest['assignments']:
                (session / f'r{label}-{seat}.prompt.md').write_text(call('render', path, seat))
                (session / f'r{label}-{seat}.json').write_text(
                    json.dumps({'summary': summary, 'findings': []}))
                (session / f'r{label}-{seat}.exit').write_text('0\n')
                (session / f'r{label}-{seat}.stream.ndjson').write_text(raw)
        # One seat gets a transcript that really proves its assigned reads. Without it every row
        # below would read `would_pass: false` and the verdict would be a constant, not a
        # measurement - which is exactly what it was until review-read-audit.py learned --result,
        # since it had derived the result path from the enforced audit's own file name.
        sol = manifest['assignments']['sol']
        sol_prompt = session / 'rcode-sol.prompt.md'
        # `## Your lens this round:` is added by rev-prompt.sh when it composes the launched prompt;
        # the evidence render alone carries the scope and bundle lines but not the lens.
        sol_prompt.write_text(sol_prompt.read_text()
                              + '\n## Your lens this round: ' + sol['bundle'] + '\n')
        write_agent_stream(session, 'code', 'sol')
        # The production shape: nothing writes an enforced read audit for an Agent row.
        assert not list(session.glob('r*-*.read-audit.json'))
        verified = json.loads(call('verify-panel', session, 'code', env=AUDIT_ON))
        assert verified['advisories'] == {}
        audits = verified['unenforced_audits']
        assert set(audits) == set(seats), audits
        assert audits['sol'] == {
            'audit': 'rcode-sol.unenforced-audit.json',
            'audit_sha256': module.digest((session / 'rcode-sol.unenforced-audit.json').read_bytes()),
            'status': 'valid', 'would_pass': True, 'reason': None}, audits['sol']
        for seat in ('terra', 'opus', 'sonnet'):
            assert audits[seat]['status'] == 'invalid' and audits[seat]['would_pass'] is False
            assert audits[seat]['reason'] == 'invalid or stale read audit: ' + seat, audits[seat]
        # Recording an invalid audit must not gate by another route: the file is written under a
        # name neither rev-attempt.py's hard-failure scan nor rev-profile.py's metric scan globs.
        assert not list(session.glob('r*-*.read-audit.json'))
        assert not list(session.glob('r*-*.audit.json'))
        assert sorted(path.name for path in session.glob('rcode-*.unenforced-audit.json')) == sorted(
            f'rcode-{seat}.unenforced-audit.json' for seat in seats)
        missing = session / 'rcode-opus.stream.ndjson'; kept = missing.read_bytes()
        missing.unlink()
        absent = json.loads(call('verify-panel', session, 'code', env=AUDIT_ON))['unenforced_audits']['opus']
        assert absent == {'audit': 'rcode-opus.unenforced-audit.json', 'audit_sha256': None,
                          'status': None, 'would_pass': False, 'reason': 'no transcript'}, absent
        missing.write_bytes(kept)
        for suffix, detected in (('prompt.md', True), ('stream.ndjson', False), ('json', False)):
            target = session / f'rcode-sol.{suffix}'; saved = target.read_bytes()
            target.write_bytes((session / f'rsibling-sol.{suffix}').read_bytes())
            call('verify-panel', session, 'code', good=not detected)
            target.write_bytes(saved)
        (session / 'rcode-terra.exit').write_text('1\n')
        call('receipt', session, 'code', good=False, error='seat failed: terra')
        # An Agent result cannot be bound against copying, so no Agent seat may replace another.
        (session / 'rcode-terra.audit-invalid.json').write_text('{"summary":"kept","findings":[]}\n')
        call('prepare', session, 'codex', '--phase', 'repair', '--assignment', 'sol=' + bundles[1],
             '--parent-assignment', 'code:terra', good=False,
             error='replacement executor must be an enforced seat')

def agent_code_panel(session, call, prepare, label='code'):
    """A code panel of Agent seats in which only sol's transcript proves its reads."""
    manifest = prepare(label, 'risk', *assign)
    path = session / f'r{label}-evidence.manifest.json'
    for seat, assignment in manifest['assignments'].items():
        (session / f'r{label}-{seat}.prompt.md').write_text(
            call('render', path, seat) + '\n## Your lens this round: ' + assignment['bundle'] + '\n')
        (session / f'r{label}-{seat}.json').write_text('{"summary":"checked","findings":[]}')
        (session / f'r{label}-{seat}.exit').write_text('0\n')
        (session / f'r{label}-{seat}.stream.ndjson').write_text('{}\n')
    write_agent_stream(session, label, 'sol')
    return manifest

def audits_spawned(flag, run, fake=None):
    """Run `run()` in process with the audit flag at `flag`; return the stems it audited and its value.

    `fake(real, command, ...)`, when given, stands in for the audit child so it can crash or race."""
    spawned, real, saved = [], subprocess.run, os.environ.pop(AUDIT_FLAG, None)
    def spy(command, *args, **kwargs):
        if any(str(part).endswith('review-read-audit.py') for part in command):
            spawned.append(Path(command[command.index('--out') + 1]).name.split('.')[0])
            if fake is not None:
                return fake(real, command, *args, **kwargs)
        return real(command, *args, **kwargs)
    if flag is not None:
        os.environ[AUDIT_FLAG] = flag
    subprocess.run = spy
    try:
        value = run()
    finally:
        subprocess.run = real
        os.environ.pop(AUDIT_FLAG, None)
        if saved is not None:
            os.environ[AUDIT_FLAG] = saved
    return sorted(spawned), value

def panel_verdicts(session, label='code'):
    verdicts = {}
    module.verify_panel_selection(session, label, verdicts=verdicts)
    return verdicts

def in_process_receipt(session, label):
    args = type('Args', (), {'session': str(session), 'label': label, 'replacement': []})()
    with open(os.devnull, 'w') as sink, contextlib.redirect_stdout(sink):
        module.receipt(args)
    return json.loads((session / f'r{label}-coverage.receipt.json').read_text())

def seat_verdict(session, manifest, seat='sol', **changed):
    stem = session / f"r{manifest['label']}-{seat}"
    values = dict(session=session, manifest=manifest,
                  manifest_hash=module.digest((session / f"r{manifest['label']}-evidence.manifest.json").read_bytes()),
                  phase=manifest['phase'], seat=seat, stem=stem, assignment=manifest['assignments'][seat],
                  prompt=Path(str(stem) + '.prompt.md'), result=Path(str(stem) + '.json'),
                  result_data=json.loads(Path(str(stem) + '.json').read_text()))
    values.update(changed)
    return module.unenforced_verdict(**values)

def unenforced_audit_is_opt_in():
    # Every verify-panel, receipt and predecessor walk reaches the advisory audit of every Agent
    # seat of every earlier round, so unasked it spawns nothing and says why.
    with fixture() as (root, session, git, write, call, prepare, finish):
        session = session.resolve(); agent_code_panel(session, call, prepare)
        off = {seat: {'audit': f'rcode-{seat}.unenforced-audit.json', 'audit_sha256': None,
                      'status': None, 'would_pass': False, 'reason': AUDIT_OFF_REASON} for seat in seats}
        for flag in (None, '', '0', 'true', 'yes', ' 1', '1 '):
            spawned, verdicts = audits_spawned(flag, lambda: panel_verdicts(session))
            assert spawned == [] and verdicts == off, (flag, spawned, verdicts)
        cli = json.loads(call('verify-panel', session, 'code', env={AUDIT_FLAG: '0'}))
        assert cli['unenforced_audits'] == off, cli
        assert not list(session.glob('rcode-*.unenforced-audit*'))
        manifest, mh = module.validated_manifest(session / 'rcode-evidence.manifest.json', fresh=False)
        spawned, (_, row) = audits_spawned(None, lambda: module.result_generation(session, manifest, mh, 'sol'))
        assert spawned == [] and row['enforced'] is False and row['unenforced_audit'] == off['sol'], row
        spawned, verdicts = audits_spawned('1', lambda: panel_verdicts(session))
        assert spawned == ['rcode-' + seat for seat in sorted(seats)], spawned
        assert verdicts['sol'] == {
            'audit': 'rcode-sol.unenforced-audit.json', 'status': 'valid', 'would_pass': True,
            'audit_sha256': module.digest((session / 'rcode-sol.unenforced-audit.json').read_bytes()),
            'reason': None}, verdicts['sol']
        assert all(verdicts[seat]['status'] == 'invalid' and verdicts[seat]['would_pass'] is False
                   for seat in seats if seat != 'sol'), verdicts
        spawned, receipt = audits_spawned('0', lambda: in_process_receipt(session, 'code'))
        assert spawned == [] and set(receipt) == RECEIPT_KEYS and receipt['unenforced_audits'] == off

def unenforced_audit_cache_is_keyed_on_every_input():
    with fixture() as (root, session, git, write, call, prepare, finish):
        session = session.resolve(); manifest = agent_code_panel(session, call, prepare)
        stems = ['rcode-' + seat for seat in sorted(seats)]
        spawned, first = audits_spawned('1', lambda: panel_verdicts(session))
        assert spawned == stems and first['sol']['would_pass'] is True, (spawned, first)
        caches = sorted(path.name for path in session.glob('rcode-*.unenforced-audit.cache'))
        assert caches == [stem + '.unenforced-audit.cache' for stem in stems], caches
        # The attempt and profile scans must never read the cache as a result or an audit.
        assert not any(Path(name).match(pattern) for name in caches for pattern in (
            'r*-*.read-audit.json', 'r*-*.audit.json', '*.json', '*.stream.*', '*.prompt.md'))
        spawned, again = audits_spawned('1', lambda: panel_verdicts(session))
        assert spawned == [] and again == first, (spawned, again)
        spawned, receipt = audits_spawned('1', lambda: in_process_receipt(session, 'code'))
        assert spawned == [] and set(receipt) == RECEIPT_KEYS and receipt['unenforced_audits'] == first
        for cache in session.glob('rcode-*.unenforced-audit.cache'):
            cache.unlink()
        spawned, fresh = audits_spawned('1', lambda: panel_verdicts(session))
        assert spawned == stems and fresh == first, (spawned, fresh)

        # Each input alone invalidates a warm entry. The scripts run from a copy so their bytes can change.
        sol = session / 'rcode-sol'; plugin = session.parent / 'plugin'; real_file = module.__file__
        shutil.copytree(script.parent, plugin / 'scripts'); shutil.copytree(script.parent.parent / 'schema', plugin / 'schema')
        # copytree keeps modes, and the release verifier stages the tree read-only.
        for path in (plugin, *plugin.rglob('*')):
            path.chmod(path.stat().st_mode | 0o200)
        scope_path = session / 'scope.env'; deps = session.parent / 'deps'; deps.mkdir()
        other_root = session.parent / 'other-root'; other_root.mkdir()
        def edit(path, data):
            saved = path.read_bytes()
            return lambda: path.write_bytes(data(saved)), lambda: path.write_bytes(saved)
        def environ(name, value):
            return lambda: os.environ.__setitem__(name, value), lambda: os.environ.pop(name, None)
        nothing = (lambda: None, lambda: None)
        changes = (
            ('stream', *edit(Path(str(sol) + '.stream.ndjson'), lambda raw: raw + b'\n'), None),
            ('prompt', *edit(Path(str(sol) + '.prompt.md'), lambda raw: raw + b'\n'), None),
            ('result', *edit(Path(str(sol) + '.json'), lambda raw: raw.replace(b'checked', b'rechecked')), None),
            ('audit script', *edit(plugin / 'scripts/lib/review-read-audit.py', lambda raw: raw + b'\n# changed\n'), None),
            ('evidence script', *edit(plugin / 'scripts/rev-evidence.py', lambda raw: raw + b'\n# changed\n'), None),
            ('manifest hash', *nothing, {'manifest_hash': '0' * 64}),
            ('adapter', *nothing, {'assignment': dict(manifest['assignments']['sol'], adapter='claude')}),
            ('root', *edit(scope_path, lambda raw: b''.join(
                (b'REV_ROOT=' + shlex.quote(str(other_root)).encode() + b'\n') if line.startswith(b'REV_ROOT=')
                else line for line in raw.splitlines(keepends=True))), None),
            ('deps', *environ('REV_DEPS_DIR', str(deps)), None),
        )
        module.__file__ = str(plugin / 'scripts/rev-evidence.py')
        try:
            for name, mutate, restore, changed in changes:
                audits_spawned('1', lambda: seat_verdict(session, manifest))
                spawned, warm = audits_spawned('1', lambda: seat_verdict(session, manifest))
                assert spawned == [] and warm == first['sol'], (name, spawned, warm)
                mutate()
                try:
                    spawned, _ = audits_spawned('1', lambda: seat_verdict(session, manifest, **(changed or {})))
                finally:
                    restore()
                assert spawned == ['rcode-sol'], (name, spawned)
        finally:
            module.__file__ = real_file

        # A missing, stale or unreadable entry, or an audit that no longer matches it, audits afresh:
        # the passing seat gets its verdict back and the failing one never passes.
        audits_spawned('1', lambda: panel_verdicts(session))
        for seat in ('sol', 'terra'):
            cache = session / f'rcode-{seat}.unenforced-audit.cache'; audit = session / f'rcode-{seat}.unenforced-audit.json'
            good_cache, good_audit = cache.read_bytes(), audit.read_bytes(); entry = json.loads(good_cache)
            def directory():
                cache.unlink(); cache.mkdir()
            for corrupt in (lambda: cache.write_bytes(b'{bad'), lambda: cache.write_bytes(b'\xff'),
                            lambda: cache.write_text(json.dumps([entry])),
                            lambda: cache.write_text(json.dumps(dict(entry, key='0' * 64))),
                            lambda: cache.write_text(json.dumps(dict(entry, audit_sha256='0' * 64))),
                            lambda: cache.write_text(json.dumps(dict(entry, would_pass=True))),
                            directory, cache.unlink, lambda: audit.write_bytes(good_audit + b' '), audit.unlink):
                corrupt()
                spawned, verdict = audits_spawned('1', lambda: seat_verdict(session, manifest, seat))
                assert spawned == ['rcode-' + seat] and verdict == first[seat], (seat, spawned, verdict)
                if cache.is_dir():
                    cache.rmdir()
                cache.write_bytes(good_cache); audit.write_bytes(good_audit)
        # Even an entry that matches its audit only lets the gate judge that audit, never pass it.
        sol_audit = (session / 'rcode-sol.unenforced-audit.json').read_bytes()
        forged = json.loads((session / 'rcode-terra.unenforced-audit.cache').read_text())
        (session / 'rcode-terra.unenforced-audit.json').write_bytes(sol_audit)
        (session / 'rcode-terra.unenforced-audit.cache').write_text(
            json.dumps(dict(forged, audit_sha256=module.digest(sol_audit))))
        spawned, verdict = audits_spawned('1', lambda: seat_verdict(session, manifest, 'terra'))
        assert spawned == [] and verdict['would_pass'] is False, verdict

        # Only an audit this run wrote, over the inputs it was keyed on, is recorded.
        stream = Path(str(sol) + '.stream.ndjson'); kept = stream.read_bytes()
        stream.write_bytes(kept + b'\n')
        crashed = lambda real, command, *args, **kwargs: subprocess.CompletedProcess(command, 1, b'', b'')
        spawned, verdict = audits_spawned('1', lambda: seat_verdict(session, manifest), crashed)
        assert spawned == ['rcode-sol'] and verdict['would_pass'] is False, verdict
        spawned, verdict = audits_spawned('1', lambda: seat_verdict(session, manifest))
        assert spawned == ['rcode-sol'] and verdict['would_pass'] is True, (spawned, verdict)
        def racing(real, command, *args, **kwargs):
            stream.write_bytes(kept + b'\n\n')
            return real(command, *args, **kwargs)
        stream.write_bytes(kept)
        spawned, _ = audits_spawned('1', lambda: seat_verdict(session, manifest), racing)
        stream.write_bytes(kept)
        spawned, verdict = audits_spawned('1', lambda: seat_verdict(session, manifest))
        assert spawned == ['rcode-sol'] and verdict == first['sol'], (spawned, verdict)

def nested_walks_reuse_cached_audits():
    # A delta round's audit walks its predecessor panel, whose Agent seats it audits again, and each
    # of those audits walks its own predecessor: 4, 28 and 148 audits for the receipts of rounds 1-3.
    with fixture() as (root, session, git, write, call, prepare, finish):
        session = session.resolve()
        write('large.py', ''.join(f'value_{i} = {i}\n' for i in range(1200)))
        for label in ('1', '2'):
            if label == '2':
                write('main.py', (root / 'main.py').read_text() + '# again\n')
            manifest = prepare(label, 'risk' if label == '1' else 'verification', *assign, env=AUDIT_ON)
            path = session / f'r{label}-evidence.manifest.json'
            for seat in manifest['assignments']:
                (session / f'r{label}-{seat}.prompt.md').write_text(call('render', path, seat))
                (session / f'r{label}-{seat}.json').write_text('{"summary":"checked","findings":[]}')
                (session / f'r{label}-{seat}.exit').write_text('0\n')
                (session / f'r{label}-{seat}.stream.ndjson').write_text('{}\n')
            spawned, _ = audits_spawned('1', lambda: in_process_receipt(session, label))
            assert spawned == [f'r{label}-{seat}' for seat in sorted(seats)], (label, spawned)
            if label == '1':
                audited = {path.name: (path.stat().st_ino, path.stat().st_mtime_ns)
                           for path in session.glob('r1-*.unenforced-audit.json')}
        assert any(row['scope'] == 'delta' for row in manifest['assignments'].values()), manifest['fallback_reason']
        assert len(audited) == len(seats) and audited == {
            path.name: (path.stat().st_ino, path.stat().st_mtime_ns)
            for path in session.glob('r1-*.unenforced-audit.json')}, 'a round-2 audit re-audited round 1'

def scoped_names_and_gitlink_lifecycle():
    with fixture() as (root, session, git, write, call, prepare, finish):
        write(':(glob)thing[1].py', 'literal = 1\n'); write('thing1.py', 'SECRET_SIBLING\n')
        text = (session / 'scope.env').read_text().replace('REV_SCOPE=branch', "REV_SCOPE=':(glob)thing[1].py'")
        (session / 'scope.env').write_text(text)
        m = prepare(); assert m['paths'] == [':(glob)thing[1].py']; finish()
    with fixture() as (root, session, git, write, call, prepare, finish):
        child = root / 'module'; child.mkdir()
        def subgit(*args):
            return subprocess.check_output(['git', '-C', str(child), *args], stderr=subprocess.PIPE).decode().strip()
        subgit('init','-q'); subgit('config','user.name','Test'); subgit('config','user.email','test@example.invalid'); subgit('config','commit.gpgsign','false')
        (child / 'entry.py').write_text('value = 1\n'); subgit('add','.'); subgit('commit','-qm','first')
        git('add','module'); git('commit','-qm','gitlink base')
        base = git('rev-parse','HEAD'); text = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join('REV_BASE=' + base if s.startswith('REV_BASE=') else s for s in text.splitlines()) + '\n')
        (child / 'entry.py').write_text('value = 2\n'); subgit('add','.'); subgit('commit','-qm','second')
        m = prepare(); assert 'Subproject commit' in (session / 'r1-full.patch').read_text(); finish()
        (child / 'entry.py').write_text('dirty\n'); call('prepare', session, 'dirty', '--phase','discovery',good=False)
        assert not list(session.glob('rdirty-*'))
        git('rm','-f','--cached','module'); shutil.rmtree(child)
        m = prepare('deleted'); assert 'deleted file mode 160000' in (session / 'rdeleted-full.patch').read_text(); finish('deleted')

def component_and_full_tampering():
    with fixture() as (root, session, git, write, call, prepare, finish):
        m = prepare(); mp = session / 'r1-evidence.manifest.json'; ep = session / 'r1-evidence.json'
        saved = {p: p.read_bytes() for p in session.glob('r1-*')}
        def replace(m,e):
            ep.write_bytes(module.encoded(e)); m['artifacts'][ep.name] = {'sha256':module.digest(ep.read_bytes()),'words':len(ep.read_bytes().split())}
            mp.write_bytes(module.encoded(m))
        e = json.loads(ep.read_text()); m['components'][0]['specialists'] = []; e['components'] = m['components']; replace(m,e)
        call('render', mp, 'sol', good=False)
        for path, data in saved.items(): path.write_bytes(data)
        m = json.loads(mp.read_text()); e = json.loads(ep.read_text())
        m['components'][0]['prior_owners'] = ['sol']; e['components'] = m['components']; replace(m,e)
        call('render',mp,'sol',good=False)
        for path, data in saved.items(): path.write_bytes(data)
        m = json.loads(mp.read_text()); e = json.loads(ep.read_text())
        m['paths'] = []; m['semantic_paths'] = []; m['components'] = []; m['fallback_reason'] = 'no semantic components'
        for seat, a in m['assignments'].items(): a.update(scope='full', full_state=True, patch=str(session.resolve()/'r1-full.patch'),components=[])
        for key in ('paths','semantic_paths','components','fallback_reason','assignments'): e[key] = m[key]
        for name in list(m['artifacts']):
            if name.endswith('.patch'):
                if name not in ('r1-full.patch','r1-semantic.patch','r1-delta.patch'): del m['artifacts'][name]; continue
                (session/name).write_bytes(b''); m['artifacts'][name] = {'sha256':module.digest(b''),'words':0}
        words=m['word_counts']; words.update(full=0,semantic=0,delta=0,assigned_patch=0,avoided=0); replace(m,e)
        call('render',mp,'sol',good=False)

def offline_structure_and_predecessor_walk():
    with fixture() as (root, session, git, write, call, prepare, finish):
        old = module.prior_coverage
        try:
            module.prior_coverage = lambda *_: (_ for _ in ()).throw(AssertionError('discovery/risk walked predecessor'))
            args = type('Args', (), {'session':str(session),'label':'probe','phase':'discovery','head':None,'assignment':[],'full_seat':None})()
            module.prepare(args)
            args.phase='risk'; args.label='risk-probe'; args.assignment=[s+'='+b for s,b in zip(seats,bundles)]; module.prepare(args)
        finally: module.prior_coverage=old
        m=prepare(); path=session/'r1-evidence.manifest.json'
        for bad in ({}, None, [], {'seats':None}):
            (session/'coverage-head.json').write_text(json.dumps(bad))
            m=prepare('fallback','verification',*assign)
            assert 'invalid coverage predecessor:' in m['fallback_reason']
        (session/'coverage-head.json').unlink()
        (session/'coverage-head.json').symlink_to('missing-coverage-head.json')
        m=prepare('dangling-head','verification',*assign)
        assert all(row['scope'] == 'full' for row in m['assignments'].values())
        assert 'invalid coverage predecessor:' in m['fallback_reason']
        old=module.Repository
        try:
            module.Repository=lambda *_: (_ for _ in ()).throw(AssertionError('offline used repository'))
            module.validated_manifest(path, offline=True)
        finally: module.Repository=old

def local_ignored_instructions():
    with fixture() as (root, session, git, write, call, prepare, finish):
        (root/'.git/info/exclude').write_text('AGENTS.md\n')
        write('AGENTS.md','Applicable ignored repository rule.\n'); write('inside/main.py','value = 1\n')
        text=(session/'scope.env').read_text().replace('REV_SCOPE=branch','REV_SCOPE=inside'); (session/'scope.env').write_text(text)
        m=prepare(); assert 'Applicable ignored repository rule.' in (session/'r1-instructions.md').read_text()
        assert m['paths']==['inside/main.py']
        write('AGENTS.md','Changed local rule.\n'); call('render', session/'r1-evidence.manifest.json','sol',good=False)
        old=prepare('historical','discovery','--head','HEAD'); assert old['instructions']==[]
        (root/'AGENTS.md').unlink(); outside=root.parent/'outside-rules'; outside.write_text('OUTSIDE_RULE\n')
        (root/'AGENTS.md').symlink_to(outside)
        call('prepare',session,'unsafe-rules','--phase','discovery',good=False)
        assert not list(session.glob('runsafe-rules-*'))

def current_coverage_receipts():
    with fixture(adapter='codex') as (root, session, git, write, call, prepare, finish):
        check = lambda: json.loads(call('current-coverage', session))
        assert check()['eligible'] is False
        (root / '.git/info/exclude').write_text('AGENTS.md\n')
        write('AGENTS.md', 'Original repository instruction.\n')
        roster_path = session / 'roster.json'
        roster = json.loads(roster_path.read_text())
        for row in roster['seats']:
            row.update(model='model-' + row['seat'], effort='xhigh')
        roster_path.write_text(json.dumps(roster))
        prepare('risk', 'risk', *assign); finish('risk')
        assert check()['eligible'] is False
        prepare('current', 'verification', *assign)
        assert check()['eligible'] is False
        finish('current')
        expected = check()
        assert expected['eligible'] is True and expected['reason'] is None, expected
        assert expected['phase'] == 'verification' and expected['label'] == 'current'
        assert expected['receipt'] == 'rcurrent-coverage.receipt.json'
        assert set(expected['selected_generations']) == set(seats)
        assert all(row['effort'] == 'xhigh' and row['enforced'] is True
                   for row in expected['selected_generations'].values())
        receipt_path = session / expected['receipt']
        head_path = session / 'coverage-head.json'
        original_receipt = receipt_path.read_bytes(); original_head = head_path.read_bytes()
        for field, value in (
                ('phase', 'risk'), ('snapshot_tree', '0' * 40), ('base_tree', '0' * 40),
                ('manifest_sha256', '0' * 64), ('assignments', {}), ('results', {}),
                ('findings', [{}]), ('schema_version', 2)):
            bad = json.loads(original_receipt); bad[field] = value
            raw = module.encoded(bad); receipt_path.write_bytes(raw)
            head_path.write_bytes(module.encoded({'receipt': receipt_path.name, 'sha256': module.digest(raw)}))
            assert check()['eligible'] is False, field
        receipt_path.write_bytes(original_receipt); head_path.write_bytes(original_head)
        for path, raw in (
                (root / 'main.py', b'def first():\n    return 3\n'),
                (root / 'AGENTS.md', b'Changed ignored repository instruction.\n'),
                (session / 'rcurrent-sol.json', b'{"summary":"changed","findings":[]}'),
                (session / 'rcurrent-sol.exit', b'1\n'),
                (session / 'rcurrent-sol.stream.ndjson', b'{"changed":true}\n'),
                (session / 'files.txt', b'different.py\n')):
            saved = path.read_bytes(); path.write_bytes(raw)
            assert check()['eligible'] is False, str(path)
            path.write_bytes(saved)
        saved_roster = roster_path.read_bytes()
        for field, value in (('model', 'another-model'), ('effort', 'max')):
            changed = json.loads(saved_roster); changed['seats'][0][field] = value
            roster_path.write_bytes(module.encoded(changed))
            assert check()['eligible'] is False, field
        roster_path.write_bytes(saved_roster)
        manifest_path = session / 'rcurrent-evidence.manifest.json'
        saved_manifest = manifest_path.read_bytes()
        changed = json.loads(saved_manifest); changed['assignments'].pop('sol')
        manifest_path.write_bytes(module.encoded(changed))
        assert check()['eligible'] is False
        manifest_path.write_bytes(saved_manifest)
        assert check() == expected
        prepare('latest-risk', 'risk', *assign); finish('latest-risk')
        assert check()['eligible'] is False, 'an older verification cannot replace the latest risk head'
    with fixture() as (root, session, git, write, call, prepare, finish):
        prepare('agent', 'verification', *assign); finish('agent')
        assert json.loads(call('current-coverage', session))['eligible'] is False

def current_coverage_replacements_and_refs():
    with fixture(adapter='codex') as (root, session, git, write, call, prepare, finish):
        roster = json.loads((session / 'roster.json').read_text())
        next(row for row in roster['seats'] if row['seat'] == 'terra').update(
            model='gpt-5.6-luna', effort='high')
        next(row for row in roster['seats'] if row['seat'] == 'sol').update(
            model='gpt-5.6-sol', effort='high')
        (session / 'roster.json').write_text(json.dumps(roster))
        parent = prepare('parent', 'verification', *assign)
        for seat in parent['assignments']:
            (session / f'rparent-{seat}.prompt.md').write_text(
                call('render', session / 'rparent-evidence.manifest.json', seat))
            (session / f'rparent-{seat}.json').write_text('{"summary":"parent","findings":[]}')
            (session / f'rparent-{seat}.exit').write_text('0\n')
            write_agent_audit(session, 'parent', seat)
        (session / 'rparent-terra.exit').write_text('1\n')
        (session / 'rparent-terra.audit-invalid.json').write_text('{"summary":"kept","findings":[]}\n')
        prepare('parentx', 'repair', '--assignment', 'sol=' + bundles[1],
                '--parent-assignment', 'parent:terra')
        (session / 'rparentx-sol.prompt.md').write_text(
            call('render', session / 'rparentx-evidence.manifest.json', 'sol'))
        (session / 'rparentx-sol.json').write_text('{"summary":"replacement","findings":[]}')
        (session / 'rparentx-sol.exit').write_text('0\n')
        write_agent_audit(session, 'parentx', 'sol')
        call('receipt', session, 'parent', '--replacement', 'terra=parentx')
        check = lambda: json.loads(call('current-coverage', session))
        value = check()
        assert value['eligible'] is True, value
        assert value['selected_generations']['terra']['label'] == 'parentx'
        assert value['selected_generations']['terra']['seat'] == 'sol'
        child = session / 'rparentx-sol.json'; saved = child.read_bytes()
        child.write_text('{"summary":"changed replacement","findings":[]}')
        assert check()['eligible'] is False
        child.write_bytes(saved)
        assert check() == value
    with fixture(adapter='codex') as (root, session, git, write, call, prepare, finish):
        git('add', 'main.py'); git('commit', '-qm', 'reviewed material')
        prepare('ref', 'verification', '--head', git('rev-parse', 'HEAD'), *assign); finish('ref')
        check = lambda: json.loads(call('current-coverage', session))
        assert check()['eligible'] is True
        saved = (root / 'main.py').read_bytes(); write('main.py', 'changed current worktree\n')
        assert check()['eligible'] is False, 'a pinned ref cannot certify changed current source'
        (root / 'main.py').write_bytes(saved)
        (root / '.git/info/exclude').write_text('AGENTS.md\n')
        write('AGENTS.md', 'New current instruction outside the pinned ref.\n')
        assert check()['eligible'] is False

def binary_files_are_hash_pointers():
    with fixture() as (root, session, git, write, call, prepare, finish):
        git('add', '-A'); git('commit', '-qm', 'pointer base')
        base = git('rev-parse', 'HEAD')
        scope = (session / 'scope.env').read_text()
        (session / 'scope.env').write_text('\n'.join(
            'REV_BASE=' + base if row.startswith('REV_BASE=') else row
            for row in scope.splitlines()) + '\n')
        write('src/pointer_app.py', 'def value():\n    return 2\n')
        raw = b'\x89PNG\r\n\x1a\n' + b'\0' * 65536
        (root / 'docs').mkdir(parents=True, exist_ok=True)
        (root / 'docs' / 'shot.png').write_bytes(raw)
        manifest = prepare('png')
        patch = (session / 'rpng-full.patch').read_bytes()
        assert b'GIT binary patch' not in patch
        assert b'\0' not in patch
        assert b'docs/shot.png' in patch
        assert b'Binary-File-Pointer' in patch
        assert f'after size {len(raw)}'.encode() in patch
        assert f'after sha256 {hashlib.sha256(raw).hexdigest()}'.encode() in patch
        assert b'before absent' in patch
        assert len(patch) < 8000
        for patch_set in manifest['patch_sets'].values():
            assert len(patch_set['chunks']) <= 1

cases = (
    storage_redirects, quoted_paths, changed_symbols, empty_patch_needs_no_fake_read,
    binary_files_are_hash_pointers,
    conservative_mechanical_classification, bounded_navigation_markdown, opaque_transitions,
    opaque_mode_transition, invalid_manifests, phase_and_predecessor_integrity,
    source_context_inputs_batches_uncached_blobs, source_context_memo_validation_guards,
    source_context_memo_reuses_shared_predecessor_reconstruction,
    cumulative_verification_routing, verification_delta_retains_restored_path_source_context,
    verification_delta_source_context_controls, verification_nested_restoration_retains_instruction_context,
    verification_nested_restoration_refuses_unusable_instruction_budget, coverage_head_publication_is_monotonic,
    same_stat_and_index_flags, cstyle_enclosing_bodies, wallet_scale,
    literal_scope_and_inventories, sparse_gitlink_and_special, roster_bundle_coverage,
    source_context_packets, local_names_do_not_expand_cross_file_proof,
    wildcard_reexports_use_exact_source_proof,
    wildcard_reexport_syntax_preserves_start_lines,
    rust_use_imports_keep_cross_file_callers,
    rust_grouped_use_alias_is_a_capacity_counted_obligation,
    ts_default_import_alias_is_a_capacity_counted_obligation,
    rust_module_alias_and_self_import_keep_qualified_callers,
    rust_grouped_root_reexport_is_a_capacity_counted_obligation,
    ts_namespace_alias_missing_target_is_a_capacity_counted_obligation,
    coexisting_ts_projects_are_explicitly_ambiguous_with_matching_base_url,
    ambiguous_ts_configs_are_explicit_search_obligations,
    ts_paths_alias_and_missing_targets_are_capacity_counted,
    ts_transitive_excluded_file_uses_project_path_aliases,
    ts_explicit_files_root_keeps_path_aliases_outside_config_and_exclude,
    provider_visible_source_packet_limit,
    source_context_prefers_named_production_and_maps_gates, complete_declaration_context,
    budget_omissions_are_segmented_or_retained, innermost_declarations_and_bounded_anchors,
    high_confidence_component_union, components_ownership_and_instructions,
    instruction_override_precedence, empty_source_context, bounded_work_and_memory,
    receipt_read_audits, seat_local_recovery, narrow_seat_requires_proven_reads,
    full_seat_requires_proven_reads, unenforced_agent_seat_binds_only_its_prompt,
    unenforced_audit_is_opt_in, unenforced_audit_cache_is_keyed_on_every_input,
    nested_walks_reuse_cached_audits, replacement_runs_on_another_seat,
    replacement_accepts_only_durable_provider_exit_3,
    replacement_requires_quota_disabled_escalation_record,
    replacement_accepts_only_a_recorded_owned_provider_cancellation,
    record_provider_cancellation_binds_the_finished_attempts,
    replacement_chain_reaches_opus,
    incomplete_proof_is_never_a_valid_result, incomplete_proof_is_replaced_at_once,
    semantic_rejection_revokes_sealed_coverage,
    semantic_rejection_checks_identity_and_preserves_siblings,
    semantic_rejection_replaces_a_previously_sealed_child,
    semantic_rejection_retry_promotes_existing_successor,
    semantic_rejection_replaces_a_different_original_sibling,
    semantic_rejection_refuses_redirected_and_stale_records,
    hardlinked_incomplete_proof_cannot_verify, hardlinked_incomplete_proof_cannot_seal,
    symlinked_incomplete_proof_cannot_verify, symlinked_incomplete_proof_cannot_seal,
    incomplete_proof_latches_only_its_label_and_seat, incomplete_proof_from_a_failed_launch_keeps_its_retry,
    incomplete_proof_replacement_survives_a_changed_prompt,
    old_success_cannot_retire_a_current_failed_launch,
    old_success_cannot_make_a_current_failed_launch_replaceable,
    incomplete_proof_is_only_a_summary_prefix,
    review_origin_counts_the_reviews_own_lines, scoped_names_and_gitlink_lifecycle,
    component_and_full_tampering, offline_structure_and_predecessor_walk,
    local_ignored_instructions, overlapping_boundaries_keep_prior_owner_routing,
    current_coverage_receipts, current_coverage_replacements_and_refs,
)
groups = {
    'semantic_rejection': (semantic_rejection_revokes_sealed_coverage,
        semantic_rejection_checks_identity_and_preserves_siblings,
        semantic_rejection_replaces_a_previously_sealed_child,
        semantic_rejection_retry_promotes_existing_successor,
        semantic_rejection_replaces_a_different_original_sibling,
        semantic_rejection_refuses_redirected_and_stale_records),
    'structure': (
        storage_redirects, quoted_paths, changed_symbols, empty_patch_needs_no_fake_read,
        conservative_mechanical_classification, bounded_navigation_markdown,
        binary_files_are_hash_pointers,
        opaque_transitions, opaque_mode_transition, invalid_manifests,
        phase_and_predecessor_integrity,
    ),
    'source_context_memo': (
        source_context_inputs_batches_uncached_blobs, source_context_memo_validation_guards,
        source_context_memo_reuses_shared_predecessor_reconstruction,
    ),
    'routing': (
        cumulative_verification_routing, verification_delta_retains_restored_path_source_context,
        verification_delta_source_context_controls, verification_nested_restoration_retains_instruction_context,
        verification_nested_restoration_refuses_unusable_instruction_budget, coverage_head_publication_is_monotonic,
        same_stat_and_index_flags, literal_scope_and_inventories,
        sparse_gitlink_and_special, roster_bundle_coverage,
        scoped_names_and_gitlink_lifecycle, component_and_full_tampering,
        offline_structure_and_predecessor_walk, local_ignored_instructions,
        overlapping_boundaries_keep_prior_owner_routing,
    ),
    'context': (
        cstyle_enclosing_bodies, source_context_packets,
        local_names_do_not_expand_cross_file_proof,
        wildcard_reexports_use_exact_source_proof,
        wildcard_reexport_syntax_preserves_start_lines,
        rust_use_imports_keep_cross_file_callers,
        rust_grouped_use_alias_is_a_capacity_counted_obligation,
        ts_default_import_alias_is_a_capacity_counted_obligation,
        rust_module_alias_and_self_import_keep_qualified_callers,
        rust_grouped_root_reexport_is_a_capacity_counted_obligation,
        ts_namespace_alias_missing_target_is_a_capacity_counted_obligation,
        coexisting_ts_projects_are_explicitly_ambiguous_with_matching_base_url,
        ambiguous_ts_configs_are_explicit_search_obligations,
        ts_paths_alias_and_missing_targets_are_capacity_counted,
        ts_transitive_excluded_file_uses_project_path_aliases,
        ts_explicit_files_root_keeps_path_aliases_outside_config_and_exclude,
        provider_visible_source_packet_limit,
        source_context_prefers_named_production_and_maps_gates,
        complete_declaration_context, budget_omissions_are_segmented_or_retained,
        innermost_declarations_and_bounded_anchors, high_confidence_component_union,
        components_ownership_and_instructions, instruction_override_precedence,
        empty_source_context,
    ),
    'scale_receipts': (
        wallet_scale, bounded_work_and_memory, receipt_read_audits,
        seat_local_recovery, narrow_seat_requires_proven_reads,
        full_seat_requires_proven_reads, unenforced_agent_seat_binds_only_its_prompt,
        unenforced_audit_is_opt_in, unenforced_audit_cache_is_keyed_on_every_input,
        nested_walks_reuse_cached_audits,
    ),
    'replacement': (
        replacement_runs_on_another_seat, replacement_accepts_only_durable_provider_exit_3,
        replacement_requires_quota_disabled_escalation_record,
        replacement_accepts_only_a_recorded_owned_provider_cancellation,
        record_provider_cancellation_binds_the_finished_attempts,
        replacement_chain_reaches_opus,
        incomplete_proof_is_never_a_valid_result,
        incomplete_proof_is_replaced_at_once, incomplete_proof_latches_only_its_label_and_seat,
        hardlinked_incomplete_proof_cannot_verify, hardlinked_incomplete_proof_cannot_seal,
        symlinked_incomplete_proof_cannot_verify, symlinked_incomplete_proof_cannot_seal,
        incomplete_proof_from_a_failed_launch_keeps_its_retry,
        incomplete_proof_replacement_survives_a_changed_prompt,
        old_success_cannot_retire_a_current_failed_launch,
        old_success_cannot_make_a_current_failed_launch_replaceable,
        incomplete_proof_is_only_a_summary_prefix, review_origin_counts_the_reviews_own_lines,
    ),
    'current_coverage': (current_coverage_receipts, current_coverage_replacements_and_refs),
}
partition = tuple(test for group in groups.values() for test in group)
assert len(partition) == len(set(partition)) and set(partition) == set(cases), \
    'evidence hardening groups must partition the canonical cases exactly once'
selected = os.environ.get('REV_EVIDENCE_CASE')
selected_group = os.environ.get('REV_EVIDENCE_GROUP')
assert not (selected and selected_group), 'select one evidence case or group'
if selected_group:
    assert selected_group in groups, 'unknown evidence hardening group: ' + selected_group
    chosen = set(groups[selected_group])
elif selected:
    matches = [test for test in cases if test.__name__ == selected]
    assert len(matches) == 1, 'unknown evidence hardening case: ' + selected
    chosen = set(matches)
else:
    chosen = set(cases)
for test in cases:
    if test not in chosen:
        continue
    try:
        test(); print('PASS', test.__name__)
    except Exception as error:
        failures.append(test.__name__); print('FAIL', test.__name__, str(error))
assert not failures, failures
PY
  local rc=$?
  if declare -F ok >/dev/null && declare -F fail >/dev/null; then
    if [ "$rc" -eq 0 ]; then ok "evidence hardening and scale"; else fail "evidence hardening and scale" "exit $rc"; fi
  fi
  return "$rc"
}

test_evidence_hardening_structure() {
  REV_EVIDENCE_GROUP=structure evidence_hardening
}

test_evidence_source_context_memo() {
  REV_EVIDENCE_GROUP=source_context_memo evidence_hardening
}

test_evidence_hardening_routing() {
  REV_EVIDENCE_GROUP=routing evidence_hardening
}

test_evidence_hardening_context() {
  REV_EVIDENCE_GROUP=context evidence_hardening
}

test_evidence_hardening_scale_receipts() {
  REV_EVIDENCE_GROUP=scale_receipts evidence_hardening
}

test_evidence_hardening_replacement() {
  REV_EVIDENCE_GROUP=replacement evidence_hardening
}

test_evidence_current_coverage() {
  REV_EVIDENCE_GROUP=current_coverage evidence_hardening
}

test_evidence_semantic_rejection() {
  REV_EVIDENCE_GROUP=semantic_rejection evidence_hardening
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  test_evidence_contract \
    && test_evidence_hardening_structure \
    && test_evidence_source_context_memo \
    && test_evidence_hardening_routing \
    && test_evidence_hardening_context \
    && test_evidence_hardening_scale_receipts \
    && test_evidence_provider_contract_binding
fi
