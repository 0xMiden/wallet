---
name: stack
description: Run the /review-council:rev multi-model review across a STACK of related PRs in several repos - per-PR legs in dependency order, two passes, a cross-repo seam review, a completeness critic, stall recovery, and one push per repo with review commits kept one per fix. Use when one change spans multiple repositories that must be reviewed together (a protocol change plus the SDK, client and app PRs that consume it), or when a review must run unattended for many hours. For a single PR or branch, use /review-council:rev directly.
user_invocable: true
---

# stack - one review across a stack of PRs

Wraps `/review-council:rev` for the case it does not cover: **one change spread across several repos**,
each with its own PR, that only makes sense reviewed together - and a run long enough
(10-20 h) that it must survive stalls and machine contention without supervision.

`/review-council:rev` runs one loop in this session and waits. This skill runs many, in
sequence, as headless `claude -p "/review-council:rev …"` legs, and keeps them alive.

## When this is the right tool

Both must hold:

- The change spans 3+ repos whose PRs depend on each other.
- The review will outlast your attention: legs take 1-4 h each; two passes over six
  repos is most of a day.

For one PR, one branch, or uncommitted work: `/review-council:rev`. Do not reach for this.

## Shape of a run

    PHASE 1  per-PR legs, PASS 1     one review loop per repo, in dependency order
    PHASE 1  per-PR legs, PASS 2     again - pass 1 reviewed a tree that has since changed, including by pass 1 itself
    PHASE 2  cross-repo seam review  the contracts BETWEEN the PRs
    PHASE 3  completeness critic     what did every pass miss
    FINISH   one push per repo, review commits kept one per fix (skipped for a repo whose leg failed)

**Pass 2 is not redundant.** In the run this skill was built from, pass 2 found that a
change landing after pass 1 had invalidated a security assumption documented on the
function it rerouted. Nothing in pass 1 could have seen it.

## Preflight

Apply `rev`'s repository-check policy independently to every leg: inherit that
repository's runner routing, request helper, guarded fallback and opt-in checks.
After an authorized push, explicitly request manual-only CI where needed and
verify the tested revision; stack completion or publication is not a CI pass.

Everything `/review-council:rev`'s preflight checks per leg (working branch, non-empty
scope, a roster of at least three signed-in seats), plus:

1. **Order the legs by dependency.** Review the thing others build on first; its
   findings change what the dependents should say.
2. **Give each leg a written premise.** A leg with no context "fixes" things that are
   not broken - one reverted a deliberate version pin as a P0 overnight. Say what the PR
   claims, what is already known, and **name the claim you most want attacked**; that
   sentence produced the highest-value findings in the source run.
3. **Nothing else heavy on the box** (below).

## Running it

Copy `${CLAUDE_PLUGIN_ROOT}/scripts/stack.example.sh`, fill in `legs()` and the
seam/critic repos, then - from a plain foreground `Bash` call:

The numeric round count in each existing `run_leg` explicitly selects the legacy
numbered schedule. Numeric legs may continue past the requested minimum under the
numeric completion rules in `rev`; plan panels do not count toward that minimum. It
does not opt that leg into the direct adaptive default.

Treat roster or preflight exit codes distinctly. Exit 5 is retryable: retain the
session and let the bounded attempt loop retry it. Exit 6 is permanent: relay the
one-line reason verbatim, fail that leg, and do not retry the same contract.

```bash
${CLAUDE_PLUGIN_ROOT}/scripts/stack.sh my-stack.sh
```

It **detaches itself** into a new session (nohup + setsid) and returns at once,
printing the session root, the log path and the orchestrator's own output file.
Do NOT launch it with `run_in_background`: a Claude Code background command is
killed by the harness after roughly an hour, and the kill takes the leg's whole
process group with it mid-round - that is exactly how the first live stack run
died. `REV_STACK_FOREGROUND=1` keeps it attached for tests or a terminal you will
keep open.

Then arm ONE `Monitor` on the log so the user gets the 10-minute status line the
`/review-council:rev` skill promises:

```
Monitor({ command: "tail -n0 -f <the log path it printed> | grep --line-buffered -E '^\\S+ \\S+ (\\[status\\]|===|!!!|#####|ALL )'",
          description: "review-council stack progress", persistent: true, timeout_ms: 3600000 })
```

Relay each event to the user as-is with at most one sentence of context. The
Monitor has its own lifetime cap; re-arm it if it expires while the run is alive
(`pgrep -f stack.sh`), and never treat a quiet Monitor as a finished run -
the log is the record.

Legs run with `REV_STACK_LEG=1`, so a leg never squashes or pushes; the orchestrator
does both once per repo at the end (`NO_PUSH=1` to skip the push). Give every
working branch an upstream of the same name first (`git push -u origin HEAD`). The
stack fails closed before squash or push when the upstream destination differs from
the reviewed branch, including a branch created while tracking `origin/main`.
`ROOT` (session root, one
`<leg>/` dir each), `LOG`, `PASSES`, `STALL_SECS`, `MAX_ATTEMPTS` are env knobs; see
the script header.

**Resume.** Re-running with the same `LOG` skips legs already marked `=== DONE`.

## Stalls and status - one detector, in the orchestrator

A headless leg that hangs looks exactly like one that is working. `stack.sh`
polls each leg and kills it only when **both** hold:

- `run.log` (stream-json: one event per assistant message and tool call) **and** the
  leg's session dir have been quiet for `STALL_SECS` (default 30 min);
- the leg's CPU time did not move across a 45 s sample - the veto that stops a long,
  silent compile from being mistaken for a hang.

A killed leg is retried (4 attempts) with a resume note pointing at its own ledger. A
stall is never counted as an "infrastructure" fast failure.

Every 10 minutes the log gets one line per running leg:

```
[status] wallet pass1 attempt1 | r3/7 triage | Council is in triage, round 3 of 7: 3 of 4 reviewers have returned results. Terra is still reviewing; its last recorded step was git diff. 1 P0-P2 finding remains open (P0: 0, P1: 1, P2: 0); 6 fixes are recorded. A recent returned report flags P1 at src/api.ts:42: retry skips the expired response. | sol: done 4f 9m | terra: running 12m ← git diff … | sonnet: done 2f 8m | opus: done 3f 7m | open P0:0 P1:1 P2:0 fixed 6 | idle=41s cpu=12:07(moving) commits=3
```

Read `idle` and `cpu` together. A large `idle` with `cpu=…(moving)` is a leg mid-build;
`idle` climbing past the limit with `cpu=…(frozen)` is what gets killed.

**There is exactly one stall detector.** The previous version of this skill had two -
an external guard script and one inside the orchestrator - and the one nobody had
hardened false-killed a working leg. Do not arm a second one. If you need a different
threshold, set `STALL_SECS`; do not add a watcher.

## Do not run heavy work beside the review

On one box, review legs and E2E suites contend for CPU and any shared prover. In the
source run this produced three false failures in one night: a unit test that "failed"
under sweep load, a "hung" suite that was debug-mode proving, and an E2E spec dying on
`Deadline expired`. Any failure whose text mentions a timeout or deadline is suspect:
re-run it idle before touching code.

## Finishing: push, publish, then promote

Each leg commits one fix per commit, and the orchestrator pushes each repo once with
those commits intact: review commits are never squashed, because the finding-to-commit
mapping is the audit trail. `NO_SQUASH=1` is the default on both hosts; `NO_SQUASH=0`
is a legacy opt-in that collapses each repo's run with `${CLAUDE_PLUGIN_ROOT}/scripts/rev-squash.sh --apply`
and discards that mapping; a refused squash is then logged (`!!! squash refused for <repo>`) while the push
still happens. Before pushing, the orchestrator reconciles the validated upstream tracking ref from
the captured literal push URL. After a pinned push succeeds, it records the immutable
pushed commit in that ref before checking whether the local branch moved. A retry can
therefore recognize remote success without rewriting an already-pushed review commit.

After every completed repository is pushed successfully, `stack.sh` follows
`docs/pr-review.md`: unsquashed fix commits keep their own links, and a changed-head squash (`NO_SQUASH=0`) must preserve the inspected tree, decision
links and reviewed-PR fix links are mapped to the pushed aggregate commit, the
canonical body is rendered again, and only then is the latest completed review for
each canonical repository published. Separate-PR fix links stay pinned. A pushed
retry derives the transition from the frozen target and current head. It skips
sessions with no associated open PR and suppresses an exact prior `COMMENTED` review.
A failed repository is skipped while every successful repository still finalizes and
publishes; the overall run remains failed. Legs leave `stack-report.md` with
`phase=stack-ready`. Only successful publication or an explicit no-push skip promotes
that file to `report.md` and sets `phase=done`. A push, finalization, missing-input,
or publication failure keeps that repository's ready receipt unpromoted. `NO_PUSH=1`
suppresses every external GitHub call made by rendering, finalization, and publication.

A repo whose leg never completed is **not** finished: it is skipped (no squash, no
push) and the run ends `COMPLETE WITH FAILURES: <labels>` with a non-zero exit instead
of `ALL PHASES COMPLETE`. Re-run the stack - the resume check skips the legs already
DONE for this session root - before touching those repos by hand.

**Promote out of draft LAST**, and by whether CI can go green, not by position in the
stack:

| State | Action |
|---|---|
| CI structurally cannot pass until the root ships | stay draft, say what it waits on |
| CI can pass; only a merge gate is pending | promote - review starts while the gate waits |

Check `mergeable`, not just `isDraft`: a long run gives the base branch time to move.
Once the root PR needs a human reviewer it is the critical path; say so rather than
generating motion on the consumers.

## Reading the output

Each ready leg leaves `<ROOT>/<leg>/stack-report.md` and `findings.md`; after successful
stack completion, the ready report is promoted to `report.md`. Findings cluster into
shapes worth naming when you summarise:

- **Tests that cannot fail** - assertions satisfied by the call under test, fixtures
  that only exercise the benign ordering. The single most common P1.
- **Coverage that does not execute** - comparing hashes instead of running the thing.
  Ask for mutation evidence: a test proven to fail when the code is broken.
- **Docs contradicting their own code** - especially a stated precondition a later
  change invalidated.
- **The same defect in N repos** - the seam finding; it usually has one upstream fix.
