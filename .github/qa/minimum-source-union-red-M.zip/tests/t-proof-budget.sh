#!/bin/bash
# Exact source artifacts preserve caller proof within the frozen repository read budget.

test_code_proof_budget_promotes_exact_caller_segments() {
  ( local R="$T/proof-budget-root" S="$T/proof-budget-session"
    mkrepo "$R"; mkdir -p "$R/src" "$S"
    python3 - "$R" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
functions = []
for index in range(13):
    body = 'x' * 10000
    functions.append(f'def fn{index:02d}(value=None):\n    return "{body}"\n')
    call = 'y' * 8000
    (root / 'src' / f'use{index:02d}.py').write_text(
        f'from src.lib import fn{index:02d}\n\ndef use{index:02d}():\n    return fn{index:02d}("{call}")\n')
(root / 'src' / 'lib.py').write_text('\n'.join(functions))
PY
    git -C "$R" add . && git -C "$R" commit -qm "proof budget base"
    local base; base=$(git -C "$R" rev-parse HEAD)
    python3 - "$R/src/lib.py" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
path.write_text(path.read_text().replace('return "x', 'return "y', 13))
PY
    printf "REV_BASE='%s'\nREV_BRANCH='feature'\nREV_DEFAULT='main'\nREV_ROOT='%s'\nREV_SCOPE='branch'\n" \
      "$base" "$R" > "$S/scope.env"
    printf '%s\n' src/lib.py > "$S/files.txt"
    : > "$S/untracked.txt"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"terra","adapter":"codex"},{"seat":"opus","adapter":"claude"},{"seat":"sonnet","adapter":"claude"}]}' > "$S/roster.json"
    REV_PATCH_CHUNKS=auto REV_SOURCE_CONTEXT=1 \
      python3 "$SCRIPTS/rev-evidence.py" prepare "$S" proof --phase discovery \
      > "$T/proof-budget.out" 2> "$T/proof-budget.err"
    local status=$?
    if [ "$status" -ne 0 ]; then
      cat "$T/proof-budget.out" "$T/proof-budget.err" >&2
    fi
    assert_eq "thirteen qualified consumers launch with exact source proof" "$status" 0
    [ "$status" -eq 0 ] || return 0
    local manifest="$S/rproof-evidence.manifest.json" prompt
    local bundle
    bundle=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["assignments"]["sol"]["bundle"])' "$manifest") || return
    prompt=$("$SCRIPTS/rev-prompt.sh" "$S" proof sol "$bundle" \
      proof-budget --evidence "$manifest") || return
    printf '%s\n' '{"summary":"checked","findings":[]}' > "$S/rproof-sol.json"
    python3 - "$manifest" "$SCRIPTS/rev-evidence.py" <<'PYPROOF'
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import sys

manifest_path = Path(sys.argv[1])
session = manifest_path.parent
manifest = json.loads(manifest_path.read_text())
context = manifest['source_context']['seats']['sol']
capacity = manifest['task_capacity']['seats']['sol']
assert manifest['task_capacity']['mandatory_repository_read_limit'] == 12, capacity
assert capacity['mandatory_repository_reads'] <= 12, capacity
expected = {f'src/use{index:02d}.py' for index in range(13)}
delivered = [row for shard in context['shards'] for row in shard['ranges']]
delivered += context['required_source_ranges']
assert all(any(row['path'] == path and row['line_start'] <= 4 <= row['line_end']
               for row in delivered) for path in expected), delivered
assert any(row['path'] in expected for row in context['required_source_ranges']), context
assert not any(row['path'] in expected for row in context['omitted_source_ranges']), context
spec = importlib.util.spec_from_file_location('proof_evidence', sys.argv[2])
evidence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evidence)
events = []
def command(identifier, text, output):
    events.extend([
        {'type': 'item.started', 'item': {'id': identifier, 'type': 'command_execution',
                                         'command': text}},
        {'type': 'item.completed', 'item': {'id': identifier, 'type': 'command_execution',
                                           'command': text, 'aggregated_output': output,
                                           'exit_code': 0}},
    ])
def artifact(identifier, path):
    command(identifier, shlex.join(['cat', str(path)]), path.read_text())
for index, shard in enumerate(context['shards']):
    artifact(f'packet-{index}', session / shard['artifact'])
assignment = manifest['assignments']['sol']
if assignment['patch_read_mode'] == 'chunks':
    for chunk in manifest['patch_sets'][assignment['patch_set']]['chunks']:
        artifact(f'patch-{chunk["index"]}', session / chunk['artifact'])
else:
    patch = Path(assignment['patch'])
    lines = patch.read_text().splitlines(keepends=True)
    for first in range(1, len(lines) + 1, 40):
        last = min(first + 39, len(lines))
        command(f'patch-{first}', shlex.join(['sed', '-n', f'{first},{last}p', str(patch)]),
                ''.join(lines[first - 1:last]))
for index, required in enumerate(context['required_source_ranges']):
    for segment in required['segments']:
        artifact(f'source-{index}-{segment["index"]}', session / segment['artifact'])
artifact('index', session / 'rproof-evidence.md')
if context['source_read_required']:
    prompt = (session / 'rproof-sol.prompt.md').read_text()
    target = re.search(r'^Required post-index original-source target: (.+):(\d+)-(\d+) '
                       r'tree (\w+) blob (\w+) content SHA-256 (\w+) reasons ', prompt, re.M)
    assert target, prompt
    path, start, end, tree, oid, content_hash = target.groups()
    start, end = int(start), int(end)
    repo = evidence.Repository(session.resolve())
    entry = repo.entries(tree)[path]
    assert entry[1] == oid
    lines = evidence.split_lf_lines(repo.blob(entry))
    assert hashlib.sha256(b''.join(lines[start - 1:end])).hexdigest() == content_hash
    for first in range(start, end + 1, 40):
        last = min(first + 39, end)
        command(f'current-{first}', shlex.join(['git', 'show', tree + ':' + path])
                + ' | ' + shlex.join(['sed', '-n', f'{first},{last}p']),
                b''.join(lines[first - 1:last]).decode())
(session / 'rproof-sol.stream.ndjson').write_text(
    ''.join(json.dumps(event) + '\n' for event in events))
PYPROOF
    assert_eq "all thirteen consumers receive bounded immutable proof artifacts" "$?" 0
    python3 "$SCRIPTS/lib/review-read-audit.py" audit --adapter codex \
      --raw "$S/rproof-sol.stream.ndjson" --prompt "$prompt" --root "$R" --session "$S" \
      --out "$S/rproof-sol.read-audit.json" > "$T/proof-budget-audit.out" 2> "$T/proof-budget-audit.err"
    assert_eq "the complete caller proof passes the transcript audit" "$?" 0
    python3 - "$S/rproof-sol.read-audit.json" <<'PYAUDIT'
import json
import sys

audit = json.load(open(sys.argv[1]))
assert audit['status'] == 'valid', audit
expected = {f'src/use{index:02d}.py' for index in range(13)}
assert all(any(row['path'] == path and row['line_start'] <= 4 <= row['line_end']
               for row in audit['source_ranges']) for path in expected), audit
assert not audit['violations'], audit
PYAUDIT
    assert_eq "the auditor credits every qualified caller range" "$?" 0
  )
}

test_edited_tests_exceeding_proof_budget_are_refused() {
  ( local R="$T/proof-tests-root" S="$T/proof-tests-session"
    mkrepo "$R"; mkdir -p "$R/tests" "$S"
    python3 - "$R" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
for index in range(17):
    (root / 'tests' / f'test_{index:02d}.py').write_text(
        f'def test_{index:02d}():\n    assert True\n')
PY
    git -C "$R" add . && git -C "$R" commit -qm "proof test base"
    local base; base=$(git -C "$R" rev-parse HEAD)
    python3 - "$R" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
for path in (root / 'tests').glob('test_*.py'):
    path.write_text(path.read_text().replace('assert True', 'assert False'))
PY
    printf "REV_BASE='%s'\nREV_BRANCH='feature'\nREV_DEFAULT='main'\nREV_ROOT='%s'\nREV_SCOPE='branch'\n" \
      "$base" "$R" > "$S/scope.env"
    printf '%s\n' "$R"/tests/test_*.py | sed "s#^$R/##" > "$S/files.txt"
    : > "$S/untracked.txt"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"terra","adapter":"codex"},{"seat":"opus","adapter":"claude"},{"seat":"sonnet","adapter":"claude"}]}' > "$S/roster.json"
    REV_PATCH_CHUNKS=auto REV_SOURCE_CONTEXT=0 \
      python3 "$SCRIPTS/rev-evidence.py" prepare "$S" tests --phase discovery \
      > "$T/proof-tests.out" 2> "$T/proof-tests.err"
    local status=$?
    if [ "$status" -ne 2 ]; then
      echo "---- prepare stdout ----" >&2
      cat "$T/proof-tests.out" >&2
      echo "---- prepare stderr ----" >&2
      cat "$T/proof-tests.err" >&2
    fi
    assert_eq "edited tests beyond the proof budget are refused before launch" "$status" 2
    [ "$status" -eq 2 ] || return 0
    assert_grep "the refusal names the frozen proof budget" \
      "$T/proof-tests.err" 'proof reads exceed repository capacity: sol limit=16 count='
    python3 - "$S" <<'PY'
import json, sys
from pathlib import Path
diagnostic = json.loads((Path(sys.argv[1]) / 'prepare-diagnostic-tests.json').read_text())
row = next(item for item in diagnostic['refusals'] if item['seat'] == 'sol')
assert row['count'] > 16, row
assert row['partitions']
assert sum(partition['reads'] for partition in row['partitions']) == row['count']
assert all(1 <= partition['reads'] <= 16 for partition in row['partitions'])
assert all(path.startswith('tests/test_') for partition in row['partitions'] for path in partition['paths'])
PY
    assert_eq "edited-test partitions stay inside the frozen budget" "$?" 0
  )
}

# Mutation prediction: discarding the parent's 200-line proof windows during
# 240-line repair loses inherited 230-277 coverage, despite retaining anchors.
test_required_source_union_nonmonotone() {
  ( local R="$T/union-root" S="$T/union-session"
    seat_env
    export REV_PATCH_CHUNKS=auto REV_SOURCE_CONTEXT=1
    mkrepo "$R" || { fail "union fixture repository setup"; return 0; }
    mkdir -p "$R/tests" "$R/src" "$S"
    python3 - "$R" "$S" "$SCRIPTS/rev-evidence.py" <<'PYUNIONSETUP'
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root, session, script = map(Path, sys.argv[1:])
def call(*args):
    result = subprocess.run([str(arg) for arg in args], capture_output=True, text=True)
    assert result.returncode == 0, (args, result.returncode, result.stdout, result.stderr)
    return result.stdout.strip()

def git(*args):
    return call('git', '-C', root, *args)

# Wide public lines force the old proof into required segments, not optional rows.
# No declarations/imports/providers; each line stays far below the visible bound.
subject = root / 'tests/union_subject.py'
def source_line(line, value):
    return ('value_%04d = %d # ' % (line, value)) + ('x' * 300) + '\n'
subject.write_text(''.join(source_line(line, 0) for line in range(1, 901)))
(root / 'a.txt').unlink()
for index in range(184):
    (root / 'src' / ('unit_%03d.txt' % index)).write_text('before\n')
git('add', '-A')
git('commit', '-qm', 'public union base')
base = git('rev-parse', 'HEAD')
lines = subject.read_text().splitlines(keepends=True)
# Hand-merging raw anchors at 200: 17-18 / 209-278 / 639-800 / 874;
# at 240: 17-229 / 278 / 639-874. No planner supplies this oracle.
# The second group makes 850-865 genuinely current-only, even with anchor padding.
for line in [17, 18, 209, 229, 278, 639, 800, 874]:
    lines[line - 1] = source_line(line, 1)
subject.write_text(''.join(lines))
for index in range(184):
    (root / 'src' / ('unit_%03d.txt' % index)).write_text('after\n')
(session / 'scope.env').write_text(
    "REV_BASE='%s'\nREV_BRANCH='feature'\nREV_DEFAULT='main'\nREV_ROOT='%s'\nREV_SCOPE='branch'\n"
    % (base, root))
paths = sorted(['tests/union_subject.py'] + ['src/unit_%03d.txt' % i for i in range(184)])
(session / 'files.txt').write_text('\n'.join(paths) + '\n')
(session / 'untracked.txt').write_text('')
(session / 'roster.json').write_text(json.dumps({'seats': [
    {'seat': 'luna-1', 'adapter': 'codex', 'model': 'gpt-5.6-luna', 'effort': 'high', 'extra': False},
    {'seat': 'luna-3', 'adapter': 'codex', 'model': 'gpt-5.6-luna', 'effort': 'high', 'extra': False},
    {'seat': 'luna-4', 'adapter': 'codex', 'model': 'gpt-5.6-luna', 'effort': 'high', 'extra': False},
    {'seat': 'escalate-sonnet', 'adapter': 'claude', 'model': 'sonnet', 'effort': 'high', 'extra': False},
]}) + '\n')
call(sys.executable, script, 'prepare', session, 'union', '--phase', 'discovery',
     '--full-seat', 'luna-3')
parent_path = session / 'runion-evidence.manifest.json'
parent = json.loads(parent_path.read_text())
assert len(parent['paths']) == 185 and parent['paths'] == paths
assert set(parent['assignments']) == {'luna-1', 'luna-3', 'luna-4', 'escalate-sonnet'}
assert parent['assignments']['luna-3']['scope'] == 'full'
# Existing hard-audit fixture pattern: synthetic terminal failure, no provider launch.
(session / 'runion-luna-3.audit-invalid.json').write_text('{"summary":"synthetic hard audit","findings":[]}\n')
call(sys.executable, script, 'prepare', session, 'unionx', '--phase', 'repair',
     '--assignment', 'escalate-sonnet=simplicity', '--parent-assignment', 'union:luna-3')
child = json.loads((session / 'runionx-evidence.manifest.json').read_text())
binding = child['parent_assignment']
assert binding['manifest'] == parent_path.name and binding['seat'] == 'luna-3'
assert binding['manifest_sha256'] == hashlib.sha256(parent_path.read_bytes()).hexdigest()
assert binding['assignment_sha256'] == hashlib.sha256(
    (json.dumps(parent['assignments']['luna-3'], sort_keys=True, ensure_ascii=True, indent=2) + '\n').encode()).hexdigest()
assert binding['roster_sha256'] == parent['inputs']['roster.json']
assert child['snapshot_tree'] == parent['snapshot_tree'] == binding['snapshot_tree']
assert child['base_tree'] == parent['base_tree'] and child['source'] == parent['source']
assert child['paths'] == paths and list(child['assignments']) == ['escalate-sonnet']
assert child['assignments']['escalate-sonnet']['scope'] == 'full'
assert child['assignments']['escalate-sonnet']['bundle'] == parent['assignments']['luna-3']['bundle']

# Validate actual delivered bytes and immutable identities before interpreting coverage.
coverage = {}
for label, seat, manifest in [('union', 'luna-3', parent), ('unionx', 'escalate-sonnet', child)]:
    packet = manifest['source_context']['seats'][seat]
    covered = set()
    required = set()
    typed = set()
    intervals = {}
    for shard in packet['shards']:
        raw = (session / shard['artifact']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == shard['sha256']
        entries = json.loads(raw)['entries']
        assert [{k: v for k, v in row.items() if k != 'content'} for row in entries] == shard['ranges']
        for row in entries:
            if row['path'] == 'tests/union_subject.py':
                covered.update(range(row['line_start'], row['line_end'] + 1))
    for row in packet['required_source_ranges']:
        if row['path'] == 'tests/union_subject.py':
            covered.update(range(row['line_start'], row['line_end'] + 1))
            required.update(range(row['line_start'], row['line_end'] + 1))
    for row in [r for shard in packet['shards'] for r in shard['ranges']] + packet['required_source_ranges']:
        tree = row['blob_tree']
        assert tree in (manifest['snapshot_tree'], manifest['base_tree'])
        identity = git('ls-tree', tree, '--', row['path']).split()
        assert identity[:3] == [row['blob_mode'], 'blob', row['blob_oid']]
        assert row['blob_mode'] == '100644'
        raw = subprocess.check_output(['git', '-C', str(root), 'cat-file', 'blob', row['blob_oid']])
        source = raw.splitlines(keepends=True)
        first, last = row['line_start'], row['line_end']
        assert 1 <= first <= last <= len(source)
        expected = b''.join(source[first - 1:last])
        assert hashlib.sha256(expected).hexdigest() == row['content_sha256']
        identity_key = (tree, row['blob_oid'], row['blob_mode'], row['path'])
        spans = intervals.setdefault(identity_key, [])
        assert all(last < lo or first > hi for lo, hi in spans), 'duplicate mandatory coverage'
        spans.append((first, last))
        typed.update(identity_key + (line,) for line in range(first, last + 1))
        assert row['reasons'] and row['component_ids']
        assigned = set(manifest['assignments'][seat]['components'])
        assert set(row['component_ids']) <= assigned
        evidence = json.loads((session / ('r' + label + '-evidence.json')).read_text())
        owners = {item['id']: item for item in manifest['components']}
        hunk_binding = [
            {'component_id': cid,
             'hunk_sha256': sorted(hunk['sha256'] for path in owners[cid]['files']
                                   for hunk in evidence['hunks'] if hunk['path'] == path)}
            for cid in sorted(row['component_ids'])]
        encoded = (json.dumps(hunk_binding, sort_keys=True, ensure_ascii=True, indent=2) + '\n').encode()
        assert hashlib.sha256(encoded).hexdigest() == row['hunk_binding_sha256']
        if 'segments' in row:
            cursor = first
            rebuilt = b''
            for segment in row['segments']:
                assert segment['line_start'] == cursor
                assert cursor <= segment['line_end'] <= last
                assert segment['line_end'] - cursor + 1 <= 240
                part = (session / segment['artifact']).read_bytes()
                assert part == b''.join(source[cursor - 1:segment['line_end']])
                assert hashlib.sha256(part).hexdigest() == segment['content_sha256']
                rebuilt += part
                cursor = segment['line_end'] + 1
            assert cursor == last + 1 and rebuilt == expected
        else:
            payload = next(r for shard in packet['shards']
                           for r in json.loads((session / shard['artifact']).read_text())['entries']
                           if all(r[k] == row[k] for k in ('path', 'blob_tree', 'line_start', 'line_end')))
            assert payload['content'].encode() == expected
    # Only the shared current snapshot may credit this fixture's coverage.
    subject_rows = [r for shard in packet['shards'] for r in shard['ranges']] + packet['required_source_ranges']
    assert all(r['blob_tree'] == manifest['snapshot_tree'] for r in subject_rows
               if r['path'] == 'tests/union_subject.py')
    coverage[label + '_typed'] = sorted(typed)
    coverage[label] = sorted(covered)
    coverage[label + '_required'] = sorted(required)
assert set(range(230, 278)) <= set(coverage['union_required']), 'fixture lacks explicit ancestor mandatory interval'
assert not set(range(850, 866)) & set(coverage['union']), 'new interval already covered by ancestor'
assert set(range(850, 866)) <= set(coverage['unionx']), 'fixture lacks distinct current mandatory interval'
(session / 'union-coverage.json').write_text(json.dumps(coverage))
PYUNIONSETUP
    local status=$?
    assert_eq "union fixture prepares valid same-root identities and mandatory intervals" "$status" 0
    [ "$status" -eq 0 ] || return 0
    python3 - "$S/union-coverage.json" <<'PYUNIONOLD'
import json
import sys
coverage = json.load(open(sys.argv[1]))
sys.exit(0 if set(range(230, 278)) <= set(coverage['unionx']) else 1)
PYUNIONOLD
    status=$?
    assert_eq "missing-inherited-coverage: repair retains ancestor-required 230-277" "$status" 0
    [ "$status" -eq 0 ] || return 0
    python3 - "$S/union-coverage.json" <<'PYUNIONCURRENT'
import json
import sys
coverage = json.load(open(sys.argv[1]))
assert {tuple(point) for point in coverage['union_typed']} <= {tuple(point) for point in coverage['unionx_typed']}
assert set(range(17, 19)) | set(range(209, 279)) | set(range(850, 866)) <= set(coverage['unionx'])
PYUNIONCURRENT
    status=$?
    assert_eq "union retains full old proof and current mandatory 850-865" "$status" 0
    [ "$status" -eq 0 ] || return 0
    python3 - "$S/runionx-evidence.manifest.json" <<'PYUNIONSCHEMA'
import json
import sys
assert json.load(open(sys.argv[1]))['source_context']['schema_version'] == 4
PYUNIONSCHEMA
    assert_eq "union repair independently pins source-context schema four" "$?" 0
  )
}

test_unsplittable_source_line_stays_launchable() {
  ( local R="$T/wide-line-root" S="$T/wide-line-session"
    mkrepo "$R"; mkdir -p "$R/src" "$S"
    printf '%s\n' 'def wide():' '    return "base"' > "$R/src/lib.py"
    git -C "$R" add . && git -C "$R" commit -qm "wide line base"
    local base; base=$(git -C "$R" rev-parse HEAD)
    python3 - "$R/src/lib.py" <<'PY'
from pathlib import Path
import sys
Path(sys.argv[1]).write_text('def wide():\n    return "' + ('x' * 40000) + '"\n')
PY
    printf "REV_BASE='%s'\nREV_BRANCH='feature'\nREV_DEFAULT='main'\nREV_ROOT='%s'\nREV_SCOPE='branch'\n" \
      "$base" "$R" > "$S/scope.env"
    printf '%s\n' src/lib.py > "$S/files.txt"
    : > "$S/untracked.txt"
    printf '%s\n' '{"seats":[{"seat":"sol","adapter":"codex"},{"seat":"terra","adapter":"codex"},{"seat":"opus","adapter":"claude"},{"seat":"sonnet","adapter":"claude"}]}' > "$S/roster.json"
    REV_PATCH_CHUNKS=auto REV_SOURCE_CONTEXT=1 \
      python3 "$SCRIPTS/rev-evidence.py" prepare "$S" wide --phase discovery \
      > "$T/wide-line.out" 2> "$T/wide-line.err"
    local status=$?
    if [ "$status" -ne 0 ]; then
      echo "---- prepare stdout ----" >&2
      cat "$T/wide-line.out" >&2
      echo "---- prepare stderr ----" >&2
      cat "$T/wide-line.err" >&2
    fi
    assert_eq "an unsplittable source line does not abort preparation" "$status" 0
    [ "$status" -eq 0 ] || return 0
    assert_nogrep "the segment ceiling is not a prepare failure" \
      "$T/wide-line.err" 'required source line exceeds visible segment limit'
    python3 - "$S" <<'PY'
import json, sys
from pathlib import Path
session = Path(sys.argv[1])
manifest = json.loads((session / 'rwide-evidence.manifest.json').read_text())
packet = manifest['source_context']['seats']['sol']
assert packet['required_source_ranges'] == []
assert packet['omitted_source_ranges'] == []
assert packet['source_read_required'] is False
assert packet['omitted']['declaration'] >= 1
PY
    assert_eq "the unsplittable line is not a required source read" "$?" 0
    python3 "$SCRIPTS/rev-evidence.py" verify "$S/rwide-evidence.manifest.json" \
      > "$T/wide-line-verify.out" 2> "$T/wide-line-verify.err"
    assert_eq "verify accepts a panel that omitted an unsplittable line" "$?" 0
  )
}
